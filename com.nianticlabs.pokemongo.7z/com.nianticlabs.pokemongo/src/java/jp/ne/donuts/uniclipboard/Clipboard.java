/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ClipData
 *  android.content.ClipData$Item
 *  android.content.ClipDescription
 *  android.content.ClipboardManager
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.concurrent.Callable
 *  java.util.concurrent.FutureTask
 */
package jp.ne.donuts.uniclipboard;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import com.unity3d.player.UnityPlayer;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class Clipboard {
    public static String getText() {
        Object object = UnityPlayer.currentActivity;
        FutureTask futureTask = new FutureTask((Callable)new Callable<String>(object){
            final Activity val$activity;
            {
                this.val$activity = activity2;
            }

            public String call() throws Exception {
                ClipData clipData = ((ClipboardManager)this.val$activity.getSystemService("clipboard")).getPrimaryClip();
                if (clipData != null) {
                    return clipData.getItemAt(0).getText().toString();
                }
                return "";
            }
        });
        object.runOnUiThread((Runnable)futureTask);
        try {
            object = (String)futureTask.get();
            return object;
        }
        catch (Exception exception) {
            return "";
        }
    }

    public static void setText(String string2) {
        Activity activity2 = UnityPlayer.currentActivity;
        activity2.runOnUiThread(new Runnable(string2, activity2){
            final Activity val$activity;
            final String val$text;
            {
                this.val$text = string2;
                this.val$activity = activity2;
            }

            public void run() {
                ClipData.Item item = new ClipData.Item((CharSequence)this.val$text);
                item = new ClipData(new ClipDescription((CharSequence)"text_data", new String[]{"text/uri-list"}), item);
                ((ClipboardManager)this.val$activity.getSystemService("clipboard")).setPrimaryClip((ClipData)item);
            }
        });
    }
}

