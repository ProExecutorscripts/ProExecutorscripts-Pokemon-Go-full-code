/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

public final class CpuCollectionData {
    final double cpuUsagePercentage;
    final long timestampMillis;

    public CpuCollectionData(long l2, double d2) {
        this.timestampMillis = l2;
        this.cpuUsagePercentage = d2;
    }

    public double getCpuUsagePercentage() {
        return this.cpuUsagePercentage;
    }

    public long getTimestampMillis() {
        return this.timestampMillis;
    }
}

