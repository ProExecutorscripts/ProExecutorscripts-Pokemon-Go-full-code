/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.ISpan;
import io.sentry.Instrumenter;
import io.sentry.MeasurementUnit;
import io.sentry.SentryDate;
import io.sentry.SentryNanotimeDate;
import io.sentry.SentryTraceHeader;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.SentryId;
import java.util.List;

public final class NoOpSpan
implements ISpan {
    private static final NoOpSpan instance = new NoOpSpan();

    private NoOpSpan() {
    }

    public static NoOpSpan getInstance() {
        return instance;
    }

    @Override
    public void finish() {
    }

    @Override
    public void finish(SpanStatus spanStatus) {
    }

    @Override
    public void finish(SpanStatus spanStatus, SentryDate sentryDate) {
    }

    @Override
    public Object getData(String string2) {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public SentryDate getFinishDate() {
        return new SentryNanotimeDate();
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        return null;
    }

    @Override
    public String getOperation() {
        return "";
    }

    @Override
    public SpanContext getSpanContext() {
        return new SpanContext(SentryId.EMPTY_ID, SpanId.EMPTY_ID, "op", null, null);
    }

    @Override
    public SentryDate getStartDate() {
        return new SentryNanotimeDate();
    }

    @Override
    public SpanStatus getStatus() {
        return null;
    }

    @Override
    public String getTag(String string2) {
        return null;
    }

    @Override
    public Throwable getThrowable() {
        return null;
    }

    @Override
    public boolean isFinished() {
        return false;
    }

    @Override
    public boolean isNoOp() {
        return true;
    }

    @Override
    public void setData(String string2, Object object) {
    }

    @Override
    public void setDescription(String string2) {
    }

    @Override
    public void setMeasurement(String string2, Number number) {
    }

    @Override
    public void setMeasurement(String string2, Number number, MeasurementUnit measurementUnit) {
    }

    @Override
    public void setOperation(String string2) {
    }

    @Override
    public void setStatus(SpanStatus spanStatus) {
    }

    @Override
    public void setTag(String string2, String string3) {
    }

    @Override
    public void setThrowable(Throwable throwable) {
    }

    @Override
    public ISpan startChild(String string2) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SpanOptions spanOptions) {
        return NoOpSpan.getInstance();
    }

    @Override
    public BaggageHeader toBaggageHeader(List<String> list) {
        return null;
    }

    @Override
    public SentryTraceHeader toSentryTrace() {
        return new SentryTraceHeader(SentryId.EMPTY_ID, SpanId.EMPTY_ID, false);
    }

    @Override
    public TraceContext traceContext() {
        return new TraceContext(SentryId.EMPTY_ID, "");
    }

    @Override
    public boolean updateEndDate(SentryDate sentryDate) {
        return false;
    }
}

