/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.Thread
 */
package io.sentry;

import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.ShutdownHookIntegration$$ExternalSyntheticLambda0;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class ShutdownHookIntegration
implements Integration,
Closeable {
    private final Runtime runtime;
    private Thread thread;

    public ShutdownHookIntegration() {
        this(Runtime.getRuntime());
    }

    public ShutdownHookIntegration(Runtime runtime) {
        this.runtime = Objects.requireNonNull(runtime, "Runtime is required");
    }

    static /* synthetic */ void lambda$register$0(IHub iHub, SentryOptions sentryOptions) {
        iHub.flush(sentryOptions.getFlushTimeoutMillis());
    }

    public void close() throws IOException {
        block3: {
            Thread thread = this.thread;
            if (thread != null) {
                try {
                    this.runtime.removeShutdownHook(thread);
                }
                catch (IllegalStateException illegalStateException) {
                    String string2 = illegalStateException.getMessage();
                    if (string2 != null && string2.equals((Object)"Shutdown in progress")) break block3;
                    throw illegalStateException;
                }
            }
        }
    }

    Thread getHook() {
        return this.thread;
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        Objects.requireNonNull(iHub, "Hub is required");
        Objects.requireNonNull(sentryOptions, "SentryOptions is required");
        if (sentryOptions.isEnableShutdownHook()) {
            iHub = new Thread((Runnable)new ShutdownHookIntegration$$ExternalSyntheticLambda0(iHub, sentryOptions));
            this.thread = iHub;
            this.runtime.addShutdownHook((Thread)iHub);
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "ShutdownHookIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        } else {
            sentryOptions.getLogger().log(SentryLevel.INFO, "enableShutdownHook is disabled.", new Object[0]);
        }
    }
}

