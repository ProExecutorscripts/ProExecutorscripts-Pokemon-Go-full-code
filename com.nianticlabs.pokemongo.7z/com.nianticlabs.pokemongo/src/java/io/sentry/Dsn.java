/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URI
 */
package io.sentry;

import io.sentry.util.Objects;
import java.net.URI;

final class Dsn {
    private final String path;
    private final String projectId;
    private final String publicKey;
    private final String secretKey;
    private final URI sentryUri;

    /*
     * WARNING - combined exceptions agressively - possible behaviour change.
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Dsn(String object) throws IllegalArgumentException {
        try {
            Objects.requireNonNull(object, "The DSN is required.");
            URI uRI = new URI(object);
            URI uRI2 = uRI.normalize();
            String string2 = uRI2.getScheme();
            if (!"http".equalsIgnoreCase(string2) && !"https".equalsIgnoreCase(string2)) {
                StringBuilder stringBuilder = new StringBuilder("Invalid DSN scheme: ");
                IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.append(string2).toString());
                throw illegalArgumentException;
            }
            String string3 = uRI2.getUserInfo();
            if (string3 != null && !string3.isEmpty()) {
                String string4;
                String[] stringArray = string3.split(":", -1);
                this.publicKey = string4 = stringArray[0];
                if (string4 != null && !string4.isEmpty()) {
                    String string5;
                    void var1_12;
                    String string6;
                    void var3_22;
                    String string7;
                    void var1_7;
                    if (stringArray.length > 1) {
                        String string8 = stringArray[1];
                    } else {
                        Object var1_6 = null;
                    }
                    this.secretKey = var1_7;
                    String string9 = string7 = uRI2.getPath();
                    if (string7.endsWith("/")) {
                        String string10 = string7.substring(0, string7.length() - 1);
                    }
                    int n2 = var3_22.lastIndexOf("/") + 1;
                    String string11 = string6 = var3_22.substring(0, n2);
                    if (!string6.endsWith("/")) {
                        StringBuilder stringBuilder = new StringBuilder();
                        String string12 = stringBuilder.append(string6).append("/").toString();
                    }
                    this.path = var1_12;
                    this.projectId = string5 = var3_22.substring(n2);
                    if (!string5.isEmpty()) {
                        String string13 = uRI2.getHost();
                        n2 = uRI2.getPort();
                        super(string2, null, string13, n2, uRI2.append((String)var1_12).append("api/").append(string5).toString(), null, null);
                        this.sentryUri = string6;
                        return;
                    }
                    IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid DSN: A Project Id is required.");
                    throw illegalArgumentException;
                }
                IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid DSN: No public key provided.");
                throw illegalArgumentException;
            }
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Invalid DSN: No public key provided.");
            throw illegalArgumentException;
        }
        catch (Throwable throwable) {
            throw new IllegalArgumentException(throwable);
        }
    }

    public String getPath() {
        return this.path;
    }

    public String getProjectId() {
        return this.projectId;
    }

    public String getPublicKey() {
        return this.publicKey;
    }

    public String getSecretKey() {
        return this.secretKey;
    }

    URI getSentryUri() {
        return this.sentryUri;
    }
}

