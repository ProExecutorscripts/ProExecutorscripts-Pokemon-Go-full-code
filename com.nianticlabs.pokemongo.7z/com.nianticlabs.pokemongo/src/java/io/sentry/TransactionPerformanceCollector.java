/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package io.sentry;

import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PerformanceCollectionData;
import java.util.List;

public interface TransactionPerformanceCollector {
    public void close();

    public void onSpanFinished(ISpan var1);

    public void onSpanStarted(ISpan var1);

    public void start(ITransaction var1);

    public List<PerformanceCollectionData> stop(ITransaction var1);
}

