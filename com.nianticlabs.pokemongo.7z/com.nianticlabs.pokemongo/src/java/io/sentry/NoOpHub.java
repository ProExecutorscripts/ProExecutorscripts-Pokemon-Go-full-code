/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ISentryClient;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.NoOpScope;
import io.sentry.NoOpTransaction;
import io.sentry.ProfilingTraceData;
import io.sentry.ScopeCallback;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryTraceHeader;
import io.sentry.SpanId;
import io.sentry.TraceContext;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.UserFeedback;
import io.sentry.metrics.MetricsApi;
import io.sentry.metrics.NoopMetricsAggregator;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.transport.RateLimiter;
import java.util.List;

public final class NoOpHub
implements IHub {
    private static final NoOpHub instance = new NoOpHub();
    private final SentryOptions emptyOptions = SentryOptions.empty();
    private final MetricsApi metricsApi = new MetricsApi(NoopMetricsAggregator.getInstance());

    private NoOpHub() {
    }

    public static NoOpHub getInstance() {
        return instance;
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb, Hint hint) {
    }

    @Override
    public void bindClient(ISentryClient iSentryClient) {
    }

    @Override
    public SentryId captureCheckIn(CheckIn checkIn) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureEnvelope(SentryEnvelope sentryEnvelope, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint, ScopeCallback scopeCallback) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint, ScopeCallback scopeCallback) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel, ScopeCallback scopeCallback) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext, Hint hint, ProfilingTraceData profilingTraceData) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public void captureUserFeedback(UserFeedback userFeedback) {
    }

    @Override
    public void clearBreadcrumbs() {
    }

    @Override
    public IHub clone() {
        return instance;
    }

    @Override
    public void close() {
    }

    @Override
    public void close(boolean bl) {
    }

    @Override
    public void configureScope(ScopeCallback scopeCallback) {
    }

    @Override
    public TransactionContext continueTrace(String string2, List<String> list) {
        return null;
    }

    @Override
    public void endSession() {
    }

    @Override
    public void flush(long l2) {
    }

    @Override
    public BaggageHeader getBaggage() {
        return null;
    }

    @Override
    public SentryId getLastEventId() {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryOptions getOptions() {
        return this.emptyOptions;
    }

    @Override
    public RateLimiter getRateLimiter() {
        return null;
    }

    @Override
    public ISpan getSpan() {
        return null;
    }

    @Override
    public SentryTraceHeader getTraceparent() {
        return null;
    }

    @Override
    public ITransaction getTransaction() {
        return null;
    }

    @Override
    public Boolean isCrashedLastRun() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    @Override
    public boolean isHealthy() {
        return true;
    }

    @Override
    public MetricsApi metrics() {
        return this.metricsApi;
    }

    @Override
    public void popScope() {
    }

    @Override
    public void pushScope() {
    }

    @Override
    public void removeExtra(String string2) {
    }

    @Override
    public void removeTag(String string2) {
    }

    @Override
    public void reportFullyDisplayed() {
    }

    @Override
    public void setExtra(String string2, String string3) {
    }

    @Override
    public void setFingerprint(List<String> list) {
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
    }

    @Override
    public void setSpanContext(Throwable throwable, ISpan iSpan, String string2) {
    }

    @Override
    public void setTag(String string2, String string3) {
    }

    @Override
    public void setTransaction(String string2) {
    }

    @Override
    public void setUser(User user) {
    }

    @Override
    public void startSession() {
    }

    @Override
    public ITransaction startTransaction(TransactionContext transactionContext, TransactionOptions transactionOptions) {
        return NoOpTransaction.getInstance();
    }

    @Override
    @Deprecated
    public SentryTraceHeader traceHeaders() {
        return new SentryTraceHeader(SentryId.EMPTY_ID, SpanId.EMPTY_ID, true);
    }

    @Override
    public void withScope(ScopeCallback scopeCallback) {
        scopeCallback.run(NoOpScope.getInstance());
    }
}

