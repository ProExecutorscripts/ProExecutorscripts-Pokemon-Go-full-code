/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry;

import io.sentry.SentryEnvelope;
import io.sentry.SpotlightIntegration;

public final class SpotlightIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final SpotlightIntegration f$0;
    public final SentryEnvelope f$1;

    public /* synthetic */ SpotlightIntegration$$ExternalSyntheticLambda0(SpotlightIntegration spotlightIntegration, SentryEnvelope sentryEnvelope) {
        this.f$0 = spotlightIntegration;
        this.f$1 = sentryEnvelope;
    }

    public final void run() {
        this.f$0.lambda$execute$0$io-sentry-SpotlightIntegration(this.f$1);
    }
}

