/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.JsonObjectDeserializer;
import io.sentry.JsonObjectReader;

public final class JsonObjectDeserializer$$ExternalSyntheticLambda2
implements JsonObjectDeserializer.NextValue {
    public final JsonObjectReader f$0;

    public /* synthetic */ JsonObjectDeserializer$$ExternalSyntheticLambda2(JsonObjectReader jsonObjectReader) {
        this.f$0 = jsonObjectReader;
    }

    @Override
    public final Object nextValue() {
        return JsonObjectDeserializer.lambda$parse$2(this.f$0);
    }
}

