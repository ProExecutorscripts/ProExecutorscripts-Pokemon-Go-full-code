/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.Locale
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import java.io.IOException;
import java.util.Locale;

public enum SentryLevel implements JsonSerializable
{
    DEBUG,
    INFO,
    WARNING,
    ERROR,
    FATAL;


    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.value(this.name().toLowerCase(Locale.ROOT));
    }

    static final class Deserializer
    implements JsonDeserializer<SentryLevel> {
        Deserializer() {
        }

        @Override
        public SentryLevel deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            return SentryLevel.valueOf(jsonObjectReader.nextString().toUpperCase(Locale.ROOT));
        }
    }
}

