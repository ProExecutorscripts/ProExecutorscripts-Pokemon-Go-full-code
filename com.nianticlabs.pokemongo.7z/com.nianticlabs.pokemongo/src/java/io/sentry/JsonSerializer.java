/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedOutputStream
 *  java.io.BufferedWriter
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.Breadcrumb;
import io.sentry.ISerializer;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectWriter;
import io.sentry.ObjectWriter;
import io.sentry.ProfilingTraceData;
import io.sentry.ProfilingTransactionData;
import io.sentry.SentryAppStartProfilingOptions;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeHeader;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryEnvelopeItemHeader;
import io.sentry.SentryEvent;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.SentryLockReason;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.SpanStatus;
import io.sentry.UserFeedback;
import io.sentry.clientreport.ClientReport;
import io.sentry.profilemeasurements.ProfileMeasurement;
import io.sentry.profilemeasurements.ProfileMeasurementValue;
import io.sentry.protocol.App;
import io.sentry.protocol.Browser;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.DebugImage;
import io.sentry.protocol.DebugMeta;
import io.sentry.protocol.Device;
import io.sentry.protocol.Geo;
import io.sentry.protocol.Gpu;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.Mechanism;
import io.sentry.protocol.Message;
import io.sentry.protocol.MetricSummary;
import io.sentry.protocol.OperatingSystem;
import io.sentry.protocol.Request;
import io.sentry.protocol.SdkInfo;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryException;
import io.sentry.protocol.SentryPackage;
import io.sentry.protocol.SentryRuntime;
import io.sentry.protocol.SentrySpan;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.protocol.ViewHierarchy;
import io.sentry.protocol.ViewHierarchyNode;
import io.sentry.util.Objects;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public final class JsonSerializer
implements ISerializer {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private final Map<Class<?>, JsonDeserializer<?>> deserializersByClass;
    private final SentryOptions options;

    public JsonSerializer(SentryOptions sentryOptions) {
        this.options = sentryOptions;
        sentryOptions = new HashMap();
        this.deserializersByClass = sentryOptions;
        sentryOptions.put(App.class, new App.Deserializer());
        sentryOptions.put(Breadcrumb.class, new Breadcrumb.Deserializer());
        sentryOptions.put(Browser.class, new Browser.Deserializer());
        sentryOptions.put(Contexts.class, new Contexts.Deserializer());
        sentryOptions.put(DebugImage.class, new DebugImage.Deserializer());
        sentryOptions.put(DebugMeta.class, new DebugMeta.Deserializer());
        sentryOptions.put(Device.class, new Device.Deserializer());
        sentryOptions.put(Device.DeviceOrientation.class, new Device.DeviceOrientation.Deserializer());
        sentryOptions.put(Gpu.class, new Gpu.Deserializer());
        sentryOptions.put(MeasurementValue.class, new MeasurementValue.Deserializer());
        sentryOptions.put(Mechanism.class, new Mechanism.Deserializer());
        sentryOptions.put(Message.class, new Message.Deserializer());
        sentryOptions.put(MetricSummary.class, new MetricSummary.Deserializer());
        sentryOptions.put(OperatingSystem.class, new OperatingSystem.Deserializer());
        sentryOptions.put(ProfilingTraceData.class, new ProfilingTraceData.Deserializer());
        sentryOptions.put(ProfilingTransactionData.class, new ProfilingTransactionData.Deserializer());
        sentryOptions.put(ProfileMeasurement.class, new ProfileMeasurement.Deserializer());
        sentryOptions.put(ProfileMeasurementValue.class, new ProfileMeasurementValue.Deserializer());
        sentryOptions.put(Request.class, new Request.Deserializer());
        sentryOptions.put(SdkInfo.class, new SdkInfo.Deserializer());
        sentryOptions.put(SdkVersion.class, new SdkVersion.Deserializer());
        sentryOptions.put(SentryEnvelopeHeader.class, new SentryEnvelopeHeader.Deserializer());
        sentryOptions.put(SentryEnvelopeItemHeader.class, new SentryEnvelopeItemHeader.Deserializer());
        sentryOptions.put(SentryEvent.class, new SentryEvent.Deserializer());
        sentryOptions.put(SentryException.class, new SentryException.Deserializer());
        sentryOptions.put(SentryItemType.class, new SentryItemType.Deserializer());
        sentryOptions.put(SentryLevel.class, new SentryLevel.Deserializer());
        sentryOptions.put(SentryLockReason.class, new SentryLockReason.Deserializer());
        sentryOptions.put(SentryPackage.class, new SentryPackage.Deserializer());
        sentryOptions.put(SentryRuntime.class, new SentryRuntime.Deserializer());
        sentryOptions.put(SentrySpan.class, new SentrySpan.Deserializer());
        sentryOptions.put(SentryStackFrame.class, new SentryStackFrame.Deserializer());
        sentryOptions.put(SentryStackTrace.class, new SentryStackTrace.Deserializer());
        sentryOptions.put(SentryAppStartProfilingOptions.class, new SentryAppStartProfilingOptions.Deserializer());
        sentryOptions.put(SentryThread.class, new SentryThread.Deserializer());
        sentryOptions.put(SentryTransaction.class, new SentryTransaction.Deserializer());
        sentryOptions.put(Session.class, new Session.Deserializer());
        sentryOptions.put(SpanContext.class, new SpanContext.Deserializer());
        sentryOptions.put(SpanId.class, new SpanId.Deserializer());
        sentryOptions.put(SpanStatus.class, new SpanStatus.Deserializer());
        sentryOptions.put(User.class, new User.Deserializer());
        sentryOptions.put(Geo.class, new Geo.Deserializer());
        sentryOptions.put(UserFeedback.class, new UserFeedback.Deserializer());
        sentryOptions.put(ClientReport.class, new ClientReport.Deserializer());
        sentryOptions.put(ViewHierarchyNode.class, new ViewHierarchyNode.Deserializer());
        sentryOptions.put(ViewHierarchy.class, new ViewHierarchy.Deserializer());
    }

    private <T> boolean isKnownPrimitive(Class<T> clazz) {
        boolean bl = clazz.isArray() || Collection.class.isAssignableFrom(clazz) || String.class.isAssignableFrom(clazz) || Map.class.isAssignableFrom(clazz);
        return bl;
    }

    private String serializeToString(Object object, boolean bl) throws IOException {
        StringWriter stringWriter = new StringWriter();
        JsonObjectWriter jsonObjectWriter = new JsonObjectWriter((Writer)stringWriter, this.options.getMaxDepth());
        if (bl) {
            jsonObjectWriter.setIndent("\t");
        }
        jsonObjectWriter.value(this.options.getLogger(), object);
        return stringWriter.toString();
    }

    /*
     * Exception decompiling
     */
    @Override
    public <T> T deserialize(Reader var1_1, Class<T> var2_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    @Override
    public <T, R> T deserializeCollection(Reader var1_1, Class<T> var2_4, JsonDeserializer<R> var3_6) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public SentryEnvelope deserializeEnvelope(InputStream object) {
        Objects.requireNonNull(object, "The InputStream object is required.");
        try {
            object = this.options.getEnvelopeReader().read((InputStream)object);
            return object;
        }
        catch (IOException iOException) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error deserializing envelope.", iOException);
            return null;
        }
    }

    @Override
    public String serialize(Map<String, Object> map2) throws Exception {
        return this.serializeToString(map2, false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void serialize(SentryEnvelope sentryEnvelope, OutputStream outputStream) throws Exception {
        Objects.requireNonNull(sentryEnvelope, "The SentryEnvelope object is required.");
        Objects.requireNonNull(outputStream, "The Stream object is required.");
        BufferedWriter bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new BufferedOutputStream(outputStream), UTF_8));
        try {
            Object object = sentryEnvelope.getHeader();
            Object object2222 = new JsonObjectWriter((Writer)bufferedWriter, this.options.getMaxDepth());
            ((SentryEnvelopeHeader)object).serialize((ObjectWriter)object2222, this.options.getLogger());
            bufferedWriter.write("\n");
            for (Object object2222 : sentryEnvelope.getItems()) {
                try {
                    object = ((SentryEnvelopeItem)object2222).getData();
                    SentryEnvelopeItemHeader sentryEnvelopeItemHeader = ((SentryEnvelopeItem)object2222).getHeader();
                    object2222 = new JsonObjectWriter((Writer)bufferedWriter, this.options.getMaxDepth());
                    sentryEnvelopeItemHeader.serialize((ObjectWriter)object2222, this.options.getLogger());
                    bufferedWriter.write("\n");
                    bufferedWriter.flush();
                    outputStream.write((byte[])object);
                    bufferedWriter.write("\n");
                }
                catch (Exception exception) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Failed to create envelope item. Dropping it.", exception);
                }
            }
            return;
        }
        finally {
            bufferedWriter.flush();
        }
    }

    @Override
    public <T> void serialize(T t2, Writer writer) throws IOException {
        Objects.requireNonNull(t2, "The entity is required.");
        Objects.requireNonNull(writer, "The Writer object is required.");
        if (this.options.getLogger().isEnabled(SentryLevel.DEBUG)) {
            String string2 = this.serializeToString(t2, this.options.isEnablePrettySerializationOutput());
            this.options.getLogger().log(SentryLevel.DEBUG, "Serializing object: %s", string2);
        }
        new JsonObjectWriter(writer, this.options.getMaxDepth()).value(this.options.getLogger(), t2);
        writer.flush();
    }
}

