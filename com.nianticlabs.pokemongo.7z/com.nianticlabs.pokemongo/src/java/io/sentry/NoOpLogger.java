/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.SentryLevel;

public final class NoOpLogger
implements ILogger {
    private static final NoOpLogger instance = new NoOpLogger();

    private NoOpLogger() {
    }

    public static NoOpLogger getInstance() {
        return instance;
    }

    @Override
    public boolean isEnabled(SentryLevel sentryLevel) {
        return false;
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Throwable throwable) {
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Object ... objectArray) {
    }

    @Override
    public void log(SentryLevel sentryLevel, Throwable throwable, String string2, Object ... objectArray) {
    }
}

