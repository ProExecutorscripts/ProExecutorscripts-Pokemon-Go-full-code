/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.Hub;
import io.sentry.IScope;
import io.sentry.ScopeCallback;

public final class Hub$$ExternalSyntheticLambda2
implements ScopeCallback {
    @Override
    public final void run(IScope iScope) {
        Hub.lambda$close$0(iScope);
    }
}

