/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.Hub;
import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.ScopeCallback;

public final class Hub$$ExternalSyntheticLambda1
implements ScopeCallback {
    public final ITransaction f$0;

    public /* synthetic */ Hub$$ExternalSyntheticLambda1(ITransaction iTransaction) {
        this.f$0 = iTransaction;
    }

    @Override
    public final void run(IScope iScope) {
        Hub.lambda$createTransaction$2(this.f$0, iScope);
    }
}

