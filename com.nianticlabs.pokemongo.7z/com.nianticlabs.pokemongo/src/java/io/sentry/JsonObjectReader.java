/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.TimeZone
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectDeserializer;
import io.sentry.SentryLevel;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public final class JsonObjectReader
extends JsonReader {
    public JsonObjectReader(Reader reader) {
        super(reader);
    }

    public static Date dateOrNull(String string2, ILogger iLogger) {
        if (string2 == null) {
            return null;
        }
        try {
            Date date = DateUtils.getDateTime(string2);
            return date;
        }
        catch (Exception exception) {
            try {
                string2 = DateUtils.getDateTimeWithMillisPrecision(string2);
                return string2;
            }
            catch (Exception exception2) {
                iLogger.log(SentryLevel.ERROR, "Error when deserializing millis timestamp format.", exception2);
                return null;
            }
        }
    }

    public Boolean nextBooleanOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextBoolean();
    }

    public Date nextDateOrNull(ILogger iLogger) throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return JsonObjectReader.dateOrNull(this.nextString(), iLogger);
    }

    public Double nextDoubleOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextDouble();
    }

    public Float nextFloat() throws IOException {
        return Float.valueOf((float)((float)this.nextDouble()));
    }

    public Float nextFloatOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextFloat();
    }

    public Integer nextIntegerOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextInt();
    }

    public <T> List<T> nextListOrNull(ILogger iLogger, JsonDeserializer<T> jsonDeserializer) throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        this.beginArray();
        ArrayList arrayList = new ArrayList();
        if (this.hasNext()) {
            do {
                try {
                    arrayList.add(jsonDeserializer.deserialize(this, iLogger));
                }
                catch (Exception exception) {
                    iLogger.log(SentryLevel.WARNING, "Failed to deserialize object in list.", exception);
                }
            } while (this.peek() == JsonToken.BEGIN_OBJECT);
        }
        this.endArray();
        return arrayList;
    }

    public Long nextLongOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextLong();
    }

    public <T> Map<String, List<T>> nextMapOfListOrNull(ILogger iLogger, JsonDeserializer<T> jsonDeserializer) throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        HashMap hashMap = new HashMap();
        this.beginObject();
        if (this.hasNext()) {
            do {
                String string2 = this.nextName();
                List<T> list = this.nextListOrNull(iLogger, jsonDeserializer);
                if (list == null) continue;
                hashMap.put((Object)string2, list);
            } while (this.peek() == JsonToken.BEGIN_OBJECT || this.peek() == JsonToken.NAME);
        }
        this.endObject();
        return hashMap;
    }

    public <T> Map<String, T> nextMapOrNull(ILogger iLogger, JsonDeserializer<T> jsonDeserializer) throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        this.beginObject();
        HashMap hashMap = new HashMap();
        if (this.hasNext()) {
            do {
                try {
                    hashMap.put((Object)this.nextName(), jsonDeserializer.deserialize(this, iLogger));
                }
                catch (Exception exception) {
                    iLogger.log(SentryLevel.WARNING, "Failed to deserialize object in map.", exception);
                }
            } while (this.peek() == JsonToken.BEGIN_OBJECT || this.peek() == JsonToken.NAME);
        }
        this.endObject();
        return hashMap;
    }

    public Object nextObjectOrNull() throws IOException {
        return new JsonObjectDeserializer().deserialize(this);
    }

    public <T> T nextOrNull(ILogger iLogger, JsonDeserializer<T> jsonDeserializer) throws Exception {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return jsonDeserializer.deserialize(this, iLogger);
    }

    public String nextStringOrNull() throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        return this.nextString();
    }

    public TimeZone nextTimeZoneOrNull(ILogger iLogger) throws IOException {
        if (this.peek() == JsonToken.NULL) {
            this.nextNull();
            return null;
        }
        try {
            TimeZone timeZone = TimeZone.getTimeZone((String)this.nextString());
            return timeZone;
        }
        catch (Exception exception) {
            iLogger.log(SentryLevel.ERROR, "Error when deserializing TimeZone", exception);
            return null;
        }
    }

    public void nextUnknown(ILogger iLogger, Map<String, Object> map2, String string2) {
        try {
            map2.put((Object)string2, this.nextObjectOrNull());
        }
        catch (Exception exception) {
            iLogger.log(SentryLevel.ERROR, exception, "Error deserializing unknown key: %s", string2);
        }
    }
}

