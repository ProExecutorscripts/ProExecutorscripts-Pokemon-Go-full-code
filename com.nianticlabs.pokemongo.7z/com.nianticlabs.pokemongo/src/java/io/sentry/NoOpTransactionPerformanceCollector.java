/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.List
 */
package io.sentry;

import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PerformanceCollectionData;
import io.sentry.TransactionPerformanceCollector;
import java.util.List;

public final class NoOpTransactionPerformanceCollector
implements TransactionPerformanceCollector {
    private static final NoOpTransactionPerformanceCollector instance = new NoOpTransactionPerformanceCollector();

    private NoOpTransactionPerformanceCollector() {
    }

    public static NoOpTransactionPerformanceCollector getInstance() {
        return instance;
    }

    @Override
    public void close() {
    }

    @Override
    public void onSpanFinished(ISpan iSpan) {
    }

    @Override
    public void onSpanStarted(ISpan iSpan) {
    }

    @Override
    public void start(ITransaction iTransaction) {
    }

    @Override
    public List<PerformanceCollectionData> stop(ITransaction iTransaction) {
        return null;
    }
}

