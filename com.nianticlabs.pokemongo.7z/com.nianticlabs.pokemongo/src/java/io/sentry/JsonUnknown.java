/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry;

import java.util.Map;

public interface JsonUnknown {
    public Map<String, Object> getUnknown();

    public void setUnknown(Map<String, Object> var1);
}

