/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.JsonObjectDeserializer;
import io.sentry.JsonObjectReader;

public final class JsonObjectDeserializer$$ExternalSyntheticLambda1
implements JsonObjectDeserializer.NextValue {
    public final JsonObjectDeserializer f$0;
    public final JsonObjectReader f$1;

    public /* synthetic */ JsonObjectDeserializer$$ExternalSyntheticLambda1(JsonObjectDeserializer jsonObjectDeserializer, JsonObjectReader jsonObjectReader) {
        this.f$0 = jsonObjectDeserializer;
        this.f$1 = jsonObjectReader;
    }

    @Override
    public final Object nextValue() {
        return this.f$0.lambda$parse$1$io-sentry-JsonObjectDeserializer(this.f$1);
    }
}

