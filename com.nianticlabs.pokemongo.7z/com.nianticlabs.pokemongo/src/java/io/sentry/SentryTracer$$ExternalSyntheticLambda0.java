/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.SentryTracer;

public final class SentryTracer$$ExternalSyntheticLambda0
implements ScopeCallback {
    public final SentryTracer f$0;

    public /* synthetic */ SentryTracer$$ExternalSyntheticLambda0(SentryTracer sentryTracer) {
        this.f$0 = sentryTracer;
    }

    @Override
    public final void run(IScope iScope) {
        this.f$0.lambda$finish$1$io-sentry-SentryTracer(iScope);
    }
}

