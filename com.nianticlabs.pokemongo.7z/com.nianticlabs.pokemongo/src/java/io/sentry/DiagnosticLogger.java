/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.util.Objects;

public final class DiagnosticLogger
implements ILogger {
    private final ILogger logger;
    private final SentryOptions options;

    public DiagnosticLogger(SentryOptions sentryOptions, ILogger iLogger) {
        this.options = Objects.requireNonNull(sentryOptions, "SentryOptions is required.");
        this.logger = iLogger;
    }

    public ILogger getLogger() {
        return this.logger;
    }

    @Override
    public boolean isEnabled(SentryLevel sentryLevel) {
        SentryLevel sentryLevel2 = this.options.getDiagnosticLevel();
        boolean bl = false;
        if (sentryLevel == null) {
            return false;
        }
        boolean bl2 = bl;
        if (this.options.isDebug()) {
            bl2 = bl;
            if (sentryLevel.ordinal() >= sentryLevel2.ordinal()) {
                bl2 = true;
            }
        }
        return bl2;
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Throwable throwable) {
        if (this.logger != null && this.isEnabled(sentryLevel)) {
            this.logger.log(sentryLevel, string2, throwable);
        }
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Object ... objectArray) {
        if (this.logger != null && this.isEnabled(sentryLevel)) {
            this.logger.log(sentryLevel, string2, objectArray);
        }
    }

    @Override
    public void log(SentryLevel sentryLevel, Throwable throwable, String string2, Object ... objectArray) {
        if (this.logger != null && this.isEnabled(sentryLevel)) {
            this.logger.log(sentryLevel, throwable, string2, objectArray);
        }
    }
}

