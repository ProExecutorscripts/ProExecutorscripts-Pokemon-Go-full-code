/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Locale
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.SentryEvent;
import io.sentry.Session;
import io.sentry.clientreport.ClientReport;
import io.sentry.protocol.SentryTransaction;
import java.io.IOException;
import java.util.Locale;

public enum SentryItemType implements JsonSerializable
{
    Session("session"),
    Event("event"),
    UserFeedback("user_report"),
    Attachment("attachment"),
    Transaction("transaction"),
    Profile("profile"),
    ClientReport("client_report"),
    ReplayEvent("replay_event"),
    ReplayRecording("replay_recording"),
    CheckIn("check_in"),
    Statsd("statsd"),
    Unknown("__unknown__");

    private final String itemType;

    private SentryItemType(String string3) {
        this.itemType = string3;
    }

    public static SentryItemType resolve(Object object) {
        if (object instanceof SentryEvent) {
            return Event;
        }
        if (object instanceof SentryTransaction) {
            return Transaction;
        }
        if (object instanceof Session) {
            return Session;
        }
        if (object instanceof ClientReport) {
            return ClientReport;
        }
        return Attachment;
    }

    public static SentryItemType valueOfLabel(String string2) {
        for (SentryItemType sentryItemType : SentryItemType.values()) {
            if (!sentryItemType.itemType.equals((Object)string2)) continue;
            return sentryItemType;
        }
        return Unknown;
    }

    public String getItemType() {
        return this.itemType;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.value(this.itemType);
    }

    static final class Deserializer
    implements JsonDeserializer<SentryItemType> {
        Deserializer() {
        }

        @Override
        public SentryItemType deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            return SentryItemType.valueOfLabel(jsonObjectReader.nextString().toLowerCase(Locale.ROOT));
        }
    }
}

