/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Void
 *  java.net.InetAddress
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.TimeoutException
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry;

import io.sentry.HostnameCache$$ExternalSyntheticLambda0;
import io.sentry.HostnameCache$$ExternalSyntheticLambda1;
import io.sentry.util.Objects;
import java.net.InetAddress;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class HostnameCache {
    private static final long GET_HOSTNAME_TIMEOUT;
    private static final long HOSTNAME_CACHE_DURATION;
    private static HostnameCache INSTANCE;
    private final long cacheDuration;
    private final ExecutorService executorService;
    private volatile long expirationTimestamp;
    private final Callable<InetAddress> getLocalhost;
    private volatile String hostname;
    private final AtomicBoolean updateRunning = new AtomicBoolean(false);

    static {
        HOSTNAME_CACHE_DURATION = TimeUnit.HOURS.toMillis(5L);
        GET_HOSTNAME_TIMEOUT = TimeUnit.SECONDS.toMillis(1L);
    }

    private HostnameCache() {
        this(HOSTNAME_CACHE_DURATION);
    }

    HostnameCache(long l2) {
        this(l2, new HostnameCache$$ExternalSyntheticLambda0());
    }

    HostnameCache(long l2, Callable<InetAddress> callable) {
        this.executorService = Executors.newSingleThreadExecutor((ThreadFactory)new HostnameCacheThreadFactory());
        this.cacheDuration = l2;
        this.getLocalhost = Objects.requireNonNull(callable, "getLocalhost is required");
        this.updateCache();
    }

    static HostnameCache getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HostnameCache();
        }
        return INSTANCE;
    }

    private void handleCacheUpdateFailure() {
        this.expirationTimestamp = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(1L);
    }

    static /* synthetic */ InetAddress lambda$new$0() throws Exception {
        return InetAddress.getLocalHost();
    }

    private void updateCache() {
        HostnameCache$$ExternalSyntheticLambda1 hostnameCache$$ExternalSyntheticLambda1 = new HostnameCache$$ExternalSyntheticLambda1(this);
        try {
            this.executorService.submit((Callable)hostnameCache$$ExternalSyntheticLambda1).get(GET_HOSTNAME_TIMEOUT, TimeUnit.MILLISECONDS);
        }
        catch (RuntimeException | ExecutionException | TimeoutException throwable) {
            this.handleCacheUpdateFailure();
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            this.handleCacheUpdateFailure();
        }
    }

    void close() {
        this.executorService.shutdown();
    }

    String getHostname() {
        if (this.expirationTimestamp < System.currentTimeMillis() && this.updateRunning.compareAndSet(false, true)) {
            this.updateCache();
        }
        return this.hostname;
    }

    boolean isClosed() {
        return this.executorService.isShutdown();
    }

    /* synthetic */ Void lambda$updateCache$1$io-sentry-HostnameCache() throws Exception {
        try {
            this.hostname = ((InetAddress)this.getLocalhost.call()).getCanonicalHostName();
            this.expirationTimestamp = System.currentTimeMillis() + this.cacheDuration;
            return null;
        }
        finally {
            this.updateRunning.set(false);
        }
    }

    private static final class HostnameCacheThreadFactory
    implements ThreadFactory {
        private int cnt;

        private HostnameCacheThreadFactory() {
        }

        public Thread newThread(Runnable runnable) {
            StringBuilder stringBuilder = new StringBuilder("SentryHostnameCache-");
            int n2 = this.cnt;
            this.cnt = n2 + 1;
            runnable = new Thread(runnable, stringBuilder.append(n2).toString());
            runnable.setDaemon(true);
            return runnable;
        }
    }
}

