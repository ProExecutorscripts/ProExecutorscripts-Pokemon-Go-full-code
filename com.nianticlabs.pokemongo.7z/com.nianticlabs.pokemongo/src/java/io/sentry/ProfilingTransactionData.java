/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.ITransaction;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.NoOpTransaction;
import io.sentry.ObjectWriter;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ProfilingTransactionData
implements JsonUnknown,
JsonSerializable {
    private String id;
    private String name;
    private Long relativeEndCpuMs;
    private Long relativeEndNs;
    private Long relativeStartCpuMs;
    private Long relativeStartNs;
    private String traceId;
    private Map<String, Object> unknown;

    public ProfilingTransactionData() {
        NoOpTransaction noOpTransaction = NoOpTransaction.getInstance();
        Long l2 = 0L;
        this(noOpTransaction, l2, l2);
    }

    public ProfilingTransactionData(ITransaction iTransaction, Long l2, Long l3) {
        this.id = iTransaction.getEventId().toString();
        this.traceId = iTransaction.getSpanContext().getTraceId().toString();
        this.name = iTransaction.getName();
        this.relativeStartNs = l2;
        this.relativeStartCpuMs = l3;
    }

    static /* synthetic */ String access$002(ProfilingTransactionData profilingTransactionData, String string2) {
        profilingTransactionData.id = string2;
        return string2;
    }

    static /* synthetic */ String access$102(ProfilingTransactionData profilingTransactionData, String string2) {
        profilingTransactionData.traceId = string2;
        return string2;
    }

    static /* synthetic */ String access$202(ProfilingTransactionData profilingTransactionData, String string2) {
        profilingTransactionData.name = string2;
        return string2;
    }

    static /* synthetic */ Long access$302(ProfilingTransactionData profilingTransactionData, Long l2) {
        profilingTransactionData.relativeStartNs = l2;
        return l2;
    }

    static /* synthetic */ Long access$402(ProfilingTransactionData profilingTransactionData, Long l2) {
        profilingTransactionData.relativeEndNs = l2;
        return l2;
    }

    static /* synthetic */ Long access$502(ProfilingTransactionData profilingTransactionData, Long l2) {
        profilingTransactionData.relativeStartCpuMs = l2;
        return l2;
    }

    static /* synthetic */ Long access$602(ProfilingTransactionData profilingTransactionData, Long l2) {
        profilingTransactionData.relativeEndCpuMs = l2;
        return l2;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (ProfilingTransactionData)object;
            if (!(this.id.equals((Object)((ProfilingTransactionData)object).id) && this.traceId.equals((Object)((ProfilingTransactionData)object).traceId) && this.name.equals((Object)((ProfilingTransactionData)object).name) && this.relativeStartNs.equals((Object)((ProfilingTransactionData)object).relativeStartNs) && this.relativeStartCpuMs.equals((Object)((ProfilingTransactionData)object).relativeStartCpuMs) && Objects.equals(this.relativeEndCpuMs, ((ProfilingTransactionData)object).relativeEndCpuMs) && Objects.equals(this.relativeEndNs, ((ProfilingTransactionData)object).relativeEndNs) && Objects.equals(this.unknown, ((ProfilingTransactionData)object).unknown))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public Long getRelativeEndCpuMs() {
        return this.relativeEndCpuMs;
    }

    public Long getRelativeEndNs() {
        return this.relativeEndNs;
    }

    public Long getRelativeStartCpuMs() {
        return this.relativeStartCpuMs;
    }

    public Long getRelativeStartNs() {
        return this.relativeStartNs;
    }

    public String getTraceId() {
        return this.traceId;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public int hashCode() {
        return Objects.hash(this.id, this.traceId, this.name, this.relativeStartNs, this.relativeEndNs, this.relativeStartCpuMs, this.relativeEndCpuMs, this.unknown);
    }

    public void notifyFinish(Long l2, Long l3, Long l4, Long l5) {
        if (this.relativeEndNs == null) {
            this.relativeEndNs = l2 - l3;
            this.relativeStartNs = this.relativeStartNs - l3;
            this.relativeEndCpuMs = l4 - l5;
            this.relativeStartCpuMs = this.relativeStartCpuMs - l5;
        }
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("id").value(iLogger, this.id);
        objectWriter.name("trace_id").value(iLogger, this.traceId);
        objectWriter.name("name").value(iLogger, this.name);
        objectWriter.name("relative_start_ns").value(iLogger, this.relativeStartNs);
        objectWriter.name("relative_end_ns").value(iLogger, this.relativeEndNs);
        objectWriter.name("relative_cpu_start_ms").value(iLogger, this.relativeStartCpuMs);
        objectWriter.name("relative_cpu_end_ms").value(iLogger, this.relativeEndCpuMs);
        Object object = this.unknown;
        if (object != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setRelativeEndNs(Long l2) {
        this.relativeEndNs = l2;
    }

    public void setRelativeStartNs(Long l2) {
        this.relativeStartNs = l2;
    }

    public void setTraceId(String string2) {
        this.traceId = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<ProfilingTransactionData> {
        @Override
        public ProfilingTransactionData deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            ProfilingTransactionData profilingTransactionData = new ProfilingTransactionData();
            Long l2 = null;
            block18: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Object object;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1902256621: {
                        if (!string2.equals((Object)"relative_cpu_start_ms")) break;
                        n3 = 6;
                        break;
                    }
                    case 1566648660: {
                        if (!string2.equals((Object)"relative_cpu_end_ms")) break;
                        n3 = 5;
                        break;
                    }
                    case 1270300245: {
                        if (!string2.equals((Object)"trace_id")) break;
                        n3 = 4;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 3;
                        break;
                    }
                    case 3355: {
                        if (!string2.equals((Object)"id")) break;
                        n3 = 2;
                        break;
                    }
                    case -84607876: {
                        if (!string2.equals((Object)"relative_end_ns")) break;
                        n3 = 1;
                        break;
                    }
                    case -112372011: {
                        if (!string2.equals((Object)"relative_start_ns")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        object = l2;
                        if (l2 == null) {
                            object = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)object, string2);
                        l2 = object;
                        continue block18;
                    }
                    case 6: {
                        object = jsonObjectReader.nextLongOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$502(profilingTransactionData, object);
                        continue block18;
                    }
                    case 5: {
                        object = jsonObjectReader.nextLongOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$602(profilingTransactionData, object);
                        continue block18;
                    }
                    case 4: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$102(profilingTransactionData, (String)object);
                        continue block18;
                    }
                    case 3: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$202(profilingTransactionData, (String)object);
                        continue block18;
                    }
                    case 2: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$002(profilingTransactionData, (String)object);
                        continue block18;
                    }
                    case 1: {
                        object = jsonObjectReader.nextLongOrNull();
                        if (object == null) continue block18;
                        ProfilingTransactionData.access$402(profilingTransactionData, object);
                        continue block18;
                    }
                    case 0: 
                }
                object = jsonObjectReader.nextLongOrNull();
                if (object == null) continue;
                ProfilingTransactionData.access$302(profilingTransactionData, object);
            }
            profilingTransactionData.setUnknown((Map<String, Object>)l2);
            jsonObjectReader.endObject();
            return profilingTransactionData;
        }
    }

    public static final class JsonKeys {
        public static final String END_CPU_MS = "relative_cpu_end_ms";
        public static final String END_NS = "relative_end_ns";
        public static final String ID = "id";
        public static final String NAME = "name";
        public static final String START_CPU_MS = "relative_cpu_start_ms";
        public static final String START_NS = "relative_start_ns";
        public static final String TRACE_ID = "trace_id";
    }
}

