/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.math.BigDecimal
 *  java.math.RoundingMode
 *  java.text.ParseException
 *  java.text.ParsePosition
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.TimeZone
 */
package io.sentry;

import io.sentry.SentryDate;
import io.sentry.vendor.gson.internal.bind.util.ISO8601Utils;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public final class DateUtils {
    private DateUtils() {
    }

    public static long dateToNanos(Date date) {
        return DateUtils.millisToNanos(date.getTime());
    }

    public static double dateToSeconds(Date date) {
        return DateUtils.millisToSeconds(date.getTime());
    }

    public static Date getCurrentDateTime() {
        return Calendar.getInstance((TimeZone)ISO8601Utils.TIMEZONE_UTC).getTime();
    }

    public static Date getDateTime(long l2) {
        Calendar calendar = Calendar.getInstance((TimeZone)ISO8601Utils.TIMEZONE_UTC);
        calendar.setTimeInMillis(l2);
        return calendar.getTime();
    }

    public static Date getDateTime(String string2) throws IllegalArgumentException {
        try {
            ParsePosition parsePosition = new ParsePosition(0);
            parsePosition = ISO8601Utils.parse(string2, parsePosition);
            return parsePosition;
        }
        catch (ParseException parseException) {
            throw new IllegalArgumentException("timestamp is not ISO format " + string2);
        }
    }

    public static Date getDateTimeWithMillisPrecision(String string2) throws IllegalArgumentException {
        try {
            BigDecimal bigDecimal = new BigDecimal(string2);
            bigDecimal = DateUtils.getDateTime(bigDecimal.setScale(3, RoundingMode.DOWN).movePointRight(3).longValue());
            return bigDecimal;
        }
        catch (NumberFormatException numberFormatException) {
            throw new IllegalArgumentException("timestamp is not millis format " + string2);
        }
    }

    public static String getTimestamp(Date date) {
        return ISO8601Utils.format(date, true);
    }

    public static long millisToNanos(long l2) {
        return l2 * 1000000L;
    }

    public static double millisToSeconds(double d2) {
        return d2 / 1000.0;
    }

    public static Date nanosToDate(long l2) {
        return DateUtils.getDateTime(Double.valueOf((double)DateUtils.nanosToMillis(l2)).longValue());
    }

    public static double nanosToMillis(double d2) {
        return d2 / 1000000.0;
    }

    public static double nanosToSeconds(long l2) {
        return Double.valueOf((double)l2) / 1.0E9;
    }

    public static long secondsToNanos(long l2) {
        return l2 * 1000000000L;
    }

    public static Date toUtilDate(SentryDate sentryDate) {
        if (sentryDate == null) {
            return null;
        }
        return DateUtils.toUtilDateNotNull(sentryDate);
    }

    public static Date toUtilDateNotNull(SentryDate sentryDate) {
        return DateUtils.nanosToDate(sentryDate.nanoTimestamp());
    }
}

