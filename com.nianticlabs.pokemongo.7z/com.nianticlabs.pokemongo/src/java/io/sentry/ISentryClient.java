/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.CheckIn;
import io.sentry.Hint;
import io.sentry.IMetricsAggregator;
import io.sentry.IScope;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.Session;
import io.sentry.TraceContext;
import io.sentry.UserFeedback;
import io.sentry.protocol.Message;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.transport.RateLimiter;

public interface ISentryClient {
    public SentryId captureCheckIn(CheckIn var1, IScope var2, Hint var3);

    default public SentryId captureEnvelope(SentryEnvelope sentryEnvelope) {
        return this.captureEnvelope(sentryEnvelope, null);
    }

    public SentryId captureEnvelope(SentryEnvelope var1, Hint var2);

    default public SentryId captureEvent(SentryEvent sentryEvent) {
        return this.captureEvent(sentryEvent, null, null);
    }

    default public SentryId captureEvent(SentryEvent sentryEvent, Hint hint) {
        return this.captureEvent(sentryEvent, null, hint);
    }

    default public SentryId captureEvent(SentryEvent sentryEvent, IScope iScope) {
        return this.captureEvent(sentryEvent, iScope, null);
    }

    public SentryId captureEvent(SentryEvent var1, IScope var2, Hint var3);

    default public SentryId captureException(Throwable throwable) {
        return this.captureException(throwable, null, null);
    }

    default public SentryId captureException(Throwable throwable, Hint hint) {
        return this.captureException(throwable, null, hint);
    }

    default public SentryId captureException(Throwable throwable, IScope iScope) {
        return this.captureException(throwable, iScope, null);
    }

    default public SentryId captureException(Throwable throwable, IScope iScope, Hint hint) {
        return this.captureEvent(new SentryEvent(throwable), iScope, hint);
    }

    default public SentryId captureMessage(String string2, SentryLevel sentryLevel) {
        return this.captureMessage(string2, sentryLevel, null);
    }

    default public SentryId captureMessage(String string2, SentryLevel sentryLevel, IScope iScope) {
        SentryEvent sentryEvent = new SentryEvent();
        Message message = new Message();
        message.setFormatted(string2);
        sentryEvent.setMessage(message);
        sentryEvent.setLevel(sentryLevel);
        return this.captureEvent(sentryEvent, iScope);
    }

    default public void captureSession(Session session) {
        this.captureSession(session, null);
    }

    public void captureSession(Session var1, Hint var2);

    default public SentryId captureTransaction(SentryTransaction sentryTransaction) {
        return this.captureTransaction(sentryTransaction, null, null, null);
    }

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, IScope iScope, Hint hint) {
        return this.captureTransaction(sentryTransaction, null, iScope, hint);
    }

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext) {
        return this.captureTransaction(sentryTransaction, traceContext, null, null);
    }

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext, IScope iScope, Hint hint) {
        return this.captureTransaction(sentryTransaction, traceContext, iScope, hint, null);
    }

    public SentryId captureTransaction(SentryTransaction var1, TraceContext var2, IScope var3, Hint var4, ProfilingTraceData var5);

    public void captureUserFeedback(UserFeedback var1);

    public void close();

    public void close(boolean var1);

    public void flush(long var1);

    public IMetricsAggregator getMetricsAggregator();

    public RateLimiter getRateLimiter();

    public boolean isEnabled();

    default public boolean isHealthy() {
        return true;
    }
}

