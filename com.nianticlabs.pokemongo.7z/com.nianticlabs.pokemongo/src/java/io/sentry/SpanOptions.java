/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

public class SpanOptions {
    private boolean isIdle = false;
    private boolean trimEnd = false;
    private boolean trimStart = false;

    public boolean isIdle() {
        return this.isIdle;
    }

    public boolean isTrimEnd() {
        return this.trimEnd;
    }

    public boolean isTrimStart() {
        return this.trimStart;
    }

    public void setIdle(boolean bl) {
        this.isIdle = bl;
    }

    public void setTrimEnd(boolean bl) {
        this.trimEnd = bl;
    }

    public void setTrimStart(boolean bl) {
        this.trimStart = bl;
    }
}

