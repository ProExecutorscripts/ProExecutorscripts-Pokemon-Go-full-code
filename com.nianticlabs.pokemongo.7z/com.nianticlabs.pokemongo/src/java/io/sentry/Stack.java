/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Deque
 *  java.util.concurrent.LinkedBlockingDeque
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.IScope;
import io.sentry.ISentryClient;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.util.Objects;
import java.util.Deque;
import java.util.concurrent.LinkedBlockingDeque;

final class Stack {
    private final Deque<StackItem> items;
    private final ILogger logger;

    public Stack(ILogger iLogger, StackItem stackItem) {
        LinkedBlockingDeque linkedBlockingDeque;
        this.items = linkedBlockingDeque = new LinkedBlockingDeque();
        this.logger = Objects.requireNonNull(iLogger, "logger is required");
        linkedBlockingDeque.push((Object)Objects.requireNonNull(stackItem, "rootStackItem is required"));
    }

    public Stack(Stack stack) {
        this(stack.logger, new StackItem((StackItem)stack.items.getLast()));
        stack = stack.items.descendingIterator();
        if (stack.hasNext()) {
            stack.next();
        }
        while (stack.hasNext()) {
            this.push(new StackItem((StackItem)stack.next()));
        }
    }

    StackItem peek() {
        return (StackItem)this.items.peek();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void pop() {
        Deque<StackItem> deque;
        Deque<StackItem> deque2 = deque = this.items;
        synchronized (deque2) {
            if (this.items.size() != 1) {
                this.items.pop();
            } else {
                this.logger.log(SentryLevel.WARNING, "Attempt to pop the root scope.", new Object[0]);
            }
            return;
        }
    }

    void push(StackItem stackItem) {
        this.items.push((Object)stackItem);
    }

    int size() {
        return this.items.size();
    }

    static final class StackItem {
        private volatile ISentryClient client;
        private final SentryOptions options;
        private volatile IScope scope;

        StackItem(SentryOptions sentryOptions, ISentryClient iSentryClient, IScope iScope) {
            this.client = Objects.requireNonNull(iSentryClient, "ISentryClient is required.");
            this.scope = Objects.requireNonNull(iScope, "Scope is required.");
            this.options = Objects.requireNonNull(sentryOptions, "Options is required");
        }

        StackItem(StackItem stackItem) {
            this.options = stackItem.options;
            this.client = stackItem.client;
            this.scope = stackItem.scope.clone();
        }

        public ISentryClient getClient() {
            return this.client;
        }

        public SentryOptions getOptions() {
            return this.options;
        }

        public IScope getScope() {
            return this.scope;
        }

        public void setClient(ISentryClient iSentryClient) {
            this.client = iSentryClient;
        }
    }
}

