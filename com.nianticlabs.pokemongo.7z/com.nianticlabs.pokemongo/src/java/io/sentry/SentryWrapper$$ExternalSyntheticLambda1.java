/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.IHub;
import io.sentry.SentryWrapper;
import java.util.concurrent.Callable;

public final class SentryWrapper$$ExternalSyntheticLambda1
implements Callable {
    public final IHub f$0;
    public final Callable f$1;

    public /* synthetic */ SentryWrapper$$ExternalSyntheticLambda1(IHub iHub, Callable callable) {
        this.f$0 = iHub;
        this.f$1 = callable;
    }

    public final Object call() {
        return SentryWrapper.lambda$wrapCallable$0(this.f$0, this.f$1);
    }
}

