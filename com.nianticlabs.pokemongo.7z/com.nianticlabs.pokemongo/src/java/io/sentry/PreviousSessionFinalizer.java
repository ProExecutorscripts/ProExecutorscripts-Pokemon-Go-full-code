/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.Date
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.IHub;
import io.sentry.ISerializer;
import io.sentry.SentryEnvelope;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.cache.EnvelopeCache;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Date;

final class PreviousSessionFinalizer
implements Runnable {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private final IHub hub;
    private final SentryOptions options;

    PreviousSessionFinalizer(SentryOptions sentryOptions, IHub iHub) {
        this.options = sentryOptions;
        this.hub = iHub;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Date getTimestampFromCrashMarkerFile(File object) {
        FileInputStream fileInputStream = new FileInputStream(object);
        InputStreamReader inputStreamReader = new InputStreamReader((InputStream)fileInputStream, UTF_8);
        BufferedReader bufferedReader = new BufferedReader((Reader)inputStreamReader);
        String string2 = bufferedReader.readLine();
        this.options.getLogger().log(SentryLevel.DEBUG, "Crash marker file has %s timestamp.", string2);
        Date date = DateUtils.getDateTime(string2);
        bufferedReader.close();
        return date;
        catch (Throwable throwable) {
            try {
                bufferedReader.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    this.options.getLogger().log(SentryLevel.ERROR, illegalArgumentException, "Error converting the crash timestamp.", new Object[0]);
                    return null;
                }
                catch (IOException iOException) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Error reading the crash marker file.", iOException);
                }
            }
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        BufferedReader bufferedReader;
        String string2;
        block15: {
            string2 = this.options.getCacheDirPath();
            if (string2 == null) {
                this.options.getLogger().log(SentryLevel.INFO, "Cache dir is not set, not finalizing the previous session.", new Object[0]);
                return;
            }
            if (!this.options.isEnableAutoSessionTracking()) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Session tracking is disabled, bailing from previous session finalizer.", new Object[0]);
                return;
            }
            Object object = this.options.getEnvelopeDiskCache();
            if (object instanceof EnvelopeCache && !((EnvelopeCache)object).waitPreviousSessionFlush()) {
                this.options.getLogger().log(SentryLevel.WARNING, "Timed out waiting to flush previous session to its own file in session finalizer.", new Object[0]);
                return;
            }
            string2 = EnvelopeCache.getPreviousSessionFile(string2);
            ISerializer iSerializer = this.options.getSerializer();
            if (!string2.exists()) return;
            this.options.getLogger().log(SentryLevel.WARNING, "Current session is not ended, we'd need to end it.", new Object[0]);
            Object object2 = new FileInputStream((File)string2);
            object = new InputStreamReader((InputStream)object2, UTF_8);
            bufferedReader = new BufferedReader((Reader)object);
            object2 = iSerializer.deserialize((Reader)bufferedReader, Session.class);
            if (object2 == null) {
                this.options.getLogger().log(SentryLevel.ERROR, "Stream from path %s resulted in a null envelope.", string2.getAbsolutePath());
                break block15;
            }
            File file = new File(this.options.getCacheDirPath(), ".sentry-native/last_crash");
            boolean bl = file.exists();
            object = null;
            if (bl) {
                this.options.getLogger().log(SentryLevel.INFO, "Crash marker file exists, last Session is gonna be Crashed.", new Object[0]);
                object = this.getTimestampFromCrashMarkerFile(file);
                if (!file.delete()) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Failed to delete the crash marker file. %s.", file.getAbsolutePath());
                }
                ((Session)object2).update(Session.State.Crashed, null, true);
            }
            if (((Session)object2).getAbnormalMechanism() == null) {
                ((Session)object2).end((Date)object);
            }
            object = SentryEnvelope.from(iSerializer, (Session)object2, this.options.getSdkVersion());
            this.hub.captureEnvelope((SentryEnvelope)object);
        }
        bufferedReader.close();
        catch (Throwable throwable) {
            try {
                bufferedReader.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Error processing previous session.", throwable3);
                }
            }
        }
        if (string2.delete()) return;
        this.options.getLogger().log(SentryLevel.WARNING, "Failed to delete the previous session file.", new Object[0]);
    }
}

