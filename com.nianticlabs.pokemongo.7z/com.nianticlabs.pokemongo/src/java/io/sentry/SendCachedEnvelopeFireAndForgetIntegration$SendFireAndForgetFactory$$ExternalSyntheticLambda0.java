/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry;

import io.sentry.DirectoryProcessor;
import io.sentry.ILogger;
import io.sentry.SendCachedEnvelopeFireAndForgetIntegration;
import java.io.File;

public final class SendCachedEnvelopeFireAndForgetIntegration$SendFireAndForgetFactory$$ExternalSyntheticLambda0
implements SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForget {
    public final ILogger f$0;
    public final String f$1;
    public final DirectoryProcessor f$2;
    public final File f$3;

    public /* synthetic */ SendCachedEnvelopeFireAndForgetIntegration$SendFireAndForgetFactory$$ExternalSyntheticLambda0(ILogger iLogger, String string2, DirectoryProcessor directoryProcessor, File file) {
        this.f$0 = iLogger;
        this.f$1 = string2;
        this.f$2 = directoryProcessor;
        this.f$3 = file;
    }

    @Override
    public final void send() {
        SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForgetFactory.lambda$processDir$0(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

