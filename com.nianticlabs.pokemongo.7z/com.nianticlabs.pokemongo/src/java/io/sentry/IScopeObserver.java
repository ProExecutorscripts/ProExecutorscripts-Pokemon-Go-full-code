/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Map
 */
package io.sentry;

import io.sentry.Breadcrumb;
import io.sentry.SentryLevel;
import io.sentry.SpanContext;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.User;
import java.util.Collection;
import java.util.Map;

public interface IScopeObserver {
    public void addBreadcrumb(Breadcrumb var1);

    public void removeExtra(String var1);

    public void removeTag(String var1);

    public void setBreadcrumbs(Collection<Breadcrumb> var1);

    public void setContexts(Contexts var1);

    public void setExtra(String var1, String var2);

    public void setExtras(Map<String, Object> var1);

    public void setFingerprint(Collection<String> var1);

    public void setLevel(SentryLevel var1);

    public void setRequest(Request var1);

    public void setTag(String var1, String var2);

    public void setTags(Map<String, String> var1);

    public void setTrace(SpanContext var1);

    public void setTransaction(String var1);

    public void setUser(User var1);
}

