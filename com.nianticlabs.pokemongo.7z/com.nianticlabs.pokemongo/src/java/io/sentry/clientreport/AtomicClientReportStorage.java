/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.atomic.AtomicLong
 */
package io.sentry.clientreport;

import io.sentry.DataCategory;
import io.sentry.clientreport.ClientReportKey;
import io.sentry.clientreport.DiscardReason;
import io.sentry.clientreport.DiscardedEvent;
import io.sentry.clientreport.IClientReportStorage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

final class AtomicClientReportStorage
implements IClientReportStorage {
    private final Map<ClientReportKey, AtomicLong> lostEventCounts;

    public AtomicClientReportStorage() {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        for (DiscardReason discardReason : DiscardReason.values()) {
            for (DataCategory dataCategory : DataCategory.values()) {
                concurrentHashMap.put((Object)new ClientReportKey(discardReason.getReason(), dataCategory.getCategory()), (Object)new AtomicLong(0L));
            }
        }
        this.lostEventCounts = Collections.unmodifiableMap((Map)concurrentHashMap);
    }

    @Override
    public void addCount(ClientReportKey clientReportKey, Long l2) {
        if ((clientReportKey = (AtomicLong)this.lostEventCounts.get((Object)clientReportKey)) != null) {
            clientReportKey.addAndGet(l2);
        }
    }

    @Override
    public List<DiscardedEvent> resetCountsAndGet() {
        ArrayList arrayList = new ArrayList();
        for (Map.Entry entry : this.lostEventCounts.entrySet()) {
            Long l2 = ((AtomicLong)entry.getValue()).getAndSet(0L);
            if (l2 <= 0L) continue;
            arrayList.add((Object)new DiscardedEvent(((ClientReportKey)entry.getKey()).getReason(), ((ClientReportKey)entry.getKey()).getCategory(), l2));
        }
        return arrayList;
    }
}

