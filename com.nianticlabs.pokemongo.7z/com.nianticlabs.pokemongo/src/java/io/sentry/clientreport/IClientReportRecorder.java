/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.clientreport;

import io.sentry.DataCategory;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.clientreport.DiscardReason;

public interface IClientReportRecorder {
    public SentryEnvelope attachReportToEnvelope(SentryEnvelope var1);

    public void recordLostEnvelope(DiscardReason var1, SentryEnvelope var2);

    public void recordLostEnvelopeItem(DiscardReason var1, SentryEnvelopeItem var2);

    public void recordLostEvent(DiscardReason var1, DataCategory var2);
}

