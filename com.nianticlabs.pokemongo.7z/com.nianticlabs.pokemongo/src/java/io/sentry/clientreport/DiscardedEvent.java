/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry.clientreport;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class DiscardedEvent
implements JsonUnknown,
JsonSerializable {
    private final String category;
    private final Long quantity;
    private final String reason;
    private Map<String, Object> unknown;

    public DiscardedEvent(String string2, String string3, Long l2) {
        this.reason = string2;
        this.category = string3;
        this.quantity = l2;
    }

    public String getCategory() {
        return this.category;
    }

    public Long getQuantity() {
        return this.quantity;
    }

    public String getReason() {
        return this.reason;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("reason").value(this.reason);
        objectWriter.name("category").value(this.category);
        objectWriter.name("quantity").value((Number)this.quantity);
        Object object2 = this.unknown;
        if (object2 != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public String toString() {
        return "DiscardedEvent{reason='" + this.reason + "', category='" + this.category + "', quantity=" + this.quantity + '}';
    }

    public static final class Deserializer
    implements JsonDeserializer<DiscardedEvent> {
        private Exception missingRequiredFieldException(String object, ILogger iLogger) {
            String string2 = "Missing required field \"" + object + "\"";
            object = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, (Throwable)object);
            return object;
        }

        @Override
        public DiscardedEvent deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            Long l2;
            ((JsonReader)object).beginObject();
            String string2 = null;
            String string3 = null;
            Long l3 = l2 = null;
            block10: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string4 = ((JsonReader)object).nextName();
                string4.hashCode();
                int n2 = string4.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 50511102: {
                        if (!string4.equals((Object)"category")) break;
                        n3 = 2;
                        break;
                    }
                    case -934964668: {
                        if (!string4.equals((Object)"reason")) break;
                        n3 = 1;
                        break;
                    }
                    case -1285004149: {
                        if (!string4.equals((Object)"quantity")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Long l4 = l3;
                        if (l3 == null) {
                            l4 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)l4, string4);
                        l3 = l4;
                        continue block10;
                    }
                    case 2: {
                        string3 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block10;
                    }
                    case 1: {
                        string2 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block10;
                    }
                    case 0: 
                }
                l2 = ((JsonObjectReader)object).nextLongOrNull();
            }
            ((JsonReader)object).endObject();
            if (string2 != null) {
                if (string3 != null) {
                    if (l2 != null) {
                        object = new DiscardedEvent(string2, string3, l2);
                        ((DiscardedEvent)object).setUnknown((Map<String, Object>)l3);
                        return object;
                    }
                    throw this.missingRequiredFieldException("quantity", iLogger);
                }
                throw this.missingRequiredFieldException("category", iLogger);
            }
            throw this.missingRequiredFieldException("reason", iLogger);
        }
    }

    public static final class JsonKeys {
        public static final String CATEGORY = "category";
        public static final String QUANTITY = "quantity";
        public static final String REASON = "reason";
    }
}

