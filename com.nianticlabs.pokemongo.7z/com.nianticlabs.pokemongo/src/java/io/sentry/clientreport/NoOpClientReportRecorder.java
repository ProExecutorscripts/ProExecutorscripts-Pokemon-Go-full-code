/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.clientreport;

import io.sentry.DataCategory;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.clientreport.DiscardReason;
import io.sentry.clientreport.IClientReportRecorder;

public final class NoOpClientReportRecorder
implements IClientReportRecorder {
    @Override
    public SentryEnvelope attachReportToEnvelope(SentryEnvelope sentryEnvelope) {
        return sentryEnvelope;
    }

    @Override
    public void recordLostEnvelope(DiscardReason discardReason, SentryEnvelope sentryEnvelope) {
    }

    @Override
    public void recordLostEnvelopeItem(DiscardReason discardReason, SentryEnvelopeItem sentryEnvelopeItem) {
    }

    @Override
    public void recordLostEvent(DiscardReason discardReason, DataCategory dataCategory) {
    }
}

