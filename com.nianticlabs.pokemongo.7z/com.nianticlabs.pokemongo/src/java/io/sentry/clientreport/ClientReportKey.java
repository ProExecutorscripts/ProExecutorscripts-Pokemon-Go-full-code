/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.clientreport;

import io.sentry.util.Objects;

final class ClientReportKey {
    private final String category;
    private final String reason;

    ClientReportKey(String string2, String string3) {
        this.reason = string2;
        this.category = string3;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (!(object instanceof ClientReportKey)) {
            return false;
        }
        object = (ClientReportKey)object;
        if (!Objects.equals(this.getReason(), ((ClientReportKey)object).getReason()) || !Objects.equals(this.getCategory(), ((ClientReportKey)object).getCategory())) {
            bl = false;
        }
        return bl;
    }

    public String getCategory() {
        return this.category;
    }

    public String getReason() {
        return this.reason;
    }

    public int hashCode() {
        return Objects.hash(this.getReason(), this.getCategory());
    }
}

