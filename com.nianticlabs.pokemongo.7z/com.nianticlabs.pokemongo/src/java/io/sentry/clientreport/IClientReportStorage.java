/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.List
 */
package io.sentry.clientreport;

import io.sentry.clientreport.ClientReportKey;
import io.sentry.clientreport.DiscardedEvent;
import java.util.List;

public interface IClientReportStorage {
    public void addCount(ClientReportKey var1, Long var2);

    public List<DiscardedEvent> resetCountsAndGet();
}

