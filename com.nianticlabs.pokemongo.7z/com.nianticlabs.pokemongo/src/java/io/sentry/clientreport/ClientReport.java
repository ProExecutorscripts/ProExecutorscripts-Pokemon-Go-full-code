/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.clientreport;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.clientreport.DiscardedEvent;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ClientReport
implements JsonUnknown,
JsonSerializable {
    private final List<DiscardedEvent> discardedEvents;
    private final Date timestamp;
    private Map<String, Object> unknown;

    public ClientReport(Date date, List<DiscardedEvent> list) {
        this.timestamp = date;
        this.discardedEvents = list;
    }

    public List<DiscardedEvent> getDiscardedEvents() {
        return this.discardedEvents;
    }

    public Date getTimestamp() {
        return this.timestamp;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("timestamp").value(DateUtils.getTimestamp(this.timestamp));
        objectWriter.name("discarded_events").value(iLogger, this.discardedEvents);
        Object object2 = this.unknown;
        if (object2 != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<ClientReport> {
        private Exception missingRequiredFieldException(String object, ILogger iLogger) {
            String string2 = "Missing required field \"" + object + "\"";
            object = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, (Throwable)object);
            return object;
        }

        @Override
        public ClientReport deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            ArrayList arrayList = new ArrayList();
            ((JsonReader)object).beginObject();
            Date date = null;
            HashMap hashMap = null;
            while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string2 = ((JsonReader)object).nextName();
                string2.hashCode();
                if (!string2.equals((Object)"discarded_events")) {
                    if (!string2.equals((Object)"timestamp")) {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue;
                    }
                    date = ((JsonObjectReader)object).nextDateOrNull(iLogger);
                    continue;
                }
                arrayList.addAll(((JsonObjectReader)object).nextListOrNull(iLogger, new DiscardedEvent.Deserializer()));
            }
            ((JsonReader)object).endObject();
            if (date != null) {
                if (!arrayList.isEmpty()) {
                    object = new ClientReport(date, (List<DiscardedEvent>)arrayList);
                    ((ClientReport)object).setUnknown((Map<String, Object>)hashMap);
                    return object;
                }
                throw this.missingRequiredFieldException("discarded_events", iLogger);
            }
            throw this.missingRequiredFieldException("timestamp", iLogger);
        }
    }

    public static final class JsonKeys {
        public static final String DISCARDED_EVENTS = "discarded_events";
        public static final String TIMESTAMP = "timestamp";
    }
}

