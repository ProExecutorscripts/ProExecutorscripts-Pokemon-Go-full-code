/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 */
package io.sentry.clientreport;

import io.sentry.DataCategory;
import io.sentry.DateUtils;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.clientreport.AtomicClientReportStorage;
import io.sentry.clientreport.ClientReport;
import io.sentry.clientreport.ClientReportKey;
import io.sentry.clientreport.DiscardReason;
import io.sentry.clientreport.DiscardedEvent;
import io.sentry.clientreport.IClientReportRecorder;
import io.sentry.clientreport.IClientReportStorage;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public final class ClientReportRecorder
implements IClientReportRecorder {
    private final SentryOptions options;
    private final IClientReportStorage storage;

    public ClientReportRecorder(SentryOptions sentryOptions) {
        this.options = sentryOptions;
        this.storage = new AtomicClientReportStorage();
    }

    private DataCategory categoryFromItemType(SentryItemType sentryItemType) {
        if (SentryItemType.Event.equals(sentryItemType)) {
            return DataCategory.Error;
        }
        if (SentryItemType.Session.equals(sentryItemType)) {
            return DataCategory.Session;
        }
        if (SentryItemType.Transaction.equals(sentryItemType)) {
            return DataCategory.Transaction;
        }
        if (SentryItemType.UserFeedback.equals(sentryItemType)) {
            return DataCategory.UserReport;
        }
        if (SentryItemType.Profile.equals(sentryItemType)) {
            return DataCategory.Profile;
        }
        if (SentryItemType.Statsd.equals(sentryItemType)) {
            return DataCategory.MetricBucket;
        }
        if (SentryItemType.Attachment.equals(sentryItemType)) {
            return DataCategory.Attachment;
        }
        if (SentryItemType.CheckIn.equals(sentryItemType)) {
            return DataCategory.Monitor;
        }
        return DataCategory.Default;
    }

    private void recordLostEventInternal(String object, String string2, Long l2) {
        object = new ClientReportKey((String)object, string2);
        this.storage.addCount((ClientReportKey)object, l2);
    }

    private void restoreCountsFromClientReport(ClientReport clientReport) {
        if (clientReport == null) {
            return;
        }
        for (DiscardedEvent discardedEvent : clientReport.getDiscardedEvents()) {
            this.recordLostEventInternal(discardedEvent.getReason(), discardedEvent.getCategory(), discardedEvent.getQuantity());
        }
    }

    @Override
    public SentryEnvelope attachReportToEnvelope(SentryEnvelope sentryEnvelope) {
        ClientReport clientReport = this.resetCountsAndGenerateClientReport();
        if (clientReport == null) {
            return sentryEnvelope;
        }
        try {
            this.options.getLogger().log(SentryLevel.DEBUG, "Attaching client report to envelope.", new Object[0]);
            Object object = new ArrayList();
            Iterator iterator = sentryEnvelope.getItems().iterator();
            while (iterator.hasNext()) {
                object.add((Object)((SentryEnvelopeItem)iterator.next()));
            }
            object.add((Object)SentryEnvelopeItem.fromClientReport(this.options.getSerializer(), clientReport));
            object = new SentryEnvelope(sentryEnvelope.getHeader(), (Iterable<SentryEnvelopeItem>)object);
            return object;
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Unable to attach client report to envelope.", new Object[0]);
            return sentryEnvelope;
        }
    }

    @Override
    public void recordLostEnvelope(DiscardReason discardReason, SentryEnvelope sentryEnvelope) {
        if (sentryEnvelope == null) {
            return;
        }
        try {
            sentryEnvelope = sentryEnvelope.getItems().iterator();
            while (sentryEnvelope.hasNext()) {
                this.recordLostEnvelopeItem(discardReason, (SentryEnvelopeItem)sentryEnvelope.next());
            }
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Unable to record lost envelope.", new Object[0]);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void recordLostEnvelopeItem(DiscardReason discardReason, SentryEnvelopeItem sentryEnvelopeItem) {
        if (sentryEnvelopeItem == null) {
            return;
        }
        try {
            SentryItemType sentryItemType = sentryEnvelopeItem.getHeader().getType();
            boolean bl = SentryItemType.ClientReport.equals(sentryItemType);
            if (!bl) {
                this.recordLostEventInternal(discardReason.getReason(), this.categoryFromItemType(sentryItemType).getCategory(), 1L);
                return;
            }
            try {
                this.restoreCountsFromClientReport(sentryEnvelopeItem.getClientReport(this.options.getSerializer()));
                return;
            }
            catch (Exception exception) {
                this.options.getLogger().log(SentryLevel.ERROR, "Unable to restore counts from previous client report.", new Object[0]);
                return;
            }
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Unable to record lost envelope item.", new Object[0]);
        }
    }

    @Override
    public void recordLostEvent(DiscardReason discardReason, DataCategory dataCategory) {
        try {
            this.recordLostEventInternal(discardReason.getReason(), dataCategory.getCategory(), 1L);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Unable to record lost event.", new Object[0]);
        }
    }

    ClientReport resetCountsAndGenerateClientReport() {
        Date date = DateUtils.getCurrentDateTime();
        List<DiscardedEvent> list = this.storage.resetCountsAndGet();
        if (list.isEmpty()) {
            return null;
        }
        return new ClientReport(date, list);
    }
}

