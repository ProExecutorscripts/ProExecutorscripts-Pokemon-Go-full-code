/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.Scope;
import io.sentry.SentryTracer;

public final class SentryTracer$$ExternalSyntheticLambda2
implements Scope.IWithTransaction {
    public final SentryTracer f$0;
    public final IScope f$1;

    public /* synthetic */ SentryTracer$$ExternalSyntheticLambda2(SentryTracer sentryTracer, IScope iScope) {
        this.f$0 = sentryTracer;
        this.f$1 = iScope;
    }

    @Override
    public final void accept(ITransaction iTransaction) {
        this.f$0.lambda$finish$0$io-sentry-SentryTracer(this.f$1, iTransaction);
    }
}

