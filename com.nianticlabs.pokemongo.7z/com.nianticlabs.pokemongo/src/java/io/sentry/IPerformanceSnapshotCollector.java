/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.IPerformanceCollector;
import io.sentry.PerformanceCollectionData;

public interface IPerformanceSnapshotCollector
extends IPerformanceCollector {
    public void collect(PerformanceCollectionData var1);

    public void setup();
}

