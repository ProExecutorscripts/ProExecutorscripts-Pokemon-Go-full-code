/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.util.Objects;
import java.util.HashMap;
import java.util.Map;

public final class CustomSamplingContext {
    private final Map<String, Object> data = new HashMap();

    public Object get(String string2) {
        Objects.requireNonNull(string2, "key is required");
        return this.data.get((Object)string2);
    }

    public Map<String, Object> getData() {
        return this.data;
    }

    public void set(String string2, Object object) {
        Objects.requireNonNull(string2, "key is required");
        this.data.put((Object)string2, object);
    }
}

