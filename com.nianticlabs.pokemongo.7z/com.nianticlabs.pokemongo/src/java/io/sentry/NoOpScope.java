/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Queue
 */
package io.sentry;

import io.sentry.Attachment;
import io.sentry.Breadcrumb;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.IScope;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PropagationContext;
import io.sentry.Scope;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.User;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public final class NoOpScope
implements IScope {
    private static final NoOpScope instance = new NoOpScope();
    private final SentryOptions emptyOptions = SentryOptions.empty();

    private NoOpScope() {
    }

    public static NoOpScope getInstance() {
        return instance;
    }

    @Override
    public void addAttachment(Attachment attachment) {
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb, Hint hint) {
    }

    @Override
    public void addEventProcessor(EventProcessor eventProcessor) {
    }

    @Override
    public void clear() {
    }

    @Override
    public void clearAttachments() {
    }

    @Override
    public void clearBreadcrumbs() {
    }

    @Override
    public void clearTransaction() {
    }

    @Override
    public IScope clone() {
        return NoOpScope.getInstance();
    }

    @Override
    public Session endSession() {
        return null;
    }

    @Override
    public List<Attachment> getAttachments() {
        return new ArrayList();
    }

    @Override
    public Queue<Breadcrumb> getBreadcrumbs() {
        return new ArrayDeque();
    }

    @Override
    public Contexts getContexts() {
        return new Contexts();
    }

    @Override
    public List<EventProcessor> getEventProcessors() {
        return new ArrayList();
    }

    @Override
    public Map<String, Object> getExtras() {
        return new HashMap();
    }

    @Override
    public List<String> getFingerprint() {
        return new ArrayList();
    }

    @Override
    public SentryLevel getLevel() {
        return null;
    }

    @Override
    public SentryOptions getOptions() {
        return this.emptyOptions;
    }

    @Override
    public PropagationContext getPropagationContext() {
        return new PropagationContext();
    }

    @Override
    public Request getRequest() {
        return null;
    }

    @Override
    public String getScreen() {
        return null;
    }

    @Override
    public Session getSession() {
        return null;
    }

    @Override
    public ISpan getSpan() {
        return null;
    }

    @Override
    public Map<String, String> getTags() {
        return new HashMap();
    }

    @Override
    public ITransaction getTransaction() {
        return null;
    }

    @Override
    public String getTransactionName() {
        return null;
    }

    @Override
    public User getUser() {
        return null;
    }

    @Override
    public void removeContexts(String string2) {
    }

    @Override
    public void removeExtra(String string2) {
    }

    @Override
    public void removeTag(String string2) {
    }

    @Override
    public void setContexts(String string2, Boolean bl) {
    }

    @Override
    public void setContexts(String string2, Character c2) {
    }

    @Override
    public void setContexts(String string2, Number number) {
    }

    @Override
    public void setContexts(String string2, Object object) {
    }

    @Override
    public void setContexts(String string2, String string3) {
    }

    @Override
    public void setContexts(String string2, Collection<?> collection) {
    }

    @Override
    public void setContexts(String string2, Object[] objectArray) {
    }

    @Override
    public void setExtra(String string2, String string3) {
    }

    @Override
    public void setFingerprint(List<String> list) {
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
    }

    @Override
    public void setPropagationContext(PropagationContext propagationContext) {
    }

    @Override
    public void setRequest(Request request) {
    }

    @Override
    public void setScreen(String string2) {
    }

    @Override
    public void setTag(String string2, String string3) {
    }

    @Override
    public void setTransaction(ITransaction iTransaction) {
    }

    @Override
    public void setTransaction(String string2) {
    }

    @Override
    public void setUser(User user) {
    }

    @Override
    public Scope.SessionPair startSession() {
        return null;
    }

    @Override
    public PropagationContext withPropagationContext(Scope.IWithPropagationContext iWithPropagationContext) {
        return new PropagationContext();
    }

    @Override
    public Session withSession(Scope.IWithSession iWithSession) {
        return null;
    }

    @Override
    public void withTransaction(Scope.IWithTransaction iWithTransaction) {
    }
}

