/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Enumeration
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.SpanContext;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class MonitorContexts
extends ConcurrentHashMap<String, Object>
implements JsonSerializable {
    private static final long serialVersionUID = 3987329379811822556L;

    public MonitorContexts() {
    }

    public MonitorContexts(MonitorContexts monitorContexts) {
        for (Map.Entry entry : monitorContexts.entrySet()) {
            if (entry == null) continue;
            Object object = entry.getValue();
            if ("trace".equals(entry.getKey()) && object instanceof SpanContext) {
                this.setTrace(new SpanContext((SpanContext)object));
                continue;
            }
            this.put((String)entry.getKey(), object);
        }
    }

    private <T> T toContextType(String object, Class<T> clazz) {
        object = clazz.isInstance(object = this.get(object)) ? clazz.cast(object) : null;
        return (T)object;
    }

    public SpanContext getTrace() {
        return this.toContextType("trace", SpanContext.class);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        Object object = Collections.list((Enumeration)this.keys());
        Collections.sort((List)object);
        for (String string2 : object) {
            object = this.get(string2);
            if (object == null) continue;
            objectWriter.name(string2).value(iLogger, object);
        }
        objectWriter.endObject();
    }

    public void setTrace(SpanContext spanContext) {
        Objects.requireNonNull(spanContext, "traceContext is required");
        this.put("trace", spanContext);
    }

    public static final class Deserializer
    implements JsonDeserializer<MonitorContexts> {
        @Override
        public MonitorContexts deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            MonitorContexts monitorContexts = new MonitorContexts();
            jsonObjectReader.beginObject();
            while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                if (!string2.equals((Object)"trace")) {
                    Object object = jsonObjectReader.nextObjectOrNull();
                    if (object == null) continue;
                    monitorContexts.put(string2, object);
                    continue;
                }
                monitorContexts.setTrace(new SpanContext.Deserializer().deserialize(jsonObjectReader, iLogger));
            }
            jsonObjectReader.endObject();
            return monitorContexts;
        }
    }
}

