/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.CheckIn;
import io.sentry.Hint;
import io.sentry.IMetricsAggregator;
import io.sentry.IScope;
import io.sentry.ISentryClient;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.Session;
import io.sentry.TraceContext;
import io.sentry.UserFeedback;
import io.sentry.metrics.NoopMetricsAggregator;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.transport.RateLimiter;

final class NoOpSentryClient
implements ISentryClient {
    private static final NoOpSentryClient instance = new NoOpSentryClient();

    private NoOpSentryClient() {
    }

    public static NoOpSentryClient getInstance() {
        return instance;
    }

    @Override
    public SentryId captureCheckIn(CheckIn checkIn, IScope iScope, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureEnvelope(SentryEnvelope sentryEnvelope, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, IScope iScope, Hint hint) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public void captureSession(Session session, Hint hint) {
    }

    @Override
    public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext, IScope iScope, Hint hint, ProfilingTraceData profilingTraceData) {
        return SentryId.EMPTY_ID;
    }

    @Override
    public void captureUserFeedback(UserFeedback userFeedback) {
    }

    @Override
    public void close() {
    }

    @Override
    public void close(boolean bl) {
    }

    @Override
    public void flush(long l2) {
    }

    @Override
    public IMetricsAggregator getMetricsAggregator() {
        return NoopMetricsAggregator.getInstance();
    }

    @Override
    public RateLimiter getRateLimiter() {
        return null;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}

