/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.NoOpSentryExecutorService;
import java.util.concurrent.Callable;

public final class NoOpSentryExecutorService$$ExternalSyntheticLambda2
implements Callable {
    public final Object call() {
        return NoOpSentryExecutorService.lambda$schedule$2();
    }
}

