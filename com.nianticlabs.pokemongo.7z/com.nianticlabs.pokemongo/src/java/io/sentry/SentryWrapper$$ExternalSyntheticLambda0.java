/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.function.Supplier
 */
package io.sentry;

import io.sentry.IHub;
import io.sentry.SentryWrapper;
import java.util.function.Supplier;

public final class SentryWrapper$$ExternalSyntheticLambda0
implements Supplier {
    public final IHub f$0;
    public final Supplier f$1;

    public /* synthetic */ SentryWrapper$$ExternalSyntheticLambda0(IHub iHub, Supplier supplier) {
        this.f$0 = iHub;
        this.f$1 = supplier;
    }

    public final Object get() {
        return SentryWrapper.lambda$wrapSupplier$1(this.f$0, this.f$1);
    }
}

