/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.Queue
 */
package io.sentry;

import io.sentry.SynchronizedCollection;
import java.util.Queue;

final class SynchronizedQueue<E>
extends SynchronizedCollection<E>
implements Queue<E> {
    private static final long serialVersionUID = 1L;

    private SynchronizedQueue(Queue<E> queue) {
        super(queue);
    }

    protected SynchronizedQueue(Queue<E> queue, Object object) {
        super(queue, object);
    }

    static <E> SynchronizedQueue<E> synchronizedQueue(Queue<E> queue) {
        return new SynchronizedQueue<E>(queue);
    }

    @Override
    protected Queue<E> decorated() {
        return (Queue)super.decorated();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public E element() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            Object object3 = this.decorated().element();
            return (E)object3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean equals(Object object) {
        Object object2;
        if (object == this) {
            return true;
        }
        Object object3 = object2 = this.lock;
        synchronized (object3) {
            return this.decorated().equals(object);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int hashCode() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().hashCode();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean offer(E e2) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().offer(e2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public E peek() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            Object object3 = this.decorated().peek();
            return (E)object3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public E poll() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            Object object3 = this.decorated().poll();
            return (E)object3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public E remove() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            Object object3 = this.decorated().remove();
            return (E)object3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object[] toArray() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().toArray();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public <T> T[] toArray(T[] objectArray) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().toArray(objectArray);
        }
    }
}

