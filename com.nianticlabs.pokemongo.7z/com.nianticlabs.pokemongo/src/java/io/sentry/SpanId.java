/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.UUID
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.util.Objects;
import io.sentry.util.StringUtils;
import java.io.IOException;
import java.util.UUID;

public final class SpanId
implements JsonSerializable {
    public static final SpanId EMPTY_ID = new SpanId(new UUID(0L, 0L));
    private final String value;

    public SpanId() {
        this(UUID.randomUUID());
    }

    public SpanId(String string2) {
        this.value = Objects.requireNonNull(string2, "value is required");
    }

    private SpanId(UUID uUID) {
        this(StringUtils.normalizeUUID(uUID.toString()).replace((CharSequence)"-", (CharSequence)"").substring(0, 16));
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (SpanId)object;
            return this.value.equals((Object)((SpanId)object).value);
        }
        return false;
    }

    public int hashCode() {
        return this.value.hashCode();
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.value(this.value);
    }

    public String toString() {
        return this.value;
    }

    public static final class Deserializer
    implements JsonDeserializer<SpanId> {
        @Override
        public SpanId deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            return new SpanId(jsonObjectReader.nextString());
        }
    }
}

