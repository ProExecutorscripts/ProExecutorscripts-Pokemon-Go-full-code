/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.ProfilingTraceData;
import java.util.concurrent.Callable;

public final class ProfilingTraceData$$ExternalSyntheticLambda0
implements Callable {
    public final Object call() {
        return ProfilingTraceData.lambda$new$0();
    }
}

