/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Object
 */
package io.sentry;

public final class TracesSamplingDecision {
    private final Double profileSampleRate;
    private final Boolean profileSampled;
    private final Double sampleRate;
    private final Boolean sampled;

    public TracesSamplingDecision(Boolean bl) {
        this(bl, null);
    }

    public TracesSamplingDecision(Boolean bl, Double d2) {
        this(bl, d2, false, null);
    }

    public TracesSamplingDecision(Boolean bl, Double d2, Boolean bl2, Double d3) {
        this.sampled = bl;
        this.sampleRate = d2;
        boolean bl3 = bl != false && bl2 != false;
        this.profileSampled = bl3;
        this.profileSampleRate = d3;
    }

    public Double getProfileSampleRate() {
        return this.profileSampleRate;
    }

    public Boolean getProfileSampled() {
        return this.profileSampled;
    }

    public Double getSampleRate() {
        return this.sampleRate;
    }

    public Boolean getSampled() {
        return this.sampled;
    }
}

