/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.net.InetAddress
 *  java.net.URI
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Currency
 *  java.util.Date
 *  java.util.Locale
 *  java.util.Map
 *  java.util.TimeZone
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicIntegerArray
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonReflectionObjectSerializer;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.util.JsonSerializationUtils;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class JsonObjectSerializer {
    public static final String OBJECT_PLACEHOLDER = "[OBJECT]";
    public final JsonReflectionObjectSerializer jsonReflectionObjectSerializer;

    public JsonObjectSerializer(int n2) {
        this.jsonReflectionObjectSerializer = new JsonReflectionObjectSerializer(n2);
    }

    private void serializeCollection(ObjectWriter objectWriter, ILogger iLogger, Collection<?> iterator) throws IOException {
        objectWriter.beginArray();
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            this.serialize(objectWriter, iLogger, iterator.next());
        }
        objectWriter.endArray();
    }

    private void serializeDate(ObjectWriter objectWriter, ILogger iLogger, Date date) throws IOException {
        try {
            objectWriter.value(DateUtils.getTimestamp(date));
        }
        catch (Exception exception) {
            iLogger.log(SentryLevel.ERROR, "Error when serializing Date", exception);
            objectWriter.nullValue();
        }
    }

    private void serializeMap(ObjectWriter objectWriter, ILogger iLogger, Map<?, ?> map2) throws IOException {
        objectWriter.beginObject();
        for (Object object : map2.keySet()) {
            if (!(object instanceof String)) continue;
            objectWriter.name((String)object);
            this.serialize(objectWriter, iLogger, map2.get(object));
        }
        objectWriter.endObject();
    }

    private void serializeTimeZone(ObjectWriter objectWriter, ILogger iLogger, TimeZone timeZone) throws IOException {
        try {
            objectWriter.value(timeZone.getID());
        }
        catch (Exception exception) {
            iLogger.log(SentryLevel.ERROR, "Error when serializing TimeZone", exception);
            objectWriter.nullValue();
        }
    }

    public void serialize(ObjectWriter objectWriter, ILogger iLogger, Object object) throws IOException {
        if (object == null) {
            objectWriter.nullValue();
        } else if (object instanceof Character) {
            objectWriter.value(Character.toString((char)((Character)object).charValue()));
        } else if (object instanceof String) {
            objectWriter.value((String)object);
        } else if (object instanceof Boolean) {
            objectWriter.value((boolean)((Boolean)object));
        } else if (object instanceof Number) {
            objectWriter.value((Number)object);
        } else if (object instanceof Date) {
            this.serializeDate(objectWriter, iLogger, (Date)object);
        } else if (object instanceof TimeZone) {
            this.serializeTimeZone(objectWriter, iLogger, (TimeZone)object);
        } else if (object instanceof JsonSerializable) {
            ((JsonSerializable)object).serialize(objectWriter, iLogger);
        } else if (object instanceof Collection) {
            this.serializeCollection(objectWriter, iLogger, (Collection)object);
        } else if (object.getClass().isArray()) {
            this.serializeCollection(objectWriter, iLogger, (Collection<?>)Arrays.asList((Object[])((Object[])object)));
        } else if (object instanceof Map) {
            this.serializeMap(objectWriter, iLogger, (Map)object);
        } else if (object instanceof Locale) {
            objectWriter.value(object.toString());
        } else if (object instanceof AtomicIntegerArray) {
            this.serializeCollection(objectWriter, iLogger, (Collection<?>)JsonSerializationUtils.atomicIntegerArrayToList((AtomicIntegerArray)object));
        } else if (object instanceof AtomicBoolean) {
            objectWriter.value(((AtomicBoolean)object).get());
        } else if (object instanceof URI) {
            objectWriter.value(object.toString());
        } else if (object instanceof InetAddress) {
            objectWriter.value(object.toString());
        } else if (object instanceof UUID) {
            objectWriter.value(object.toString());
        } else if (object instanceof Currency) {
            objectWriter.value(object.toString());
        } else if (object instanceof Calendar) {
            this.serializeMap(objectWriter, iLogger, JsonSerializationUtils.calendarToMap((Calendar)object));
        } else if (object.getClass().isEnum()) {
            objectWriter.value(object.toString());
        } else {
            try {
                this.serialize(objectWriter, iLogger, this.jsonReflectionObjectSerializer.serialize(object, iLogger));
            }
            catch (Exception exception) {
                iLogger.log(SentryLevel.ERROR, "Failed serializing unknown object.", exception);
                objectWriter.value(OBJECT_PLACEHOLDER);
            }
        }
    }
}

