/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Timer
 *  java.util.TimerTask
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry;

import io.sentry.DefaultTransactionPerformanceCollector$$ExternalSyntheticLambda0;
import io.sentry.IPerformanceContinuousCollector;
import io.sentry.IPerformanceSnapshotCollector;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PerformanceCollectionData;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.TransactionPerformanceCollector;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class DefaultTransactionPerformanceCollector
implements TransactionPerformanceCollector {
    private static final long TRANSACTION_COLLECTION_INTERVAL_MILLIS = 100L;
    private static final long TRANSACTION_COLLECTION_TIMEOUT_MILLIS = 30000L;
    private final List<IPerformanceContinuousCollector> continuousCollectors;
    private final boolean hasNoCollectors;
    private final AtomicBoolean isStarted;
    private long lastCollectionTimestamp;
    private final SentryOptions options;
    private final Map<String, List<PerformanceCollectionData>> performanceDataMap;
    private final List<IPerformanceSnapshotCollector> snapshotCollectors;
    private volatile Timer timer = null;
    private final Object timerLock = new Object();

    public DefaultTransactionPerformanceCollector(SentryOptions object2) {
        this.performanceDataMap = new ConcurrentHashMap();
        boolean bl = false;
        this.isStarted = new AtomicBoolean(false);
        this.lastCollectionTimestamp = 0L;
        this.options = (SentryOptions)Objects.requireNonNull(object2, "The options object is required.");
        this.snapshotCollectors = new ArrayList();
        this.continuousCollectors = new ArrayList();
        for (Object object2 : ((SentryOptions)object2).getPerformanceCollectors()) {
            if (object2 instanceof IPerformanceSnapshotCollector) {
                this.snapshotCollectors.add((Object)((IPerformanceSnapshotCollector)object2));
            }
            if (!(object2 instanceof IPerformanceContinuousCollector)) continue;
            this.continuousCollectors.add((Object)((IPerformanceContinuousCollector)object2));
        }
        boolean bl2 = bl;
        if (this.snapshotCollectors.isEmpty()) {
            bl2 = bl;
            if (this.continuousCollectors.isEmpty()) {
                bl2 = true;
            }
        }
        this.hasNoCollectors = bl2;
    }

    static /* synthetic */ long access$102(DefaultTransactionPerformanceCollector defaultTransactionPerformanceCollector, long l2) {
        defaultTransactionPerformanceCollector.lastCollectionTimestamp = l2;
        return l2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close() {
        this.options.getLogger().log(SentryLevel.DEBUG, "stop collecting all performance info for transactions", new Object[0]);
        this.performanceDataMap.clear();
        Object object = this.continuousCollectors.iterator();
        while (true) {
            if (!object.hasNext()) {
                if (!this.isStarted.getAndSet(false)) return;
                Object object2 = object = this.timerLock;
                synchronized (object2) {
                    if (this.timer == null) return;
                    this.timer.cancel();
                    this.timer = null;
                    return;
                }
            }
            ((IPerformanceContinuousCollector)object.next()).clear();
        }
    }

    /* synthetic */ void lambda$start$0$io-sentry-DefaultTransactionPerformanceCollector(ITransaction iTransaction) {
        this.stop(iTransaction);
    }

    @Override
    public void onSpanFinished(ISpan iSpan) {
        Iterator iterator = this.continuousCollectors.iterator();
        while (iterator.hasNext()) {
            ((IPerformanceContinuousCollector)iterator.next()).onSpanFinished(iSpan);
        }
    }

    @Override
    public void onSpanStarted(ISpan iSpan) {
        Iterator iterator = this.continuousCollectors.iterator();
        while (iterator.hasNext()) {
            ((IPerformanceContinuousCollector)iterator.next()).onSpanStarted(iSpan);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void start(ITransaction object) {
        Object object2;
        if (this.hasNoCollectors) {
            this.options.getLogger().log(SentryLevel.INFO, "No collector found. Performance stats will not be captured during transactions.", new Object[0]);
            return;
        }
        Object object3 = this.continuousCollectors.iterator();
        while (object3.hasNext()) {
            ((IPerformanceContinuousCollector)object3.next()).onSpanStarted((ISpan)object);
        }
        if (!this.performanceDataMap.containsKey((Object)object.getEventId().toString())) {
            this.performanceDataMap.put((Object)object.getEventId().toString(), (Object)new ArrayList());
            try {
                object2 = this.options.getExecutorService();
                object3 = new DefaultTransactionPerformanceCollector$$ExternalSyntheticLambda0(this, (ITransaction)object);
                object2.schedule((Runnable)object3, 30000L);
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Performance collector will not be automatically finished. Did you call Sentry.close()?", rejectedExecutionException);
            }
        }
        if (this.isStarted.getAndSet(true)) return;
        Object object4 = object = this.timerLock;
        synchronized (object4) {
            if (this.timer == null) {
                object3 = new Timer(true);
                this.timer = object3;
            }
            object3 = this.timer;
            object2 = new TimerTask(this){
                final DefaultTransactionPerformanceCollector this$0;
                {
                    this.this$0 = defaultTransactionPerformanceCollector;
                }

                public void run() {
                    Iterator iterator = this.this$0.snapshotCollectors.iterator();
                    while (iterator.hasNext()) {
                        ((IPerformanceSnapshotCollector)iterator.next()).setup();
                    }
                }
            };
            object3.schedule((TimerTask)object2, 0L);
            object3 = new TimerTask(this){
                final DefaultTransactionPerformanceCollector this$0;
                {
                    this.this$0 = defaultTransactionPerformanceCollector;
                }

                public void run() {
                    long l2 = System.currentTimeMillis();
                    if (l2 - this.this$0.lastCollectionTimestamp < 10L) {
                        return;
                    }
                    DefaultTransactionPerformanceCollector.access$102(this.this$0, l2);
                    PerformanceCollectionData performanceCollectionData = new PerformanceCollectionData();
                    Iterator iterator = this.this$0.snapshotCollectors.iterator();
                    while (iterator.hasNext()) {
                        ((IPerformanceSnapshotCollector)iterator.next()).collect(performanceCollectionData);
                    }
                    iterator = this.this$0.performanceDataMap.values().iterator();
                    while (iterator.hasNext()) {
                        ((List)iterator.next()).add((Object)performanceCollectionData);
                    }
                }
            };
            this.timer.scheduleAtFixedRate((TimerTask)object3, 100L, 100L);
            return;
        }
    }

    @Override
    public List<PerformanceCollectionData> stop(ITransaction iTransaction) {
        this.options.getLogger().log(SentryLevel.DEBUG, "stop collecting performance info for transactions %s (%s)", iTransaction.getName(), iTransaction.getSpanContext().getTraceId().toString());
        List list = (List)this.performanceDataMap.remove((Object)iTransaction.getEventId().toString());
        Iterator iterator = this.continuousCollectors.iterator();
        while (iterator.hasNext()) {
            ((IPerformanceContinuousCollector)iterator.next()).onSpanFinished(iTransaction);
        }
        if (this.performanceDataMap.isEmpty()) {
            this.close();
        }
        return list;
    }
}

