/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.LocalMetricsAggregator;
import java.io.Closeable;
import java.util.Map;

public interface IMetricsAggregator
extends Closeable {
    public void distribution(String var1, double var2, MeasurementUnit var4, Map<String, String> var5, long var6, LocalMetricsAggregator var8);

    public void flush(boolean var1);

    public void gauge(String var1, double var2, MeasurementUnit var4, Map<String, String> var5, long var6, LocalMetricsAggregator var8);

    public void increment(String var1, double var2, MeasurementUnit var4, Map<String, String> var5, long var6, LocalMetricsAggregator var8);

    public void set(String var1, int var2, MeasurementUnit var3, Map<String, String> var4, long var5, LocalMetricsAggregator var7);

    public void set(String var1, String var2, MeasurementUnit var3, Map<String, String> var4, long var5, LocalMetricsAggregator var7);

    public void timing(String var1, Runnable var2, MeasurementUnit.Duration var3, Map<String, String> var4, LocalMetricsAggregator var5);
}

