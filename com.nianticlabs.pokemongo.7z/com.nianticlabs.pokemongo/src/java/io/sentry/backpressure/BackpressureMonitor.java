/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 */
package io.sentry.backpressure;

import io.sentry.IHub;
import io.sentry.ISentryExecutorService;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.backpressure.IBackpressureMonitor;

public final class BackpressureMonitor
implements IBackpressureMonitor,
Runnable {
    private static final int CHECK_INTERVAL_IN_MS = 10000;
    private static final int INITIAL_CHECK_DELAY_IN_MS = 500;
    static final int MAX_DOWNSAMPLE_FACTOR = 10;
    private int downsampleFactor = 0;
    private final IHub hub;
    private final SentryOptions sentryOptions;

    public BackpressureMonitor(SentryOptions sentryOptions, IHub iHub) {
        this.sentryOptions = sentryOptions;
        this.hub = iHub;
    }

    private boolean isHealthy() {
        return this.hub.isHealthy();
    }

    private void reschedule(int n2) {
        ISentryExecutorService iSentryExecutorService = this.sentryOptions.getExecutorService();
        if (!iSentryExecutorService.isClosed()) {
            iSentryExecutorService.schedule(this, n2);
        }
    }

    void checkHealth() {
        if (this.isHealthy()) {
            if (this.downsampleFactor > 0) {
                this.sentryOptions.getLogger().log(SentryLevel.DEBUG, "Health check positive, reverting to normal sampling.", new Object[0]);
            }
            this.downsampleFactor = 0;
        } else {
            int n2 = this.downsampleFactor;
            if (n2 < 10) {
                this.downsampleFactor = n2 + 1;
                this.sentryOptions.getLogger().log(SentryLevel.DEBUG, "Health check negative, downsampling with a factor of %d", this.downsampleFactor);
            }
        }
    }

    @Override
    public int getDownsampleFactor() {
        return this.downsampleFactor;
    }

    public void run() {
        this.checkHealth();
        this.reschedule(10000);
    }

    @Override
    public void start() {
        this.reschedule(500);
    }
}

