/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry;

import io.sentry.ISerializer;
import io.sentry.JsonDeserializer;
import io.sentry.SentryEnvelope;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;

final class NoOpSerializer
implements ISerializer {
    private static final NoOpSerializer instance = new NoOpSerializer();

    private NoOpSerializer() {
    }

    public static NoOpSerializer getInstance() {
        return instance;
    }

    @Override
    public <T> T deserialize(Reader reader, Class<T> clazz) {
        return null;
    }

    @Override
    public <T, R> T deserializeCollection(Reader reader, Class<T> clazz, JsonDeserializer<R> jsonDeserializer) {
        return null;
    }

    @Override
    public SentryEnvelope deserializeEnvelope(InputStream inputStream) {
        return null;
    }

    @Override
    public String serialize(Map<String, Object> map2) throws Exception {
        return "";
    }

    @Override
    public void serialize(SentryEnvelope sentryEnvelope, OutputStream outputStream) throws Exception {
    }

    @Override
    public <T> void serialize(T t2, Writer writer) throws IOException {
    }
}

