/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.SentryLevel;

public interface ILogger {
    public boolean isEnabled(SentryLevel var1);

    public void log(SentryLevel var1, String var2, Throwable var3);

    public void log(SentryLevel var1, String var2, Object ... var3);

    public void log(SentryLevel var1, Throwable var2, String var3, Object ... var4);
}

