/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedWriter
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.InstantiationException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.ThreadLocal
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.nio.charset.Charset
 *  java.util.Arrays
 *  java.util.List
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.TimeUnit
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.Dsn;
import io.sentry.ExternalOptions;
import io.sentry.Hint;
import io.sentry.Hub;
import io.sentry.HubAdapter;
import io.sentry.IHub;
import io.sentry.IOptionsObserver;
import io.sentry.ISentryClient;
import io.sentry.ISentryExecutorService;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.Integration;
import io.sentry.JavaMemoryCollector;
import io.sentry.NoOpHub;
import io.sentry.NoOpLogger;
import io.sentry.OptionsContainer;
import io.sentry.PreviousSessionFinalizer;
import io.sentry.SamplingContext;
import io.sentry.ScopeCallback;
import io.sentry.Sentry$$ExternalSyntheticLambda0;
import io.sentry.Sentry$$ExternalSyntheticLambda1;
import io.sentry.Sentry$$ExternalSyntheticLambda2;
import io.sentry.Sentry$$ExternalSyntheticLambda3;
import io.sentry.Sentry$$ExternalSyntheticLambda4;
import io.sentry.SentryAppStartProfilingOptions;
import io.sentry.SentryEvent;
import io.sentry.SentryExecutorService;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryTraceHeader;
import io.sentry.SystemOutLogger;
import io.sentry.TracesSampler;
import io.sentry.TracesSamplingDecision;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.UserFeedback;
import io.sentry.backpressure.BackpressureMonitor;
import io.sentry.cache.EnvelopeCache;
import io.sentry.config.PropertiesProviderFactory;
import io.sentry.internal.debugmeta.NoOpDebugMetaLoader;
import io.sentry.internal.debugmeta.ResourcesDebugMetaLoader;
import io.sentry.internal.modules.CompositeModulesLoader;
import io.sentry.internal.modules.IModulesLoader;
import io.sentry.internal.modules.ManifestModulesLoader;
import io.sentry.internal.modules.NoOpModulesLoader;
import io.sentry.internal.modules.ResourcesModulesLoader;
import io.sentry.metrics.MetricsApi;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.User;
import io.sentry.transport.NoOpEnvelopeCache;
import io.sentry.util.DebugMetaPropertiesApplier;
import io.sentry.util.FileUtils;
import io.sentry.util.Platform;
import io.sentry.util.thread.MainThreadChecker;
import io.sentry.util.thread.NoOpMainThreadChecker;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

public final class Sentry {
    public static final String APP_START_PROFILING_CONFIG_FILE_NAME = "app_start_profiling_config";
    private static final boolean GLOBAL_HUB_DEFAULT_MODE = false;
    private static final Charset UTF_8;
    private static final long classCreationTimestamp;
    private static final ThreadLocal<IHub> currentHub;
    private static volatile boolean globalHubMode;
    private static volatile IHub mainHub;

    static {
        currentHub = new ThreadLocal();
        mainHub = NoOpHub.getInstance();
        globalHubMode = false;
        UTF_8 = Charset.forName((String)"UTF-8");
        classCreationTimestamp = System.currentTimeMillis();
    }

    private Sentry() {
    }

    public static void addBreadcrumb(Breadcrumb breadcrumb) {
        Sentry.getCurrentHub().addBreadcrumb(breadcrumb);
    }

    public static void addBreadcrumb(Breadcrumb breadcrumb, Hint hint) {
        Sentry.getCurrentHub().addBreadcrumb(breadcrumb, hint);
    }

    public static void addBreadcrumb(String string2) {
        Sentry.getCurrentHub().addBreadcrumb(string2);
    }

    public static void addBreadcrumb(String string2, String string3) {
        Sentry.getCurrentHub().addBreadcrumb(string2, string3);
    }

    private static <T extends SentryOptions> void applyOptionsConfiguration(OptionsConfiguration<T> optionsConfiguration, T t2) {
        try {
            optionsConfiguration.configure(t2);
        }
        catch (Throwable throwable) {
            t2.getLogger().log(SentryLevel.ERROR, "Error in the 'OptionsConfiguration.configure' callback.", throwable);
        }
    }

    public static void bindClient(ISentryClient iSentryClient) {
        Sentry.getCurrentHub().bindClient(iSentryClient);
    }

    public static SentryId captureCheckIn(CheckIn checkIn) {
        return Sentry.getCurrentHub().captureCheckIn(checkIn);
    }

    public static SentryId captureEvent(SentryEvent sentryEvent) {
        return Sentry.getCurrentHub().captureEvent(sentryEvent);
    }

    public static SentryId captureEvent(SentryEvent sentryEvent, Hint hint) {
        return Sentry.getCurrentHub().captureEvent(sentryEvent, hint);
    }

    public static SentryId captureEvent(SentryEvent sentryEvent, Hint hint, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureEvent(sentryEvent, hint, scopeCallback);
    }

    public static SentryId captureEvent(SentryEvent sentryEvent, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureEvent(sentryEvent, scopeCallback);
    }

    public static SentryId captureException(Throwable throwable) {
        return Sentry.getCurrentHub().captureException(throwable);
    }

    public static SentryId captureException(Throwable throwable, Hint hint) {
        return Sentry.getCurrentHub().captureException(throwable, hint);
    }

    public static SentryId captureException(Throwable throwable, Hint hint, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureException(throwable, hint, scopeCallback);
    }

    public static SentryId captureException(Throwable throwable, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureException(throwable, scopeCallback);
    }

    public static SentryId captureMessage(String string2) {
        return Sentry.getCurrentHub().captureMessage(string2);
    }

    public static SentryId captureMessage(String string2, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureMessage(string2, scopeCallback);
    }

    public static SentryId captureMessage(String string2, SentryLevel sentryLevel) {
        return Sentry.getCurrentHub().captureMessage(string2, sentryLevel);
    }

    public static SentryId captureMessage(String string2, SentryLevel sentryLevel, ScopeCallback scopeCallback) {
        return Sentry.getCurrentHub().captureMessage(string2, sentryLevel, scopeCallback);
    }

    public static void captureUserFeedback(UserFeedback userFeedback) {
        Sentry.getCurrentHub().captureUserFeedback(userFeedback);
    }

    public static void clearBreadcrumbs() {
        Sentry.getCurrentHub().clearBreadcrumbs();
    }

    public static IHub cloneMainHub() {
        if (globalHubMode) {
            return mainHub;
        }
        return mainHub.clone();
    }

    public static void close() {
        Class<Sentry> clazz = Sentry.class;
        synchronized (Sentry.class) {
            IHub iHub = Sentry.getCurrentHub();
            mainHub = NoOpHub.getInstance();
            currentHub.remove();
            iHub.close(false);
            // ** MonitorExit[var1] (shouldn't be in output)
            return;
        }
    }

    public static void configureScope(ScopeCallback scopeCallback) {
        Sentry.getCurrentHub().configureScope(scopeCallback);
    }

    public static TransactionContext continueTrace(String string2, List<String> list) {
        return Sentry.getCurrentHub().continueTrace(string2, list);
    }

    public static void endSession() {
        Sentry.getCurrentHub().endSession();
    }

    private static void finalizePreviousSession(SentryOptions sentryOptions, IHub iHub) {
        try {
            ISentryExecutorService iSentryExecutorService = sentryOptions.getExecutorService();
            PreviousSessionFinalizer previousSessionFinalizer = new PreviousSessionFinalizer(sentryOptions, iHub);
            iSentryExecutorService.submit(previousSessionFinalizer);
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to finalize previous session.", throwable);
        }
    }

    public static void flush(long l2) {
        Sentry.getCurrentHub().flush(l2);
    }

    public static BaggageHeader getBaggage() {
        return Sentry.getCurrentHub().getBaggage();
    }

    public static IHub getCurrentHub() {
        IHub iHub;
        block5: {
            ThreadLocal<IHub> threadLocal;
            block4: {
                if (globalHubMode) {
                    return mainHub;
                }
                threadLocal = currentHub;
                IHub iHub2 = (IHub)threadLocal.get();
                if (iHub2 == null) break block4;
                iHub = iHub2;
                if (!(iHub2 instanceof NoOpHub)) break block5;
            }
            iHub = mainHub.clone();
            threadLocal.set((Object)iHub);
        }
        return iHub;
    }

    public static SentryId getLastEventId() {
        return Sentry.getCurrentHub().getLastEventId();
    }

    public static ISpan getSpan() {
        if (globalHubMode && Platform.isAndroid()) {
            return Sentry.getCurrentHub().getTransaction();
        }
        return Sentry.getCurrentHub().getSpan();
    }

    public static SentryTraceHeader getTraceparent() {
        return Sentry.getCurrentHub().getTraceparent();
    }

    private static void handleAppStartProfilingConfig(SentryOptions sentryOptions, ISentryExecutorService iSentryExecutorService) {
        try {
            Sentry$$ExternalSyntheticLambda2 sentry$$ExternalSyntheticLambda2 = new Sentry$$ExternalSyntheticLambda2(sentryOptions);
            iSentryExecutorService.submit(sentry$$ExternalSyntheticLambda2);
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. App start profiling config will not be changed. Did you call Sentry.close()?", throwable);
        }
    }

    public static void init() {
        Sentry.init(new Sentry$$ExternalSyntheticLambda0(), false);
    }

    public static <T extends SentryOptions> void init(OptionsContainer<T> optionsContainer, OptionsConfiguration<T> optionsConfiguration) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
        Sentry.init(optionsContainer, optionsConfiguration, false);
    }

    public static <T extends SentryOptions> void init(OptionsContainer<T> object, OptionsConfiguration<T> optionsConfiguration, boolean bl) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
        object = (SentryOptions)((OptionsContainer)object).createInstance();
        Sentry.applyOptionsConfiguration(optionsConfiguration, object);
        Sentry.init((SentryOptions)object, bl);
    }

    public static void init(OptionsConfiguration<SentryOptions> optionsConfiguration) {
        Sentry.init(optionsConfiguration, false);
    }

    public static void init(OptionsConfiguration<SentryOptions> optionsConfiguration, boolean bl) {
        SentryOptions sentryOptions = new SentryOptions();
        Sentry.applyOptionsConfiguration(optionsConfiguration, sentryOptions);
        Sentry.init(sentryOptions, bl);
    }

    public static void init(SentryOptions sentryOptions) {
        Sentry.init(sentryOptions, false);
    }

    private static void init(SentryOptions sentryOptions, boolean bl) {
        Class<Sentry> clazz = Sentry.class;
        synchronized (Sentry.class) {
            block7: {
                boolean bl2;
                if (Sentry.isEnabled()) {
                    sentryOptions.getLogger().log(SentryLevel.WARNING, "Sentry has been already initialized. Previous configuration will be overwritten.", new Object[0]);
                }
                if (bl2 = Sentry.initConfigurations(sentryOptions)) break block7;
                // ** MonitorExit[var5_3] (shouldn't be in output)
                return;
            }
            sentryOptions.getLogger().log(SentryLevel.INFO, "GlobalHubMode: '%s'", String.valueOf((boolean)bl));
            globalHubMode = bl;
            Object object = Sentry.getCurrentHub();
            Hub hub = new Hub(sentryOptions);
            mainHub = hub;
            currentHub.set((Object)mainHub);
            object.close(true);
            if (sentryOptions.getExecutorService().isClosed()) {
                object = new SentryExecutorService();
                sentryOptions.setExecutorService((ISentryExecutorService)object);
            }
            object = sentryOptions.getIntegrations().iterator();
            while (object.hasNext()) {
                ((Integration)object.next()).register(HubAdapter.getInstance(), sentryOptions);
            }
            Sentry.notifyOptionsObservers(sentryOptions);
            Sentry.finalizePreviousSession(sentryOptions, HubAdapter.getInstance());
            Sentry.handleAppStartProfilingConfig(sentryOptions, sentryOptions.getExecutorService());
            // ** MonitorExit[var5_3] (shouldn't be in output)
            return;
        }
    }

    public static void init(String string2) {
        Sentry.init(new Sentry$$ExternalSyntheticLambda1(string2));
    }

    private static boolean initConfigurations(SentryOptions sentryOptions) {
        if (sentryOptions.isEnableExternalConfiguration()) {
            sentryOptions.merge(ExternalOptions.from(PropertiesProviderFactory.create(), sentryOptions.getLogger()));
        }
        Object object = sentryOptions.getDsn();
        if (sentryOptions.isEnabled() && (object == null || !object.isEmpty())) {
            if (object != null) {
                Object object2;
                new Dsn((String)object);
                object = object2 = sentryOptions.getLogger();
                if (sentryOptions.isDebug()) {
                    object = object2;
                    if (object2 instanceof NoOpLogger) {
                        sentryOptions.setLogger(new SystemOutLogger());
                        object = sentryOptions.getLogger();
                    }
                }
                object.log(SentryLevel.INFO, "Initializing SDK with DSN: '%s'", sentryOptions.getDsn());
                object2 = sentryOptions.getOutboxPath();
                if (object2 != null) {
                    new File((String)object2).mkdirs();
                } else {
                    object.log(SentryLevel.INFO, "No outbox dir path is defined in options.", new Object[0]);
                }
                object = sentryOptions.getCacheDirPath();
                if (object != null) {
                    new File((String)object).mkdirs();
                    if (sentryOptions.getEnvelopeDiskCache() instanceof NoOpEnvelopeCache) {
                        sentryOptions.setEnvelopeDiskCache(EnvelopeCache.create(sentryOptions));
                    }
                }
                object = sentryOptions.getProfilingTracesDirPath();
                if (sentryOptions.isProfilingEnabled() && object != null) {
                    object = new File((String)object);
                    object.mkdirs();
                    try {
                        ISentryExecutorService iSentryExecutorService = sentryOptions.getExecutorService();
                        object2 = new Sentry$$ExternalSyntheticLambda3((File)object);
                        iSentryExecutorService.submit((Runnable)object2);
                    }
                    catch (RejectedExecutionException rejectedExecutionException) {
                        sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Old profiles will not be deleted. Did you call Sentry.close()?", rejectedExecutionException);
                    }
                }
                object = sentryOptions.getModulesLoader();
                if (!sentryOptions.isSendModules()) {
                    sentryOptions.setModulesLoader(NoOpModulesLoader.getInstance());
                } else if (object instanceof NoOpModulesLoader) {
                    sentryOptions.setModulesLoader(new CompositeModulesLoader((List<IModulesLoader>)Arrays.asList((Object[])new IModulesLoader[]{new ManifestModulesLoader(sentryOptions.getLogger()), new ResourcesModulesLoader(sentryOptions.getLogger())}), sentryOptions.getLogger()));
                }
                if (sentryOptions.getDebugMetaLoader() instanceof NoOpDebugMetaLoader) {
                    sentryOptions.setDebugMetaLoader(new ResourcesDebugMetaLoader(sentryOptions.getLogger()));
                }
                DebugMetaPropertiesApplier.applyToOptions(sentryOptions, sentryOptions.getDebugMetaLoader().loadDebugMeta());
                if (sentryOptions.getMainThreadChecker() instanceof NoOpMainThreadChecker) {
                    sentryOptions.setMainThreadChecker(MainThreadChecker.getInstance());
                }
                if (sentryOptions.getPerformanceCollectors().isEmpty()) {
                    sentryOptions.addPerformanceCollector(new JavaMemoryCollector());
                }
                if (sentryOptions.isEnableBackpressureHandling() && Platform.isJvm()) {
                    sentryOptions.setBackpressureMonitor(new BackpressureMonitor(sentryOptions, HubAdapter.getInstance()));
                    sentryOptions.getBackpressureMonitor().start();
                }
                return true;
            }
            throw new IllegalArgumentException("DSN is required. Use empty string or set enabled to false in SentryOptions to disable SDK.");
        }
        Sentry.close();
        return false;
    }

    public static Boolean isCrashedLastRun() {
        return Sentry.getCurrentHub().isCrashedLastRun();
    }

    public static boolean isEnabled() {
        return Sentry.getCurrentHub().isEnabled();
    }

    public static boolean isHealthy() {
        return Sentry.getCurrentHub().isHealthy();
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static /* synthetic */ void lambda$handleAppStartProfilingConfig$2(SentryOptions sentryOptions) {
        Object object = sentryOptions.getCacheDirPathWithoutDsn();
        if (object == null) return;
        File file = new File((String)object, APP_START_PROFILING_CONFIG_FILE_NAME);
        FileUtils.deleteRecursively(file);
        if (!sentryOptions.isEnableAppStartProfiling()) {
            return;
        }
        if (!sentryOptions.isTracingEnabled()) {
            sentryOptions.getLogger().log(SentryLevel.INFO, "Tracing is disabled and app start profiling will not start.", new Object[0]);
            return;
        }
        if (!file.createNewFile()) return;
        object = Sentry.sampleAppStartProfiling(sentryOptions);
        SentryAppStartProfilingOptions sentryAppStartProfilingOptions = new SentryAppStartProfilingOptions(sentryOptions, (TracesSamplingDecision)object);
        object = new FileOutputStream(file);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)object, UTF_8);
        file = new BufferedWriter((Writer)outputStreamWriter);
        sentryOptions.getSerializer().serialize(sentryAppStartProfilingOptions, (Writer)file);
        file.close();
        object.close();
        return;
        catch (Throwable throwable) {
            try {
                file.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    try {
                        object.close();
                        throw throwable3;
                    }
                    catch (Throwable throwable4) {
                        try {
                            throwable3.addSuppressed(throwable4);
                            throw throwable3;
                        }
                        catch (Throwable throwable5) {
                            sentryOptions.getLogger().log(SentryLevel.ERROR, "Unable to create app start profiling config file. ", throwable5);
                        }
                    }
                }
            }
        }
    }

    static /* synthetic */ void lambda$init$0(SentryOptions sentryOptions) {
        sentryOptions.setEnableExternalConfiguration(true);
    }

    static /* synthetic */ void lambda$init$1(String string2, SentryOptions sentryOptions) {
        sentryOptions.setDsn(string2);
    }

    static /* synthetic */ void lambda$initConfigurations$4(File file2) {
        File[] fileArray = file2.listFiles();
        if (fileArray == null) {
            return;
        }
        for (File file2 : fileArray) {
            if (file2.lastModified() >= classCreationTimestamp - TimeUnit.MINUTES.toMillis(5L)) continue;
            FileUtils.deleteRecursively(file2);
        }
    }

    static /* synthetic */ void lambda$notifyOptionsObservers$3(SentryOptions sentryOptions) {
        for (IOptionsObserver iOptionsObserver : sentryOptions.getOptionsObservers()) {
            iOptionsObserver.setRelease(sentryOptions.getRelease());
            iOptionsObserver.setProguardUuid(sentryOptions.getProguardUuid());
            iOptionsObserver.setSdkVersion(sentryOptions.getSdkVersion());
            iOptionsObserver.setDist(sentryOptions.getDist());
            iOptionsObserver.setEnvironment(sentryOptions.getEnvironment());
            iOptionsObserver.setTags(sentryOptions.getTags());
        }
    }

    public static MetricsApi metrics() {
        return Sentry.getCurrentHub().metrics();
    }

    private static void notifyOptionsObservers(SentryOptions sentryOptions) {
        try {
            ISentryExecutorService iSentryExecutorService = sentryOptions.getExecutorService();
            Sentry$$ExternalSyntheticLambda4 sentry$$ExternalSyntheticLambda4 = new Sentry$$ExternalSyntheticLambda4(sentryOptions);
            iSentryExecutorService.submit(sentry$$ExternalSyntheticLambda4);
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to notify options observers.", throwable);
        }
    }

    public static void popScope() {
        if (!globalHubMode) {
            Sentry.getCurrentHub().popScope();
        }
    }

    public static void pushScope() {
        if (!globalHubMode) {
            Sentry.getCurrentHub().pushScope();
        }
    }

    public static void removeExtra(String string2) {
        Sentry.getCurrentHub().removeExtra(string2);
    }

    public static void removeTag(String string2) {
        Sentry.getCurrentHub().removeTag(string2);
    }

    @Deprecated
    public static void reportFullDisplayed() {
        Sentry.reportFullyDisplayed();
    }

    public static void reportFullyDisplayed() {
        Sentry.getCurrentHub().reportFullyDisplayed();
    }

    private static TracesSamplingDecision sampleAppStartProfiling(SentryOptions sentryOptions) {
        Object object = new TransactionContext("app.launch", "profile");
        ((TransactionContext)object).setForNextAppStart(true);
        object = new SamplingContext((TransactionContext)object, null);
        return new TracesSampler(sentryOptions).sample((SamplingContext)object);
    }

    public static void setCurrentHub(IHub iHub) {
        currentHub.set((Object)iHub);
    }

    public static void setExtra(String string2, String string3) {
        Sentry.getCurrentHub().setExtra(string2, string3);
    }

    public static void setFingerprint(List<String> list) {
        Sentry.getCurrentHub().setFingerprint(list);
    }

    public static void setLevel(SentryLevel sentryLevel) {
        Sentry.getCurrentHub().setLevel(sentryLevel);
    }

    public static void setTag(String string2, String string3) {
        Sentry.getCurrentHub().setTag(string2, string3);
    }

    public static void setTransaction(String string2) {
        Sentry.getCurrentHub().setTransaction(string2);
    }

    public static void setUser(User user) {
        Sentry.getCurrentHub().setUser(user);
    }

    public static void startSession() {
        Sentry.getCurrentHub().startSession();
    }

    public static ITransaction startTransaction(TransactionContext transactionContext) {
        return Sentry.getCurrentHub().startTransaction(transactionContext);
    }

    public static ITransaction startTransaction(TransactionContext transactionContext, TransactionOptions transactionOptions) {
        return Sentry.getCurrentHub().startTransaction(transactionContext, transactionOptions);
    }

    public static ITransaction startTransaction(String string2, String string3) {
        return Sentry.getCurrentHub().startTransaction(string2, string3);
    }

    public static ITransaction startTransaction(String string2, String string3, TransactionOptions transactionOptions) {
        return Sentry.getCurrentHub().startTransaction(string2, string3, transactionOptions);
    }

    public static ITransaction startTransaction(String object, String string2, String string3, TransactionOptions transactionOptions) {
        object = Sentry.getCurrentHub().startTransaction((String)object, string2, transactionOptions);
        object.setDescription(string3);
        return object;
    }

    @Deprecated
    public static SentryTraceHeader traceHeaders() {
        return Sentry.getCurrentHub().traceHeaders();
    }

    public static void withScope(ScopeCallback scopeCallback) {
        Sentry.getCurrentHub().withScope(scopeCallback);
    }

    public static interface OptionsConfiguration<T extends SentryOptions> {
        public void configure(T var1);
    }
}

