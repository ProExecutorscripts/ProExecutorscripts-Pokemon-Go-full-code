/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.util.UrlUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Breadcrumb
implements JsonUnknown,
JsonSerializable {
    private String category;
    private Map<String, Object> data = new ConcurrentHashMap();
    private SentryLevel level;
    private String message;
    private final Date timestamp;
    private String type;
    private Map<String, Object> unknown;

    public Breadcrumb() {
        this(DateUtils.getCurrentDateTime());
    }

    Breadcrumb(Breadcrumb breadcrumb) {
        this.timestamp = breadcrumb.timestamp;
        this.message = breadcrumb.message;
        this.type = breadcrumb.type;
        this.category = breadcrumb.category;
        Map<String, Object> map2 = CollectionUtils.newConcurrentHashMap(breadcrumb.data);
        if (map2 != null) {
            this.data = map2;
        }
        this.unknown = CollectionUtils.newConcurrentHashMap(breadcrumb.unknown);
        this.level = breadcrumb.level;
    }

    public Breadcrumb(String string2) {
        this();
        this.message = string2;
    }

    public Breadcrumb(Date date) {
        this.timestamp = date;
    }

    static /* synthetic */ String access$002(Breadcrumb breadcrumb, String string2) {
        breadcrumb.message = string2;
        return string2;
    }

    static /* synthetic */ String access$102(Breadcrumb breadcrumb, String string2) {
        breadcrumb.type = string2;
        return string2;
    }

    static /* synthetic */ Map access$202(Breadcrumb breadcrumb, Map map2) {
        breadcrumb.data = map2;
        return map2;
    }

    static /* synthetic */ String access$302(Breadcrumb breadcrumb, String string2) {
        breadcrumb.category = string2;
        return string2;
    }

    static /* synthetic */ SentryLevel access$402(Breadcrumb breadcrumb, SentryLevel sentryLevel) {
        breadcrumb.level = sentryLevel;
        return sentryLevel;
    }

    public static Breadcrumb debug(String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("debug");
        breadcrumb.setMessage(string2);
        breadcrumb.setLevel(SentryLevel.DEBUG);
        return breadcrumb;
    }

    public static Breadcrumb error(String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("error");
        breadcrumb.setMessage(string2);
        breadcrumb.setLevel(SentryLevel.ERROR);
        return breadcrumb;
    }

    /*
     * Loose catch block
     */
    public static Breadcrumb fromMap(Map<String, Object> object, SentryOptions object2) {
        Object object3;
        Object object4 = DateUtils.getCurrentDateTime();
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        Iterator iterator = object.entrySet().iterator();
        String string2 = null;
        String string3 = null;
        Object object5 = object3 = (object = string3);
        block18: while (true) {
            Map.Entry entry = object3;
            if (iterator.hasNext()) {
                object3 = (Map.Entry)iterator.next();
                Object object6 = object3.getValue();
                String string4 = (String)object3.getKey();
                string4.hashCode();
                int n2 = string4.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 954925063: {
                        if (!string4.equals((Object)"message")) break;
                        n3 = 5;
                        break;
                    }
                    case 102865796: {
                        if (!string4.equals((Object)"level")) break;
                        n3 = 4;
                        break;
                    }
                    case 55126294: {
                        if (!string4.equals((Object)"timestamp")) break;
                        n3 = 3;
                        break;
                    }
                    case 50511102: {
                        if (!string4.equals((Object)"category")) break;
                        n3 = 2;
                        break;
                    }
                    case 3575610: {
                        if (!string4.equals((Object)"type")) break;
                        n3 = 1;
                        break;
                    }
                    case 3076010: {
                        if (!string4.equals((Object)"data")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        object6 = object5;
                        if (object5 == null) {
                            object6 = new ConcurrentHashMap();
                        }
                        object6.put((Object)((String)object3.getKey()), object3.getValue());
                        object3 = entry;
                        object5 = object6;
                        continue block18;
                    }
                    case 5: {
                        if (object6 instanceof String) {
                            string2 = (String)object6;
                            object3 = entry;
                            continue block18;
                        }
                        string2 = null;
                        object3 = entry;
                        continue block18;
                    }
                    case 4: {
                        object6 = object6 instanceof String ? (String)object6 : null;
                        object3 = entry;
                        if (object6 == null) continue block18;
                        object3 = SentryLevel.valueOf(object6.toUpperCase(Locale.ROOT));
                        continue block18;
                    }
                    case 3: {
                        object3 = entry;
                        if (!(object6 instanceof String)) continue block18;
                        object6 = JsonObjectReader.dateOrNull((String)object6, ((SentryOptions)object2).getLogger());
                        object3 = entry;
                        if (object6 == null) continue block18;
                        object4 = object6;
                        object3 = entry;
                        continue block18;
                    }
                    case 2: {
                        if (object6 instanceof String) {
                            object = (String)object6;
                            object3 = entry;
                            continue block18;
                        }
                        object = null;
                        object3 = entry;
                        continue block18;
                    }
                    case 1: {
                        if (object6 instanceof String) {
                            string3 = (String)object6;
                            object3 = entry;
                            continue block18;
                        }
                        string3 = null;
                        object3 = entry;
                        continue block18;
                    }
                    case 0: 
                }
                object6 = object6 instanceof Map ? (Map)object6 : null;
                object3 = entry;
                if (object6 == null) continue;
                object6 = object6.entrySet().iterator();
                while (true) {
                    object3 = entry;
                    if (!object6.hasNext()) continue block18;
                    object3 = (Map.Entry)object6.next();
                    if (object3.getKey() instanceof String && object3.getValue() != null) {
                        concurrentHashMap.put((Object)((String)object3.getKey()), object3.getValue());
                        continue;
                    }
                    ((SentryOptions)object2).getLogger().log(SentryLevel.WARNING, "Invalid key or null value in data map.", new Object[0]);
                }
            }
            object2 = new Breadcrumb((Date)object4);
            ((Breadcrumb)object2).message = string2;
            ((Breadcrumb)object2).type = string3;
            ((Breadcrumb)object2).data = concurrentHashMap;
            ((Breadcrumb)object2).category = object;
            ((Breadcrumb)object2).level = entry;
            ((Breadcrumb)object2).setUnknown((Map<String, Object>)object5);
            return object2;
            catch (Exception exception) {
                object3 = entry;
                continue;
            }
            break;
        }
    }

    public static Breadcrumb graphqlDataFetcher(String string2, String string3, String string4, String string5) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("graphql");
        breadcrumb.setCategory("graphql.fetcher");
        if (string2 != null) {
            breadcrumb.setData("path", string2);
        }
        if (string3 != null) {
            breadcrumb.setData("field", string3);
        }
        if (string4 != null) {
            breadcrumb.setData("type", string4);
        }
        if (string5 != null) {
            breadcrumb.setData("object_type", string5);
        }
        return breadcrumb;
    }

    public static Breadcrumb graphqlDataLoader(Iterable<?> iterator, Class<?> clazz, Class<?> clazz2, String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("graphql");
        breadcrumb.setCategory("graphql.data_loader");
        ArrayList arrayList = new ArrayList();
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)iterator.next().toString());
        }
        breadcrumb.setData("keys", arrayList);
        if (clazz != null) {
            breadcrumb.setData("key_type", clazz.getName());
        }
        if (clazz2 != null) {
            breadcrumb.setData("value_type", clazz2.getName());
        }
        if (string2 != null) {
            breadcrumb.setData("name", string2);
        }
        return breadcrumb;
    }

    public static Breadcrumb graphqlOperation(String string2, String string3, String string4) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("graphql");
        if (string2 != null) {
            breadcrumb.setData("operation_name", string2);
        }
        if (string3 != null) {
            breadcrumb.setData("operation_type", string3);
            breadcrumb.setCategory(string3);
        } else {
            breadcrumb.setCategory("graphql.operation");
        }
        if (string4 != null) {
            breadcrumb.setData("operation_id", string4);
        }
        return breadcrumb;
    }

    public static Breadcrumb http(String object, String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        object = UrlUtils.parse((String)object);
        breadcrumb.setType("http");
        breadcrumb.setCategory("http");
        if (((UrlUtils.UrlDetails)object).getUrl() != null) {
            breadcrumb.setData("url", ((UrlUtils.UrlDetails)object).getUrl());
        }
        breadcrumb.setData("method", string2.toUpperCase(Locale.ROOT));
        if (((UrlUtils.UrlDetails)object).getQuery() != null) {
            breadcrumb.setData("http.query", ((UrlUtils.UrlDetails)object).getQuery());
        }
        if (((UrlUtils.UrlDetails)object).getFragment() != null) {
            breadcrumb.setData("http.fragment", ((UrlUtils.UrlDetails)object).getFragment());
        }
        return breadcrumb;
    }

    public static Breadcrumb http(String object, String string2, Integer n2) {
        object = Breadcrumb.http((String)object, string2);
        if (n2 != null) {
            ((Breadcrumb)object).setData("status_code", n2);
        }
        return object;
    }

    public static Breadcrumb info(String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("info");
        breadcrumb.setMessage(string2);
        breadcrumb.setLevel(SentryLevel.INFO);
        return breadcrumb;
    }

    public static Breadcrumb navigation(String string2, String string3) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setCategory("navigation");
        breadcrumb.setType("navigation");
        breadcrumb.setData("from", string2);
        breadcrumb.setData("to", string3);
        return breadcrumb;
    }

    public static Breadcrumb query(String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("query");
        breadcrumb.setMessage(string2);
        return breadcrumb;
    }

    public static Breadcrumb transaction(String string2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("default");
        breadcrumb.setCategory("sentry.transaction");
        breadcrumb.setMessage(string2);
        return breadcrumb;
    }

    public static Breadcrumb ui(String string2, String string3) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("default");
        breadcrumb.setCategory("ui." + string2);
        breadcrumb.setMessage(string3);
        return breadcrumb;
    }

    public static Breadcrumb user(String string2, String string3) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("user");
        breadcrumb.setCategory(string2);
        breadcrumb.setMessage(string3);
        return breadcrumb;
    }

    public static Breadcrumb userInteraction(String string2, String string3, String string4) {
        return Breadcrumb.userInteraction(string2, string3, string4, (Map<String, Object>)Collections.emptyMap());
    }

    public static Breadcrumb userInteraction(String string2, String string32, String string4, String string5, Map<String, Object> map2) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("user");
        breadcrumb.setCategory("ui." + string2);
        if (string32 != null) {
            breadcrumb.setData("view.id", string32);
        }
        if (string4 != null) {
            breadcrumb.setData("view.class", string4);
        }
        if (string5 != null) {
            breadcrumb.setData("view.tag", string5);
        }
        for (String string32 : map2.entrySet()) {
            breadcrumb.getData().put((Object)((String)string32.getKey()), string32.getValue());
        }
        breadcrumb.setLevel(SentryLevel.INFO);
        return breadcrumb;
    }

    public static Breadcrumb userInteraction(String string2, String string3, String string4, Map<String, Object> map2) {
        return Breadcrumb.userInteraction(string2, string3, string4, null, map2);
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (Breadcrumb)object;
            if (!(this.timestamp.getTime() == ((Breadcrumb)object).timestamp.getTime() && Objects.equals(this.message, ((Breadcrumb)object).message) && Objects.equals(this.type, ((Breadcrumb)object).type) && Objects.equals(this.category, ((Breadcrumb)object).category) && this.level == ((Breadcrumb)object).level)) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getCategory() {
        return this.category;
    }

    public Object getData(String string2) {
        return this.data.get((Object)string2);
    }

    public Map<String, Object> getData() {
        return this.data;
    }

    public SentryLevel getLevel() {
        return this.level;
    }

    public String getMessage() {
        return this.message;
    }

    public Date getTimestamp() {
        return (Date)this.timestamp.clone();
    }

    public String getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public int hashCode() {
        return Objects.hash(this.timestamp, this.message, this.type, this.category, this.level);
    }

    public void removeData(String string2) {
        this.data.remove((Object)string2);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        objectWriter.name("timestamp").value(iLogger, this.timestamp);
        if (this.message != null) {
            objectWriter.name("message").value(this.message);
        }
        if (this.type != null) {
            objectWriter.name("type").value(this.type);
        }
        objectWriter.name("data").value(iLogger, this.data);
        if (this.category != null) {
            objectWriter.name("category").value(this.category);
        }
        if (this.level != null) {
            objectWriter.name("level").value(iLogger, this.level);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setCategory(String string2) {
        this.category = string2;
    }

    public void setData(String string2, Object object) {
        this.data.put((Object)string2, object);
    }

    public void setLevel(SentryLevel sentryLevel) {
        this.level = sentryLevel;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Breadcrumb> {
        @Override
        public Breadcrumb deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
            ConcurrentHashMap concurrentHashMap;
            ConcurrentHashMap concurrentHashMap2;
            Object object2;
            jsonObjectReader.beginObject();
            Date date = DateUtils.getCurrentDateTime();
            ConcurrentHashMap concurrentHashMap3 = new ConcurrentHashMap();
            String string2 = null;
            String string3 = null;
            ConcurrentHashMap concurrentHashMap4 = object2 = (concurrentHashMap2 = null);
            block18: while (true) {
                ConcurrentHashMap concurrentHashMap5;
                concurrentHashMap = object2;
                if (jsonObjectReader.peek() != JsonToken.NAME) break;
                object2 = jsonObjectReader.nextName();
                object2.hashCode();
                int n2 = object2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 954925063: {
                        if (!object2.equals((Object)"message")) break;
                        n3 = 5;
                        break;
                    }
                    case 102865796: {
                        if (!object2.equals((Object)"level")) break;
                        n3 = 4;
                        break;
                    }
                    case 55126294: {
                        if (!object2.equals((Object)"timestamp")) break;
                        n3 = 3;
                        break;
                    }
                    case 50511102: {
                        if (!object2.equals((Object)"category")) break;
                        n3 = 2;
                        break;
                    }
                    case 3575610: {
                        if (!object2.equals((Object)"type")) break;
                        n3 = 1;
                        break;
                    }
                    case 3076010: {
                        if (!object2.equals((Object)"data")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        concurrentHashMap5 = concurrentHashMap4;
                        if (concurrentHashMap4 == null) {
                            concurrentHashMap5 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)concurrentHashMap5, (String)object2);
                        object2 = concurrentHashMap;
                        concurrentHashMap4 = concurrentHashMap5;
                        continue block18;
                    }
                    case 5: {
                        string2 = jsonObjectReader.nextStringOrNull();
                        object2 = concurrentHashMap;
                        continue block18;
                    }
                    case 4: {
                        try {
                            object2 = new SentryLevel.Deserializer();
                            object2 = object2.deserialize(jsonObjectReader, (ILogger)object);
                        }
                        catch (Exception exception) {
                            object.log(SentryLevel.ERROR, exception, "Error when deserializing SentryLevel", new Object[0]);
                            object2 = concurrentHashMap;
                        }
                        continue block18;
                    }
                    case 3: {
                        concurrentHashMap5 = jsonObjectReader.nextDateOrNull((ILogger)object);
                        object2 = concurrentHashMap;
                        if (concurrentHashMap5 == null) continue block18;
                        date = concurrentHashMap5;
                        object2 = concurrentHashMap;
                        continue block18;
                    }
                    case 2: {
                        concurrentHashMap2 = jsonObjectReader.nextStringOrNull();
                        object2 = concurrentHashMap;
                        continue block18;
                    }
                    case 1: {
                        string3 = jsonObjectReader.nextStringOrNull();
                        object2 = concurrentHashMap;
                        continue block18;
                    }
                    case 0: 
                }
                concurrentHashMap5 = CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull());
                object2 = concurrentHashMap;
                if (concurrentHashMap5 == null) continue;
                concurrentHashMap3 = concurrentHashMap5;
                object2 = concurrentHashMap;
            }
            object = new Breadcrumb(date);
            Breadcrumb.access$002((Breadcrumb)object, string2);
            Breadcrumb.access$102((Breadcrumb)object, string3);
            Breadcrumb.access$202((Breadcrumb)object, (Map)concurrentHashMap3);
            Breadcrumb.access$302((Breadcrumb)object, (String)concurrentHashMap2);
            Breadcrumb.access$402((Breadcrumb)object, (SentryLevel)concurrentHashMap);
            ((Breadcrumb)object).setUnknown((Map<String, Object>)concurrentHashMap4);
            jsonObjectReader.endObject();
            return object;
        }
    }

    public static final class JsonKeys {
        public static final String CATEGORY = "category";
        public static final String DATA = "data";
        public static final String LEVEL = "level";
        public static final String MESSAGE = "message";
        public static final String TIMESTAMP = "timestamp";
        public static final String TYPE = "type";
    }
}

