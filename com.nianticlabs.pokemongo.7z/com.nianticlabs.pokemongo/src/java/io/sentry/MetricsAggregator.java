/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.nio.charset.Charset
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.NavigableMap
 *  java.util.Set
 *  java.util.concurrent.ConcurrentSkipListMap
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.zip.CRC32
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.IMetricsAggregator;
import io.sentry.ISentryExecutorService;
import io.sentry.MeasurementUnit;
import io.sentry.NoOpSentryExecutorService;
import io.sentry.SentryDateProvider;
import io.sentry.SentryExecutorService;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.metrics.CounterMetric;
import io.sentry.metrics.DistributionMetric;
import io.sentry.metrics.EncodedMetrics;
import io.sentry.metrics.GaugeMetric;
import io.sentry.metrics.IMetricsClient;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import io.sentry.metrics.MetricsHelper;
import io.sentry.metrics.SetMetric;
import java.io.Closeable;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.CRC32;

public final class MetricsAggregator
implements IMetricsAggregator,
Runnable,
Closeable {
    private static final Charset UTF8 = Charset.forName((String)"UTF-8");
    private final SentryOptions.BeforeEmitMetricCallback beforeEmitCallback;
    private final NavigableMap<Long, Map<String, Metric>> buckets = new ConcurrentSkipListMap();
    private final IMetricsClient client;
    private final SentryDateProvider dateProvider;
    private volatile ISentryExecutorService executorService;
    private volatile boolean flushScheduled = false;
    private volatile boolean isClosed = false;
    private final ILogger logger;
    private final int maxWeight;
    private final AtomicInteger totalBucketsWeight = new AtomicInteger();

    public MetricsAggregator(SentryOptions sentryOptions, IMetricsClient iMetricsClient) {
        this(iMetricsClient, sentryOptions.getLogger(), sentryOptions.getDateProvider(), 100000, sentryOptions.getBeforeEmitMetricCallback(), NoOpSentryExecutorService.getInstance());
    }

    public MetricsAggregator(IMetricsClient iMetricsClient, ILogger iLogger, SentryDateProvider sentryDateProvider, int n2, SentryOptions.BeforeEmitMetricCallback beforeEmitMetricCallback, ISentryExecutorService iSentryExecutorService) {
        this.client = iMetricsClient;
        this.logger = iLogger;
        this.dateProvider = sentryDateProvider;
        this.maxWeight = n2;
        this.beforeEmitCallback = beforeEmitMetricCallback;
        this.executorService = iSentryExecutorService;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void add(MetricType object, String string2, double d2, MeasurementUnit object2, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        int n2;
        String string3;
        block19: {
            Map<String, Metric> map3;
            Object object3;
            block17: {
                block20: {
                    block18: {
                        if (this.isClosed) {
                            return;
                        }
                        object3 = this.beforeEmitCallback;
                        if (object3 != null && !object3.execute(string2, map2)) {
                            return;
                        }
                        map3 = this.getOrAddTimeBucket(MetricsHelper.getTimeBucketKey(l2));
                        string3 = MetricsHelper.getMetricBucketKey(object, string2, object2, map2);
                        Map<String, Metric> map4 = map3;
                        // MONITORENTER : map4
                        object3 = (Metric)map3.get((Object)string3);
                        if (object3 == null) break block18;
                        n2 = ((Metric)object3).getWeight();
                        ((Metric)object3).add(d2);
                        n2 = ((Metric)object3).getWeight() - n2;
                        break block19;
                    }
                    n2 = 1.$SwitchMap$io$sentry$metrics$MetricType[object.ordinal()];
                    if (n2 == 1) break block20;
                    if (n2 != 2) {
                        if (n2 != 3) {
                            if (n2 != 4) {
                                string2 = new StringBuilder("Unknown MetricType: ");
                                object2 = new IllegalArgumentException(string2.append(object.name()).toString());
                                throw object2;
                            }
                            object3 = new SetMetric(string2, (MeasurementUnit)object2, map2);
                            ((Metric)object3).add((int)d2);
                            break block17;
                        } else {
                            object3 = new DistributionMetric(string2, d2, (MeasurementUnit)object2, map2);
                        }
                        break block17;
                    } else {
                        object3 = new GaugeMetric(string2, d2, (MeasurementUnit)object2, map2);
                    }
                    break block17;
                }
                object3 = new CounterMetric(string2, d2, (MeasurementUnit)object2, map2);
            }
            n2 = ((Metric)object3).getWeight();
            map3.put((Object)string3, object3);
        }
        this.totalBucketsWeight.addAndGet(n2);
        // MONITOREXIT : map4
        if (localMetricsAggregator != null) {
            if (object == MetricType.Set) {
                d2 = n2;
            }
            localMetricsAggregator.add(string3, (MetricType)((Object)object), string2, d2, (MeasurementUnit)object2, map2, l2);
        }
        boolean bl = this.isOverWeight();
        if (this.isClosed) return;
        if (!bl) {
            if (this.flushScheduled) return;
        }
        MetricsAggregator metricsAggregator = this;
        // MONITORENTER : metricsAggregator
        if (!this.isClosed) {
            if (this.executorService instanceof NoOpSentryExecutorService) {
                object = new SentryExecutorService();
                this.executorService = object;
            }
            this.flushScheduled = true;
            l2 = bl ? 0L : 5000L;
            this.executorService.schedule(this, l2);
        }
        // MONITOREXIT : metricsAggregator
    }

    private static int getBucketWeight(Map<String, Metric> iterator) {
        iterator = iterator.values().iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            n2 += ((Metric)iterator.next()).getWeight();
        }
        return n2;
    }

    private Set<Long> getFlushableBuckets(boolean bl) {
        if (bl) {
            return this.buckets.keySet();
        }
        long l2 = MetricsHelper.getTimeBucketKey(MetricsHelper.getCutoffTimestampMs(this.nowMillis()));
        return this.buckets.headMap((Object)l2, true).keySet();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Map<String, Metric> getOrAddTimeBucket(long l2) {
        NavigableMap<Long, Map<String, Metric>> navigableMap;
        Map map2;
        Map map3 = map2 = (Map)this.buckets.get((Object)l2);
        if (map2 != null) return map3;
        NavigableMap<Long, Map<String, Metric>> navigableMap2 = navigableMap = this.buckets;
        synchronized (navigableMap2) {
            map3 = map2 = (Map)this.buckets.get((Object)l2);
            if (map2 != null) return map3;
            map3 = new HashMap();
            this.buckets.put((Object)l2, (Object)map3);
            return map3;
        }
    }

    private boolean isOverWeight() {
        boolean bl = this.buckets.size() + this.totalBucketsWeight.get() >= this.maxWeight;
        return bl;
    }

    private long nowMillis() {
        return TimeUnit.NANOSECONDS.toMillis(this.dateProvider.now().nanoTimestamp());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        MetricsAggregator metricsAggregator = this;
        synchronized (metricsAggregator) {
            this.isClosed = true;
            this.executorService.close(0L);
        }
        this.flush(true);
    }

    @Override
    public void distribution(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        this.add(MetricType.Distribution, string2, d2, measurementUnit, map2, l2, localMetricsAggregator);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void flush(boolean bl) {
        Map map2;
        boolean bl2 = bl;
        if (!bl) {
            bl2 = bl;
            if (this.isOverWeight()) {
                this.logger.log(SentryLevel.INFO, "Metrics: total weight exceeded, flushing all buckets", new Object[0]);
                bl2 = true;
            }
        }
        if ((map2 = this.getFlushableBuckets(bl2)).isEmpty()) {
            this.logger.log(SentryLevel.DEBUG, "Metrics: nothing to flush", new Object[0]);
            return;
        }
        this.logger.log(SentryLevel.DEBUG, "Metrics: flushing " + map2.size() + " buckets", new Object[0]);
        HashMap hashMap = new HashMap();
        Iterator iterator = map2.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            long l2 = (Long)iterator.next();
            map2 = (Map)this.buckets.remove((Object)l2);
            if (map2 == null) continue;
            Map map3 = map2;
            synchronized (map3) {
                int n3 = MetricsAggregator.getBucketWeight((Map<String, Metric>)map2);
                this.totalBucketsWeight.addAndGet(-n3);
                n2 += map2.size();
                hashMap.put((Object)l2, (Object)map2);
            }
        }
        if (n2 == 0) {
            this.logger.log(SentryLevel.DEBUG, "Metrics: only empty buckets found", new Object[0]);
            return;
        }
        this.logger.log(SentryLevel.DEBUG, "Metrics: capturing metrics", new Object[0]);
        this.client.captureMetrics(new EncodedMetrics((Map<Long, Map<String, Metric>>)hashMap));
    }

    @Override
    public void gauge(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        this.add(MetricType.Gauge, string2, d2, measurementUnit, map2, l2, localMetricsAggregator);
    }

    @Override
    public void increment(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        this.add(MetricType.Counter, string2, d2, measurementUnit, map2, l2, localMetricsAggregator);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        this.flush(false);
        MetricsAggregator metricsAggregator = this;
        synchronized (metricsAggregator) {
            if (!this.isClosed) {
                this.executorService.schedule(this, 5000L);
            }
            return;
        }
    }

    @Override
    public void set(String string2, int n2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        this.add(MetricType.Set, string2, n2, measurementUnit, map2, l2, localMetricsAggregator);
    }

    @Override
    public void set(String string2, String string3, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
        byte[] byArray = string3.getBytes(UTF8);
        string3 = new CRC32();
        string3.update(byArray, 0, byArray.length);
        int n2 = (int)string3.getValue();
        this.add(MetricType.Set, string2, n2, measurementUnit, map2, l2, localMetricsAggregator);
    }

    @Override
    public void timing(String string2, Runnable runnable, MeasurementUnit.Duration duration, Map<String, String> map2, LocalMetricsAggregator localMetricsAggregator) {
        long l2 = this.nowMillis();
        long l3 = System.nanoTime();
        try {
            runnable.run();
            return;
        }
        finally {
            double d2 = MetricsHelper.convertNanosTo(duration, System.nanoTime() - l3);
            this.add(MetricType.Distribution, string2, d2, duration, map2, l2, localMetricsAggregator);
        }
    }
}

