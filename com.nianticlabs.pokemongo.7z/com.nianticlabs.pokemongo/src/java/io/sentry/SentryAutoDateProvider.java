/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.SentryDate;
import io.sentry.SentryDateProvider;
import io.sentry.SentryInstantDateProvider;
import io.sentry.SentryNanotimeDateProvider;
import io.sentry.util.Platform;

public final class SentryAutoDateProvider
implements SentryDateProvider {
    private final SentryDateProvider dateProvider = SentryAutoDateProvider.checkInstantAvailabilityAndPrecision() ? new SentryInstantDateProvider() : new SentryNanotimeDateProvider();

    private static boolean checkInstantAvailabilityAndPrecision() {
        boolean bl = Platform.isJvm() && Platform.isJavaNinePlus();
        return bl;
    }

    @Override
    public SentryDate now() {
        return this.dateProvider.now();
    }
}

