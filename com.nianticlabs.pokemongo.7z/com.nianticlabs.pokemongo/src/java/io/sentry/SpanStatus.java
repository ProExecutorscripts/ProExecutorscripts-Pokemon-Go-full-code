/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.Locale
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import java.io.IOException;
import java.util.Locale;

public enum SpanStatus implements JsonSerializable
{
    OK(200, 299),
    CANCELLED(499),
    INTERNAL_ERROR(500),
    UNKNOWN(500),
    UNKNOWN_ERROR(500),
    INVALID_ARGUMENT(400),
    DEADLINE_EXCEEDED(504),
    NOT_FOUND(404),
    ALREADY_EXISTS(409),
    PERMISSION_DENIED(403),
    RESOURCE_EXHAUSTED(429),
    FAILED_PRECONDITION(400),
    ABORTED(409),
    OUT_OF_RANGE(400),
    UNIMPLEMENTED(501),
    UNAVAILABLE(503),
    DATA_LOSS(500),
    UNAUTHENTICATED(401);

    private final int maxHttpStatusCode;
    private final int minHttpStatusCode;

    private SpanStatus(int n3) {
        this.minHttpStatusCode = n3;
        this.maxHttpStatusCode = n3;
    }

    private SpanStatus(int n3, int n4) {
        this.minHttpStatusCode = n3;
        this.maxHttpStatusCode = n4;
    }

    public static SpanStatus fromHttpStatusCode(int n2) {
        for (SpanStatus spanStatus : SpanStatus.values()) {
            if (!spanStatus.matches(n2)) continue;
            return spanStatus;
        }
        return null;
    }

    public static SpanStatus fromHttpStatusCode(Integer object, SpanStatus spanStatus) {
        if ((object = object != null ? SpanStatus.fromHttpStatusCode(object) : spanStatus) != null) {
            spanStatus = object;
        }
        return spanStatus;
    }

    private boolean matches(int n2) {
        boolean bl = n2 >= this.minHttpStatusCode && n2 <= this.maxHttpStatusCode;
        return bl;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.value(this.name().toLowerCase(Locale.ROOT));
    }

    public static final class Deserializer
    implements JsonDeserializer<SpanStatus> {
        @Override
        public SpanStatus deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            return SpanStatus.valueOf(jsonObjectReader.nextString().toUpperCase(Locale.ROOT));
        }
    }
}

