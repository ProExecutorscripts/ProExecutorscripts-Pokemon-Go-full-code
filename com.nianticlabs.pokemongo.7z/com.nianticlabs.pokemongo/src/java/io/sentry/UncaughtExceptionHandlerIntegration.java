/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry;

import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.Integration;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.UncaughtExceptionHandler;
import io.sentry.exception.ExceptionMechanismException;
import io.sentry.hints.BlockingFlushHint;
import io.sentry.hints.EventDropReason;
import io.sentry.hints.SessionEnd;
import io.sentry.hints.TransactionEnd;
import io.sentry.protocol.Mechanism;
import io.sentry.protocol.SentryId;
import io.sentry.util.HintUtils;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.util.concurrent.atomic.AtomicReference;

public final class UncaughtExceptionHandlerIntegration
implements Integration,
Thread.UncaughtExceptionHandler,
Closeable {
    private Thread.UncaughtExceptionHandler defaultExceptionHandler;
    private IHub hub;
    private SentryOptions options;
    private boolean registered = false;
    private final UncaughtExceptionHandler threadAdapter;

    public UncaughtExceptionHandlerIntegration() {
        this(UncaughtExceptionHandler.Adapter.getInstance());
    }

    UncaughtExceptionHandlerIntegration(UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.threadAdapter = Objects.requireNonNull(uncaughtExceptionHandler, "threadAdapter is required.");
    }

    static Throwable getUnhandledThrowable(Thread thread, Throwable throwable) {
        Mechanism mechanism = new Mechanism();
        mechanism.setHandled(false);
        mechanism.setType("UncaughtExceptionHandler");
        return new ExceptionMechanismException(mechanism, throwable, thread);
    }

    public void close() {
        if (this == this.threadAdapter.getDefaultUncaughtExceptionHandler()) {
            this.threadAdapter.setDefaultUncaughtExceptionHandler(this.defaultExceptionHandler);
            SentryOptions sentryOptions = this.options;
            if (sentryOptions != null) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "UncaughtExceptionHandlerIntegration removed.", new Object[0]);
            }
        }
    }

    @Override
    public final void register(IHub object, SentryOptions sentryOptions) {
        if (this.registered) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Attempt to register a UncaughtExceptionHandlerIntegration twice.", new Object[0]);
            return;
        }
        this.registered = true;
        this.hub = Objects.requireNonNull(object, "Hub is required");
        this.options = object = Objects.requireNonNull(sentryOptions, "SentryOptions is required");
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "UncaughtExceptionHandlerIntegration enabled: %s", this.options.isEnableUncaughtExceptionHandler());
        if (this.options.isEnableUncaughtExceptionHandler()) {
            object = this.threadAdapter.getDefaultUncaughtExceptionHandler();
            if (object != null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "default UncaughtExceptionHandler class='" + object.getClass().getName() + "'", new Object[0]);
                this.defaultExceptionHandler = object;
            }
            this.threadAdapter.setDefaultUncaughtExceptionHandler(this);
            this.options.getLogger().log(SentryLevel.DEBUG, "UncaughtExceptionHandlerIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void uncaughtException(Thread thread, Throwable throwable) {
        Object object = this.options;
        if (object == null) return;
        if (this.hub == null) return;
        ((SentryOptions)object).getLogger().log(SentryLevel.INFO, "Uncaught exception received.", new Object[0]);
        try {
            UncaughtExceptionHint uncaughtExceptionHint = new UncaughtExceptionHint(this.options.getFlushTimeoutMillis(), this.options.getLogger());
            Throwable throwable2 = UncaughtExceptionHandlerIntegration.getUnhandledThrowable(thread, throwable);
            object = new SentryEvent(throwable2);
            ((SentryEvent)object).setLevel(SentryLevel.FATAL);
            if (this.hub.getTransaction() == null && ((SentryBaseEvent)object).getEventId() != null) {
                uncaughtExceptionHint.setFlushable(((SentryBaseEvent)object).getEventId());
            }
            Hint hint = HintUtils.createWithTypeCheckHint(uncaughtExceptionHint);
            boolean bl = this.hub.captureEvent((SentryEvent)object, hint).equals(SentryId.EMPTY_ID);
            EventDropReason eventDropReason = HintUtils.getEventDropReason(hint);
            if (!(bl && !EventDropReason.MULTITHREADED_DEDUPLICATION.equals((Object)eventDropReason) || uncaughtExceptionHint.waitFlush())) {
                this.options.getLogger().log(SentryLevel.WARNING, "Timed out waiting to flush event to disk before crashing. Event: %s", ((SentryBaseEvent)object).getEventId());
            }
        }
        catch (Throwable throwable3) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error sending uncaught exception to Sentry.", throwable3);
        }
        if (this.defaultExceptionHandler != null) {
            this.options.getLogger().log(SentryLevel.INFO, "Invoking inner uncaught exception handler.", new Object[0]);
            this.defaultExceptionHandler.uncaughtException(thread, throwable);
            return;
        }
        if (!this.options.isPrintUncaughtStackTrace()) return;
        throwable.printStackTrace();
    }

    public static class UncaughtExceptionHint
    extends BlockingFlushHint
    implements SessionEnd,
    TransactionEnd {
        private final AtomicReference<SentryId> flushableEventId = new AtomicReference();

        public UncaughtExceptionHint(long l2, ILogger iLogger) {
            super(l2, iLogger);
        }

        @Override
        public boolean isFlushable(SentryId sentryId) {
            SentryId sentryId2 = (SentryId)this.flushableEventId.get();
            boolean bl = sentryId2 != null && sentryId2.equals(sentryId);
            return bl;
        }

        @Override
        public void setFlushable(SentryId sentryId) {
            this.flushableEventId.set((Object)sentryId);
        }
    }
}

