/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package io.sentry;

import io.sentry.Dsn;
import io.sentry.SentryOptions;
import java.util.Locale;

public final class DsnUtil {
    public static boolean urlContainsDsnHost(SentryOptions object, String string2) {
        if (object == null) {
            return false;
        }
        if (string2 == null) {
            return false;
        }
        if ((object = ((SentryOptions)object).getDsn()) == null) {
            return false;
        }
        if ((object = new Dsn((String)object).getSentryUri().getHost()) == null) {
            return false;
        }
        return string2.toLowerCase(Locale.ROOT).contains((CharSequence)object.toLowerCase(Locale.ROOT));
    }
}

