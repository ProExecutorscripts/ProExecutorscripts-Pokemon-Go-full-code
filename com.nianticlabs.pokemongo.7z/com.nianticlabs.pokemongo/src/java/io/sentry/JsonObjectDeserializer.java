/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 */
package io.sentry;

import io.sentry.JsonObjectDeserializer$$ExternalSyntheticLambda0;
import io.sentry.JsonObjectDeserializer$$ExternalSyntheticLambda1;
import io.sentry.JsonObjectDeserializer$$ExternalSyntheticLambda2;
import io.sentry.JsonObjectDeserializer$$ExternalSyntheticLambda3;
import io.sentry.JsonObjectReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class JsonObjectDeserializer {
    private final ArrayList<Token> tokens = new ArrayList();

    private Token getCurrentToken() {
        if (this.tokens.isEmpty()) {
            return null;
        }
        ArrayList<Token> arrayList = this.tokens;
        return (Token)arrayList.get(arrayList.size() - 1);
    }

    private boolean handleArrayOrMapEnd() {
        if (this.hasOneToken()) {
            return true;
        }
        Token token = this.getCurrentToken();
        this.popCurrentToken();
        if (this.getCurrentToken() instanceof TokenName) {
            TokenName tokenName = (TokenName)this.getCurrentToken();
            this.popCurrentToken();
            TokenMap tokenMap = (TokenMap)this.getCurrentToken();
            if (tokenName != null && token != null && tokenMap != null) {
                tokenMap.value.put((Object)tokenName.value, token.getValue());
            }
        } else if (this.getCurrentToken() instanceof TokenArray) {
            TokenArray tokenArray = (TokenArray)this.getCurrentToken();
            if (token != null && tokenArray != null) {
                tokenArray.value.add(token.getValue());
            }
        }
        return false;
    }

    private boolean handlePrimitive(NextValue object) throws IOException {
        object = object.nextValue();
        if (this.getCurrentToken() == null && object != null) {
            this.pushCurrentToken(new TokenPrimitive(object));
            return true;
        }
        if (this.getCurrentToken() instanceof TokenName) {
            TokenName tokenName = (TokenName)this.getCurrentToken();
            this.popCurrentToken();
            ((TokenMap)this.getCurrentToken()).value.put((Object)tokenName.value, object);
        } else if (this.getCurrentToken() instanceof TokenArray) {
            ((TokenArray)this.getCurrentToken()).value.add(object);
        }
        return false;
    }

    private boolean hasOneToken() {
        int n2 = this.tokens.size();
        boolean bl = true;
        if (n2 != 1) {
            bl = false;
        }
        return bl;
    }

    static /* synthetic */ Object lambda$parse$0(JsonObjectReader jsonObjectReader) throws IOException {
        return jsonObjectReader.nextString();
    }

    static /* synthetic */ Object lambda$parse$2(JsonObjectReader jsonObjectReader) throws IOException {
        return jsonObjectReader.nextBoolean();
    }

    static /* synthetic */ Object lambda$parse$3() throws IOException {
        return null;
    }

    private Object nextNumber(JsonObjectReader jsonObjectReader) throws IOException {
        int n2;
        try {
            n2 = jsonObjectReader.nextInt();
        }
        catch (Exception exception) {
            double d2;
            try {
                d2 = jsonObjectReader.nextDouble();
            }
            catch (Exception exception2) {
                return jsonObjectReader.nextLong();
            }
            return d2;
        }
        return n2;
    }

    private void parse(JsonObjectReader jsonObjectReader) throws IOException {
        boolean bl;
        block13: {
            switch (1.$SwitchMap$io$sentry$vendor$gson$stream$JsonToken[jsonObjectReader.peek().ordinal()]) {
                default: {
                    break;
                }
                case 10: {
                    bl = true;
                    break block13;
                }
                case 9: {
                    jsonObjectReader.nextNull();
                    bl = this.handlePrimitive(new JsonObjectDeserializer$$ExternalSyntheticLambda3());
                    break block13;
                }
                case 8: {
                    bl = this.handlePrimitive(new JsonObjectDeserializer$$ExternalSyntheticLambda2(jsonObjectReader));
                    break block13;
                }
                case 7: {
                    bl = this.handlePrimitive(new JsonObjectDeserializer$$ExternalSyntheticLambda1(this, jsonObjectReader));
                    break block13;
                }
                case 6: {
                    bl = this.handlePrimitive(new JsonObjectDeserializer$$ExternalSyntheticLambda0(jsonObjectReader));
                    break block13;
                }
                case 5: {
                    this.pushCurrentToken(new TokenName(jsonObjectReader.nextName()));
                    break;
                }
                case 4: {
                    jsonObjectReader.endObject();
                    bl = this.handleArrayOrMapEnd();
                    break block13;
                }
                case 3: {
                    jsonObjectReader.beginObject();
                    this.pushCurrentToken(new TokenMap());
                    break;
                }
                case 2: {
                    jsonObjectReader.endArray();
                    bl = this.handleArrayOrMapEnd();
                    break block13;
                }
                case 1: {
                    jsonObjectReader.beginArray();
                    this.pushCurrentToken(new TokenArray());
                }
            }
            bl = false;
        }
        if (!bl) {
            this.parse(jsonObjectReader);
        }
    }

    private void popCurrentToken() {
        if (this.tokens.isEmpty()) {
            return;
        }
        ArrayList<Token> arrayList = this.tokens;
        arrayList.remove(arrayList.size() - 1);
    }

    private void pushCurrentToken(Token token) {
        this.tokens.add((Object)token);
    }

    public Object deserialize(JsonObjectReader object) throws IOException {
        this.parse((JsonObjectReader)object);
        object = this.getCurrentToken();
        if (object != null) {
            return object.getValue();
        }
        return null;
    }

    /* synthetic */ Object lambda$parse$1$io-sentry-JsonObjectDeserializer(JsonObjectReader jsonObjectReader) throws IOException {
        return this.nextNumber(jsonObjectReader);
    }

    private static interface NextValue {
        public Object nextValue() throws IOException;
    }

    private static interface Token {
        public Object getValue();
    }

    private static final class TokenArray
    implements Token {
        final ArrayList<Object> value = new ArrayList();

        private TokenArray() {
        }

        @Override
        public Object getValue() {
            return this.value;
        }
    }

    private static final class TokenMap
    implements Token {
        final HashMap<String, Object> value = new HashMap();

        private TokenMap() {
        }

        @Override
        public Object getValue() {
            return this.value;
        }
    }

    private static final class TokenName
    implements Token {
        final String value;

        TokenName(String string2) {
            this.value = string2;
        }

        @Override
        public Object getValue() {
            return this.value;
        }
    }

    private static final class TokenPrimitive
    implements Token {
        final Object value;

        TokenPrimitive(Object object) {
            this.value = object;
        }

        @Override
        public Object getValue() {
            return this.value;
        }
    }
}

