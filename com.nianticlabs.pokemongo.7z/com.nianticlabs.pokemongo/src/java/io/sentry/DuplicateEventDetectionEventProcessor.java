/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package io.sentry;

import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public final class DuplicateEventDetectionEventProcessor
implements EventProcessor {
    private final Map<Throwable, Object> capturedObjects = Collections.synchronizedMap((Map)new WeakHashMap());
    private final SentryOptions options;

    public DuplicateEventDetectionEventProcessor(SentryOptions sentryOptions) {
        this.options = Objects.requireNonNull(sentryOptions, "options are required");
    }

    private static List<Throwable> allCauses(Throwable throwable) {
        ArrayList arrayList = new ArrayList();
        while (throwable.getCause() != null) {
            arrayList.add((Object)throwable.getCause());
            throwable = throwable.getCause();
        }
        return arrayList;
    }

    private static <T> boolean containsAnyKey(Map<T, Object> map2, List<T> iterator) {
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            if (!map2.containsKey(iterator.next())) continue;
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        if (!this.options.isEnableDeduplication()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Event deduplication is disabled.", new Object[0]);
            return sentryEvent;
        }
        hint = sentryEvent.getThrowable();
        if (hint == null) return sentryEvent;
        if (!this.capturedObjects.containsKey((Object)hint) && !DuplicateEventDetectionEventProcessor.containsAnyKey(this.capturedObjects, DuplicateEventDetectionEventProcessor.allCauses((Throwable)hint))) {
            this.capturedObjects.put((Object)hint, null);
            return sentryEvent;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Duplicate Exception detected. Event %s will be discarded.", sentryEvent.getEventId());
        return null;
    }
}

