/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FilenameFilter
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.Queue
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.TimeUnit
 */
package io.sentry;

import io.sentry.CircularFifoQueue;
import io.sentry.DataCategory;
import io.sentry.DirectoryProcessor$$ExternalSyntheticLambda0;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SynchronizedQueue;
import io.sentry.hints.Cached;
import io.sentry.hints.Enqueable;
import io.sentry.hints.Flushable;
import io.sentry.hints.Retryable;
import io.sentry.hints.SubmissionResult;
import io.sentry.transport.RateLimiter;
import io.sentry.util.HintUtils;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Queue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
abstract class DirectoryProcessor {
    private static final long ENVELOPE_PROCESSING_DELAY = 100L;
    private final long flushTimeoutMillis;
    private final IHub hub;
    private final ILogger logger;
    private final Queue<String> processedEnvelopes;

    DirectoryProcessor(IHub iHub, ILogger iLogger, long l2, int n2) {
        this.hub = iHub;
        this.logger = iLogger;
        this.flushTimeoutMillis = l2;
        this.processedEnvelopes = SynchronizedQueue.synchronizedQueue(new CircularFifoQueue(n2));
    }

    protected abstract boolean isRelevantFileName(String var1);

    /* synthetic */ boolean lambda$processDirectory$0$io-sentry-DirectoryProcessor(File file, String string2) {
        return this.isRelevantFileName(string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void processDirectory(File file) {
        this.logger.log(SentryLevel.DEBUG, "Processing dir. %s", file.getAbsolutePath());
        if (!file.exists()) {
            this.logger.log(SentryLevel.WARNING, "Directory '%s' doesn't exist. No cached events to send.", file.getAbsolutePath());
            return;
        }
        if (!file.isDirectory()) {
            this.logger.log(SentryLevel.ERROR, "Cache dir %s is not a directory.", file.getAbsolutePath());
            return;
        }
        File[] fileArray = file.listFiles();
        if (fileArray == null) {
            this.logger.log(SentryLevel.ERROR, "Cache dir %s is null.", file.getAbsolutePath());
            return;
        }
        DirectoryProcessor$$ExternalSyntheticLambda0 directoryProcessor$$ExternalSyntheticLambda0 = new DirectoryProcessor$$ExternalSyntheticLambda0(this);
        File[] fileArray2 = file.listFiles((FilenameFilter)directoryProcessor$$ExternalSyntheticLambda0);
        ILogger iLogger = this.logger;
        Object object = SentryLevel.DEBUG;
        int n2 = fileArray2 != null ? fileArray2.length : 0;
        iLogger.log((SentryLevel)object, "Processing %d items from cache dir %s", n2, file.getAbsolutePath());
        for (File file2 : fileArray) {
            try {
                if (!file2.isFile()) {
                    this.logger.log(SentryLevel.DEBUG, "File %s is not a File.", file2.getAbsolutePath());
                    continue;
                }
                String string2 = file2.getAbsolutePath();
                if (this.processedEnvelopes.contains((Object)string2)) {
                    this.logger.log(SentryLevel.DEBUG, "File '%s' has already been processed so it will not be processed again.", string2);
                    continue;
                }
                object = this.hub.getRateLimiter();
                if (object != null && ((RateLimiter)object).isActiveForCategory(DataCategory.All)) {
                    this.logger.log(SentryLevel.INFO, "DirectoryProcessor, rate limiting active.", new Object[0]);
                    return;
                }
                this.logger.log(SentryLevel.DEBUG, "Processing file: %s", string2);
                object = new SendCachedEnvelopeHint(this.flushTimeoutMillis, this.logger, string2, this.processedEnvelopes);
                this.processFile(file2, HintUtils.createWithTypeCheckHint(object));
                Thread.sleep((long)100L);
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.ERROR, throwable, "Failed processing '%s'", file.getAbsolutePath());
                return;
            }
        }
    }

    protected abstract void processFile(File var1, Hint var2);

    private static final class SendCachedEnvelopeHint
    implements Cached,
    Retryable,
    SubmissionResult,
    Flushable,
    Enqueable {
        private final String filePath;
        private final long flushTimeoutMillis;
        private final CountDownLatch latch;
        private final ILogger logger;
        private final Queue<String> processedEnvelopes;
        boolean retry = false;
        boolean succeeded = false;

        public SendCachedEnvelopeHint(long l2, ILogger iLogger, String string2, Queue<String> queue) {
            this.flushTimeoutMillis = l2;
            this.filePath = string2;
            this.processedEnvelopes = queue;
            this.latch = new CountDownLatch(1);
            this.logger = iLogger;
        }

        @Override
        public boolean isRetry() {
            return this.retry;
        }

        @Override
        public boolean isSuccess() {
            return this.succeeded;
        }

        @Override
        public void markEnqueued() {
            this.processedEnvelopes.add((Object)this.filePath);
        }

        @Override
        public void setResult(boolean bl) {
            this.succeeded = bl;
            this.latch.countDown();
        }

        @Override
        public void setRetry(boolean bl) {
            this.retry = bl;
        }

        @Override
        public boolean waitFlush() {
            try {
                boolean bl = this.latch.await(this.flushTimeoutMillis, TimeUnit.MILLISECONDS);
                return bl;
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
                this.logger.log(SentryLevel.ERROR, "Exception while awaiting on lock.", interruptedException);
                return false;
            }
        }
    }
}

