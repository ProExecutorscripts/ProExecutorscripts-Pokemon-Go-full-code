/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.security.SecureRandom
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry;

import io.sentry.AsyncHttpTransportFactory;
import io.sentry.Attachment;
import io.sentry.BackfillingEventProcessor;
import io.sentry.Baggage;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.DataCategory;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.IMetricsAggregator;
import io.sentry.IScope;
import io.sentry.ISentryClient;
import io.sentry.ISpan;
import io.sentry.ITransportFactory;
import io.sentry.MetricsAggregator;
import io.sentry.NoOpTransportFactory;
import io.sentry.ProfilingTraceData;
import io.sentry.RequestDetailsResolver;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryClient$$ExternalSyntheticLambda0;
import io.sentry.SentryClient$$ExternalSyntheticLambda1;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeHeader;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.TransactionContext;
import io.sentry.UserFeedback;
import io.sentry.clientreport.DiscardReason;
import io.sentry.exception.SentryEnvelopeException;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.Backfillable;
import io.sentry.hints.DiskFlushNotification;
import io.sentry.hints.TransactionEnd;
import io.sentry.metrics.EncodedMetrics;
import io.sentry.metrics.IMetricsClient;
import io.sentry.metrics.NoopMetricsAggregator;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.transport.ITransport;
import io.sentry.transport.RateLimiter;
import io.sentry.util.CheckInUtils;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import io.sentry.util.TracingUtils;
import java.io.Closeable;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryClient
implements ISentryClient,
IMetricsClient {
    static final String SENTRY_PROTOCOL_VERSION = "7";
    private boolean enabled;
    private final IMetricsAggregator metricsAggregator;
    private final SentryOptions options;
    private final SecureRandom random;
    private final SortBreadcrumbsByDate sortBreadcrumbsByDate;
    private final ITransport transport;

    SentryClient(SentryOptions sentryOptions) {
        Object var3_2 = null;
        this.sortBreadcrumbsByDate = new SortBreadcrumbsByDate();
        this.options = Objects.requireNonNull(sentryOptions, "SentryOptions is required.");
        this.enabled = true;
        ITransportFactory iTransportFactory = sentryOptions.getTransportFactory();
        Object object = iTransportFactory;
        if (iTransportFactory instanceof NoOpTransportFactory) {
            object = new AsyncHttpTransportFactory();
            sentryOptions.setTransportFactory((ITransportFactory)object);
        }
        this.transport = object.create(sentryOptions, new RequestDetailsResolver(sentryOptions).resolve());
        object = sentryOptions.isEnableMetrics() ? new MetricsAggregator(sentryOptions, this) : NoopMetricsAggregator.getInstance();
        this.metricsAggregator = object;
        sentryOptions = sentryOptions.getSampleRate() == null ? var3_2 : new SecureRandom();
        this.random = sentryOptions;
    }

    private void addScopeAttachmentsToHint(IScope iScope, Hint hint) {
        if (iScope != null) {
            hint.addAttachments(iScope.getAttachments());
        }
    }

    private CheckIn applyScope(CheckIn checkIn, IScope iScope) {
        if (iScope != null) {
            ISpan iSpan = iScope.getSpan();
            if (checkIn.getContexts().getTrace() == null) {
                if (iSpan == null) {
                    checkIn.getContexts().setTrace(TransactionContext.fromPropagationContext(iScope.getPropagationContext()));
                } else {
                    checkIn.getContexts().setTrace(iSpan.getSpanContext());
                }
            }
        }
        return checkIn;
    }

    private <T extends SentryBaseEvent> T applyScope(T t2, IScope iScope) {
        if (iScope != null) {
            if (t2.getRequest() == null) {
                t2.setRequest(iScope.getRequest());
            }
            if (t2.getUser() == null) {
                t2.setUser(iScope.getUser());
            }
            if (t2.getTags() == null) {
                t2.setTags((Map<String, String>)new HashMap(iScope.getTags()));
            } else {
                for (Map.Entry entry : iScope.getTags().entrySet()) {
                    if (t2.getTags().containsKey(entry.getKey())) continue;
                    t2.getTags().put((Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
                }
            }
            if (t2.getBreadcrumbs() == null) {
                t2.setBreadcrumbs((List<Breadcrumb>)new ArrayList(iScope.getBreadcrumbs()));
            } else {
                this.sortBreadcrumbsByDate(t2, (Collection<Breadcrumb>)iScope.getBreadcrumbs());
            }
            if (t2.getExtras() == null) {
                t2.setExtras((Map<String, Object>)new HashMap(iScope.getExtras()));
            } else {
                for (Map.Entry entry : iScope.getExtras().entrySet()) {
                    if (t2.getExtras().containsKey(entry.getKey())) continue;
                    t2.getExtras().put((Object)((String)entry.getKey()), entry.getValue());
                }
            }
            Object object = t2.getContexts();
            for (Map.Entry entry : new Contexts(iScope.getContexts()).entrySet()) {
                if (object.containsKey(entry.getKey())) continue;
                object.put((Object)((String)entry.getKey()), entry.getValue());
            }
        }
        return t2;
    }

    private SentryEvent applyScope(SentryEvent sentryEvent, IScope iScope, Hint hint) {
        Object object = sentryEvent;
        if (iScope != null) {
            this.applyScope(sentryEvent, iScope);
            if (sentryEvent.getTransaction() == null) {
                sentryEvent.setTransaction(iScope.getTransactionName());
            }
            if (sentryEvent.getFingerprints() == null) {
                sentryEvent.setFingerprints(iScope.getFingerprint());
            }
            if (iScope.getLevel() != null) {
                sentryEvent.setLevel(iScope.getLevel());
            }
            object = iScope.getSpan();
            if (sentryEvent.getContexts().getTrace() == null) {
                if (object == null) {
                    sentryEvent.getContexts().setTrace(TransactionContext.fromPropagationContext(iScope.getPropagationContext()));
                } else {
                    sentryEvent.getContexts().setTrace(object.getSpanContext());
                }
            }
            object = this.processEvent(sentryEvent, hint, iScope.getEventProcessors());
        }
        return object;
    }

    private SentryEnvelope buildEnvelope(CheckIn checkIn, TraceContext traceContext) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)SentryEnvelopeItem.fromCheckIn(this.options.getSerializer(), checkIn));
        return new SentryEnvelope(new SentryEnvelopeHeader(checkIn.getCheckInId(), this.options.getSdkVersion(), traceContext), (Iterable<SentryEnvelopeItem>)arrayList);
    }

    private SentryEnvelope buildEnvelope(SentryBaseEvent object3, List<Attachment> iterator, Session object2, TraceContext traceContext, ProfilingTraceData profilingTraceData) throws IOException, SentryEnvelopeException {
        ArrayList arrayList = new ArrayList();
        if (object3 != null) {
            arrayList.add((Object)SentryEnvelopeItem.fromEvent(this.options.getSerializer(), (SentryBaseEvent)object3));
            object3 = ((SentryBaseEvent)object3).getEventId();
        } else {
            object3 = null;
        }
        if (object2 != null) {
            arrayList.add((Object)SentryEnvelopeItem.fromSession(this.options.getSerializer(), (Session)object2));
        }
        object2 = object3;
        if (profilingTraceData != null) {
            arrayList.add((Object)SentryEnvelopeItem.fromProfilingTrace(profilingTraceData, this.options.getMaxTraceFileSize(), this.options.getSerializer()));
            object2 = object3;
            if (object3 == null) {
                object2 = new SentryId(profilingTraceData.getProfileId());
            }
        }
        if (iterator != null) {
            for (Object object3 : iterator) {
                arrayList.add((Object)SentryEnvelopeItem.fromAttachment(this.options.getSerializer(), this.options.getLogger(), (Attachment)object3, this.options.getMaxAttachmentSize()));
            }
        }
        if (!arrayList.isEmpty()) {
            return new SentryEnvelope(new SentryEnvelopeHeader((SentryId)object2, this.options.getSdkVersion(), traceContext), (Iterable<SentryEnvelopeItem>)arrayList);
        }
        return null;
    }

    private SentryEnvelope buildEnvelope(UserFeedback userFeedback) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)SentryEnvelopeItem.fromUserFeedback(this.options.getSerializer(), userFeedback));
        return new SentryEnvelope(new SentryEnvelopeHeader(userFeedback.getEventId(), this.options.getSdkVersion()), (Iterable<SentryEnvelopeItem>)arrayList);
    }

    private SentryEvent executeBeforeSend(SentryEvent sentryEvent, Hint hint) {
        SentryOptions.BeforeSendCallback beforeSendCallback = this.options.getBeforeSend();
        SentryEvent sentryEvent2 = sentryEvent;
        if (beforeSendCallback != null) {
            try {
                sentryEvent2 = beforeSendCallback.execute(sentryEvent, hint);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "The BeforeSend callback threw an exception. It will be added as breadcrumb and continue.", throwable);
                sentryEvent2 = null;
            }
        }
        return sentryEvent2;
    }

    private SentryTransaction executeBeforeSendTransaction(SentryTransaction sentryTransaction, Hint hint) {
        SentryOptions.BeforeSendTransactionCallback beforeSendTransactionCallback = this.options.getBeforeSendTransaction();
        SentryTransaction sentryTransaction2 = sentryTransaction;
        if (beforeSendTransactionCallback != null) {
            try {
                sentryTransaction2 = beforeSendTransactionCallback.execute(sentryTransaction, hint);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "The BeforeSendTransaction callback threw an exception. It will be added as breadcrumb and continue.", throwable);
                sentryTransaction2 = null;
            }
        }
        return sentryTransaction2;
    }

    private List<Attachment> filterForTransaction(List<Attachment> object) {
        if (object == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        Iterator iterator = object.iterator();
        while (iterator.hasNext()) {
            object = (Attachment)iterator.next();
            if (!((Attachment)object).isAddToTransactions()) continue;
            arrayList.add(object);
        }
        return arrayList;
    }

    private List<Attachment> getAttachments(Hint object) {
        List<Attachment> list = ((Hint)object).getAttachments();
        Attachment attachment = ((Hint)object).getScreenshot();
        if (attachment != null) {
            list.add((Object)attachment);
        }
        if ((attachment = ((Hint)object).getViewHierarchy()) != null) {
            list.add((Object)attachment);
        }
        if ((object = ((Hint)object).getThreadDump()) != null) {
            list.add(object);
        }
        return list;
    }

    static /* synthetic */ void lambda$captureEvent$0(Session session) {
    }

    private SentryEvent processEvent(SentryEvent object, Hint hint, List<EventProcessor> object2) {
        block5: {
            EventProcessor eventProcessor;
            Iterator iterator = object2.iterator();
            object2 = object;
            do {
                block7: {
                    boolean bl;
                    boolean bl2;
                    block6: {
                        object = object2;
                        if (!iterator.hasNext()) break block5;
                        eventProcessor = (EventProcessor)iterator.next();
                        bl2 = eventProcessor instanceof BackfillingEventProcessor;
                        bl = HintUtils.hasType(hint, Backfillable.class);
                        if (!bl || !bl2) break block6;
                        object = eventProcessor.process((SentryEvent)object2, hint);
                    }
                    object = object2;
                    if (bl) break block7;
                    object = object2;
                    if (bl2) break block7;
                    try {
                        object = eventProcessor.process((SentryEvent)object2, hint);
                    }
                    catch (Throwable throwable) {
                        this.options.getLogger().log(SentryLevel.ERROR, throwable, "An exception occurred while processing event by processor: %s", eventProcessor.getClass().getName());
                        object = object2;
                    }
                }
                object2 = object;
            } while (object != null);
            this.options.getLogger().log(SentryLevel.DEBUG, "Event was dropped by a processor: %s", eventProcessor.getClass().getName());
            this.options.getClientReportRecorder().recordLostEvent(DiscardReason.EVENT_PROCESSOR, DataCategory.Error);
        }
        return object;
    }

    private SentryTransaction processTransaction(SentryTransaction object, Hint hint, List<EventProcessor> object2) {
        block3: {
            EventProcessor eventProcessor;
            Iterator iterator = object2.iterator();
            do {
                object2 = object;
                if (!iterator.hasNext()) break block3;
                eventProcessor = (EventProcessor)iterator.next();
                try {
                    object2 = eventProcessor.process((SentryTransaction)object, hint);
                }
                catch (Throwable throwable) {
                    this.options.getLogger().log(SentryLevel.ERROR, throwable, "An exception occurred while processing transaction by processor: %s", eventProcessor.getClass().getName());
                    object2 = object;
                }
                object = object2;
            } while (object2 != null);
            this.options.getLogger().log(SentryLevel.DEBUG, "Transaction was dropped by a processor: %s", eventProcessor.getClass().getName());
            this.options.getClientReportRecorder().recordLostEvent(DiscardReason.EVENT_PROCESSOR, DataCategory.Transaction);
        }
        return object2;
    }

    private boolean sample() {
        boolean bl;
        Double d2 = this.options.getSampleRate();
        boolean bl2 = bl = true;
        if (d2 != null) {
            bl2 = bl;
            if (this.random != null) {
                bl2 = !(this.options.getSampleRate() < this.random.nextDouble()) ? bl : false;
            }
        }
        return bl2;
    }

    private SentryId sendEnvelope(SentryEnvelope object, Hint hint) throws IOException {
        SentryOptions.BeforeEnvelopeCallback beforeEnvelopeCallback = this.options.getBeforeEnvelopeCallback();
        if (beforeEnvelopeCallback != null) {
            try {
                beforeEnvelopeCallback.execute((SentryEnvelope)object, hint);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "The BeforeEnvelope callback threw an exception.", throwable);
            }
        }
        if (hint == null) {
            this.transport.send((SentryEnvelope)object);
        } else {
            this.transport.send((SentryEnvelope)object, hint);
        }
        object = ((SentryEnvelope)object).getHeader().getEventId();
        if (object == null) {
            object = SentryId.EMPTY_ID;
        }
        return object;
    }

    private boolean shouldApplyScopeData(CheckIn checkIn, Hint hint) {
        if (HintUtils.shouldApplyScopeData(hint)) {
            return true;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Check-in was cached so not applying scope: %s", checkIn.getCheckInId());
        return false;
    }

    private boolean shouldApplyScopeData(SentryBaseEvent sentryBaseEvent, Hint hint) {
        if (HintUtils.shouldApplyScopeData(hint)) {
            return true;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Event was cached so not applying scope: %s", sentryBaseEvent.getEventId());
        return false;
    }

    private boolean shouldSendSessionUpdateForDroppedEvent(Session session, Session session2) {
        if (session2 == null) {
            return false;
        }
        if (session == null) {
            return true;
        }
        boolean bl = session2.getStatus() == Session.State.Crashed && session.getStatus() != Session.State.Crashed;
        if (bl) {
            return true;
        }
        bl = session2.errorCount() > 0 && session.errorCount() <= 0;
        return bl;
    }

    private void sortBreadcrumbsByDate(SentryBaseEvent list, Collection<Breadcrumb> collection) {
        if ((list = list.getBreadcrumbs()) != null && !collection.isEmpty()) {
            list.addAll(collection);
            Collections.sort(list, (Comparator)this.sortBreadcrumbsByDate);
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public SentryId captureCheckIn(CheckIn var1_1, IScope var2_3, Hint var3_4) {
        block9: {
            block10: {
                var4_5 = var3_4;
                if (var3_4 == null) {
                    var4_5 = new Hint();
                }
                if (var1_1.getEnvironment() == null) {
                    var1_1.setEnvironment(this.options.getEnvironment());
                }
                if (var1_1.getRelease() == null) {
                    var1_1.setRelease(this.options.getRelease());
                }
                var3_4 = var1_1;
                if (this.shouldApplyScopeData((CheckIn)var1_1, var4_5)) {
                    var3_4 = this.applyScope((CheckIn)var1_1, var2_3);
                }
                if (CheckInUtils.isIgnored(this.options.getIgnoredCheckIns(), var3_4.getMonitorSlug())) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "Check-in was dropped as slug %s is ignored", new Object[]{var3_4.getMonitorSlug()});
                    return SentryId.EMPTY_ID;
                }
                this.options.getLogger().log(SentryLevel.DEBUG, "Capturing check-in: %s", new Object[]{var3_4.getCheckInId()});
                var5_6 = var3_4.getCheckInId();
                if (var2_3 == null) break block10;
                var1_1 = var2_3.getTransaction();
                if (var1_1 == null) ** GOTO lbl23
                var1_1 = var1_1.traceContext();
                break block9;
lbl23:
                // 1 sources

                var1_1 = TracingUtils.maybeUpdateBaggage(var2_3, this.options).traceContext();
                break block9;
            }
            var1_1 = null;
        }
        try {
            var1_1 = this.buildEnvelope((CheckIn)var3_4, (TraceContext)var1_1);
            var4_5.clear();
            var1_1 = this.sendEnvelope((SentryEnvelope)var1_1, var4_5);
        }
        catch (IOException var1_2) {
            this.options.getLogger().log(SentryLevel.WARNING, var1_2, "Capturing check-in %s failed.", new Object[]{var5_6});
            var1_1 = SentryId.EMPTY_ID;
        }
        return var1_1;
    }

    @Override
    public SentryId captureEnvelope(SentryEnvelope object, Hint hint) {
        Objects.requireNonNull(object, "SentryEnvelope is required.");
        Hint hint2 = hint;
        if (hint == null) {
            hint2 = new Hint();
        }
        try {
            hint2.clear();
            object = this.sendEnvelope((SentryEnvelope)object, hint2);
            return object;
        }
        catch (IOException iOException) {
            this.options.getLogger().log(SentryLevel.ERROR, "Failed to capture envelope.", iOException);
            return SentryId.EMPTY_ID;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public SentryId captureEvent(SentryEvent var1_1, IScope var2_4, Hint var3_5) {
        block31: {
            block30: {
                block29: {
                    block28: {
                        var6_6 = var1_1;
                        Objects.requireNonNull(var1_1, "SentryEvent is required.");
                        var7_7 = var3_5 == null ? new Hint() : var3_5;
                        if (this.shouldApplyScopeData((SentryBaseEvent)var1_1, (Hint)var7_7)) {
                            this.addScopeAttachmentsToHint((IScope)var2_4, (Hint)var7_7);
                        }
                        this.options.getLogger().log(SentryLevel.DEBUG, "Capturing event: %s", new Object[]{var1_1.getEventId()});
                        if (var6_6 != null && (var3_5 = var1_1.getThrowable()) != null && this.options.containsIgnoredExceptionForType((Throwable)var3_5)) {
                            this.options.getLogger().log(SentryLevel.DEBUG, "Event was dropped as the exception %s is ignored", new Object[]{var3_5.getClass()});
                            this.options.getClientReportRecorder().recordLostEvent(DiscardReason.EVENT_PROCESSOR, DataCategory.Error);
                            return SentryId.EMPTY_ID;
                        }
                        if (this.shouldApplyScopeData((SentryBaseEvent)var1_1, (Hint)var7_7)) {
                            var6_6 = var1_1 = this.applyScope((SentryEvent)var1_1, (IScope)var2_4, (Hint)var7_7);
                            if (var1_1 == null) {
                                this.options.getLogger().log(SentryLevel.DEBUG, "Event was dropped by applyScope", new Object[0]);
                                return SentryId.EMPTY_ID;
                            }
                        }
                        var1_1 = var3_5 = this.processEvent((SentryEvent)var6_6, (Hint)var7_7, this.options.getEventProcessors());
                        if (var3_5 != null) {
                            var1_1 = var3_5 = this.executeBeforeSend((SentryEvent)var3_5, (Hint)var7_7);
                            if (var3_5 == null) {
                                this.options.getLogger().log(SentryLevel.DEBUG, "Event was dropped by beforeSend", new Object[0]);
                                this.options.getClientReportRecorder().recordLostEvent(DiscardReason.BEFORE_SEND, DataCategory.Error);
                                var1_1 = var3_5;
                            }
                        }
                        if (var1_1 == null) {
                            return SentryId.EMPTY_ID;
                        }
                        var8_8 = var2_4 != null ? var2_4.withSession(new SentryClient$$ExternalSyntheticLambda0()) : null;
                        if (var1_1 != null) {
                            var3_5 = var8_8 != null && var8_8.isTerminated() ? null : this.updateSessionData((SentryEvent)var1_1, (Hint)var7_7, (IScope)var2_4);
                            if (!this.sample()) {
                                this.options.getLogger().log(SentryLevel.DEBUG, "Event %s was dropped due to sampling decision.", new Object[]{var1_1.getEventId()});
                                this.options.getClientReportRecorder().recordLostEvent(DiscardReason.SAMPLE_RATE, DataCategory.Error);
                                var6_6 = var3_5;
                                var3_5 = null;
                            } else {
                                var6_6 = var3_5;
                                var3_5 = var1_1;
                            }
                        } else {
                            var6_6 = null;
                            var3_5 = var1_1;
                        }
                        var5_9 = this.shouldSendSessionUpdateForDroppedEvent((Session)var8_8, (Session)var6_6);
                        if (var3_5 == null && !var5_9) {
                            this.options.getLogger().log(SentryLevel.DEBUG, "Not sending session update for dropped event as it did not cause the session health to change.", new Object[0]);
                            return SentryId.EMPTY_ID;
                        }
                        var1_1 = var8_8 = SentryId.EMPTY_ID;
                        if (var3_5 != null) {
                            var1_1 = var8_8;
                            if (var3_5.getEventId() != null) {
                                var1_1 = var3_5.getEventId();
                            }
                        }
                        var8_8 = var1_1;
                        if (!HintUtils.hasType((Hint)var7_7, Backfillable.class)) break block28;
                        if (var3_5 == null) break block29;
                        var1_1 = Baggage.fromEvent((SentryEvent)var3_5, this.options).toTraceContext();
                        break block30;
                    }
                    if (var2_4 == null) break block29;
                    var1_1 = var2_4.getTransaction();
                    if (var1_1 == null) ** GOTO lbl64
                    var1_1 = var1_1.traceContext();
                    break block30;
lbl64:
                    // 1 sources

                    var1_1 = TracingUtils.maybeUpdateBaggage((IScope)var2_4, this.options).traceContext();
                    break block30;
                }
                var1_1 = null;
            }
            var4_10 = var3_5 != null;
            if (var4_10) {
                var9_11 = this.getAttachments((Hint)var7_7);
            } else {
                var9_11 = null;
            }
            var3_5 = this.buildEnvelope((SentryBaseEvent)var3_5, var9_11, (Session)var6_6, (TraceContext)var1_1, null);
            var7_7.clear();
            var1_1 = var8_8;
            if (var3_5 == null) break block31;
            try {
                var1_1 = this.sendEnvelope((SentryEnvelope)var3_5, (Hint)var7_7);
                break block31;
            }
            catch (SentryEnvelopeException var1_2) {
            }
            catch (IOException var1_3) {
                // empty catch block
            }
            this.options.getLogger().log(SentryLevel.WARNING, (Throwable)var1_1, "Capturing event %s failed.", new Object[]{var8_8});
            var1_1 = SentryId.EMPTY_ID;
        }
        if (var2_4 != null && (var3_5 = var2_4.getTransaction()) != null && HintUtils.hasType((Hint)var7_7, TransactionEnd.class)) {
            var2_4 = HintUtils.getSentrySdkHint((Hint)var7_7);
            if (var2_4 instanceof DiskFlushNotification) {
                ((DiskFlushNotification)var2_4).setFlushable(var3_5.getEventId());
                var3_5.forceFinish(SpanStatus.ABORTED, false, (Hint)var7_7);
            } else {
                var3_5.forceFinish(SpanStatus.ABORTED, false, null);
            }
        }
        return var1_1;
    }

    @Override
    public SentryId captureMetrics(EncodedMetrics object) {
        object = SentryEnvelopeItem.fromMetrics((EncodedMetrics)object);
        object = this.captureEnvelope(new SentryEnvelope(new SentryEnvelopeHeader(new SentryId(), this.options.getSdkVersion(), null), (Iterable<SentryEnvelopeItem>)Collections.singleton((Object)object)));
        if (object == null) {
            object = SentryId.EMPTY_ID;
        }
        return object;
    }

    @Override
    public void captureSession(Session object, Hint hint) {
        Objects.requireNonNull(object, "Session is required.");
        if (((Session)object).getRelease() != null && !((Session)object).getRelease().isEmpty()) {
            try {
                object = SentryEnvelope.from(this.options.getSerializer(), (Session)object, this.options.getSdkVersion());
            }
            catch (IOException iOException) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to capture session.", iOException);
                return;
            }
            this.captureEnvelope((SentryEnvelope)object, hint);
            return;
        }
        this.options.getLogger().log(SentryLevel.WARNING, "Sessions can't be captured without setting a release.", new Object[0]);
    }

    @Override
    public SentryId captureTransaction(SentryTransaction object, TraceContext object2, IScope iScope, Hint object3, ProfilingTraceData profilingTraceData) {
        block13: {
            SentryTransaction sentryTransaction = object;
            Objects.requireNonNull(object, "Transaction is required.");
            Object object4 = object3 == null ? new Hint() : object3;
            if (this.shouldApplyScopeData((SentryBaseEvent)object, (Hint)object4)) {
                this.addScopeAttachmentsToHint(iScope, (Hint)object4);
            }
            this.options.getLogger().log(SentryLevel.DEBUG, "Capturing transaction: %s", ((SentryBaseEvent)object).getEventId());
            object3 = SentryId.EMPTY_ID;
            if (((SentryBaseEvent)object).getEventId() != null) {
                object3 = ((SentryBaseEvent)object).getEventId();
            }
            Object object5 = object3;
            object3 = sentryTransaction;
            if (this.shouldApplyScopeData((SentryBaseEvent)object, (Hint)object4)) {
                object = object3 = this.applyScope(object, iScope);
                if (object3 != null) {
                    object = object3;
                    if (iScope != null) {
                        object = this.processTransaction((SentryTransaction)object3, (Hint)object4, iScope.getEventProcessors());
                    }
                }
                object3 = object;
                if (object == null) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "Transaction was dropped by applyScope", new Object[0]);
                    object3 = object;
                }
            }
            object = object3;
            if (object3 != null) {
                object = this.processTransaction((SentryTransaction)object3, (Hint)object4, this.options.getEventProcessors());
            }
            if (object == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Transaction was dropped by Event processors.", new Object[0]);
                return SentryId.EMPTY_ID;
            }
            if ((object = this.executeBeforeSendTransaction((SentryTransaction)object, (Hint)object4)) == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Transaction was dropped by beforeSendTransaction.", new Object[0]);
                this.options.getClientReportRecorder().recordLostEvent(DiscardReason.BEFORE_SEND, DataCategory.Transaction);
                return SentryId.EMPTY_ID;
            }
            object2 = this.buildEnvelope((SentryBaseEvent)object, this.filterForTransaction(this.getAttachments((Hint)object4)), null, (TraceContext)object2, profilingTraceData);
            ((Hint)object4).clear();
            object = object5;
            if (object2 == null) break block13;
            try {
                object = this.sendEnvelope((SentryEnvelope)object2, (Hint)object4);
                break block13;
            }
            catch (SentryEnvelopeException sentryEnvelopeException) {
            }
            catch (IOException iOException) {
                // empty catch block
            }
            this.options.getLogger().log(SentryLevel.WARNING, (Throwable)object, "Capturing transaction %s failed.", object5);
            object = SentryId.EMPTY_ID;
        }
        return object;
    }

    @Override
    public void captureUserFeedback(UserFeedback userFeedback) {
        Objects.requireNonNull(userFeedback, "SentryEvent is required.");
        if (SentryId.EMPTY_ID.equals(userFeedback.getEventId())) {
            this.options.getLogger().log(SentryLevel.WARNING, "Capturing userFeedback without a Sentry Id.", new Object[0]);
            return;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Capturing userFeedback: %s", userFeedback.getEventId());
        try {
            this.sendEnvelope(this.buildEnvelope(userFeedback), null);
        }
        catch (IOException iOException) {
            this.options.getLogger().log(SentryLevel.WARNING, iOException, "Capturing user feedback %s failed.", userFeedback.getEventId());
        }
    }

    @Override
    public void close() {
        this.close(false);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void close(boolean var1_1) {
        block7: {
            this.options.getLogger().log(SentryLevel.INFO, "Closing SentryClient.", new Object[0]);
            try {
                this.metricsAggregator.close();
            }
            catch (IOException var4_2) {
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to close the metrics aggregator.", var4_2);
            }
            if (!var1_1) break block7;
            var2_5 = 0L;
            ** GOTO lbl13
        }
        try {
            var2_5 = this.options.getShutdownTimeoutMillis();
lbl13:
            // 2 sources

            this.flush(var2_5);
            this.transport.close(var1_1);
        }
        catch (IOException var4_3) {
            this.options.getLogger().log(SentryLevel.WARNING, "Failed to close the connection to the Sentry Server.", var4_3);
        }
        for (EventProcessor var6_7 : this.options.getEventProcessors()) {
            if (!(var6_7 instanceof Closeable)) continue;
            try {
                ((Closeable)var6_7).close();
            }
            catch (IOException var5_6) {
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to close the event processor {}.", new Object[]{var6_7, var5_6});
            }
        }
        this.enabled = false;
    }

    @Override
    public void flush(long l2) {
        this.transport.flush(l2);
    }

    @Override
    public IMetricsAggregator getMetricsAggregator() {
        return this.metricsAggregator;
    }

    @Override
    public RateLimiter getRateLimiter() {
        return this.transport.getRateLimiter();
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    @Override
    public boolean isHealthy() {
        return this.transport.isHealthy();
    }

    /* synthetic */ void lambda$updateSessionData$1$io-sentry-SentryClient(SentryEvent object, Hint object2, Session session) {
        boolean bl = false;
        if (session != null) {
            boolean bl2 = ((SentryEvent)object).isCrashed();
            Object var7_6 = null;
            Session.State state = bl2 ? Session.State.Crashed : null;
            if (Session.State.Crashed == state || ((SentryEvent)object).isErrored()) {
                bl = true;
            }
            object = ((SentryBaseEvent)object).getRequest() != null && ((SentryBaseEvent)object).getRequest().getHeaders() != null && ((SentryBaseEvent)object).getRequest().getHeaders().containsKey((Object)"user-agent") ? (String)((SentryBaseEvent)object).getRequest().getHeaders().get((Object)"user-agent") : null;
            Object object3 = HintUtils.getSentrySdkHint((Hint)object2);
            object2 = var7_6;
            if (object3 instanceof AbnormalExit) {
                object2 = ((AbnormalExit)object3).mechanism();
                state = Session.State.Abnormal;
            }
            if (session.update(state, (String)object, bl, (String)object2) && session.isTerminated()) {
                session.end();
            }
        } else {
            this.options.getLogger().log(SentryLevel.INFO, "Session is null on scope.withSession", new Object[0]);
        }
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     */
    Session updateSessionData(SentryEvent jsonSerializable, Hint hint, IScope iScope) {
        void var1_4;
        void var2_5;
        if (HintUtils.shouldApplyScopeData((Hint)var2_5)) {
            void var3_6;
            if (var3_6 != null) {
                Session session = var3_6.withSession(new SentryClient$$ExternalSyntheticLambda1(this, (SentryEvent)jsonSerializable, (Hint)var2_5));
                return var1_4;
            }
            this.options.getLogger().log(SentryLevel.INFO, "Scope is null on client.captureEvent", new Object[0]);
        }
        Object var1_3 = null;
        return var1_4;
    }

    private static final class SortBreadcrumbsByDate
    implements Comparator<Breadcrumb> {
        private SortBreadcrumbsByDate() {
        }

        public int compare(Breadcrumb breadcrumb, Breadcrumb breadcrumb2) {
            return breadcrumb.getTimestamp().compareTo(breadcrumb2.getTimestamp());
        }
    }
}

