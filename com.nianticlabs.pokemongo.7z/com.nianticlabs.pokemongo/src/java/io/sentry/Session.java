/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Date
 *  java.util.Locale
 *  java.util.Map
 *  java.util.UUID
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.atomic.AtomicInteger
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.protocol.User;
import io.sentry.util.StringUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class Session
implements JsonUnknown,
JsonSerializable {
    private String abnormalMechanism;
    private final String distinctId;
    private Double duration;
    private final String environment;
    private final AtomicInteger errorCount;
    private Boolean init;
    private final String ipAddress;
    private final String release;
    private Long sequence;
    private final UUID sessionId;
    private final Object sessionLock;
    private final Date started;
    private State status;
    private Date timestamp;
    private Map<String, Object> unknown;
    private String userAgent;

    public Session(State state, Date date, Date date2, int n2, String string2, UUID uUID, Boolean bl, Long l2, Double d2, String string3, String string4, String string5, String string6, String string7) {
        this.sessionLock = new Object();
        this.status = state;
        this.started = date;
        this.timestamp = date2;
        this.errorCount = new AtomicInteger(n2);
        this.distinctId = string2;
        this.sessionId = uUID;
        this.init = bl;
        this.sequence = l2;
        this.duration = d2;
        this.ipAddress = string3;
        this.userAgent = string4;
        this.environment = string5;
        this.release = string6;
        this.abnormalMechanism = string7;
    }

    public Session(String string2, User object, String string3, String string4) {
        State state = State.Ok;
        Date date = DateUtils.getCurrentDateTime();
        Date date2 = DateUtils.getCurrentDateTime();
        UUID uUID = UUID.randomUUID();
        object = object != null ? ((User)object).getIpAddress() : null;
        this(state, date, date2, 0, string2, uUID, true, null, null, (String)object, null, string3, string4, null);
    }

    private double calculateDurationTime(Date date) {
        return (double)Math.abs((long)(date.getTime() - this.started.getTime())) / 1000.0;
    }

    private long getSequenceTimestamp(Date date) {
        long l2;
        long l3 = l2 = date.getTime();
        if (l2 < 0L) {
            l3 = Math.abs((long)l2);
        }
        return l3;
    }

    public Session clone() {
        return new Session(this.status, this.started, this.timestamp, this.errorCount.get(), this.distinctId, this.sessionId, this.init, this.sequence, this.duration, this.ipAddress, this.userAgent, this.environment, this.release, this.abnormalMechanism);
    }

    public void end() {
        this.end(DateUtils.getCurrentDateTime());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void end(Date date) {
        Object object;
        Object object2 = object = this.sessionLock;
        synchronized (object2) {
            this.init = null;
            if (this.status == State.Ok) {
                this.status = State.Exited;
            }
            this.timestamp = date != null ? date : DateUtils.getCurrentDateTime();
            date = this.timestamp;
            if (date != null) {
                this.duration = this.calculateDurationTime(date);
                this.sequence = this.getSequenceTimestamp(this.timestamp);
            }
            return;
        }
    }

    public int errorCount() {
        return this.errorCount.get();
    }

    public String getAbnormalMechanism() {
        return this.abnormalMechanism;
    }

    public String getDistinctId() {
        return this.distinctId;
    }

    public Double getDuration() {
        return this.duration;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public Boolean getInit() {
        return this.init;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public String getRelease() {
        return this.release;
    }

    public Long getSequence() {
        return this.sequence;
    }

    public UUID getSessionId() {
        return this.sessionId;
    }

    public Date getStarted() {
        Date date = this.started;
        if (date == null) {
            return null;
        }
        return (Date)date.clone();
    }

    public State getStatus() {
        return this.status;
    }

    public Date getTimestamp() {
        Object object = this.timestamp;
        object = object != null ? (Date)object.clone() : null;
        return object;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getUserAgent() {
        return this.userAgent;
    }

    public boolean isTerminated() {
        boolean bl = this.status != State.Ok;
        return bl;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        if (this.sessionId != null) {
            objectWriter.name("sid").value(this.sessionId.toString());
        }
        if (this.distinctId != null) {
            objectWriter.name("did").value(this.distinctId);
        }
        if (this.init != null) {
            objectWriter.name("init").value(this.init);
        }
        objectWriter.name("started").value(iLogger, this.started);
        objectWriter.name("status").value(iLogger, this.status.name().toLowerCase(Locale.ROOT));
        if (this.sequence != null) {
            objectWriter.name("seq").value((Number)this.sequence);
        }
        objectWriter.name("errors").value(this.errorCount.intValue());
        if (this.duration != null) {
            objectWriter.name("duration").value((Number)this.duration);
        }
        if (this.timestamp != null) {
            objectWriter.name("timestamp").value(iLogger, this.timestamp);
        }
        if (this.abnormalMechanism != null) {
            objectWriter.name("abnormal_mechanism").value(iLogger, this.abnormalMechanism);
        }
        objectWriter.name("attrs");
        objectWriter.beginObject();
        objectWriter.name("release").value(iLogger, this.release);
        if (this.environment != null) {
            objectWriter.name("environment").value(iLogger, this.environment);
        }
        if (this.ipAddress != null) {
            objectWriter.name("ip_address").value(iLogger, this.ipAddress);
        }
        if (this.userAgent != null) {
            objectWriter.name("user_agent").value(iLogger, this.userAgent);
        }
        objectWriter.endObject();
        Object object2 = this.unknown;
        if (object2 != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setInitAsTrue() {
        this.init = true;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public boolean update(State state, String string2, boolean bl) {
        return this.update(state, string2, bl, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean update(State state, String string2, boolean bl, String string3) {
        Object object;
        Object object2 = object = this.sessionLock;
        synchronized (object2) {
            Throwable throwable2;
            block11: {
                boolean bl2;
                boolean bl3;
                block10: {
                    bl3 = true;
                    if (state != null) {
                        try {
                            this.status = state;
                            bl2 = true;
                            break block10;
                        }
                        catch (Throwable throwable2) {
                            break block11;
                        }
                    }
                    bl2 = false;
                }
                if (string2 != null) {
                    this.userAgent = string2;
                    bl2 = true;
                }
                if (bl) {
                    this.errorCount.addAndGet(1);
                    bl2 = true;
                }
                if (string3 != null) {
                    this.abnormalMechanism = string3;
                    bl = bl3;
                } else {
                    bl = bl2;
                }
                if (bl) {
                    this.init = null;
                    state = DateUtils.getCurrentDateTime();
                    this.timestamp = state;
                    if (state != null) {
                        this.sequence = this.getSequenceTimestamp((Date)state);
                    }
                }
                return bl;
            }
            throw throwable2;
        }
    }

    public static final class Deserializer
    implements JsonDeserializer<Session> {
        private Exception missingRequiredFieldException(String object, ILogger iLogger) {
            String string2 = "Missing required field \"" + object + "\"";
            object = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, (Throwable)object);
            return object;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public Session deserialize(JsonObjectReader var1_1, ILogger var2_2) throws Exception {
            var1_1.beginObject();
            var15_3 /* !! */  = null;
            var14_4 = null;
            var13_5 = null;
            var12_6 = null;
            var4_7 /* !! */  = null;
            var11_8 = null;
            var10_9 = null;
            var9_10 /* !! */  = null;
            var18_11 = null;
            var17_12 = null;
            var5_13 /* !! */  = null;
            var6_14 /* !! */  = null;
            var16_15 /* !! */  = null;
            var8_16 = null;
            var7_17 = null;
            block61: while ((var20_21 = var1_1.peek()) == (var19_19 /* !! */  = JsonToken.NAME)) {
                var19_19 /* !! */  = var1_1.nextName();
                var19_19 /* !! */ .hashCode();
                tmp = -1;
                switch (var19_19 /* !! */ .hashCode()) {
                    case 213717026: {
                        if (var19_19 /* !! */ .equals("abnormal_mechanism")) {
                            tmp = 1;
                            ** break;
                        }
                    }
lbl27:
                    // 24 sources

                    default: {
                        break;
                    }
                    case 93152418: {
                        if (!var19_19 /* !! */ .equals("attrs")) ** GOTO lbl27
                        tmp = 2;
                        ** break;
                    }
                    case 55126294: {
                        if (!var19_19 /* !! */ .equals("timestamp")) ** GOTO lbl27
                        tmp = 3;
                        ** break;
                    }
                    case 3237136: {
                        if (!var19_19 /* !! */ .equals("init")) ** GOTO lbl27
                        tmp = 4;
                        ** break;
                    }
                    case 113870: {
                        if (!var19_19 /* !! */ .equals("sid")) ** GOTO lbl27
                        tmp = 5;
                        ** break;
                    }
                    case 113759: {
                        if (!var19_19 /* !! */ .equals("seq")) ** GOTO lbl27
                        tmp = 6;
                        ** break;
                    }
                    case 99455: {
                        if (!var19_19 /* !! */ .equals("did")) ** GOTO lbl27
                        tmp = 7;
                        ** break;
                    }
                    case -892481550: {
                        if (!var19_19 /* !! */ .equals("status")) ** GOTO lbl27
                        tmp = 8;
                        ** break;
                    }
                    case -1294635157: {
                        if (!var19_19 /* !! */ .equals("errors")) ** GOTO lbl27
                        tmp = 9;
                        ** break;
                    }
                    case -1897185151: {
                        if (!var19_19 /* !! */ .equals("started")) ** GOTO lbl27
                        tmp = 10;
                        ** break;
                    }
                    case -1992012396: {
                        if (!var19_19 /* !! */ .equals("duration")) ** GOTO lbl27
                        tmp = 11;
                        ** break;
                    }
                }
                switch (tmp) {
                    default: {
                        var3_18 = -1;
                        break;
                    }
                    case 1: {
                        var3_18 = 10;
                        break;
                    }
                    case 2: {
                        var3_18 = 9;
                        break;
                    }
                    case 3: {
                        var3_18 = 8;
                        break;
                    }
                    case 4: {
                        var3_18 = 7;
                        break;
                    }
                    case 5: {
                        var3_18 = 6;
                        break;
                    }
                    case 6: {
                        var3_18 = 5;
                        break;
                    }
                    case 7: {
                        var3_18 = 4;
                        break;
                    }
                    case 8: {
                        var3_18 = 3;
                        break;
                    }
                    case 9: {
                        var3_18 = 2;
                        break;
                    }
                    case 10: {
                        var3_18 = 1;
                        break;
                    }
                    case 11: {
                        var3_18 = 0;
                    }
                }
                switch (var3_18) {
                    default: {
                        var22_24 = var4_7 /* !! */ ;
                        if (var4_7 /* !! */  == null) {
                            var22_24 = new ConcurrentHashMap();
                        }
                        var1_1.nextUnknown((ILogger)var2_2, (Map<String, Object>)var22_24, (String)var19_19 /* !! */ );
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        ** GOTO lbl219
                    }
                    case 10: {
                        var26_28 = var1_1.nextStringOrNull();
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        ** GOTO lbl219
                    }
                    case 9: {
                        var1_1.beginObject();
                        var19_19 /* !! */  = var6_14 /* !! */ ;
                        var6_14 /* !! */  = var5_13 /* !! */ ;
                        var5_13 /* !! */  = var19_19 /* !! */ ;
                        block63: while (var1_1.peek() == JsonToken.NAME) {
                            var19_19 /* !! */  = var1_1.nextName();
                            var19_19 /* !! */ .hashCode();
                            tmp = -1;
                            switch (var19_19 /* !! */ .hashCode()) {
                                case 1917799825: {
                                    if (var19_19 /* !! */ .equals("user_agent")) {
                                        tmp = 1;
                                        ** break;
                                    }
                                }
lbl144:
                                // 10 sources

                                default: {
                                    break;
                                }
                                case 1480014044: {
                                    if (!var19_19 /* !! */ .equals("ip_address")) ** GOTO lbl144
                                    tmp = 2;
                                    ** break;
                                }
                                case 1090594823: {
                                    if (!var19_19 /* !! */ .equals("release")) ** GOTO lbl144
                                    tmp = 3;
                                    ** break;
                                }
                                case -85904877: {
                                    if (!var19_19 /* !! */ .equals("environment")) ** GOTO lbl144
                                    tmp = 4;
                                    ** break;
                                }
                            }
                            switch (tmp) {
                                default: {
                                    var3_18 = -1;
                                    break;
                                }
                                case 1: {
                                    var3_18 = 3;
                                    break;
                                }
                                case 2: {
                                    var3_18 = 2;
                                    break;
                                }
                                case 3: {
                                    var3_18 = 1;
                                    break;
                                }
                                case 4: {
                                    var3_18 = 0;
                                }
                            }
                            switch (var3_18) {
                                default: {
                                    var1_1.skipValue();
                                    continue block63;
                                }
                                case 3: {
                                    var5_13 /* !! */  = var1_1.nextStringOrNull();
                                    continue block63;
                                }
                                case 2: {
                                    var6_14 /* !! */  = var1_1.nextStringOrNull();
                                    continue block63;
                                }
                                case 1: {
                                    var8_16 = var1_1.nextStringOrNull();
                                    continue block63;
                                }
                                case 0: 
                            }
                            var16_15 /* !! */  = var1_1.nextStringOrNull();
                        }
                        var1_1.endObject();
                        var22_24 = var4_7 /* !! */ ;
                        var24_26 /* !! */  = var10_9;
                        var10_9 = var9_10 /* !! */ ;
                        var4_7 /* !! */  = var16_15 /* !! */ ;
                        ** GOTO lbl230
                    }
                    case 8: {
                        var21_23 = var1_1.nextDateOrNull((ILogger)var2_2);
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        ** GOTO lbl219
                    }
                    case 7: {
                        var25_27 /* !! */  = var1_1.nextBooleanOrNull();
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var26_28 = var7_17;
                        ** GOTO lbl219
                    }
                    case 6: {
                        var19_19 /* !! */  = var1_1.nextStringOrNull();
                        ** GOTO lbl244
lbl219:
                        // 11 sources

                        while (true) {
                            var4_7 /* !! */  = var16_15 /* !! */ ;
                            var9_10 /* !! */  = var5_13 /* !! */ ;
                            var7_17 = var26_28;
                            var5_13 /* !! */  = var6_14 /* !! */ ;
                            var6_14 /* !! */  = var9_10 /* !! */ ;
                            var10_9 = var25_27 /* !! */ ;
                            var11_8 = var23_25;
                            var12_6 = var21_23;
                            var13_5 = var20_21;
                            var15_3 /* !! */  = var19_19 /* !! */ ;
lbl230:
                            // 2 sources

                            var9_10 /* !! */  = var17_12;
lbl231:
                            // 2 sources

                            while (true) {
                                var20_21 = var10_9;
                                var17_12 = var9_10 /* !! */ ;
                                var16_15 /* !! */  = var5_13 /* !! */ ;
                                var19_19 /* !! */  = var4_7 /* !! */ ;
lbl236:
                                // 2 sources

                                while (true) {
                                    var4_7 /* !! */  = var22_24;
                                    var10_9 = var24_26 /* !! */ ;
                                    var9_10 /* !! */  = var20_21;
                                    var5_13 /* !! */  = var6_14 /* !! */ ;
                                    var6_14 /* !! */  = var16_15 /* !! */ ;
                                    var16_15 /* !! */  = var19_19 /* !! */ ;
                                    continue block61;
                                    break;
                                }
                                break;
                            }
                            break;
                        }
lbl244:
                        // 1 sources

                        try {
                            var24_26 /* !! */  = UUID.fromString((String)var19_19 /* !! */ );
                            var19_19 /* !! */  = var15_3 /* !! */ ;
                            var20_21 = var13_5;
                            var21_23 = var12_6;
                            var22_24 = var4_7 /* !! */ ;
                            var23_25 = var11_8;
                            var25_27 /* !! */  = var9_10 /* !! */ ;
                            var26_28 = var7_17;
                        }
                        catch (IllegalArgumentException var20_22) {
                            ** continue;
                        }
                        catch (IllegalArgumentException var19_20) {
                            var19_19 /* !! */  = null;
lbl258:
                            // 2 sources

                            while (true) {
                                var2_2.log(SentryLevel.ERROR, "%s sid is not valid.", new Object[]{var19_19 /* !! */ });
                                var19_19 /* !! */  = var15_3 /* !! */ ;
                                var20_21 = var13_5;
                                var21_23 = var12_6;
                                var22_24 = var4_7 /* !! */ ;
                                var23_25 = var11_8;
                                var24_26 /* !! */  = var10_9;
                                var25_27 /* !! */  = var9_10 /* !! */ ;
                                var26_28 = var7_17;
                                ** GOTO lbl219
                                break;
                            }
                        }
                    }
                    case 5: {
                        var18_11 = var1_1.nextLongOrNull();
                        var19_19 /* !! */  = var16_15 /* !! */ ;
                        var16_15 /* !! */  = var6_14 /* !! */ ;
                        var22_24 = var4_7 /* !! */ ;
                        var24_26 /* !! */  = var10_9;
                        var20_21 = var9_10 /* !! */ ;
                        var6_14 /* !! */  = var5_13 /* !! */ ;
                        ** continue;
                    }
                    case 4: {
                        var23_25 = var1_1.nextStringOrNull();
                        var26_28 = var7_17;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var24_26 /* !! */  = var10_9;
                        var22_24 = var4_7 /* !! */ ;
                        var21_23 = var12_6;
                        var20_21 = var13_5;
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        ** GOTO lbl219
                    }
                    case 3: {
                        var27_29 = StringUtils.capitalize(var1_1.nextStringOrNull());
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        if (var27_29 == null) ** GOTO lbl219
                        var14_4 = State.valueOf(var27_29);
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        ** GOTO lbl219
                    }
                    case 2: {
                        var19_19 /* !! */  = var1_1.nextIntegerOrNull();
                        var20_21 = var13_5;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        ** GOTO lbl219
                    }
                    case 1: {
                        var20_21 = var1_1.nextDateOrNull((ILogger)var2_2);
                        var19_19 /* !! */  = var15_3 /* !! */ ;
                        var21_23 = var12_6;
                        var22_24 = var4_7 /* !! */ ;
                        var23_25 = var11_8;
                        var24_26 /* !! */  = var10_9;
                        var25_27 /* !! */  = var9_10 /* !! */ ;
                        var26_28 = var7_17;
                        ** continue;
                    }
                    case 0: 
                }
                var19_19 /* !! */  = var1_1.nextDoubleOrNull();
                var17_12 = var6_14 /* !! */ ;
                var22_24 = var4_7 /* !! */ ;
                var24_26 /* !! */  = var10_9;
                var10_9 = var9_10 /* !! */ ;
                var9_10 /* !! */  = var19_19 /* !! */ ;
                var6_14 /* !! */  = var5_13 /* !! */ ;
                var5_13 /* !! */  = var17_12;
                var4_7 /* !! */  = var16_15 /* !! */ ;
                ** continue;
            }
            if (var14_4 == null) {
                throw this.missingRequiredFieldException("status", (ILogger)var2_2);
            }
            if (var13_5 == null) {
                throw this.missingRequiredFieldException("started", (ILogger)var2_2);
            }
            if (var15_3 /* !! */  == null) {
                throw this.missingRequiredFieldException("errors", (ILogger)var2_2);
            }
            if (var8_16 != null) {
                var2_2 = new Session(var14_4, (Date)var13_5, var12_6, var15_3 /* !! */ .intValue(), var11_8, (UUID)var10_9, (Boolean)var9_10 /* !! */ , var18_11, (Double)var17_12, (String)var5_13 /* !! */ , (String)var6_14 /* !! */ , (String)var16_15 /* !! */ , var8_16, var7_17);
                var2_2.setUnknown((Map<String, Object>)var4_7 /* !! */ );
                var1_1.endObject();
                return var2_2;
            }
            throw this.missingRequiredFieldException("release", (ILogger)var2_2);
        }
    }

    public static final class JsonKeys {
        public static final String ABNORMAL_MECHANISM = "abnormal_mechanism";
        public static final String ATTRS = "attrs";
        public static final String DID = "did";
        public static final String DURATION = "duration";
        public static final String ENVIRONMENT = "environment";
        public static final String ERRORS = "errors";
        public static final String INIT = "init";
        public static final String IP_ADDRESS = "ip_address";
        public static final String RELEASE = "release";
        public static final String SEQ = "seq";
        public static final String SID = "sid";
        public static final String STARTED = "started";
        public static final String STATUS = "status";
        public static final String TIMESTAMP = "timestamp";
        public static final String USER_AGENT = "user_agent";
    }

    public static enum State {
        Ok,
        Exited,
        Crashed,
        Abnormal;

    }
}

