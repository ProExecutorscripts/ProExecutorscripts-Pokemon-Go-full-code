/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.Proxy$Type
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.CopyOnWriteArrayList
 *  java.util.concurrent.CopyOnWriteArraySet
 *  javax.net.ssl.SSLSocketFactory
 */
package io.sentry;

import io.sentry.Breadcrumb;
import io.sentry.DiagnosticLogger;
import io.sentry.DuplicateEventDetectionEventProcessor;
import io.sentry.EnvelopeReader;
import io.sentry.EventProcessor;
import io.sentry.ExternalOptions;
import io.sentry.FullyDisplayedReporter;
import io.sentry.Hint;
import io.sentry.IConnectionStatusProvider;
import io.sentry.IEnvelopeReader;
import io.sentry.ILogger;
import io.sentry.IOptionsObserver;
import io.sentry.IPerformanceCollector;
import io.sentry.IScopeObserver;
import io.sentry.ISentryExecutorService;
import io.sentry.ISerializer;
import io.sentry.ITransactionProfiler;
import io.sentry.ITransportFactory;
import io.sentry.Instrumenter;
import io.sentry.Integration;
import io.sentry.JsonSerializer;
import io.sentry.MainEventProcessor;
import io.sentry.NoOpConnectionStatusProvider;
import io.sentry.NoOpEnvelopeReader;
import io.sentry.NoOpLogger;
import io.sentry.NoOpSentryExecutorService;
import io.sentry.NoOpSerializer;
import io.sentry.NoOpTransactionPerformanceCollector;
import io.sentry.NoOpTransactionProfiler;
import io.sentry.NoOpTransportFactory;
import io.sentry.SamplingContext;
import io.sentry.SentryAutoDateProvider;
import io.sentry.SentryDateProvider;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryExecutorService;
import io.sentry.SentryIntegrationPackageStorage;
import io.sentry.SentryLevel;
import io.sentry.SentryRuntimeEventProcessor;
import io.sentry.ShutdownHookIntegration;
import io.sentry.SpotlightIntegration;
import io.sentry.TransactionPerformanceCollector;
import io.sentry.UncaughtExceptionHandlerIntegration;
import io.sentry.backpressure.IBackpressureMonitor;
import io.sentry.backpressure.NoOpBackpressureMonitor;
import io.sentry.cache.IEnvelopeCache;
import io.sentry.clientreport.ClientReportRecorder;
import io.sentry.clientreport.IClientReportRecorder;
import io.sentry.clientreport.NoOpClientReportRecorder;
import io.sentry.internal.debugmeta.IDebugMetaLoader;
import io.sentry.internal.debugmeta.NoOpDebugMetaLoader;
import io.sentry.internal.gestures.GestureTargetLocator;
import io.sentry.internal.modules.IModulesLoader;
import io.sentry.internal.modules.NoOpModulesLoader;
import io.sentry.internal.viewhierarchy.ViewHierarchyExporter;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryTransaction;
import io.sentry.transport.ITransportGate;
import io.sentry.transport.NoOpEnvelopeCache;
import io.sentry.transport.NoOpTransportGate;
import io.sentry.util.Platform;
import io.sentry.util.SampleRateUtils;
import io.sentry.util.StringUtils;
import io.sentry.util.thread.IMainThreadChecker;
import io.sentry.util.thread.NoOpMainThreadChecker;
import java.io.File;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.net.ssl.SSLSocketFactory;

public class SentryOptions {
    static final SentryLevel DEFAULT_DIAGNOSTIC_LEVEL = SentryLevel.DEBUG;
    private static final String DEFAULT_ENVIRONMENT = "production";
    public static final String DEFAULT_PROPAGATION_TARGETS = ".*";
    private boolean attachServerName;
    private boolean attachStacktrace;
    private boolean attachThreads;
    private IBackpressureMonitor backpressureMonitor;
    private BeforeBreadcrumbCallback beforeBreadcrumb;
    private BeforeEmitMetricCallback beforeEmitMetricCallback;
    private BeforeEnvelopeCallback beforeEnvelopeCallback;
    private BeforeSendCallback beforeSend;
    private BeforeSendTransactionCallback beforeSendTransaction;
    private final Set<String> bundleIds;
    private String cacheDirPath;
    IClientReportRecorder clientReportRecorder;
    private IConnectionStatusProvider connectionStatusProvider;
    private int connectionTimeoutMillis;
    private final List<String> contextTags;
    private Cron cron;
    private SentryDateProvider dateProvider;
    private boolean debug;
    private IDebugMetaLoader debugMetaLoader;
    private final List<String> defaultTracePropagationTargets;
    private SentryLevel diagnosticLevel;
    private String dist;
    private String distinctId;
    private String dsn;
    private String dsnHash;
    private boolean enableAppStartProfiling;
    private boolean enableAutoSessionTracking;
    private boolean enableBackpressureHandling;
    private boolean enableDeduplication;
    private boolean enableDefaultTagsForMetrics;
    private boolean enableExternalConfiguration;
    private boolean enableMetrics;
    private boolean enablePrettySerializationOutput;
    private boolean enableScopePersistence;
    private boolean enableShutdownHook;
    private boolean enableSpanLocalMetricAggregation;
    private boolean enableSpotlight;
    private boolean enableTimeToFullDisplayTracing;
    private Boolean enableTracing;
    private boolean enableUncaughtExceptionHandler;
    private boolean enableUserInteractionBreadcrumbs;
    private boolean enableUserInteractionTracing;
    private boolean enabled;
    private IEnvelopeCache envelopeDiskCache;
    private IEnvelopeReader envelopeReader;
    private String environment;
    private final List<EventProcessor> eventProcessors;
    private ISentryExecutorService executorService;
    private long flushTimeoutMillis;
    private final FullyDisplayedReporter fullyDisplayedReporter;
    private final List<GestureTargetLocator> gestureTargetLocators;
    private Long idleTimeout;
    private List<String> ignoredCheckIns;
    private final Set<Class<? extends Throwable>> ignoredExceptionsForType;
    private final List<String> inAppExcludes;
    private final List<String> inAppIncludes;
    private Instrumenter instrumenter;
    private final List<Integration> integrations;
    private ILogger logger;
    private IMainThreadChecker mainThreadChecker;
    private long maxAttachmentSize;
    private int maxBreadcrumbs;
    private int maxCacheItems;
    private int maxDepth;
    private int maxQueueSize;
    private RequestSize maxRequestBodySize;
    private int maxSpans;
    private long maxTraceFileSize;
    private IModulesLoader modulesLoader;
    private final List<IScopeObserver> observers;
    private final List<IOptionsObserver> optionsObservers;
    private final List<IPerformanceCollector> performanceCollectors;
    private boolean printUncaughtStackTrace;
    private Double profilesSampleRate;
    private ProfilesSamplerCallback profilesSampler;
    private int profilingTracesHz;
    private String proguardUuid;
    private Proxy proxy;
    private int readTimeoutMillis;
    private String release;
    private Double sampleRate;
    private SdkVersion sdkVersion;
    private boolean sendClientReports;
    private boolean sendDefaultPii;
    private boolean sendModules;
    private String sentryClientName;
    private ISerializer serializer;
    private String serverName;
    private long sessionFlushTimeoutMillis;
    private long sessionTrackingIntervalMillis;
    private long shutdownTimeoutMillis;
    private String spotlightConnectionUrl;
    private SSLSocketFactory sslSocketFactory;
    private final Map<String, String> tags;
    private boolean traceOptionsRequests;
    private List<String> tracePropagationTargets;
    private boolean traceSampling;
    private Double tracesSampleRate;
    private TracesSamplerCallback tracesSampler;
    private TransactionPerformanceCollector transactionPerformanceCollector;
    private ITransactionProfiler transactionProfiler;
    private ITransportFactory transportFactory;
    private ITransportGate transportGate;
    private final List<ViewHierarchyExporter> viewHierarchyExporters;

    public SentryOptions() {
        this(false);
    }

    private SentryOptions(boolean bl) {
        CopyOnWriteArrayList copyOnWriteArrayList;
        CopyOnWriteArrayList copyOnWriteArrayList2;
        this.eventProcessors = copyOnWriteArrayList2 = new CopyOnWriteArrayList();
        this.ignoredExceptionsForType = new CopyOnWriteArraySet();
        this.integrations = copyOnWriteArrayList = new CopyOnWriteArrayList();
        this.bundleIds = new CopyOnWriteArraySet();
        this.shutdownTimeoutMillis = 2000L;
        this.flushTimeoutMillis = 15000L;
        this.sessionFlushTimeoutMillis = 15000L;
        this.logger = NoOpLogger.getInstance();
        this.diagnosticLevel = DEFAULT_DIAGNOSTIC_LEVEL;
        this.envelopeReader = new EnvelopeReader(new JsonSerializer(this));
        this.serializer = new JsonSerializer(this);
        this.maxDepth = 100;
        this.maxCacheItems = 30;
        this.maxQueueSize = 30;
        this.maxBreadcrumbs = 100;
        this.inAppExcludes = new CopyOnWriteArrayList();
        this.inAppIncludes = new CopyOnWriteArrayList();
        this.transportFactory = NoOpTransportFactory.getInstance();
        this.transportGate = NoOpTransportGate.getInstance();
        this.attachStacktrace = true;
        this.enableAutoSessionTracking = true;
        this.sessionTrackingIntervalMillis = 30000L;
        this.attachServerName = true;
        this.enableUncaughtExceptionHandler = true;
        this.printUncaughtStackTrace = false;
        this.executorService = NoOpSentryExecutorService.getInstance();
        this.connectionTimeoutMillis = 5000;
        this.readTimeoutMillis = 5000;
        this.envelopeDiskCache = NoOpEnvelopeCache.getInstance();
        this.sendDefaultPii = false;
        this.observers = new CopyOnWriteArrayList();
        this.optionsObservers = new CopyOnWriteArrayList();
        this.tags = new ConcurrentHashMap();
        this.maxAttachmentSize = 0x1400000L;
        this.enableDeduplication = true;
        this.maxSpans = 1000;
        this.enableShutdownHook = true;
        this.maxRequestBodySize = RequestSize.NONE;
        this.traceSampling = true;
        this.maxTraceFileSize = 0x500000L;
        this.transactionProfiler = NoOpTransactionProfiler.getInstance();
        this.tracePropagationTargets = null;
        this.defaultTracePropagationTargets = Collections.singletonList((Object)DEFAULT_PROPAGATION_TARGETS);
        this.idleTimeout = 3000L;
        this.contextTags = new CopyOnWriteArrayList();
        this.sendClientReports = true;
        this.clientReportRecorder = new ClientReportRecorder(this);
        this.modulesLoader = NoOpModulesLoader.getInstance();
        this.debugMetaLoader = NoOpDebugMetaLoader.getInstance();
        this.enableUserInteractionTracing = false;
        this.enableUserInteractionBreadcrumbs = true;
        this.instrumenter = Instrumenter.SENTRY;
        this.gestureTargetLocators = new ArrayList();
        this.viewHierarchyExporters = new ArrayList();
        this.mainThreadChecker = NoOpMainThreadChecker.getInstance();
        this.traceOptionsRequests = true;
        this.dateProvider = new SentryAutoDateProvider();
        this.performanceCollectors = new ArrayList();
        this.transactionPerformanceCollector = NoOpTransactionPerformanceCollector.getInstance();
        this.enableTimeToFullDisplayTracing = false;
        this.fullyDisplayedReporter = FullyDisplayedReporter.getInstance();
        this.connectionStatusProvider = new NoOpConnectionStatusProvider();
        this.enabled = true;
        this.enablePrettySerializationOutput = true;
        this.sendModules = true;
        this.enableSpotlight = false;
        this.enableScopePersistence = true;
        this.ignoredCheckIns = null;
        this.backpressureMonitor = NoOpBackpressureMonitor.getInstance();
        this.enableBackpressureHandling = true;
        this.enableAppStartProfiling = false;
        this.enableMetrics = false;
        this.enableDefaultTagsForMetrics = true;
        this.enableSpanLocalMetricAggregation = true;
        this.beforeEmitMetricCallback = null;
        this.profilingTracesHz = 101;
        this.cron = null;
        if (!bl) {
            this.executorService = new SentryExecutorService();
            copyOnWriteArrayList.add((Object)new UncaughtExceptionHandlerIntegration());
            copyOnWriteArrayList.add((Object)new ShutdownHookIntegration());
            copyOnWriteArrayList.add((Object)new SpotlightIntegration());
            copyOnWriteArrayList2.add((Object)new MainEventProcessor(this));
            copyOnWriteArrayList2.add((Object)new DuplicateEventDetectionEventProcessor(this));
            if (Platform.isJvm()) {
                copyOnWriteArrayList2.add((Object)new SentryRuntimeEventProcessor());
            }
            this.setSentryClientName("sentry.java/7.8.0");
            this.setSdkVersion(this.createSdkVersion());
            this.addPackageInfo();
        }
    }

    private void addPackageInfo() {
        SentryIntegrationPackageStorage.getInstance().addPackage("maven:io.sentry:sentry", "7.8.0");
    }

    private SdkVersion createSdkVersion() {
        SdkVersion sdkVersion = new SdkVersion("sentry.java", "7.8.0");
        sdkVersion.setVersion("7.8.0");
        return sdkVersion;
    }

    public static SentryOptions empty() {
        return new SentryOptions(true);
    }

    public void addBundleId(String string2) {
        if (string2 != null && !(string2 = string2.trim()).isEmpty()) {
            this.bundleIds.add((Object)string2);
        }
    }

    public void addContextTag(String string2) {
        this.contextTags.add((Object)string2);
    }

    public void addEventProcessor(EventProcessor eventProcessor) {
        this.eventProcessors.add((Object)eventProcessor);
    }

    public void addIgnoredExceptionForType(Class<? extends Throwable> clazz) {
        this.ignoredExceptionsForType.add(clazz);
    }

    public void addInAppExclude(String string2) {
        this.inAppExcludes.add((Object)string2);
    }

    public void addInAppInclude(String string2) {
        this.inAppIncludes.add((Object)string2);
    }

    public void addIntegration(Integration integration) {
        this.integrations.add((Object)integration);
    }

    public void addOptionsObserver(IOptionsObserver iOptionsObserver) {
        this.optionsObservers.add((Object)iOptionsObserver);
    }

    public void addPerformanceCollector(IPerformanceCollector iPerformanceCollector) {
        this.performanceCollectors.add((Object)iPerformanceCollector);
    }

    public void addScopeObserver(IScopeObserver iScopeObserver) {
        this.observers.add((Object)iScopeObserver);
    }

    @Deprecated
    public void addTracingOrigin(String string2) {
        if (this.tracePropagationTargets == null) {
            this.tracePropagationTargets = new CopyOnWriteArrayList();
        }
        if (!string2.isEmpty()) {
            this.tracePropagationTargets.add((Object)string2);
        }
    }

    boolean containsIgnoredExceptionForType(Throwable throwable) {
        return this.ignoredExceptionsForType.contains((Object)throwable.getClass());
    }

    public IBackpressureMonitor getBackpressureMonitor() {
        return this.backpressureMonitor;
    }

    public BeforeBreadcrumbCallback getBeforeBreadcrumb() {
        return this.beforeBreadcrumb;
    }

    public BeforeEmitMetricCallback getBeforeEmitMetricCallback() {
        return this.beforeEmitMetricCallback;
    }

    public BeforeEnvelopeCallback getBeforeEnvelopeCallback() {
        return this.beforeEnvelopeCallback;
    }

    public BeforeSendCallback getBeforeSend() {
        return this.beforeSend;
    }

    public BeforeSendTransactionCallback getBeforeSendTransaction() {
        return this.beforeSendTransaction;
    }

    public Set<String> getBundleIds() {
        return this.bundleIds;
    }

    public String getCacheDirPath() {
        String string2 = this.cacheDirPath;
        if (string2 != null && !string2.isEmpty()) {
            string2 = this.dsnHash != null ? new File(this.cacheDirPath, this.dsnHash).getAbsolutePath() : this.cacheDirPath;
            return string2;
        }
        return null;
    }

    String getCacheDirPathWithoutDsn() {
        String string2 = this.cacheDirPath;
        if (string2 != null && !string2.isEmpty()) {
            return this.cacheDirPath;
        }
        return null;
    }

    public IClientReportRecorder getClientReportRecorder() {
        return this.clientReportRecorder;
    }

    public IConnectionStatusProvider getConnectionStatusProvider() {
        return this.connectionStatusProvider;
    }

    public int getConnectionTimeoutMillis() {
        return this.connectionTimeoutMillis;
    }

    public List<String> getContextTags() {
        return this.contextTags;
    }

    public Cron getCron() {
        return this.cron;
    }

    public SentryDateProvider getDateProvider() {
        return this.dateProvider;
    }

    public IDebugMetaLoader getDebugMetaLoader() {
        return this.debugMetaLoader;
    }

    public SentryLevel getDiagnosticLevel() {
        return this.diagnosticLevel;
    }

    public String getDist() {
        return this.dist;
    }

    public String getDistinctId() {
        return this.distinctId;
    }

    public String getDsn() {
        return this.dsn;
    }

    public Boolean getEnableTracing() {
        return this.enableTracing;
    }

    public IEnvelopeCache getEnvelopeDiskCache() {
        return this.envelopeDiskCache;
    }

    public IEnvelopeReader getEnvelopeReader() {
        return this.envelopeReader;
    }

    public String getEnvironment() {
        String string2 = this.environment;
        if (string2 == null) {
            string2 = DEFAULT_ENVIRONMENT;
        }
        return string2;
    }

    public List<EventProcessor> getEventProcessors() {
        return this.eventProcessors;
    }

    public ISentryExecutorService getExecutorService() {
        return this.executorService;
    }

    public long getFlushTimeoutMillis() {
        return this.flushTimeoutMillis;
    }

    public FullyDisplayedReporter getFullyDisplayedReporter() {
        return this.fullyDisplayedReporter;
    }

    public List<GestureTargetLocator> getGestureTargetLocators() {
        return this.gestureTargetLocators;
    }

    public Long getIdleTimeout() {
        return this.idleTimeout;
    }

    public List<String> getIgnoredCheckIns() {
        return this.ignoredCheckIns;
    }

    public Set<Class<? extends Throwable>> getIgnoredExceptionsForType() {
        return this.ignoredExceptionsForType;
    }

    public List<String> getInAppExcludes() {
        return this.inAppExcludes;
    }

    public List<String> getInAppIncludes() {
        return this.inAppIncludes;
    }

    public Instrumenter getInstrumenter() {
        return this.instrumenter;
    }

    public List<Integration> getIntegrations() {
        return this.integrations;
    }

    public ILogger getLogger() {
        return this.logger;
    }

    public IMainThreadChecker getMainThreadChecker() {
        return this.mainThreadChecker;
    }

    public long getMaxAttachmentSize() {
        return this.maxAttachmentSize;
    }

    public int getMaxBreadcrumbs() {
        return this.maxBreadcrumbs;
    }

    public int getMaxCacheItems() {
        return this.maxCacheItems;
    }

    public int getMaxDepth() {
        return this.maxDepth;
    }

    public int getMaxQueueSize() {
        return this.maxQueueSize;
    }

    public RequestSize getMaxRequestBodySize() {
        return this.maxRequestBodySize;
    }

    public int getMaxSpans() {
        return this.maxSpans;
    }

    public long getMaxTraceFileSize() {
        return this.maxTraceFileSize;
    }

    public IModulesLoader getModulesLoader() {
        return this.modulesLoader;
    }

    public List<IOptionsObserver> getOptionsObservers() {
        return this.optionsObservers;
    }

    public String getOutboxPath() {
        String string2 = this.getCacheDirPath();
        if (string2 == null) {
            return null;
        }
        return new File(string2, "outbox").getAbsolutePath();
    }

    public List<IPerformanceCollector> getPerformanceCollectors() {
        return this.performanceCollectors;
    }

    public Double getProfilesSampleRate() {
        return this.profilesSampleRate;
    }

    public ProfilesSamplerCallback getProfilesSampler() {
        return this.profilesSampler;
    }

    public String getProfilingTracesDirPath() {
        String string2 = this.getCacheDirPath();
        if (string2 == null) {
            return null;
        }
        return new File(string2, "profiling_traces").getAbsolutePath();
    }

    public int getProfilingTracesHz() {
        return this.profilingTracesHz;
    }

    public String getProguardUuid() {
        return this.proguardUuid;
    }

    public Proxy getProxy() {
        return this.proxy;
    }

    public int getReadTimeoutMillis() {
        return this.readTimeoutMillis;
    }

    public String getRelease() {
        return this.release;
    }

    public Double getSampleRate() {
        return this.sampleRate;
    }

    public List<IScopeObserver> getScopeObservers() {
        return this.observers;
    }

    public SdkVersion getSdkVersion() {
        return this.sdkVersion;
    }

    public String getSentryClientName() {
        return this.sentryClientName;
    }

    public ISerializer getSerializer() {
        return this.serializer;
    }

    public String getServerName() {
        return this.serverName;
    }

    public long getSessionFlushTimeoutMillis() {
        return this.sessionFlushTimeoutMillis;
    }

    public long getSessionTrackingIntervalMillis() {
        return this.sessionTrackingIntervalMillis;
    }

    @Deprecated
    public long getShutdownTimeout() {
        return this.shutdownTimeoutMillis;
    }

    public long getShutdownTimeoutMillis() {
        return this.shutdownTimeoutMillis;
    }

    public String getSpotlightConnectionUrl() {
        return this.spotlightConnectionUrl;
    }

    public SSLSocketFactory getSslSocketFactory() {
        return this.sslSocketFactory;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public List<String> getTracePropagationTargets() {
        List<String> list;
        List<String> list2 = list = this.tracePropagationTargets;
        if (list == null) {
            list2 = this.defaultTracePropagationTargets;
        }
        return list2;
    }

    public Double getTracesSampleRate() {
        return this.tracesSampleRate;
    }

    public TracesSamplerCallback getTracesSampler() {
        return this.tracesSampler;
    }

    @Deprecated
    public List<String> getTracingOrigins() {
        return this.getTracePropagationTargets();
    }

    public TransactionPerformanceCollector getTransactionPerformanceCollector() {
        return this.transactionPerformanceCollector;
    }

    public ITransactionProfiler getTransactionProfiler() {
        return this.transactionProfiler;
    }

    public ITransportFactory getTransportFactory() {
        return this.transportFactory;
    }

    public ITransportGate getTransportGate() {
        return this.transportGate;
    }

    public final List<ViewHierarchyExporter> getViewHierarchyExporters() {
        return this.viewHierarchyExporters;
    }

    public boolean isAttachServerName() {
        return this.attachServerName;
    }

    public boolean isAttachStacktrace() {
        return this.attachStacktrace;
    }

    public boolean isAttachThreads() {
        return this.attachThreads;
    }

    public boolean isDebug() {
        return this.debug;
    }

    public boolean isEnableAppStartProfiling() {
        boolean bl = this.isProfilingEnabled() && this.enableAppStartProfiling;
        return bl;
    }

    public boolean isEnableAutoSessionTracking() {
        return this.enableAutoSessionTracking;
    }

    public boolean isEnableBackpressureHandling() {
        return this.enableBackpressureHandling;
    }

    public boolean isEnableDeduplication() {
        return this.enableDeduplication;
    }

    public boolean isEnableDefaultTagsForMetrics() {
        boolean bl = this.isEnableMetrics() && this.enableDefaultTagsForMetrics;
        return bl;
    }

    public boolean isEnableExternalConfiguration() {
        return this.enableExternalConfiguration;
    }

    public boolean isEnableMetrics() {
        return this.enableMetrics;
    }

    public boolean isEnablePrettySerializationOutput() {
        return this.enablePrettySerializationOutput;
    }

    public boolean isEnableScopePersistence() {
        return this.enableScopePersistence;
    }

    public boolean isEnableShutdownHook() {
        return this.enableShutdownHook;
    }

    public boolean isEnableSpanLocalMetricAggregation() {
        boolean bl = this.isEnableMetrics() && this.enableSpanLocalMetricAggregation;
        return bl;
    }

    public boolean isEnableSpotlight() {
        return this.enableSpotlight;
    }

    public boolean isEnableTimeToFullDisplayTracing() {
        return this.enableTimeToFullDisplayTracing;
    }

    public boolean isEnableUncaughtExceptionHandler() {
        return this.enableUncaughtExceptionHandler;
    }

    public boolean isEnableUserInteractionBreadcrumbs() {
        return this.enableUserInteractionBreadcrumbs;
    }

    public boolean isEnableUserInteractionTracing() {
        return this.enableUserInteractionTracing;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public boolean isPrintUncaughtStackTrace() {
        return this.printUncaughtStackTrace;
    }

    public boolean isProfilingEnabled() {
        boolean bl = this.getProfilesSampleRate() != null && this.getProfilesSampleRate() > 0.0 || this.getProfilesSampler() != null;
        return bl;
    }

    public boolean isSendClientReports() {
        return this.sendClientReports;
    }

    public boolean isSendDefaultPii() {
        return this.sendDefaultPii;
    }

    public boolean isSendModules() {
        return this.sendModules;
    }

    public boolean isTraceOptionsRequests() {
        return this.traceOptionsRequests;
    }

    public boolean isTraceSampling() {
        return this.traceSampling;
    }

    public boolean isTracingEnabled() {
        Boolean bl = this.enableTracing;
        if (bl != null) {
            return bl;
        }
        boolean bl2 = this.getTracesSampleRate() != null || this.getTracesSampler() != null;
        return bl2;
    }

    public void merge(ExternalOptions externalOptions) {
        if (externalOptions.getDsn() != null) {
            this.setDsn(externalOptions.getDsn());
        }
        if (externalOptions.getEnvironment() != null) {
            this.setEnvironment(externalOptions.getEnvironment());
        }
        if (externalOptions.getRelease() != null) {
            this.setRelease(externalOptions.getRelease());
        }
        if (externalOptions.getDist() != null) {
            this.setDist(externalOptions.getDist());
        }
        if (externalOptions.getServerName() != null) {
            this.setServerName(externalOptions.getServerName());
        }
        if (externalOptions.getProxy() != null) {
            this.setProxy(externalOptions.getProxy());
        }
        if (externalOptions.getEnableUncaughtExceptionHandler() != null) {
            this.setEnableUncaughtExceptionHandler(externalOptions.getEnableUncaughtExceptionHandler());
        }
        if (externalOptions.getPrintUncaughtStackTrace() != null) {
            this.setPrintUncaughtStackTrace(externalOptions.getPrintUncaughtStackTrace());
        }
        if (externalOptions.getEnableTracing() != null) {
            this.setEnableTracing(externalOptions.getEnableTracing());
        }
        if (externalOptions.getTracesSampleRate() != null) {
            this.setTracesSampleRate(externalOptions.getTracesSampleRate());
        }
        if (externalOptions.getProfilesSampleRate() != null) {
            this.setProfilesSampleRate(externalOptions.getProfilesSampleRate());
        }
        if (externalOptions.getDebug() != null) {
            this.setDebug(externalOptions.getDebug());
        }
        if (externalOptions.getEnableDeduplication() != null) {
            this.setEnableDeduplication(externalOptions.getEnableDeduplication());
        }
        if (externalOptions.getSendClientReports() != null) {
            this.setSendClientReports(externalOptions.getSendClientReports());
        }
        for (Map.Entry entry : new HashMap(externalOptions.getTags()).entrySet()) {
            this.tags.put((Object)((String)entry.getKey()), (Object)((String)entry.getValue()));
        }
        Iterator iterator = new ArrayList(externalOptions.getInAppIncludes()).iterator();
        while (iterator.hasNext()) {
            this.addInAppInclude((String)iterator.next());
        }
        iterator = new ArrayList(externalOptions.getInAppExcludes()).iterator();
        while (iterator.hasNext()) {
            this.addInAppExclude((String)iterator.next());
        }
        iterator = new HashSet(externalOptions.getIgnoredExceptionsForType()).iterator();
        while (iterator.hasNext()) {
            this.addIgnoredExceptionForType((Class<? extends Throwable>)((Class)iterator.next()));
        }
        if (externalOptions.getTracePropagationTargets() != null) {
            this.setTracePropagationTargets((List<String>)new ArrayList(externalOptions.getTracePropagationTargets()));
        }
        iterator = new ArrayList(externalOptions.getContextTags()).iterator();
        while (iterator.hasNext()) {
            this.addContextTag((String)iterator.next());
        }
        if (externalOptions.getProguardUuid() != null) {
            this.setProguardUuid(externalOptions.getProguardUuid());
        }
        if (externalOptions.getIdleTimeout() != null) {
            this.setIdleTimeout(externalOptions.getIdleTimeout());
        }
        iterator = externalOptions.getBundleIds().iterator();
        while (iterator.hasNext()) {
            this.addBundleId((String)iterator.next());
        }
        if (externalOptions.isEnabled() != null) {
            this.setEnabled(externalOptions.isEnabled());
        }
        if (externalOptions.isEnablePrettySerializationOutput() != null) {
            this.setEnablePrettySerializationOutput(externalOptions.isEnablePrettySerializationOutput());
        }
        if (externalOptions.isSendModules() != null) {
            this.setSendModules(externalOptions.isSendModules());
        }
        if (externalOptions.getIgnoredCheckIns() != null) {
            this.setIgnoredCheckIns((List<String>)new ArrayList(externalOptions.getIgnoredCheckIns()));
        }
        if (externalOptions.isEnableBackpressureHandling() != null) {
            this.setEnableBackpressureHandling(externalOptions.isEnableBackpressureHandling());
        }
        if (externalOptions.getCron() != null) {
            if (this.getCron() == null) {
                this.setCron(externalOptions.getCron());
            } else {
                if (externalOptions.getCron().getDefaultCheckinMargin() != null) {
                    this.getCron().setDefaultCheckinMargin(externalOptions.getCron().getDefaultCheckinMargin());
                }
                if (externalOptions.getCron().getDefaultMaxRuntime() != null) {
                    this.getCron().setDefaultMaxRuntime(externalOptions.getCron().getDefaultMaxRuntime());
                }
                if (externalOptions.getCron().getDefaultTimezone() != null) {
                    this.getCron().setDefaultTimezone(externalOptions.getCron().getDefaultTimezone());
                }
                if (externalOptions.getCron().getDefaultFailureIssueThreshold() != null) {
                    this.getCron().setDefaultFailureIssueThreshold(externalOptions.getCron().getDefaultFailureIssueThreshold());
                }
                if (externalOptions.getCron().getDefaultRecoveryThreshold() != null) {
                    this.getCron().setDefaultRecoveryThreshold(externalOptions.getCron().getDefaultRecoveryThreshold());
                }
            }
        }
    }

    public void setAttachServerName(boolean bl) {
        this.attachServerName = bl;
    }

    public void setAttachStacktrace(boolean bl) {
        this.attachStacktrace = bl;
    }

    public void setAttachThreads(boolean bl) {
        this.attachThreads = bl;
    }

    public void setBackpressureMonitor(IBackpressureMonitor iBackpressureMonitor) {
        this.backpressureMonitor = iBackpressureMonitor;
    }

    public void setBeforeBreadcrumb(BeforeBreadcrumbCallback beforeBreadcrumbCallback) {
        this.beforeBreadcrumb = beforeBreadcrumbCallback;
    }

    public void setBeforeEmitMetricCallback(BeforeEmitMetricCallback beforeEmitMetricCallback) {
        this.beforeEmitMetricCallback = beforeEmitMetricCallback;
    }

    public void setBeforeEnvelopeCallback(BeforeEnvelopeCallback beforeEnvelopeCallback) {
        this.beforeEnvelopeCallback = beforeEnvelopeCallback;
    }

    public void setBeforeSend(BeforeSendCallback beforeSendCallback) {
        this.beforeSend = beforeSendCallback;
    }

    public void setBeforeSendTransaction(BeforeSendTransactionCallback beforeSendTransactionCallback) {
        this.beforeSendTransaction = beforeSendTransactionCallback;
    }

    public void setCacheDirPath(String string2) {
        this.cacheDirPath = string2;
    }

    public void setConnectionStatusProvider(IConnectionStatusProvider iConnectionStatusProvider) {
        this.connectionStatusProvider = iConnectionStatusProvider;
    }

    public void setConnectionTimeoutMillis(int n2) {
        this.connectionTimeoutMillis = n2;
    }

    public void setCron(Cron cron) {
        this.cron = cron;
    }

    public void setDateProvider(SentryDateProvider sentryDateProvider) {
        this.dateProvider = sentryDateProvider;
    }

    public void setDebug(boolean bl) {
        this.debug = bl;
    }

    public void setDebugMetaLoader(IDebugMetaLoader iDebugMetaLoader) {
        if (iDebugMetaLoader == null) {
            iDebugMetaLoader = NoOpDebugMetaLoader.getInstance();
        }
        this.debugMetaLoader = iDebugMetaLoader;
    }

    public void setDiagnosticLevel(SentryLevel sentryLevel) {
        if (sentryLevel == null) {
            sentryLevel = DEFAULT_DIAGNOSTIC_LEVEL;
        }
        this.diagnosticLevel = sentryLevel;
    }

    public void setDist(String string2) {
        this.dist = string2;
    }

    public void setDistinctId(String string2) {
        this.distinctId = string2;
    }

    public void setDsn(String string2) {
        this.dsn = string2;
        this.dsnHash = StringUtils.calculateStringHash(string2, this.logger);
    }

    public void setEnableAppStartProfiling(boolean bl) {
        this.enableAppStartProfiling = bl;
    }

    public void setEnableAutoSessionTracking(boolean bl) {
        this.enableAutoSessionTracking = bl;
    }

    public void setEnableBackpressureHandling(boolean bl) {
        this.enableBackpressureHandling = bl;
    }

    public void setEnableDeduplication(boolean bl) {
        this.enableDeduplication = bl;
    }

    public void setEnableDefaultTagsForMetrics(boolean bl) {
        this.enableDefaultTagsForMetrics = bl;
    }

    public void setEnableExternalConfiguration(boolean bl) {
        this.enableExternalConfiguration = bl;
    }

    public void setEnableMetrics(boolean bl) {
        this.enableMetrics = bl;
    }

    public void setEnablePrettySerializationOutput(boolean bl) {
        this.enablePrettySerializationOutput = bl;
    }

    public void setEnableScopePersistence(boolean bl) {
        this.enableScopePersistence = bl;
    }

    public void setEnableShutdownHook(boolean bl) {
        this.enableShutdownHook = bl;
    }

    public void setEnableSpanLocalMetricAggregation(boolean bl) {
        this.enableSpanLocalMetricAggregation = bl;
    }

    public void setEnableSpotlight(boolean bl) {
        this.enableSpotlight = bl;
    }

    public void setEnableTimeToFullDisplayTracing(boolean bl) {
        this.enableTimeToFullDisplayTracing = bl;
    }

    public void setEnableTracing(Boolean bl) {
        this.enableTracing = bl;
    }

    public void setEnableUncaughtExceptionHandler(boolean bl) {
        this.enableUncaughtExceptionHandler = bl;
    }

    public void setEnableUserInteractionBreadcrumbs(boolean bl) {
        this.enableUserInteractionBreadcrumbs = bl;
    }

    public void setEnableUserInteractionTracing(boolean bl) {
        this.enableUserInteractionTracing = bl;
    }

    public void setEnabled(boolean bl) {
        this.enabled = bl;
    }

    public void setEnvelopeDiskCache(IEnvelopeCache iEnvelopeCache) {
        if (iEnvelopeCache == null) {
            iEnvelopeCache = NoOpEnvelopeCache.getInstance();
        }
        this.envelopeDiskCache = iEnvelopeCache;
    }

    public void setEnvelopeReader(IEnvelopeReader iEnvelopeReader) {
        if (iEnvelopeReader == null) {
            iEnvelopeReader = NoOpEnvelopeReader.getInstance();
        }
        this.envelopeReader = iEnvelopeReader;
    }

    public void setEnvironment(String string2) {
        this.environment = string2;
    }

    public void setExecutorService(ISentryExecutorService iSentryExecutorService) {
        if (iSentryExecutorService != null) {
            this.executorService = iSentryExecutorService;
        }
    }

    public void setFlushTimeoutMillis(long l2) {
        this.flushTimeoutMillis = l2;
    }

    public void setGestureTargetLocators(List<GestureTargetLocator> list) {
        this.gestureTargetLocators.clear();
        this.gestureTargetLocators.addAll(list);
    }

    public void setIdleTimeout(Long l2) {
        this.idleTimeout = l2;
    }

    public void setIgnoredCheckIns(List<String> object2) {
        if (object2 == null) {
            this.ignoredCheckIns = null;
        } else {
            ArrayList arrayList = new ArrayList();
            for (Object object2 : object2) {
                if (object2.isEmpty()) continue;
                arrayList.add(object2);
            }
            this.ignoredCheckIns = arrayList;
        }
    }

    public void setInstrumenter(Instrumenter instrumenter) {
        this.instrumenter = instrumenter;
    }

    public void setLogger(ILogger iLogger) {
        iLogger = iLogger == null ? NoOpLogger.getInstance() : new DiagnosticLogger(this, iLogger);
        this.logger = iLogger;
    }

    public void setMainThreadChecker(IMainThreadChecker iMainThreadChecker) {
        this.mainThreadChecker = iMainThreadChecker;
    }

    public void setMaxAttachmentSize(long l2) {
        this.maxAttachmentSize = l2;
    }

    public void setMaxBreadcrumbs(int n2) {
        this.maxBreadcrumbs = n2;
    }

    public void setMaxCacheItems(int n2) {
        this.maxCacheItems = n2;
    }

    public void setMaxDepth(int n2) {
        this.maxDepth = n2;
    }

    public void setMaxQueueSize(int n2) {
        if (n2 > 0) {
            this.maxQueueSize = n2;
        }
    }

    public void setMaxRequestBodySize(RequestSize requestSize) {
        this.maxRequestBodySize = requestSize;
    }

    public void setMaxSpans(int n2) {
        this.maxSpans = n2;
    }

    public void setMaxTraceFileSize(long l2) {
        this.maxTraceFileSize = l2;
    }

    public void setModulesLoader(IModulesLoader iModulesLoader) {
        if (iModulesLoader == null) {
            iModulesLoader = NoOpModulesLoader.getInstance();
        }
        this.modulesLoader = iModulesLoader;
    }

    public void setPrintUncaughtStackTrace(boolean bl) {
        this.printUncaughtStackTrace = bl;
    }

    public void setProfilesSampleRate(Double d2) {
        if (SampleRateUtils.isValidProfilesSampleRate(d2)) {
            this.profilesSampleRate = d2;
            return;
        }
        throw new IllegalArgumentException("The value " + d2 + " is not valid. Use null to disable or values between 0.0 and 1.0.");
    }

    public void setProfilesSampler(ProfilesSamplerCallback profilesSamplerCallback) {
        this.profilesSampler = profilesSamplerCallback;
    }

    @Deprecated
    public void setProfilingEnabled(boolean bl) {
        if (this.getProfilesSampleRate() == null) {
            Double d2 = bl ? Double.valueOf((double)1.0) : null;
            this.setProfilesSampleRate(d2);
        }
    }

    public void setProfilingTracesHz(int n2) {
        this.profilingTracesHz = n2;
    }

    public void setProguardUuid(String string2) {
        this.proguardUuid = string2;
    }

    public void setProxy(Proxy proxy2) {
        this.proxy = proxy2;
    }

    public void setReadTimeoutMillis(int n2) {
        this.readTimeoutMillis = n2;
    }

    public void setRelease(String string2) {
        this.release = string2;
    }

    public void setSampleRate(Double d2) {
        if (SampleRateUtils.isValidSampleRate(d2)) {
            this.sampleRate = d2;
            return;
        }
        throw new IllegalArgumentException("The value " + d2 + " is not valid. Use null to disable or values >= 0.0 and <= 1.0.");
    }

    public void setSdkVersion(SdkVersion sdkVersion) {
        this.sdkVersion = sdkVersion;
    }

    public void setSendClientReports(boolean bl) {
        this.sendClientReports = bl;
        this.clientReportRecorder = bl ? new ClientReportRecorder(this) : new NoOpClientReportRecorder();
    }

    public void setSendDefaultPii(boolean bl) {
        this.sendDefaultPii = bl;
    }

    public void setSendModules(boolean bl) {
        this.sendModules = bl;
    }

    public void setSentryClientName(String string2) {
        this.sentryClientName = string2;
    }

    public void setSerializer(ISerializer iSerializer) {
        if (iSerializer == null) {
            iSerializer = NoOpSerializer.getInstance();
        }
        this.serializer = iSerializer;
    }

    public void setServerName(String string2) {
        this.serverName = string2;
    }

    public void setSessionFlushTimeoutMillis(long l2) {
        this.sessionFlushTimeoutMillis = l2;
    }

    public void setSessionTrackingIntervalMillis(long l2) {
        this.sessionTrackingIntervalMillis = l2;
    }

    @Deprecated
    public void setShutdownTimeout(long l2) {
        this.shutdownTimeoutMillis = l2;
    }

    public void setShutdownTimeoutMillis(long l2) {
        this.shutdownTimeoutMillis = l2;
    }

    public void setSpotlightConnectionUrl(String string2) {
        this.spotlightConnectionUrl = string2;
    }

    public void setSslSocketFactory(SSLSocketFactory sSLSocketFactory) {
        this.sslSocketFactory = sSLSocketFactory;
    }

    public void setTag(String string2, String string3) {
        this.tags.put((Object)string2, (Object)string3);
    }

    public void setTraceOptionsRequests(boolean bl) {
        this.traceOptionsRequests = bl;
    }

    public void setTracePropagationTargets(List<String> object2) {
        if (object2 == null) {
            this.tracePropagationTargets = null;
        } else {
            ArrayList arrayList = new ArrayList();
            for (Object object2 : object2) {
                if (object2.isEmpty()) continue;
                arrayList.add(object2);
            }
            this.tracePropagationTargets = arrayList;
        }
    }

    @Deprecated
    public void setTraceSampling(boolean bl) {
        this.traceSampling = bl;
    }

    public void setTracesSampleRate(Double d2) {
        if (SampleRateUtils.isValidTracesSampleRate(d2)) {
            this.tracesSampleRate = d2;
            return;
        }
        throw new IllegalArgumentException("The value " + d2 + " is not valid. Use null to disable or values between 0.0 and 1.0.");
    }

    public void setTracesSampler(TracesSamplerCallback tracesSamplerCallback) {
        this.tracesSampler = tracesSamplerCallback;
    }

    @Deprecated
    public void setTracingOrigins(List<String> list) {
        this.setTracePropagationTargets(list);
    }

    public void setTransactionPerformanceCollector(TransactionPerformanceCollector transactionPerformanceCollector) {
        this.transactionPerformanceCollector = transactionPerformanceCollector;
    }

    public void setTransactionProfiler(ITransactionProfiler iTransactionProfiler) {
        if (this.transactionProfiler == NoOpTransactionProfiler.getInstance() && iTransactionProfiler != null) {
            this.transactionProfiler = iTransactionProfiler;
        }
    }

    public void setTransportFactory(ITransportFactory iTransportFactory) {
        if (iTransportFactory == null) {
            iTransportFactory = NoOpTransportFactory.getInstance();
        }
        this.transportFactory = iTransportFactory;
    }

    public void setTransportGate(ITransportGate iTransportGate) {
        if (iTransportGate == null) {
            iTransportGate = NoOpTransportGate.getInstance();
        }
        this.transportGate = iTransportGate;
    }

    public void setViewHierarchyExporters(List<ViewHierarchyExporter> list) {
        this.viewHierarchyExporters.clear();
        this.viewHierarchyExporters.addAll(list);
    }

    public static interface BeforeBreadcrumbCallback {
        public Breadcrumb execute(Breadcrumb var1, Hint var2);
    }

    public static interface BeforeEmitMetricCallback {
        public boolean execute(String var1, Map<String, String> var2);
    }

    public static interface BeforeEnvelopeCallback {
        public void execute(SentryEnvelope var1, Hint var2);
    }

    public static interface BeforeSendCallback {
        public SentryEvent execute(SentryEvent var1, Hint var2);
    }

    public static interface BeforeSendTransactionCallback {
        public SentryTransaction execute(SentryTransaction var1, Hint var2);
    }

    public static final class Cron {
        private Long defaultCheckinMargin;
        private Long defaultFailureIssueThreshold;
        private Long defaultMaxRuntime;
        private Long defaultRecoveryThreshold;
        private String defaultTimezone;

        public Long getDefaultCheckinMargin() {
            return this.defaultCheckinMargin;
        }

        public Long getDefaultFailureIssueThreshold() {
            return this.defaultFailureIssueThreshold;
        }

        public Long getDefaultMaxRuntime() {
            return this.defaultMaxRuntime;
        }

        public Long getDefaultRecoveryThreshold() {
            return this.defaultRecoveryThreshold;
        }

        public String getDefaultTimezone() {
            return this.defaultTimezone;
        }

        public void setDefaultCheckinMargin(Long l2) {
            this.defaultCheckinMargin = l2;
        }

        public void setDefaultFailureIssueThreshold(Long l2) {
            this.defaultFailureIssueThreshold = l2;
        }

        public void setDefaultMaxRuntime(Long l2) {
            this.defaultMaxRuntime = l2;
        }

        public void setDefaultRecoveryThreshold(Long l2) {
            this.defaultRecoveryThreshold = l2;
        }

        public void setDefaultTimezone(String string2) {
            this.defaultTimezone = string2;
        }
    }

    public static interface ProfilesSamplerCallback {
        public Double sample(SamplingContext var1);
    }

    public static final class Proxy {
        private String host;
        private String pass;
        private String port;
        private Proxy.Type type;
        private String user;

        public Proxy() {
            this(null, null, null, null, null);
        }

        public Proxy(String string2, String string3) {
            this(string2, string3, null, null, null);
        }

        public Proxy(String string2, String string3, String string4, String string5) {
            this(string2, string3, null, string4, string5);
        }

        public Proxy(String string2, String string3, Proxy.Type type) {
            this(string2, string3, type, null, null);
        }

        public Proxy(String string2, String string3, Proxy.Type type, String string4, String string5) {
            this.host = string2;
            this.port = string3;
            this.type = type;
            this.user = string4;
            this.pass = string5;
        }

        public String getHost() {
            return this.host;
        }

        public String getPass() {
            return this.pass;
        }

        public String getPort() {
            return this.port;
        }

        public Proxy.Type getType() {
            return this.type;
        }

        public String getUser() {
            return this.user;
        }

        public void setHost(String string2) {
            this.host = string2;
        }

        public void setPass(String string2) {
            this.pass = string2;
        }

        public void setPort(String string2) {
            this.port = string2;
        }

        public void setType(Proxy.Type type) {
            this.type = type;
        }

        public void setUser(String string2) {
            this.user = string2;
        }
    }

    public static enum RequestSize {
        NONE,
        SMALL,
        MEDIUM,
        ALWAYS;

    }

    public static interface TracesSamplerCallback {
        public Double sample(SamplingContext var1);
    }
}

