/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry;

import io.sentry.Sentry;
import io.sentry.SentryOptions;

public final class Sentry$$ExternalSyntheticLambda4
implements Runnable {
    public final SentryOptions f$0;

    public /* synthetic */ Sentry$$ExternalSyntheticLambda4(SentryOptions sentryOptions) {
        this.f$0 = sentryOptions;
    }

    public final void run() {
        Sentry.lambda$notifyOptionsObservers$3(this.f$0);
    }
}

