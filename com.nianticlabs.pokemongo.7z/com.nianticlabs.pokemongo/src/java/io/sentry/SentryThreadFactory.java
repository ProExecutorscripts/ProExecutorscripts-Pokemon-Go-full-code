/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry;

import io.sentry.SentryOptions;
import io.sentry.SentryStackTraceFactory;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class SentryThreadFactory {
    private final SentryOptions options;
    private final SentryStackTraceFactory sentryStackTraceFactory;

    public SentryThreadFactory(SentryStackTraceFactory sentryStackTraceFactory, SentryOptions sentryOptions) {
        this.sentryStackTraceFactory = Objects.requireNonNull(sentryStackTraceFactory, "The SentryStackTraceFactory is required.");
        this.options = Objects.requireNonNull(sentryOptions, "The SentryOptions is required");
    }

    private SentryThread getSentryThread(boolean bl, StackTraceElement[] object, Thread thread) {
        SentryThread sentryThread = new SentryThread();
        sentryThread.setName(thread.getName());
        sentryThread.setPriority(thread.getPriority());
        sentryThread.setId(thread.getId());
        sentryThread.setDaemon(thread.isDaemon());
        sentryThread.setState(thread.getState().name());
        sentryThread.setCrashed(bl);
        object = this.sentryStackTraceFactory.getStackFrames((StackTraceElement[])object, false);
        if (this.options.isAttachStacktrace() && object != null && !object.isEmpty()) {
            object = new SentryStackTrace((List<SentryStackFrame>)object);
            ((SentryStackTrace)object).setSnapshot(true);
            sentryThread.setStacktrace((SentryStackTrace)object);
        }
        return sentryThread;
    }

    List<SentryThread> getCurrentThread() {
        HashMap hashMap = new HashMap();
        Thread thread = Thread.currentThread();
        hashMap.put((Object)thread, (Object)thread.getStackTrace());
        return this.getCurrentThreads((Map<Thread, StackTraceElement[]>)hashMap, null, false);
    }

    List<SentryThread> getCurrentThreads(List<Long> list) {
        return this.getCurrentThreads((Map<Thread, StackTraceElement[]>)Thread.getAllStackTraces(), list, false);
    }

    List<SentryThread> getCurrentThreads(List<Long> list, boolean bl) {
        return this.getCurrentThreads((Map<Thread, StackTraceElement[]>)Thread.getAllStackTraces(), list, bl);
    }

    List<SentryThread> getCurrentThreads(Map<Thread, StackTraceElement[]> arrayList, List<Long> list, boolean bl) {
        Thread thread = Thread.currentThread();
        if (!arrayList.isEmpty()) {
            ArrayList arrayList2 = new ArrayList();
            if (!arrayList.containsKey((Object)thread)) {
                arrayList.put((Object)thread, (Object)thread.getStackTrace());
            }
            Iterator iterator = arrayList.entrySet().iterator();
            while (true) {
                arrayList = arrayList2;
                if (iterator.hasNext()) {
                    arrayList = (Map.Entry)iterator.next();
                    Thread thread2 = (Thread)arrayList.getKey();
                    boolean bl2 = thread2 == thread && !bl || list != null && list.contains((Object)thread2.getId());
                    arrayList2.add((Object)this.getSentryThread(bl2, (StackTraceElement[])arrayList.getValue(), (Thread)arrayList.getKey()));
                    continue;
                }
                break;
            }
        } else {
            arrayList = null;
        }
        return arrayList;
    }
}

