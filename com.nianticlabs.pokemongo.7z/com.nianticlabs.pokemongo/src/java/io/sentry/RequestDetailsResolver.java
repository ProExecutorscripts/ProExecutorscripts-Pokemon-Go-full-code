/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.Dsn;
import io.sentry.RequestDetails;
import io.sentry.SentryOptions;
import io.sentry.util.Objects;
import java.util.HashMap;
import java.util.Map;

final class RequestDetailsResolver {
    private static final String SENTRY_AUTH = "X-Sentry-Auth";
    private static final String USER_AGENT = "User-Agent";
    private final SentryOptions options;

    public RequestDetailsResolver(SentryOptions sentryOptions) {
        this.options = Objects.requireNonNull(sentryOptions, "options is required");
    }

    RequestDetails resolve() {
        Object object = new Dsn(this.options.getDsn());
        Object object2 = ((Dsn)object).getSentryUri();
        object2 = object2.resolve(object2.getPath() + "/envelope/").toString();
        String string2 = ((Dsn)object).getPublicKey();
        object = ((Dsn)object).getSecretKey();
        string2 = new StringBuilder("Sentry sentry_version=7,sentry_client=").append(this.options.getSentryClientName()).append(",sentry_key=").append(string2);
        object = object != null && object.length() > 0 ? ",sentry_secret=" + (String)object : "";
        String string3 = string2.append((String)object).toString();
        object = this.options.getSentryClientName();
        string2 = new HashMap();
        string2.put((Object)USER_AGENT, object);
        string2.put((Object)SENTRY_AUTH, (Object)string3);
        return new RequestDetails((String)object2, (Map<String, String>)string2);
    }
}

