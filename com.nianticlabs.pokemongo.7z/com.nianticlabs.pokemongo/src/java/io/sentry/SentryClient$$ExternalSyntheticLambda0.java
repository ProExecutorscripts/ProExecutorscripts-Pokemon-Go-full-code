/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.Scope;
import io.sentry.SentryClient;
import io.sentry.Session;

public final class SentryClient$$ExternalSyntheticLambda0
implements Scope.IWithSession {
    @Override
    public final void accept(Session session) {
        SentryClient.lambda$captureEvent$0(session);
    }
}

