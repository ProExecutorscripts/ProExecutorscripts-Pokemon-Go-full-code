/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

import io.sentry.Baggage;
import io.sentry.Instrumenter;
import io.sentry.PropagationContext;
import io.sentry.SentryTraceHeader;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.TracesSamplingDecision;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.util.Objects;

public final class TransactionContext
extends SpanContext {
    private static final String DEFAULT_NAME = "<unlabeled transaction>";
    private static final TransactionNameSource DEFAULT_NAME_SOURCE = TransactionNameSource.CUSTOM;
    private static final String DEFAULT_OPERATION = "default";
    private Baggage baggage;
    private Instrumenter instrumenter = Instrumenter.SENTRY;
    private boolean isForNextAppStart = false;
    private String name;
    private TracesSamplingDecision parentSamplingDecision;
    private TransactionNameSource transactionNameSource;

    public TransactionContext(SentryId sentryId, SpanId spanId, SpanId spanId2, TracesSamplingDecision tracesSamplingDecision, Baggage baggage) {
        super(sentryId, spanId, DEFAULT_OPERATION, spanId2, null);
        this.name = DEFAULT_NAME;
        this.parentSamplingDecision = tracesSamplingDecision;
        this.transactionNameSource = DEFAULT_NAME_SOURCE;
        this.baggage = baggage;
    }

    public TransactionContext(String string2, TransactionNameSource transactionNameSource, String string3) {
        this(string2, transactionNameSource, string3, null);
    }

    public TransactionContext(String string2, TransactionNameSource transactionNameSource, String string3, TracesSamplingDecision tracesSamplingDecision) {
        super(string3);
        this.name = Objects.requireNonNull(string2, "name is required");
        this.transactionNameSource = transactionNameSource;
        this.setSamplingDecision(tracesSamplingDecision);
    }

    public TransactionContext(String string2, String string3) {
        this(string2, string3, null);
    }

    public TransactionContext(String string2, String string3, TracesSamplingDecision tracesSamplingDecision) {
        this(string2, TransactionNameSource.CUSTOM, string3, tracesSamplingDecision);
    }

    public static TransactionContext fromPropagationContext(PropagationContext propagationContext) {
        Boolean bl = propagationContext.isSampled();
        TracesSamplingDecision tracesSamplingDecision = bl == null ? null : new TracesSamplingDecision(bl);
        Baggage baggage = propagationContext.getBaggage();
        if (baggage != null) {
            baggage.freeze();
            tracesSamplingDecision = baggage.getSampleRateDouble();
            boolean bl2 = bl != null ? bl : false;
            bl = bl2;
            tracesSamplingDecision = tracesSamplingDecision != null ? new TracesSamplingDecision(bl, (Double)tracesSamplingDecision) : new TracesSamplingDecision(bl);
        }
        return new TransactionContext(propagationContext.getTraceId(), propagationContext.getSpanId(), propagationContext.getParentSpanId(), tracesSamplingDecision, baggage);
    }

    @Deprecated
    public static TransactionContext fromSentryTrace(String string2, String string3, SentryTraceHeader object) {
        Object object2 = ((SentryTraceHeader)object).isSampled();
        object2 = object2 == null ? null : new TracesSamplingDecision((Boolean)object2);
        object = new TransactionContext(((SentryTraceHeader)object).getTraceId(), new SpanId(), ((SentryTraceHeader)object).getSpanId(), (TracesSamplingDecision)object2, null);
        ((TransactionContext)object).setName(string2);
        ((TransactionContext)object).setTransactionNameSource(TransactionNameSource.CUSTOM);
        ((SpanContext)object).setOperation(string3);
        return object;
    }

    public Baggage getBaggage() {
        return this.baggage;
    }

    public Instrumenter getInstrumenter() {
        return this.instrumenter;
    }

    public String getName() {
        return this.name;
    }

    public Boolean getParentSampled() {
        TracesSamplingDecision tracesSamplingDecision = this.parentSamplingDecision;
        if (tracesSamplingDecision == null) {
            return null;
        }
        return tracesSamplingDecision.getSampled();
    }

    public TracesSamplingDecision getParentSamplingDecision() {
        return this.parentSamplingDecision;
    }

    public TransactionNameSource getTransactionNameSource() {
        return this.transactionNameSource;
    }

    public boolean isForNextAppStart() {
        return this.isForNextAppStart;
    }

    public void setForNextAppStart(boolean bl) {
        this.isForNextAppStart = bl;
    }

    public void setInstrumenter(Instrumenter instrumenter) {
        this.instrumenter = instrumenter;
    }

    public void setName(String string2) {
        this.name = Objects.requireNonNull(string2, "name is required");
    }

    public void setParentSampled(Boolean bl) {
        this.parentSamplingDecision = bl == null ? null : new TracesSamplingDecision(bl);
    }

    public void setParentSampled(Boolean bl, Boolean bl2) {
        this.parentSamplingDecision = bl == null ? null : (bl2 == null ? new TracesSamplingDecision(bl) : new TracesSamplingDecision(bl, null, bl2, null));
    }

    public void setTransactionNameSource(TransactionNameSource transactionNameSource) {
        this.transactionNameSource = transactionNameSource;
    }
}

