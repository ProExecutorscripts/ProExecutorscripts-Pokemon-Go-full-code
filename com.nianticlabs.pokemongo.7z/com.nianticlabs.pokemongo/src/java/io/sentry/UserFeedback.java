/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.protocol.SentryId;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class UserFeedback
implements JsonUnknown,
JsonSerializable {
    private String comments;
    private String email;
    private final SentryId eventId;
    private String name;
    private Map<String, Object> unknown;

    public UserFeedback(SentryId sentryId) {
        this(sentryId, null, null, null);
    }

    public UserFeedback(SentryId sentryId, String string2, String string3, String string4) {
        this.eventId = sentryId;
        this.name = string2;
        this.email = string3;
        this.comments = string4;
    }

    public String getComments() {
        return this.comments;
    }

    public String getEmail() {
        return this.email;
    }

    public SentryId getEventId() {
        return this.eventId;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        objectWriter.name("event_id");
        this.eventId.serialize(objectWriter, iLogger);
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.email != null) {
            objectWriter.name("email").value(this.email);
        }
        if (this.comments != null) {
            objectWriter.name("comments").value(this.comments);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setComments(String string2) {
        this.comments = string2;
    }

    public void setEmail(String string2) {
        this.email = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public String toString() {
        return "UserFeedback{eventId=" + this.eventId + ", name='" + this.name + "', email='" + this.email + "', comments='" + this.comments + "'}";
    }

    public static final class Deserializer
    implements JsonDeserializer<UserFeedback> {
        @Override
        public UserFeedback deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            String string2;
            String string3;
            ((JsonReader)object).beginObject();
            SentryId sentryId = null;
            String string4 = null;
            String string5 = string3 = (string2 = null);
            block12: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string6 = ((JsonReader)object).nextName();
                string6.hashCode();
                int n2 = string6.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 278118624: {
                        if (!string6.equals((Object)"event_id")) break;
                        n3 = 3;
                        break;
                    }
                    case 96619420: {
                        if (!string6.equals((Object)"email")) break;
                        n3 = 2;
                        break;
                    }
                    case 3373707: {
                        if (!string6.equals((Object)"name")) break;
                        n3 = 1;
                        break;
                    }
                    case -602415628: {
                        if (!string6.equals((Object)"comments")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        String string7 = string5;
                        if (string5 == null) {
                            string7 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)string7, string6);
                        string5 = string7;
                        continue block12;
                    }
                    case 3: {
                        sentryId = new SentryId.Deserializer().deserialize((JsonObjectReader)object, iLogger);
                        continue block12;
                    }
                    case 2: {
                        string2 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block12;
                    }
                    case 1: {
                        string4 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block12;
                    }
                    case 0: 
                }
                string3 = ((JsonObjectReader)object).nextStringOrNull();
            }
            ((JsonReader)object).endObject();
            if (sentryId != null) {
                object = new UserFeedback(sentryId, string4, string2, string3);
                ((UserFeedback)object).setUnknown((Map<String, Object>)string5);
                return object;
            }
            object = new IllegalStateException("Missing required field \"event_id\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"event_id\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String COMMENTS = "comments";
        public static final String EMAIL = "email";
        public static final String EVENT_ID = "event_id";
        public static final String NAME = "name";
    }
}

