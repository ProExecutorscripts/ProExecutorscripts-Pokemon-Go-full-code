/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Properties
 */
package io.sentry.config;

import io.sentry.config.PropertiesProvider;
import io.sentry.util.Objects;
import io.sentry.util.StringUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

abstract class AbstractPropertiesProvider
implements PropertiesProvider {
    private final String prefix;
    private final Properties properties;

    protected AbstractPropertiesProvider(String string2, Properties properties) {
        this.prefix = Objects.requireNonNull(string2, "prefix is required");
        this.properties = Objects.requireNonNull(properties, "properties are required");
    }

    protected AbstractPropertiesProvider(Properties properties) {
        this("", properties);
    }

    @Override
    public Map<String, String> getMap(String string2) {
        String string3 = this.prefix + string2 + ".";
        HashMap hashMap = new HashMap();
        for (Object object : this.properties.entrySet()) {
            if (!(object.getKey() instanceof String) || !(object.getValue() instanceof String) || !(string2 = (String)object.getKey()).startsWith(string3)) continue;
            object = StringUtils.removeSurrounding((String)object.getValue(), "\"");
            hashMap.put((Object)string2.substring(string3.length()), object);
        }
        return hashMap;
    }

    @Override
    public String getProperty(String string2) {
        return StringUtils.removeSurrounding(this.properties.getProperty(this.prefix + string2), "\"");
    }
}

