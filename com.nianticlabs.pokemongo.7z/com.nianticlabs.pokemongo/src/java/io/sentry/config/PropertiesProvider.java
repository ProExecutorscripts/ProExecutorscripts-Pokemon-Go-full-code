/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public interface PropertiesProvider {
    default public Boolean getBooleanProperty(String string2) {
        string2 = (string2 = this.getProperty(string2)) != null ? Boolean.valueOf((String)string2) : null;
        return string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    default public Double getDoubleProperty(String string2) {
        if ((string2 = this.getProperty(string2)) == null) return null;
        try {
            return Double.valueOf((String)string2);
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    default public List<String> getList(String string2) {
        string2 = (string2 = this.getProperty(string2)) != null ? Arrays.asList((Object[])string2.split(",")) : Collections.emptyList();
        return string2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    default public Long getLongProperty(String string2) {
        if ((string2 = this.getProperty(string2)) == null) return null;
        try {
            return Long.valueOf((String)string2);
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    public Map<String, String> getMap(String var1);

    public String getProperty(String var1);

    default public String getProperty(String string2, String string3) {
        if ((string2 = this.getProperty(string2)) != null) {
            string3 = string2;
        }
        return string3;
    }
}

