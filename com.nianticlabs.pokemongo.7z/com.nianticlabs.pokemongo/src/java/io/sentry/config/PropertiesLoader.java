/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Properties
 */
package io.sentry.config;

import java.util.Properties;

interface PropertiesLoader {
    public Properties load();
}

