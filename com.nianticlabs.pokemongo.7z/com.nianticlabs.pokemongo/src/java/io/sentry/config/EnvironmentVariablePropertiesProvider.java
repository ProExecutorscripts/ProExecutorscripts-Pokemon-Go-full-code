/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.Locale
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.config;

import io.sentry.config.PropertiesProvider;
import io.sentry.util.StringUtils;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class EnvironmentVariablePropertiesProvider
implements PropertiesProvider {
    private static final String PREFIX = "SENTRY";

    EnvironmentVariablePropertiesProvider() {
    }

    private String propertyToEnvironmentVariableName(String string2) {
        return "SENTRY_" + string2.replace((CharSequence)".", (CharSequence)"_").replace((CharSequence)"-", (CharSequence)"_").toUpperCase(Locale.ROOT);
    }

    @Override
    public Map<String, String> getMap(String string2) {
        String string3 = this.propertyToEnvironmentVariableName(string2) + "_";
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        for (Object object : System.getenv().entrySet()) {
            string2 = (String)object.getKey();
            if (!string2.startsWith(string3) || (object = StringUtils.removeSurrounding((String)object.getValue(), "\"")) == null) continue;
            concurrentHashMap.put((Object)string2.substring(string3.length()).toLowerCase(Locale.ROOT), object);
        }
        return concurrentHashMap;
    }

    @Override
    public String getProperty(String string2) {
        return StringUtils.removeSurrounding(System.getenv((String)this.propertyToEnvironmentVariableName(string2)), "\"");
    }
}

