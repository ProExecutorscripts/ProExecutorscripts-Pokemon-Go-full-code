/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.config;

import io.sentry.config.PropertiesProvider;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class CompositePropertiesProvider
implements PropertiesProvider {
    private final List<PropertiesProvider> providers;

    public CompositePropertiesProvider(List<PropertiesProvider> list) {
        this.providers = list;
    }

    @Override
    public Map<String, String> getMap(String string2) {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        Iterator iterator = this.providers.iterator();
        while (iterator.hasNext()) {
            concurrentHashMap.putAll(((PropertiesProvider)iterator.next()).getMap(string2));
        }
        return concurrentHashMap;
    }

    @Override
    public String getProperty(String string2) {
        Iterator iterator = this.providers.iterator();
        while (iterator.hasNext()) {
            String string3 = ((PropertiesProvider)iterator.next()).getProperty(string2);
            if (string3 == null) continue;
            return string3;
        }
        return null;
    }
}

