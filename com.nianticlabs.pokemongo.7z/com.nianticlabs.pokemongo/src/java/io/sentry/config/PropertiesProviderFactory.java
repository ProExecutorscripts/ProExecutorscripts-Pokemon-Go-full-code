/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Properties
 */
package io.sentry.config;

import io.sentry.SystemOutLogger;
import io.sentry.config.ClasspathPropertiesLoader;
import io.sentry.config.CompositePropertiesProvider;
import io.sentry.config.EnvironmentVariablePropertiesProvider;
import io.sentry.config.FilesystemPropertiesLoader;
import io.sentry.config.PropertiesProvider;
import io.sentry.config.SimplePropertiesProvider;
import io.sentry.config.SystemPropertyPropertiesProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class PropertiesProviderFactory {
    public static PropertiesProvider create() {
        SystemOutLogger systemOutLogger = new SystemOutLogger();
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)new SystemPropertyPropertiesProvider());
        arrayList.add((Object)new EnvironmentVariablePropertiesProvider());
        String string2 = System.getProperty((String)"sentry.properties.file");
        if (string2 != null && (string2 = new FilesystemPropertiesLoader(string2, systemOutLogger).load()) != null) {
            arrayList.add((Object)new SimplePropertiesProvider((Properties)string2));
        }
        if ((string2 = System.getenv((String)"SENTRY_PROPERTIES_FILE")) != null && (string2 = new FilesystemPropertiesLoader(string2, systemOutLogger).load()) != null) {
            arrayList.add((Object)new SimplePropertiesProvider((Properties)string2));
        }
        if ((string2 = new ClasspathPropertiesLoader(systemOutLogger).load()) != null) {
            arrayList.add((Object)new SimplePropertiesProvider((Properties)string2));
        }
        if ((systemOutLogger = new FilesystemPropertiesLoader("sentry.properties", systemOutLogger).load()) != null) {
            arrayList.add((Object)new SimplePropertiesProvider((Properties)systemOutLogger));
        }
        return new CompositePropertiesProvider((List<PropertiesProvider>)arrayList);
    }
}

