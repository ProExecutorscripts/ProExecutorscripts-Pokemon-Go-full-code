/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Properties
 */
package io.sentry.config;

import io.sentry.config.AbstractPropertiesProvider;
import java.util.Properties;

final class SimplePropertiesProvider
extends AbstractPropertiesProvider {
    public SimplePropertiesProvider(Properties properties) {
        super(properties);
    }
}

