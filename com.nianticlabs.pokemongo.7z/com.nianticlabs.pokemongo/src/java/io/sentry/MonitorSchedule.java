/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.MonitorScheduleType;
import io.sentry.MonitorScheduleUnit;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class MonitorSchedule
implements JsonUnknown,
JsonSerializable {
    private String type;
    private String unit;
    private Map<String, Object> unknown;
    private String value;

    public MonitorSchedule(String string2, String string3, String string4) {
        this.type = string2;
        this.value = string3;
        this.unit = string4;
    }

    public static MonitorSchedule crontab(String string2) {
        return new MonitorSchedule(MonitorScheduleType.CRONTAB.apiName(), string2, null);
    }

    public static MonitorSchedule interval(Integer n2, MonitorScheduleUnit monitorScheduleUnit) {
        return new MonitorSchedule(MonitorScheduleType.INTERVAL.apiName(), n2.toString(), monitorScheduleUnit.apiName());
    }

    public String getType() {
        return this.type;
    }

    public String getUnit() {
        return this.unit;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getValue() {
        return this.value;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        objectWriter.name("type").value(this.type);
        if (MonitorScheduleType.INTERVAL.apiName().equalsIgnoreCase(this.type)) {
            try {
                objectWriter.name("value").value((Number)Integer.valueOf((String)this.value));
            }
            catch (Throwable throwable) {
                iLogger.log(SentryLevel.ERROR, "Unable to serialize monitor schedule value: %s", this.value);
            }
        } else {
            objectWriter.name("value").value(this.value);
        }
        if (this.unit != null) {
            objectWriter.name("unit").value(this.unit);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setType(String string2) {
        this.type = string2;
    }

    public void setUnit(MonitorScheduleUnit object) {
        object = object == null ? null : object.apiName();
        this.unit = object;
    }

    public void setUnit(String string2) {
        this.unit = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setValue(Integer n2) {
        this.value = n2.toString();
    }

    public void setValue(String string2) {
        this.value = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<MonitorSchedule> {
        @Override
        public MonitorSchedule deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            String string2;
            ((JsonReader)object).beginObject();
            String string3 = null;
            String string4 = null;
            String string5 = string2 = null;
            block10: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string6 = ((JsonReader)object).nextName();
                string6.hashCode();
                int n2 = string6.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 111972721: {
                        if (!string6.equals((Object)"value")) break;
                        n3 = 2;
                        break;
                    }
                    case 3594628: {
                        if (!string6.equals((Object)"unit")) break;
                        n3 = 1;
                        break;
                    }
                    case 3575610: {
                        if (!string6.equals((Object)"type")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        String string7 = string5;
                        if (string5 == null) {
                            string7 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)string7, string6);
                        string5 = string7;
                        continue block10;
                    }
                    case 2: {
                        string4 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block10;
                    }
                    case 1: {
                        string2 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block10;
                    }
                    case 0: 
                }
                string3 = ((JsonObjectReader)object).nextStringOrNull();
            }
            ((JsonReader)object).endObject();
            if (string3 != null) {
                if (string4 != null) {
                    object = new MonitorSchedule(string3, string4, string2);
                    ((MonitorSchedule)object).setUnknown((Map<String, Object>)string5);
                    return object;
                }
                object = new IllegalStateException("Missing required field \"value\"");
                iLogger.log(SentryLevel.ERROR, "Missing required field \"value\"", (Throwable)object);
                throw object;
            }
            object = new IllegalStateException("Missing required field \"type\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"type\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String TYPE = "type";
        public static final String UNIT = "unit";
        public static final String VALUE = "value";
    }
}

