/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public final class SystemOutLogger
implements ILogger {
    private String captureStackTrace(Throwable throwable) {
        StringWriter stringWriter = new StringWriter();
        throwable.printStackTrace(new PrintWriter((Writer)stringWriter));
        return stringWriter.toString();
    }

    @Override
    public boolean isEnabled(SentryLevel sentryLevel) {
        return true;
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Throwable throwable) {
        if (throwable == null) {
            this.log(sentryLevel, string2, new Object[0]);
        } else {
            System.out.println(String.format((String)"%s: %s\n%s", (Object[])new Object[]{sentryLevel, String.format((String)string2, (Object[])new Object[]{throwable.toString()}), this.captureStackTrace(throwable)}));
        }
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Object ... objectArray) {
        System.out.println(String.format((String)"%s: %s", (Object[])new Object[]{sentryLevel, String.format((String)string2, (Object[])objectArray)}));
    }

    @Override
    public void log(SentryLevel sentryLevel, Throwable throwable, String string2, Object ... objectArray) {
        if (throwable == null) {
            this.log(sentryLevel, string2, objectArray);
        } else {
            System.out.println(String.format((String)"%s: %s \n %s\n%s", (Object[])new Object[]{sentryLevel, String.format((String)string2, (Object[])objectArray), throwable.toString(), this.captureStackTrace(throwable)}));
        }
    }
}

