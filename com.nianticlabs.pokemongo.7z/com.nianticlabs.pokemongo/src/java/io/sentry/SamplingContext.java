/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.CustomSamplingContext;
import io.sentry.TransactionContext;
import io.sentry.util.Objects;

public final class SamplingContext {
    private final CustomSamplingContext customSamplingContext;
    private final TransactionContext transactionContext;

    public SamplingContext(TransactionContext transactionContext, CustomSamplingContext customSamplingContext) {
        this.transactionContext = Objects.requireNonNull(transactionContext, "transactionContexts is required");
        this.customSamplingContext = customSamplingContext;
    }

    public CustomSamplingContext getCustomSamplingContext() {
        return this.customSamplingContext;
    }

    public TransactionContext getTransactionContext() {
        return this.transactionContext;
    }
}

