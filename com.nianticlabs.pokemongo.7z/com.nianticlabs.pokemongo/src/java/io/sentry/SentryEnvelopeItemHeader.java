/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItemHeader
implements JsonSerializable,
JsonUnknown {
    private final String attachmentType;
    private final String contentType;
    private final String fileName;
    private final Callable<Integer> getLength;
    private final int length;
    private final SentryItemType type;
    private Map<String, Object> unknown;

    public SentryEnvelopeItemHeader(SentryItemType sentryItemType, int n2, String string2, String string3, String string4) {
        this.type = Objects.requireNonNull(sentryItemType, "type is required");
        this.contentType = string2;
        this.length = n2;
        this.fileName = string3;
        this.getLength = null;
        this.attachmentType = string4;
    }

    SentryEnvelopeItemHeader(SentryItemType sentryItemType, Callable<Integer> callable, String string2, String string3) {
        this(sentryItemType, callable, string2, string3, null);
    }

    SentryEnvelopeItemHeader(SentryItemType sentryItemType, Callable<Integer> callable, String string2, String string3, String string4) {
        this.type = Objects.requireNonNull(sentryItemType, "type is required");
        this.contentType = string2;
        this.length = -1;
        this.fileName = string3;
        this.getLength = callable;
        this.attachmentType = string4;
    }

    public String getAttachmentType() {
        return this.attachmentType;
    }

    public String getContentType() {
        return this.contentType;
    }

    public String getFileName() {
        return this.fileName;
    }

    public int getLength() {
        Callable<Integer> callable = this.getLength;
        if (callable != null) {
            try {
                int n2 = (Integer)callable.call();
                return n2;
            }
            catch (Throwable throwable) {
                return -1;
            }
        }
        return this.length;
    }

    public SentryItemType getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        if (this.contentType != null) {
            objectWriter.name("content_type").value(this.contentType);
        }
        if (this.fileName != null) {
            objectWriter.name("filename").value(this.fileName);
        }
        objectWriter.name("type").value(iLogger, this.type);
        if (this.attachmentType != null) {
            objectWriter.name("attachment_type").value(this.attachmentType);
        }
        objectWriter.name("length").value(this.getLength());
        Object object2 = this.unknown;
        if (object2 != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryEnvelopeItemHeader> {
        private Exception missingRequiredFieldException(String object, ILogger iLogger) {
            String string2 = "Missing required field \"" + object + "\"";
            object = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, (Throwable)object);
            return object;
        }

        @Override
        public SentryEnvelopeItemHeader deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
            String string2;
            String string3;
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            SentryItemType sentryItemType = null;
            String string4 = string3 = (string2 = null);
            int n2 = 0;
            block14: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string5 = jsonObjectReader.nextName();
                string5.hashCode();
                int n3 = string5.hashCode();
                int n4 = -1;
                switch (n3) {
                    default: {
                        break;
                    }
                    case 831846208: {
                        if (!string5.equals((Object)"content_type")) break;
                        n4 = 4;
                        break;
                    }
                    case 3575610: {
                        if (!string5.equals((Object)"type")) break;
                        n4 = 3;
                        break;
                    }
                    case -672977706: {
                        if (!string5.equals((Object)"attachment_type")) break;
                        n4 = 2;
                        break;
                    }
                    case -734768633: {
                        if (!string5.equals((Object)"filename")) break;
                        n4 = 1;
                        break;
                    }
                    case -1106363674: {
                        if (!string5.equals((Object)"length")) break;
                        n4 = 0;
                    }
                }
                switch (n4) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)hashMap2, string5);
                        hashMap = hashMap2;
                        continue block14;
                    }
                    case 4: {
                        string2 = jsonObjectReader.nextStringOrNull();
                        continue block14;
                    }
                    case 3: {
                        sentryItemType = jsonObjectReader.nextOrNull((ILogger)object, new SentryItemType.Deserializer());
                        continue block14;
                    }
                    case 2: {
                        string4 = jsonObjectReader.nextStringOrNull();
                        continue block14;
                    }
                    case 1: {
                        string3 = jsonObjectReader.nextStringOrNull();
                        continue block14;
                    }
                    case 0: 
                }
                n2 = jsonObjectReader.nextInt();
            }
            if (sentryItemType != null) {
                object = new SentryEnvelopeItemHeader(sentryItemType, n2, string2, string3, string4);
                ((SentryEnvelopeItemHeader)object).setUnknown((Map<String, Object>)hashMap);
                jsonObjectReader.endObject();
                return object;
            }
            throw this.missingRequiredFieldException("type", (ILogger)object);
        }
    }

    public static final class JsonKeys {
        public static final String ATTACHMENT_TYPE = "attachment_type";
        public static final String CONTENT_TYPE = "content_type";
        public static final String FILENAME = "filename";
        public static final String LENGTH = "length";
        public static final String TYPE = "type";
    }
}

