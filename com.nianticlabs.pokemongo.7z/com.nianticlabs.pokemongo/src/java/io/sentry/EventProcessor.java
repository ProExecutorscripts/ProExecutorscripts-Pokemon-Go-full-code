/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.Hint;
import io.sentry.SentryEvent;
import io.sentry.protocol.SentryTransaction;

public interface EventProcessor {
    default public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        return sentryEvent;
    }

    default public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        return sentryTransaction;
    }
}

