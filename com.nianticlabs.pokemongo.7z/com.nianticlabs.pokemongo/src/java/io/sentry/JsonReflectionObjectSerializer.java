/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Modifier
 *  java.net.InetAddress
 *  java.net.URI
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Currency
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicIntegerArray
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.util.JsonSerializationUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.net.URI;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Currency;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class JsonReflectionObjectSerializer {
    private final int maxDepth;
    private final Set<Object> visiting = new HashSet();

    JsonReflectionObjectSerializer(int n2) {
        this.maxDepth = n2;
    }

    private List<Object> list(Collection<?> iterator, ILogger iLogger) throws Exception {
        ArrayList arrayList = new ArrayList();
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            arrayList.add(this.serialize(iterator.next(), iLogger));
        }
        return arrayList;
    }

    private List<Object> list(Object[] objectArray, ILogger iLogger) throws Exception {
        ArrayList arrayList = new ArrayList();
        int n2 = objectArray.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add(this.serialize(objectArray[i2], iLogger));
        }
        return arrayList;
    }

    private Map<String, Object> map(Map<?, ?> map2, ILogger iLogger) throws Exception {
        HashMap hashMap = new HashMap();
        for (Object object : map2.keySet()) {
            Object object2 = map2.get(object);
            if (object2 != null) {
                hashMap.put((Object)object.toString(), this.serialize(object2, iLogger));
                continue;
            }
            hashMap.put((Object)object.toString(), null);
        }
        return hashMap;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Object serialize(Object object, ILogger list) throws Exception {
        Throwable throwable2;
        block25: {
            block24: {
                Object var3_4 = null;
                if (object == null) {
                    return null;
                }
                if (object instanceof Character) {
                    return object.toString();
                }
                if (object instanceof Number) {
                    return object;
                }
                if (object instanceof Boolean) {
                    return object;
                }
                if (object instanceof String) {
                    return object;
                }
                if (object instanceof Locale) {
                    return object.toString();
                }
                if (object instanceof AtomicIntegerArray) {
                    return JsonSerializationUtils.atomicIntegerArrayToList((AtomicIntegerArray)object);
                }
                if (object instanceof AtomicBoolean) {
                    return ((AtomicBoolean)object).get();
                }
                if (object instanceof URI) {
                    return object.toString();
                }
                if (object instanceof InetAddress) {
                    return object.toString();
                }
                if (object instanceof UUID) {
                    return object.toString();
                }
                if (object instanceof Currency) {
                    return object.toString();
                }
                if (object instanceof Calendar) {
                    return JsonSerializationUtils.calendarToMap((Calendar)object);
                }
                if (object.getClass().isEnum()) {
                    return object.toString();
                }
                if (this.visiting.contains(object)) {
                    list.log(SentryLevel.INFO, "Cyclic reference detected. Calling toString() on object.", new Object[0]);
                    return object.toString();
                }
                this.visiting.add(object);
                if (this.visiting.size() > this.maxDepth) {
                    this.visiting.remove(object);
                    list.log(SentryLevel.INFO, "Max depth exceeded. Calling toString() on object.", new Object[0]);
                    return object.toString();
                }
                try {
                    try {
                        if (object.getClass().isArray()) {
                            List<Object> list2;
                            list = list2 = this.list((Object[])object, (ILogger)list);
                            break block24;
                        }
                        if (object instanceof Collection) {
                            List<Object> list3 = this.list((Collection<?>)((Collection)object), (ILogger)list);
                            list = list3;
                            break block24;
                        }
                        if (object instanceof Map) {
                            Map<String, Object> map2 = this.map((Map<?, ?>)((Map)object), (ILogger)list);
                            list = map2;
                            break block24;
                        }
                        Object object2 = this.serializeObject(object, (ILogger)list);
                        if (object2.isEmpty()) {
                            object2 = object.toString();
                            list = object2;
                            break block24;
                        }
                        list = object2;
                    }
                    catch (Exception exception) {
                        list.log(SentryLevel.INFO, "Not serializing object due to throwing sub-path.", (Throwable)exception);
                        list = var3_4;
                    }
                }
                catch (Throwable throwable2) {
                    break block25;
                }
            }
            this.visiting.remove(object);
            return list;
        }
        this.visiting.remove(object);
        throw throwable2;
    }

    public Map<String, Object> serializeObject(Object object, ILogger iLogger) throws Exception {
        Field[] fieldArray = object.getClass().getDeclaredFields();
        HashMap hashMap = new HashMap();
        for (Field field : fieldArray) {
            if (Modifier.isTransient((int)field.getModifiers()) || Modifier.isStatic((int)field.getModifiers())) continue;
            String string2 = field.getName();
            try {
                field.setAccessible(true);
                hashMap.put((Object)string2, this.serialize(field.get(object), iLogger));
                field.setAccessible(false);
            }
            catch (Exception exception) {
                iLogger.log(SentryLevel.INFO, "Cannot access field " + string2 + ".", new Object[0]);
            }
        }
        return hashMap;
    }
}

