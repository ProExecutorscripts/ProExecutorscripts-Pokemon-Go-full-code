/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

public final class HttpStatusCodeRange {
    public static final int DEFAULT_MAX = 599;
    public static final int DEFAULT_MIN = 500;
    private final int max;
    private final int min;

    public HttpStatusCodeRange(int n2) {
        this.min = n2;
        this.max = n2;
    }

    public HttpStatusCodeRange(int n2, int n3) {
        this.min = n2;
        this.max = n3;
    }

    public boolean isInRange(int n2) {
        boolean bl = n2 >= this.min && n2 <= this.max;
        return bl;
    }
}

