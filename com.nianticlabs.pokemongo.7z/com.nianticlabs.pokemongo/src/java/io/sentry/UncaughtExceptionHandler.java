/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 */
package io.sentry;

interface UncaughtExceptionHandler {
    public Thread.UncaughtExceptionHandler getDefaultUncaughtExceptionHandler();

    public void setDefaultUncaughtExceptionHandler(Thread.UncaughtExceptionHandler var1);

    public static final class Adapter
    implements UncaughtExceptionHandler {
        private static final Adapter INSTANCE = new Adapter();

        private Adapter() {
        }

        static UncaughtExceptionHandler getInstance() {
            return INSTANCE;
        }

        @Override
        public Thread.UncaughtExceptionHandler getDefaultUncaughtExceptionHandler() {
            return Thread.getDefaultUncaughtExceptionHandler();
        }

        @Override
        public void setDefaultUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
            Thread.setDefaultUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)uncaughtExceptionHandler);
        }
    }
}

