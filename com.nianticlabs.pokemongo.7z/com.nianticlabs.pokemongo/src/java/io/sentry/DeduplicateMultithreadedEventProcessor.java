/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.UncaughtExceptionHandlerIntegration;
import io.sentry.hints.EventDropReason;
import io.sentry.protocol.SentryException;
import io.sentry.util.HintUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class DeduplicateMultithreadedEventProcessor
implements EventProcessor {
    private final SentryOptions options;
    private final Map<String, Long> processedEvents = Collections.synchronizedMap((Map)new HashMap());

    public DeduplicateMultithreadedEventProcessor(SentryOptions sentryOptions) {
        this.options = sentryOptions;
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        if (!HintUtils.hasType(hint, UncaughtExceptionHandlerIntegration.UncaughtExceptionHint.class)) {
            return sentryEvent;
        }
        SentryException sentryException = sentryEvent.getUnhandledException();
        if (sentryException == null) {
            return sentryEvent;
        }
        String string2 = sentryException.getType();
        if (string2 == null) {
            return sentryEvent;
        }
        Long l2 = sentryException.getThreadId();
        if (l2 == null) {
            return sentryEvent;
        }
        sentryException = (Long)this.processedEvents.get((Object)string2);
        if (sentryException != null && !sentryException.equals(l2)) {
            this.options.getLogger().log(SentryLevel.INFO, "Event %s has been dropped due to multi-threaded deduplication", sentryEvent.getEventId());
            HintUtils.setEventDropReason(hint, EventDropReason.MULTITHREADED_DEDUPLICATION);
            return null;
        }
        this.processedEvents.put((Object)string2, (Object)l2);
        return sentryEvent;
    }
}

