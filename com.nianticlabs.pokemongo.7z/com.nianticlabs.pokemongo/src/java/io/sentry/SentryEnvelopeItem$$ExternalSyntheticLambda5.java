/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.SentryEnvelopeItem;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem$$ExternalSyntheticLambda5
implements Callable {
    public final SentryEnvelopeItem.CachedItem f$0;

    public /* synthetic */ SentryEnvelopeItem$$ExternalSyntheticLambda5(SentryEnvelopeItem.CachedItem cachedItem) {
        this.f$0 = cachedItem;
    }

    public final Object call() {
        return SentryEnvelopeItem.lambda$fromMetrics$14(this.f$0);
    }
}

