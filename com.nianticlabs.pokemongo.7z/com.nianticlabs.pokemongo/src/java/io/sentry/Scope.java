/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Queue
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package io.sentry;

import io.sentry.Attachment;
import io.sentry.Breadcrumb;
import io.sentry.CircularFifoQueue;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.IScope;
import io.sentry.IScopeObserver;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PropagationContext;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.Span;
import io.sentry.SynchronizedQueue;
import io.sentry.protocol.App;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.protocol.User;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class Scope
implements IScope {
    private List<Attachment> attachments;
    private final Queue<Breadcrumb> breadcrumbs;
    private Contexts contexts;
    private List<EventProcessor> eventProcessors;
    private Map<String, Object> extra;
    private List<String> fingerprint = new ArrayList();
    private SentryLevel level;
    private final SentryOptions options;
    private PropagationContext propagationContext;
    private final Object propagationContextLock;
    private Request request;
    private String screen;
    private volatile Session session;
    private final Object sessionLock;
    private Map<String, String> tags = new ConcurrentHashMap();
    private ITransaction transaction;
    private final Object transactionLock;
    private String transactionName;
    private User user;

    private Scope(Scope scope2) {
        this.extra = new ConcurrentHashMap();
        this.eventProcessors = new CopyOnWriteArrayList();
        this.sessionLock = new Object();
        this.transactionLock = new Object();
        this.propagationContextLock = new Object();
        this.contexts = new Contexts();
        this.attachments = new CopyOnWriteArrayList();
        this.transaction = scope2.transaction;
        this.transactionName = scope2.transactionName;
        this.session = scope2.session;
        this.options = scope2.options;
        this.level = scope2.level;
        Object object = scope2.user;
        Iterator iterator2 = null;
        object = object != null ? new User((User)object) : null;
        this.user = object;
        this.screen = scope2.screen;
        Request request2 = scope2.request;
        object = iterator2;
        if (request2 != null) {
            object = new Request(request2);
        }
        this.request = object;
        this.fingerprint = new ArrayList(scope2.fingerprint);
        this.eventProcessors = new CopyOnWriteArrayList(scope2.eventProcessors);
        object = scope2.breadcrumbs;
        object = (ConcurrentHashMap)object.toArray((Object[])new Breadcrumb[0]);
        iterator2 = this.createBreadcrumbsList(scope2.options.getMaxBreadcrumbs());
        int n2 = ((Breadcrumb[])object).length;
        for (int i2 = 0; i2 < n2; ++i2) {
            iterator2.add((Object)new Breadcrumb(object[i2]));
        }
        this.breadcrumbs = iterator2;
        iterator2 = scope2.tags;
        object = new ConcurrentHashMap();
        for (Iterator iterator2 : iterator2.entrySet()) {
            if (iterator2 == null) continue;
            object.put((Object)((String)iterator2.getKey()), (Object)((String)iterator2.getValue()));
        }
        this.tags = object;
        iterator2 = scope2.extra;
        object = new ConcurrentHashMap();
        for (Request request2 : iterator2.entrySet()) {
            if (request2 == null) continue;
            object.put((Object)((String)request2.getKey()), request2.getValue());
        }
        this.extra = object;
        this.contexts = new Contexts(scope2.contexts);
        this.attachments = new CopyOnWriteArrayList(scope2.attachments);
        this.propagationContext = new PropagationContext(scope2.propagationContext);
    }

    public Scope(SentryOptions sentryOptions) {
        this.extra = new ConcurrentHashMap();
        this.eventProcessors = new CopyOnWriteArrayList();
        this.sessionLock = new Object();
        this.transactionLock = new Object();
        this.propagationContextLock = new Object();
        this.contexts = new Contexts();
        this.attachments = new CopyOnWriteArrayList();
        this.options = sentryOptions = Objects.requireNonNull(sentryOptions, "SentryOptions is required.");
        this.breadcrumbs = this.createBreadcrumbsList(sentryOptions.getMaxBreadcrumbs());
        this.propagationContext = new PropagationContext();
    }

    private Queue<Breadcrumb> createBreadcrumbsList(int n2) {
        return SynchronizedQueue.synchronizedQueue(new CircularFifoQueue(n2));
    }

    private Breadcrumb executeBeforeBreadcrumb(SentryOptions.BeforeBreadcrumbCallback object, Breadcrumb breadcrumb, Hint hint) {
        block2: {
            try {
                object = object.execute(breadcrumb, hint);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "The BeforeBreadcrumbCallback callback threw an exception. Exception details will be added to the breadcrumb.", throwable);
                object = breadcrumb;
                if (throwable.getMessage() == null) break block2;
                breadcrumb.setData("sentry:message", throwable.getMessage());
                object = breadcrumb;
            }
        }
        return object;
    }

    @Override
    public void addAttachment(Attachment attachment) {
        this.attachments.add((Object)attachment);
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
        this.addBreadcrumb(breadcrumb, null);
    }

    @Override
    public void addBreadcrumb(Breadcrumb object4, Hint object2) {
        if (object4 == null) {
            return;
        }
        Object object3 = object2;
        if (object2 == null) {
            object3 = new Hint();
        }
        SentryOptions.BeforeBreadcrumbCallback beforeBreadcrumbCallback = this.options.getBeforeBreadcrumb();
        object2 = object4;
        if (beforeBreadcrumbCallback != null) {
            object2 = this.executeBeforeBreadcrumb(beforeBreadcrumbCallback, (Breadcrumb)object4, (Hint)object3);
        }
        if (object2 != null) {
            this.breadcrumbs.add(object2);
            for (Object object4 : this.options.getScopeObservers()) {
                object4.addBreadcrumb((Breadcrumb)object2);
                object4.setBreadcrumbs((Collection<Breadcrumb>)this.breadcrumbs);
            }
        } else {
            this.options.getLogger().log(SentryLevel.INFO, "Breadcrumb was dropped by beforeBreadcrumb", new Object[0]);
        }
    }

    @Override
    public void addEventProcessor(EventProcessor eventProcessor) {
        this.eventProcessors.add((Object)eventProcessor);
    }

    @Override
    public void clear() {
        this.level = null;
        this.user = null;
        this.request = null;
        this.screen = null;
        this.fingerprint.clear();
        this.clearBreadcrumbs();
        this.tags.clear();
        this.extra.clear();
        this.eventProcessors.clear();
        this.clearTransaction();
        this.clearAttachments();
    }

    @Override
    public void clearAttachments() {
        this.attachments.clear();
    }

    @Override
    public void clearBreadcrumbs() {
        this.breadcrumbs.clear();
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            ((IScopeObserver)iterator.next()).setBreadcrumbs((Collection<Breadcrumb>)this.breadcrumbs);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearTransaction() {
        Object object;
        Object object2 = object = this.transactionLock;
        synchronized (object2) {
            this.transaction = null;
        }
        this.transactionName = null;
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            object = (IScopeObserver)iterator.next();
            object.setTransaction(null);
            object.setTrace(null);
        }
        return;
    }

    @Override
    public IScope clone() {
        return new Scope(this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Session endSession() {
        Object object;
        Object object2 = object = this.sessionLock;
        synchronized (object2) {
            Session session = this.session;
            Session session2 = null;
            if (session != null) {
                this.session.end();
                session2 = this.session.clone();
                this.session = null;
            }
            return session2;
        }
    }

    @Override
    public List<Attachment> getAttachments() {
        return new CopyOnWriteArrayList(this.attachments);
    }

    @Override
    public Queue<Breadcrumb> getBreadcrumbs() {
        return this.breadcrumbs;
    }

    @Override
    public Contexts getContexts() {
        return this.contexts;
    }

    @Override
    public List<EventProcessor> getEventProcessors() {
        return this.eventProcessors;
    }

    @Override
    public Map<String, Object> getExtras() {
        return this.extra;
    }

    @Override
    public List<String> getFingerprint() {
        return this.fingerprint;
    }

    @Override
    public SentryLevel getLevel() {
        return this.level;
    }

    @Override
    public SentryOptions getOptions() {
        return this.options;
    }

    @Override
    public PropagationContext getPropagationContext() {
        return this.propagationContext;
    }

    @Override
    public Request getRequest() {
        return this.request;
    }

    @Override
    public String getScreen() {
        return this.screen;
    }

    @Override
    public Session getSession() {
        return this.session;
    }

    @Override
    public ISpan getSpan() {
        Span span;
        ITransaction iTransaction = this.transaction;
        if (iTransaction != null && (span = iTransaction.getLatestActiveSpan()) != null) {
            return span;
        }
        return iTransaction;
    }

    @Override
    public Map<String, String> getTags() {
        return CollectionUtils.newConcurrentHashMap(this.tags);
    }

    @Override
    public ITransaction getTransaction() {
        return this.transaction;
    }

    @Override
    public String getTransactionName() {
        Object object = this.transaction;
        object = object != null ? object.getName() : this.transactionName;
        return object;
    }

    @Override
    public User getUser() {
        return this.user;
    }

    @Override
    public void removeContexts(String string2) {
        this.contexts.remove(string2);
    }

    @Override
    public void removeExtra(String string2) {
        this.extra.remove((Object)string2);
        for (IScopeObserver iScopeObserver : this.options.getScopeObservers()) {
            iScopeObserver.removeExtra(string2);
            iScopeObserver.setExtras(this.extra);
        }
    }

    @Override
    public void removeTag(String string2) {
        this.tags.remove((Object)string2);
        for (IScopeObserver iScopeObserver : this.options.getScopeObservers()) {
            iScopeObserver.removeTag(string2);
            iScopeObserver.setTags(this.tags);
        }
    }

    @Override
    public void setContexts(String string2, Boolean bl) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", (Object)bl);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setContexts(String string2, Character c2) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", (Object)c2);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setContexts(String string2, Number number) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", (Object)number);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setContexts(String string2, Object object) {
        this.contexts.put(string2, object);
        string2 = this.options.getScopeObservers().iterator();
        while (string2.hasNext()) {
            ((IScopeObserver)string2.next()).setContexts(this.contexts);
        }
    }

    @Override
    public void setContexts(String string2, String string3) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", (Object)string3);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setContexts(String string2, Collection<?> collection) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", collection);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setContexts(String string2, Object[] objectArray) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"value", (Object)objectArray);
        this.setContexts(string2, hashMap);
    }

    @Override
    public void setExtra(String string2, String string3) {
        this.extra.put((Object)string2, (Object)string3);
        for (IScopeObserver iScopeObserver : this.options.getScopeObservers()) {
            iScopeObserver.setExtra(string2, string3);
            iScopeObserver.setExtras(this.extra);
        }
    }

    @Override
    public void setFingerprint(List<String> list) {
        if (list == null) {
            return;
        }
        this.fingerprint = new ArrayList(list);
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            ((IScopeObserver)iterator.next()).setFingerprint((Collection<String>)list);
        }
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
        this.level = sentryLevel;
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            ((IScopeObserver)iterator.next()).setLevel(sentryLevel);
        }
    }

    @Override
    public void setPropagationContext(PropagationContext propagationContext) {
        this.propagationContext = propagationContext;
    }

    @Override
    public void setRequest(Request request) {
        this.request = request;
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            ((IScopeObserver)iterator.next()).setRequest(request);
        }
    }

    @Override
    public void setScreen(String string2) {
        App app;
        this.screen = string2;
        Contexts contexts = this.getContexts();
        App app2 = app = contexts.getApp();
        if (app == null) {
            app2 = new App();
            contexts.setApp(app2);
        }
        if (string2 == null) {
            app2.setViewNames(null);
        } else {
            app = new ArrayList(1);
            app.add(string2);
            app2.setViewNames((List<String>)app);
        }
        string2 = this.options.getScopeObservers().iterator();
        while (string2.hasNext()) {
            ((IScopeObserver)string2.next()).setContexts(contexts);
        }
    }

    @Override
    public void setTag(String string2, String string3) {
        this.tags.put((Object)string2, (Object)string3);
        for (IScopeObserver iScopeObserver : this.options.getScopeObservers()) {
            iScopeObserver.setTag(string2, string3);
            iScopeObserver.setTags(this.tags);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void setTransaction(ITransaction iTransaction) {
        Object object;
        Object object2 = object = this.transactionLock;
        synchronized (object2) {
            this.transaction = iTransaction;
            Iterator iterator = this.options.getScopeObservers().iterator();
            while (iterator.hasNext()) {
                IScopeObserver iScopeObserver = (IScopeObserver)iterator.next();
                if (iTransaction != null) {
                    iScopeObserver.setTransaction(iTransaction.getName());
                    iScopeObserver.setTrace(iTransaction.getSpanContext());
                    continue;
                }
                iScopeObserver.setTransaction(null);
                iScopeObserver.setTrace(null);
            }
            return;
        }
    }

    @Override
    public void setTransaction(String string2) {
        if (string2 != null) {
            ITransaction iTransaction = this.transaction;
            if (iTransaction != null) {
                iTransaction.setName(string2, TransactionNameSource.CUSTOM);
            }
            this.transactionName = string2;
            iTransaction = this.options.getScopeObservers().iterator();
            while (iTransaction.hasNext()) {
                ((IScopeObserver)iTransaction.next()).setTransaction(string2);
            }
        } else {
            this.options.getLogger().log(SentryLevel.WARNING, "Transaction cannot be null", new Object[0]);
        }
    }

    @Override
    public void setUser(User user) {
        this.user = user;
        Iterator iterator = this.options.getScopeObservers().iterator();
        while (iterator.hasNext()) {
            ((IScopeObserver)iterator.next()).setUser(user);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public SessionPair startSession() {
        Object object;
        Object object2 = object = this.sessionLock;
        synchronized (object2) {
            if (this.session != null) {
                this.session.end();
            }
            Session session = this.session;
            String string2 = this.options.getRelease();
            Object object3 = null;
            Object object4 = null;
            if (string2 != null) {
                object3 = new Session(this.options.getDistinctId(), this.user, this.options.getEnvironment(), this.options.getRelease());
                this.session = object3;
                object3 = new SessionPair(this.session.clone(), (Session)object4);
                if (session == null) return object3;
                object4 = session.clone();
                return object3;
            }
            this.options.getLogger().log(SentryLevel.WARNING, "Release is not set on SentryOptions. Session could not be started", new Object[0]);
            return object3;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public PropagationContext withPropagationContext(IWithPropagationContext object) {
        Object object2;
        Object object3 = object2 = this.propagationContextLock;
        synchronized (object3) {
            object.accept(this.propagationContext);
            return new PropagationContext(this.propagationContext);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Session withSession(IWithSession object) {
        Object object2;
        Object object3 = object2 = this.sessionLock;
        synchronized (object3) {
            object.accept(this.session);
            if (this.session == null) return null;
            return this.session.clone();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void withTransaction(IWithTransaction iWithTransaction) {
        Object object;
        Object object2 = object = this.transactionLock;
        synchronized (object2) {
            iWithTransaction.accept(this.transaction);
            return;
        }
    }

    public static interface IWithPropagationContext {
        public void accept(PropagationContext var1);
    }

    static interface IWithSession {
        public void accept(Session var1);
    }

    public static interface IWithTransaction {
        public void accept(ITransaction var1);
    }

    static final class SessionPair {
        private final Session current;
        private final Session previous;

        public SessionPair(Session session, Session session2) {
            this.current = session;
            this.previous = session2;
        }

        public Session getCurrent() {
            return this.current;
        }

        public Session getPrevious() {
            return this.previous;
        }
    }
}

