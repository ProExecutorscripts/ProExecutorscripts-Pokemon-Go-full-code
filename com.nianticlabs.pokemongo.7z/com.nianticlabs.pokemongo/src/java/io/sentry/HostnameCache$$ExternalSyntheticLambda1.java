/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.HostnameCache;
import java.util.concurrent.Callable;

public final class HostnameCache$$ExternalSyntheticLambda1
implements Callable {
    public final HostnameCache f$0;

    public /* synthetic */ HostnameCache$$ExternalSyntheticLambda1(HostnameCache hostnameCache) {
        this.f$0 = hostnameCache;
    }

    public final Object call() {
        return this.f$0.lambda$updateCache$1$io-sentry-HostnameCache();
    }
}

