/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ISpan;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentrySpanStorage {
    private static volatile SentrySpanStorage INSTANCE;
    private final Map<String, ISpan> spans = new ConcurrentHashMap();

    private SentrySpanStorage() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SentrySpanStorage getInstance() {
        if (INSTANCE != null) return INSTANCE;
        Class<SentrySpanStorage> clazz = SentrySpanStorage.class;
        synchronized (SentrySpanStorage.class) {
            SentrySpanStorage sentrySpanStorage;
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = sentrySpanStorage = new SentrySpanStorage();
            // ** MonitorExit[var1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    public ISpan get(String string2) {
        return (ISpan)this.spans.get((Object)string2);
    }

    public ISpan removeAndGet(String string2) {
        return (ISpan)this.spans.remove((Object)string2);
    }

    public void store(String string2, ISpan iSpan) {
        this.spans.put((Object)string2, (Object)iSpan);
    }
}

