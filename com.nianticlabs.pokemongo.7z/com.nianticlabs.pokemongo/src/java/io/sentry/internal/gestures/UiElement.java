/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package io.sentry.internal.gestures;

import io.sentry.util.Objects;
import java.lang.ref.WeakReference;

public final class UiElement {
    final String className;
    final String origin;
    final String resourceName;
    final String tag;
    final WeakReference<Object> viewRef;

    public UiElement(Object object, String string2, String string3, String string4, String string5) {
        this.viewRef = new WeakReference(object);
        this.className = string2;
        this.resourceName = string3;
        this.tag = string4;
        this.origin = string5;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (UiElement)object;
            if (!(Objects.equals(this.className, ((UiElement)object).className) && Objects.equals(this.resourceName, ((UiElement)object).resourceName) && Objects.equals(this.tag, ((UiElement)object).tag))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getClassName() {
        return this.className;
    }

    public String getIdentifier() {
        String string2 = this.resourceName;
        if (string2 != null) {
            return string2;
        }
        return Objects.requireNonNull(this.tag, "UiElement.tag can't be null");
    }

    public String getOrigin() {
        return this.origin;
    }

    public String getResourceName() {
        return this.resourceName;
    }

    public String getTag() {
        return this.tag;
    }

    public Object getView() {
        return this.viewRef.get();
    }

    public int hashCode() {
        return Objects.hash(this.viewRef, this.resourceName, this.tag);
    }

    public static enum Type {
        CLICKABLE,
        SCROLLABLE;

    }
}

