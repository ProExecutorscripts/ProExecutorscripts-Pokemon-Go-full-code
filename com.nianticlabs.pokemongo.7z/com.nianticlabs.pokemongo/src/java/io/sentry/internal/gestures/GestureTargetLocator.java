/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.internal.gestures;

import io.sentry.internal.gestures.UiElement;

public interface GestureTargetLocator {
    public UiElement locate(Object var1, float var2, float var3, UiElement.Type var4);
}

