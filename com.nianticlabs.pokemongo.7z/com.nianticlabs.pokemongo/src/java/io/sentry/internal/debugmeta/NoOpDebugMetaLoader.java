/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.List
 *  java.util.Properties
 */
package io.sentry.internal.debugmeta;

import io.sentry.internal.debugmeta.IDebugMetaLoader;
import java.util.List;
import java.util.Properties;

public final class NoOpDebugMetaLoader
implements IDebugMetaLoader {
    private static final NoOpDebugMetaLoader instance = new NoOpDebugMetaLoader();

    private NoOpDebugMetaLoader() {
    }

    public static NoOpDebugMetaLoader getInstance() {
        return instance;
    }

    @Override
    public List<Properties> loadDebugMeta() {
        return null;
    }
}

