/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 *  java.util.Properties
 */
package io.sentry.internal.debugmeta;

import java.util.List;
import java.util.Properties;

public interface IDebugMetaLoader {
    public List<Properties> loadDebugMeta();
}

