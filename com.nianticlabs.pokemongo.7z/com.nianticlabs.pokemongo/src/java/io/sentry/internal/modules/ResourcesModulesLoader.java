/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.TreeMap
 */
package io.sentry.internal.modules;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.internal.modules.ModulesLoader;
import io.sentry.util.ClassLoaderUtils;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.TreeMap;

public final class ResourcesModulesLoader
extends ModulesLoader {
    private final ClassLoader classLoader;

    public ResourcesModulesLoader(ILogger iLogger) {
        this(iLogger, ResourcesModulesLoader.class.getClassLoader());
    }

    ResourcesModulesLoader(ILogger iLogger, ClassLoader classLoader) {
        super(iLogger);
        this.classLoader = ClassLoaderUtils.classLoaderOrDefault(classLoader);
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Map<String, String> loadModules() {
        InputStream inputStream;
        TreeMap treeMap;
        block11: {
            treeMap = new TreeMap();
            inputStream = this.classLoader.getResourceAsStream("sentry-external-modules.txt");
            if (inputStream != null) break block11;
            this.logger.log(SentryLevel.INFO, "%s file was not found.", "sentry-external-modules.txt");
            if (inputStream == null) return treeMap;
            inputStream.close();
            return treeMap;
        }
        Map<String, String> map2 = this.parseStream(inputStream);
        if (inputStream == null) return map2;
        inputStream.close();
        return map2;
        catch (Throwable throwable) {
            if (inputStream == null) throw throwable;
            try {
                inputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (IOException iOException) {
                    this.logger.log(SentryLevel.INFO, "Access to resources failed.", iOException);
                    return treeMap;
                }
                catch (SecurityException securityException) {
                    this.logger.log(SentryLevel.INFO, "Access to resources denied.", securityException);
                }
            }
        }
        return treeMap;
    }
}

