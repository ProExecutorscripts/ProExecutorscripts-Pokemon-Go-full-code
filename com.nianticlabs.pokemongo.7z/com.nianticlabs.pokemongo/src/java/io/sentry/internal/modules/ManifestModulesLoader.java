/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.URL
 *  java.util.ArrayList
 *  java.util.Enumeration
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.regex.Pattern
 */
package io.sentry.internal.modules;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.internal.modules.ModulesLoader;
import io.sentry.util.ClassLoaderUtils;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public final class ManifestModulesLoader
extends ModulesLoader {
    private final Pattern NAME_AND_VERSION;
    private final Pattern URL_LIB_PATTERN = Pattern.compile((String)".*/(.+)!/META-INF/MANIFEST.MF");
    private final ClassLoader classLoader;

    public ManifestModulesLoader(ILogger iLogger) {
        this(ManifestModulesLoader.class.getClassLoader(), iLogger);
    }

    ManifestModulesLoader(ClassLoader classLoader, ILogger iLogger) {
        super(iLogger);
        this.NAME_AND_VERSION = Pattern.compile((String)"(.*?)-(\\d+\\.\\d+.*).jar");
        this.classLoader = ClassLoaderUtils.classLoaderOrDefault(classLoader);
    }

    private Module convertOriginalNameToModule(String string2) {
        if (string2 == null) {
            return null;
        }
        if ((string2 = this.NAME_AND_VERSION.matcher((CharSequence)string2)).matches() && string2.groupCount() == 2) {
            return new Module(string2.group(1), string2.group(2));
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private List<Module> detectModulesViaManifestFiles() {
        ArrayList arrayList = new ArrayList();
        try {
            Enumeration enumeration = this.classLoader.getResources("META-INF/MANIFEST.MF");
            while (enumeration.hasMoreElements()) {
                Module module = this.convertOriginalNameToModule(this.extractDependencyNameFromUrl((URL)enumeration.nextElement()));
                if (module == null) continue;
                arrayList.add((Object)module);
            }
            return arrayList;
        }
        catch (Throwable throwable) {
            this.logger.log(SentryLevel.ERROR, "Unable to detect modules via manifest files.", throwable);
        }
        return arrayList;
    }

    private String extractDependencyNameFromUrl(URL object) {
        object = object.toString();
        if ((object = this.URL_LIB_PATTERN.matcher((CharSequence)object)).matches() && object.groupCount() == 1) {
            return object.group(1);
        }
        return null;
    }

    @Override
    protected Map<String, String> loadModules() {
        HashMap hashMap = new HashMap();
        for (Module module : this.detectModulesViaManifestFiles()) {
            hashMap.put((Object)module.name, (Object)module.version);
        }
        return hashMap;
    }

    private static final class Module {
        private final String name;
        private final String version;

        public Module(String string2, String string3) {
            this.name = string2;
            this.version = string3;
        }
    }
}

