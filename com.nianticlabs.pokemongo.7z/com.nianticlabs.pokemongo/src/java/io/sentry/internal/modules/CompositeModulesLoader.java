/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.TreeMap
 */
package io.sentry.internal.modules;

import io.sentry.ILogger;
import io.sentry.internal.modules.IModulesLoader;
import io.sentry.internal.modules.ModulesLoader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class CompositeModulesLoader
extends ModulesLoader {
    private final List<IModulesLoader> loaders;

    public CompositeModulesLoader(List<IModulesLoader> list, ILogger iLogger) {
        super(iLogger);
        this.loaders = list;
    }

    @Override
    protected Map<String, String> loadModules() {
        TreeMap treeMap = new TreeMap();
        Iterator iterator = this.loaders.iterator();
        while (iterator.hasNext()) {
            Map<String, String> map2 = ((IModulesLoader)iterator.next()).getOrLoadModules();
            if (map2 == null) continue;
            treeMap.putAll(map2);
        }
        return treeMap;
    }
}

