/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry.internal.modules;

import java.util.Map;

public interface IModulesLoader {
    public Map<String, String> getOrLoadModules();
}

