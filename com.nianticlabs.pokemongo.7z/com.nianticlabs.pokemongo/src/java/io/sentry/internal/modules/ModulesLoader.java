/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.Map
 *  java.util.TreeMap
 */
package io.sentry.internal.modules;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.internal.modules.IModulesLoader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.TreeMap;

public abstract class ModulesLoader
implements IModulesLoader {
    public static final String EXTERNAL_MODULES_FILENAME = "sentry-external-modules.txt";
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private Map<String, String> cachedModules = null;
    protected final ILogger logger;

    public ModulesLoader(ILogger iLogger) {
        this.logger = iLogger;
    }

    @Override
    public Map<String, String> getOrLoadModules() {
        Map<String, String> map2 = this.cachedModules;
        if (map2 != null) {
            return map2;
        }
        this.cachedModules = map2 = this.loadModules();
        return map2;
    }

    protected abstract Map<String, String> loadModules();

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected Map<String, String> parseStream(InputStream object) {
        TreeMap treeMap = new TreeMap();
        InputStreamReader inputStreamReader = new InputStreamReader(object, UTF_8);
        BufferedReader bufferedReader = new BufferedReader((Reader)inputStreamReader);
        object = bufferedReader.readLine();
        while (object != null) {
            int n2 = object.lastIndexOf(58);
            treeMap.put((Object)object.substring(0, n2), (Object)object.substring(n2 + 1));
            object = bufferedReader.readLine();
        }
        this.logger.log(SentryLevel.DEBUG, "Extracted %d modules from resources.", treeMap.size());
        bufferedReader.close();
        return treeMap;
        catch (Throwable throwable) {
            try {
                bufferedReader.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (RuntimeException runtimeException) {
                    this.logger.log(SentryLevel.ERROR, runtimeException, "%s file is malformed.", EXTERNAL_MODULES_FILENAME);
                    return treeMap;
                }
                catch (IOException iOException) {
                    this.logger.log(SentryLevel.ERROR, "Error extracting modules.", iOException);
                }
            }
        }
        return treeMap;
    }
}

