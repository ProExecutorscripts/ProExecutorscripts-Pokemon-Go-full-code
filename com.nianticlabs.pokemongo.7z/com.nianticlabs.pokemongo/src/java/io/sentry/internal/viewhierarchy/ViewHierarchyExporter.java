/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.internal.viewhierarchy;

import io.sentry.protocol.ViewHierarchyNode;

public interface ViewHierarchyExporter {
    public boolean export(ViewHierarchyNode var1, Object var2);
}

