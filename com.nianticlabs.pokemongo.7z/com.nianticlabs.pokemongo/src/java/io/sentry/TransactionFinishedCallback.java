/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.ITransaction;

public interface TransactionFinishedCallback {
    public void execute(ITransaction var1);
}

