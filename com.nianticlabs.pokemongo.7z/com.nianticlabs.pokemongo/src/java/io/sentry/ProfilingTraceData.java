/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.UUID
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.ITransaction;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.NoOpTransaction;
import io.sentry.ObjectWriter;
import io.sentry.ProfilingTraceData$$ExternalSyntheticLambda0;
import io.sentry.ProfilingTransactionData;
import io.sentry.profilemeasurements.ProfileMeasurement;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;

public final class ProfilingTraceData
implements JsonUnknown,
JsonSerializable {
    private static final String DEFAULT_ENVIRONMENT = "production";
    public static final String TRUNCATION_REASON_BACKGROUNDED = "backgrounded";
    public static final String TRUNCATION_REASON_NORMAL = "normal";
    public static final String TRUNCATION_REASON_TIMEOUT = "timeout";
    private int androidApiLevel;
    private String buildId;
    private String cpuArchitecture;
    private List<Integer> deviceCpuFrequencies = new ArrayList();
    private final Callable<List<Integer>> deviceCpuFrequenciesReader;
    private boolean deviceIsEmulator;
    private String deviceLocale;
    private String deviceManufacturer;
    private String deviceModel;
    private String deviceOsBuildNumber;
    private String deviceOsName;
    private String deviceOsVersion;
    private String devicePhysicalMemoryBytes;
    private String durationNs;
    private String environment;
    private final Map<String, ProfileMeasurement> measurementsMap;
    private String platform;
    private String profileId;
    private String release;
    private String sampledProfile = null;
    private final File traceFile;
    private String traceId;
    private String transactionId;
    private String transactionName;
    private List<ProfilingTransactionData> transactions;
    private String truncationReason;
    private Map<String, Object> unknown;
    private String versionCode;

    private ProfilingTraceData() {
        this(new File("dummy"), NoOpTransaction.getInstance());
    }

    public ProfilingTraceData(File file, ITransaction iTransaction) {
        this(file, (List<ProfilingTransactionData>)new ArrayList(), iTransaction.getName(), iTransaction.getEventId().toString(), iTransaction.getSpanContext().getTraceId().toString(), "0", 0, "", new ProfilingTraceData$$ExternalSyntheticLambda0(), null, null, null, null, null, null, null, null, TRUNCATION_REASON_NORMAL, (Map<String, ProfileMeasurement>)new HashMap());
    }

    public ProfilingTraceData(File object, List<ProfilingTransactionData> list, String string2, String string3, String string4, String string5, int n2, String string6, Callable<List<Integer>> callable, String string7, String string8, String string9, Boolean bl, String string10, String string11, String string12, String string13, String string14, Map<String, ProfileMeasurement> map2) {
        this.traceFile = object;
        this.cpuArchitecture = string6;
        this.deviceCpuFrequenciesReader = callable;
        this.androidApiLevel = n2;
        this.deviceLocale = Locale.getDefault().toString();
        string6 = "";
        object = string7 != null ? string7 : "";
        this.deviceManufacturer = object;
        object = string8 != null ? string8 : "";
        this.deviceModel = object;
        if (string9 == null) {
            string9 = "";
        }
        this.deviceOsVersion = string9;
        boolean bl2 = bl != null ? bl : false;
        this.deviceIsEmulator = bl2;
        if (string10 == null) {
            string10 = "0";
        }
        this.devicePhysicalMemoryBytes = string10;
        this.deviceOsBuildNumber = "";
        this.deviceOsName = "android";
        this.platform = "android";
        object = string11 != null ? string11 : "";
        this.buildId = object;
        this.transactions = list;
        this.transactionName = string2;
        this.durationNs = string5;
        this.versionCode = "";
        object = string6;
        if (string12 != null) {
            object = string12;
        }
        this.release = object;
        this.transactionId = string3;
        this.traceId = string4;
        this.profileId = UUID.randomUUID().toString();
        object = string13 != null ? string13 : DEFAULT_ENVIRONMENT;
        this.environment = object;
        this.truncationReason = string14;
        if (!this.isTruncationReasonValid()) {
            this.truncationReason = TRUNCATION_REASON_NORMAL;
        }
        this.measurementsMap = map2;
    }

    static /* synthetic */ List access$1002(ProfilingTraceData profilingTraceData, List list) {
        profilingTraceData.deviceCpuFrequencies = list;
        return list;
    }

    static /* synthetic */ int access$102(ProfilingTraceData profilingTraceData, int n2) {
        profilingTraceData.androidApiLevel = n2;
        return n2;
    }

    static /* synthetic */ String access$1102(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.devicePhysicalMemoryBytes = string2;
        return string2;
    }

    static /* synthetic */ String access$1202(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.platform = string2;
        return string2;
    }

    static /* synthetic */ String access$1302(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.buildId = string2;
        return string2;
    }

    static /* synthetic */ String access$1402(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.transactionName = string2;
        return string2;
    }

    static /* synthetic */ String access$1502(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.durationNs = string2;
        return string2;
    }

    static /* synthetic */ String access$1602(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.versionCode = string2;
        return string2;
    }

    static /* synthetic */ String access$1702(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.release = string2;
        return string2;
    }

    static /* synthetic */ String access$1902(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.transactionId = string2;
        return string2;
    }

    static /* synthetic */ String access$2002(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.traceId = string2;
        return string2;
    }

    static /* synthetic */ String access$202(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceLocale = string2;
        return string2;
    }

    static /* synthetic */ String access$2102(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.profileId = string2;
        return string2;
    }

    static /* synthetic */ String access$2202(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.environment = string2;
        return string2;
    }

    static /* synthetic */ String access$2302(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.truncationReason = string2;
        return string2;
    }

    static /* synthetic */ String access$2502(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.sampledProfile = string2;
        return string2;
    }

    static /* synthetic */ String access$302(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceManufacturer = string2;
        return string2;
    }

    static /* synthetic */ String access$402(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceModel = string2;
        return string2;
    }

    static /* synthetic */ String access$502(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceOsBuildNumber = string2;
        return string2;
    }

    static /* synthetic */ String access$602(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceOsName = string2;
        return string2;
    }

    static /* synthetic */ String access$702(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.deviceOsVersion = string2;
        return string2;
    }

    static /* synthetic */ boolean access$802(ProfilingTraceData profilingTraceData, boolean bl) {
        profilingTraceData.deviceIsEmulator = bl;
        return bl;
    }

    static /* synthetic */ String access$902(ProfilingTraceData profilingTraceData, String string2) {
        profilingTraceData.cpuArchitecture = string2;
        return string2;
    }

    private boolean isTruncationReasonValid() {
        boolean bl = this.truncationReason.equals((Object)TRUNCATION_REASON_NORMAL) || this.truncationReason.equals((Object)TRUNCATION_REASON_TIMEOUT) || this.truncationReason.equals((Object)TRUNCATION_REASON_BACKGROUNDED);
        return bl;
    }

    static /* synthetic */ List lambda$new$0() throws Exception {
        return new ArrayList();
    }

    public int getAndroidApiLevel() {
        return this.androidApiLevel;
    }

    public String getBuildId() {
        return this.buildId;
    }

    public String getCpuArchitecture() {
        return this.cpuArchitecture;
    }

    public List<Integer> getDeviceCpuFrequencies() {
        return this.deviceCpuFrequencies;
    }

    public String getDeviceLocale() {
        return this.deviceLocale;
    }

    public String getDeviceManufacturer() {
        return this.deviceManufacturer;
    }

    public String getDeviceModel() {
        return this.deviceModel;
    }

    public String getDeviceOsBuildNumber() {
        return this.deviceOsBuildNumber;
    }

    public String getDeviceOsName() {
        return this.deviceOsName;
    }

    public String getDeviceOsVersion() {
        return this.deviceOsVersion;
    }

    public String getDevicePhysicalMemoryBytes() {
        return this.devicePhysicalMemoryBytes;
    }

    public String getDurationNs() {
        return this.durationNs;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public Map<String, ProfileMeasurement> getMeasurementsMap() {
        return this.measurementsMap;
    }

    public String getPlatform() {
        return this.platform;
    }

    public String getProfileId() {
        return this.profileId;
    }

    public String getRelease() {
        return this.release;
    }

    public String getSampledProfile() {
        return this.sampledProfile;
    }

    public File getTraceFile() {
        return this.traceFile;
    }

    public String getTraceId() {
        return this.traceId;
    }

    public String getTransactionId() {
        return this.transactionId;
    }

    public String getTransactionName() {
        return this.transactionName;
    }

    public List<ProfilingTransactionData> getTransactions() {
        return this.transactions;
    }

    public String getTruncationReason() {
        return this.truncationReason;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public boolean isDeviceIsEmulator() {
        return this.deviceIsEmulator;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void readDeviceCpuFrequencies() {
        try {
            this.deviceCpuFrequencies = (List)this.deviceCpuFrequenciesReader.call();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("android_api_level").value(iLogger, this.androidApiLevel);
        objectWriter.name("device_locale").value(iLogger, this.deviceLocale);
        objectWriter.name("device_manufacturer").value(this.deviceManufacturer);
        objectWriter.name("device_model").value(this.deviceModel);
        objectWriter.name("device_os_build_number").value(this.deviceOsBuildNumber);
        objectWriter.name("device_os_name").value(this.deviceOsName);
        objectWriter.name("device_os_version").value(this.deviceOsVersion);
        objectWriter.name("device_is_emulator").value(this.deviceIsEmulator);
        objectWriter.name("architecture").value(iLogger, this.cpuArchitecture);
        objectWriter.name("device_cpu_frequencies").value(iLogger, this.deviceCpuFrequencies);
        objectWriter.name("device_physical_memory_bytes").value(this.devicePhysicalMemoryBytes);
        objectWriter.name("platform").value(this.platform);
        objectWriter.name("build_id").value(this.buildId);
        objectWriter.name("transaction_name").value(this.transactionName);
        objectWriter.name("duration_ns").value(this.durationNs);
        objectWriter.name("version_name").value(this.release);
        objectWriter.name("version_code").value(this.versionCode);
        if (!this.transactions.isEmpty()) {
            objectWriter.name("transactions").value(iLogger, this.transactions);
        }
        objectWriter.name("transaction_id").value(this.transactionId);
        objectWriter.name("trace_id").value(this.traceId);
        objectWriter.name("profile_id").value(this.profileId);
        objectWriter.name("environment").value(this.environment);
        objectWriter.name("truncation_reason").value(this.truncationReason);
        if (this.sampledProfile != null) {
            objectWriter.name("sampled_profile").value(this.sampledProfile);
        }
        objectWriter.name("measurements").value(iLogger, this.measurementsMap);
        Object object = this.unknown;
        if (object != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setAndroidApiLevel(int n2) {
        this.androidApiLevel = n2;
    }

    public void setBuildId(String string2) {
        this.buildId = string2;
    }

    public void setCpuArchitecture(String string2) {
        this.cpuArchitecture = string2;
    }

    public void setDeviceCpuFrequencies(List<Integer> list) {
        this.deviceCpuFrequencies = list;
    }

    public void setDeviceIsEmulator(boolean bl) {
        this.deviceIsEmulator = bl;
    }

    public void setDeviceLocale(String string2) {
        this.deviceLocale = string2;
    }

    public void setDeviceManufacturer(String string2) {
        this.deviceManufacturer = string2;
    }

    public void setDeviceModel(String string2) {
        this.deviceModel = string2;
    }

    public void setDeviceOsBuildNumber(String string2) {
        this.deviceOsBuildNumber = string2;
    }

    public void setDeviceOsVersion(String string2) {
        this.deviceOsVersion = string2;
    }

    public void setDevicePhysicalMemoryBytes(String string2) {
        this.devicePhysicalMemoryBytes = string2;
    }

    public void setDurationNs(String string2) {
        this.durationNs = string2;
    }

    public void setEnvironment(String string2) {
        this.environment = string2;
    }

    public void setProfileId(String string2) {
        this.profileId = string2;
    }

    public void setRelease(String string2) {
        this.release = string2;
    }

    public void setSampledProfile(String string2) {
        this.sampledProfile = string2;
    }

    public void setTraceId(String string2) {
        this.traceId = string2;
    }

    public void setTransactionId(String string2) {
        this.transactionId = string2;
    }

    public void setTransactionName(String string2) {
        this.transactionName = string2;
    }

    public void setTransactions(List<ProfilingTransactionData> list) {
        this.transactions = list;
    }

    public void setTruncationReason(String string2) {
        this.truncationReason = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<ProfilingTraceData> {
        @Override
        public ProfilingTraceData deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            ProfilingTraceData profilingTraceData = new ProfilingTraceData();
            block54: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Object object;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1954122069: {
                        if (!string2.equals((Object)"transactions")) break;
                        n3 = 24;
                        break;
                    }
                    case 1953158756: {
                        if (!string2.equals((Object)"sampled_profile")) break;
                        n3 = 23;
                        break;
                    }
                    case 1874684019: {
                        if (!string2.equals((Object)"platform")) break;
                        n3 = 22;
                        break;
                    }
                    case 1270300245: {
                        if (!string2.equals((Object)"trace_id")) break;
                        n3 = 21;
                        break;
                    }
                    case 1163928186: {
                        if (!string2.equals((Object)"truncation_reason")) break;
                        n3 = 20;
                        break;
                    }
                    case 1052553990: {
                        if (!string2.equals((Object)"device_os_version")) break;
                        n3 = 19;
                        break;
                    }
                    case 1010584092: {
                        if (!string2.equals((Object)"transaction_id")) break;
                        n3 = 18;
                        break;
                    }
                    case 839674195: {
                        if (!string2.equals((Object)"architecture")) break;
                        n3 = 17;
                        break;
                    }
                    case 796476189: {
                        if (!string2.equals((Object)"device_os_name")) break;
                        n3 = 16;
                        break;
                    }
                    case 508853068: {
                        if (!string2.equals((Object)"transaction_name")) break;
                        n3 = 15;
                        break;
                    }
                    case -85904877: {
                        if (!string2.equals((Object)"environment")) break;
                        n3 = 14;
                        break;
                    }
                    case -102670958: {
                        if (!string2.equals((Object)"version_name")) break;
                        n3 = 13;
                        break;
                    }
                    case -102985484: {
                        if (!string2.equals((Object)"version_code")) break;
                        n3 = 12;
                        break;
                    }
                    case -212264198: {
                        if (!string2.equals((Object)"device_cpu_frequencies")) break;
                        n3 = 11;
                        break;
                    }
                    case -332426004: {
                        if (!string2.equals((Object)"device_physical_memory_bytes")) break;
                        n3 = 10;
                        break;
                    }
                    case -362243017: {
                        if (!string2.equals((Object)"measurements")) break;
                        n3 = 9;
                        break;
                    }
                    case -478065584: {
                        if (!string2.equals((Object)"duration_ns")) break;
                        n3 = 8;
                        break;
                    }
                    case -512511455: {
                        if (!string2.equals((Object)"device_is_emulator")) break;
                        n3 = 7;
                        break;
                    }
                    case -591076352: {
                        if (!string2.equals((Object)"device_model")) break;
                        n3 = 6;
                        break;
                    }
                    case -716656436: {
                        if (!string2.equals((Object)"device_os_build_number")) break;
                        n3 = 5;
                        break;
                    }
                    case -1102636175: {
                        if (!string2.equals((Object)"profile_id")) break;
                        n3 = 4;
                        break;
                    }
                    case -1172160413: {
                        if (!string2.equals((Object)"device_locale")) break;
                        n3 = 3;
                        break;
                    }
                    case -1430655860: {
                        if (!string2.equals((Object)"build_id")) break;
                        n3 = 2;
                        break;
                    }
                    case -1981468849: {
                        if (!string2.equals((Object)"android_api_level")) break;
                        n3 = 1;
                        break;
                    }
                    case -2133529830: {
                        if (!string2.equals((Object)"device_manufacturer")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        object = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            object = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)object, string2);
                        concurrentHashMap = object;
                        continue block54;
                    }
                    case 24: {
                        object = jsonObjectReader.nextListOrNull(iLogger, new ProfilingTransactionData.Deserializer());
                        if (object == null) continue block54;
                        profilingTraceData.transactions.addAll((Collection)object);
                        continue block54;
                    }
                    case 23: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$2502(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 22: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1202(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 21: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$2002(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 20: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$2302(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 19: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$702(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 18: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1902(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 17: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$902(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 16: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$602(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 15: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1402(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 14: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$2202(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 13: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1702(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 12: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1602(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 11: {
                        object = (List)jsonObjectReader.nextObjectOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1002(profilingTraceData, (List)object);
                        continue block54;
                    }
                    case 10: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1102(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 9: {
                        object = jsonObjectReader.nextMapOrNull(iLogger, new ProfileMeasurement.Deserializer());
                        if (object == null) continue block54;
                        profilingTraceData.measurementsMap.putAll((Map)object);
                        continue block54;
                    }
                    case 8: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1502(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 7: {
                        object = jsonObjectReader.nextBooleanOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$802(profilingTraceData, object.booleanValue());
                        continue block54;
                    }
                    case 6: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$402(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 5: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$502(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 4: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$2102(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 3: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$202(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 2: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$1302(profilingTraceData, (String)object);
                        continue block54;
                    }
                    case 1: {
                        object = jsonObjectReader.nextIntegerOrNull();
                        if (object == null) continue block54;
                        ProfilingTraceData.access$102(profilingTraceData, object.intValue());
                        continue block54;
                    }
                    case 0: 
                }
                object = jsonObjectReader.nextStringOrNull();
                if (object == null) continue;
                ProfilingTraceData.access$302(profilingTraceData, (String)object);
            }
            profilingTraceData.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return profilingTraceData;
        }
    }

    public static final class JsonKeys {
        public static final String ANDROID_API_LEVEL = "android_api_level";
        public static final String ARCHITECTURE = "architecture";
        public static final String BUILD_ID = "build_id";
        public static final String DEVICE_CPU_FREQUENCIES = "device_cpu_frequencies";
        public static final String DEVICE_IS_EMULATOR = "device_is_emulator";
        public static final String DEVICE_LOCALE = "device_locale";
        public static final String DEVICE_MANUFACTURER = "device_manufacturer";
        public static final String DEVICE_MODEL = "device_model";
        public static final String DEVICE_OS_BUILD_NUMBER = "device_os_build_number";
        public static final String DEVICE_OS_NAME = "device_os_name";
        public static final String DEVICE_OS_VERSION = "device_os_version";
        public static final String DEVICE_PHYSICAL_MEMORY_BYTES = "device_physical_memory_bytes";
        public static final String DURATION_NS = "duration_ns";
        public static final String ENVIRONMENT = "environment";
        public static final String MEASUREMENTS = "measurements";
        public static final String PLATFORM = "platform";
        public static final String PROFILE_ID = "profile_id";
        public static final String RELEASE = "version_name";
        public static final String SAMPLED_PROFILE = "sampled_profile";
        public static final String TRACE_ID = "trace_id";
        public static final String TRANSACTION_ID = "transaction_id";
        public static final String TRANSACTION_LIST = "transactions";
        public static final String TRANSACTION_NAME = "transaction_name";
        public static final String TRUNCATION_REASON = "truncation_reason";
        public static final String VERSION_CODE = "version_code";
    }
}

