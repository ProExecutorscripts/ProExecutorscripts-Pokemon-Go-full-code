/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.FutureTask
 */
package io.sentry;

import io.sentry.ISentryExecutorService;
import io.sentry.NoOpSentryExecutorService$$ExternalSyntheticLambda0;
import io.sentry.NoOpSentryExecutorService$$ExternalSyntheticLambda1;
import io.sentry.NoOpSentryExecutorService$$ExternalSyntheticLambda2;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

final class NoOpSentryExecutorService
implements ISentryExecutorService {
    private static final NoOpSentryExecutorService instance = new NoOpSentryExecutorService();

    private NoOpSentryExecutorService() {
    }

    public static ISentryExecutorService getInstance() {
        return instance;
    }

    static /* synthetic */ Object lambda$schedule$2() throws Exception {
        return null;
    }

    static /* synthetic */ Object lambda$submit$0() throws Exception {
        return null;
    }

    static /* synthetic */ Object lambda$submit$1() throws Exception {
        return null;
    }

    @Override
    public void close(long l2) {
    }

    @Override
    public boolean isClosed() {
        return false;
    }

    @Override
    public Future<?> schedule(Runnable runnable, long l2) {
        return new FutureTask((Callable)new NoOpSentryExecutorService$$ExternalSyntheticLambda2());
    }

    @Override
    public Future<?> submit(Runnable runnable) {
        return new FutureTask((Callable)new NoOpSentryExecutorService$$ExternalSyntheticLambda1());
    }

    @Override
    public <T> Future<T> submit(Callable<T> callable) {
        return new FutureTask((Callable)new NoOpSentryExecutorService$$ExternalSyntheticLambda0());
    }
}

