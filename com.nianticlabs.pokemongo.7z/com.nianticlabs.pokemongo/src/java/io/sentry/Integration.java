/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.IHub;
import io.sentry.SentryOptions;

public interface Integration {
    public void register(IHub var1, SentryOptions var2);
}

