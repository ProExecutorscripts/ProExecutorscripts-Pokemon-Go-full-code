/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 *  java.util.Map
 *  java.util.Queue
 */
package io.sentry;

import io.sentry.Attachment;
import io.sentry.Breadcrumb;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.PropagationContext;
import io.sentry.Scope;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.User;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public interface IScope {
    public void addAttachment(Attachment var1);

    public void addBreadcrumb(Breadcrumb var1);

    public void addBreadcrumb(Breadcrumb var1, Hint var2);

    public void addEventProcessor(EventProcessor var1);

    public void clear();

    public void clearAttachments();

    public void clearBreadcrumbs();

    public void clearTransaction();

    public IScope clone();

    public Session endSession();

    public List<Attachment> getAttachments();

    public Queue<Breadcrumb> getBreadcrumbs();

    public Contexts getContexts();

    public List<EventProcessor> getEventProcessors();

    public Map<String, Object> getExtras();

    public List<String> getFingerprint();

    public SentryLevel getLevel();

    public SentryOptions getOptions();

    public PropagationContext getPropagationContext();

    public Request getRequest();

    public String getScreen();

    public Session getSession();

    public ISpan getSpan();

    public Map<String, String> getTags();

    public ITransaction getTransaction();

    public String getTransactionName();

    public User getUser();

    public void removeContexts(String var1);

    public void removeExtra(String var1);

    public void removeTag(String var1);

    public void setContexts(String var1, Boolean var2);

    public void setContexts(String var1, Character var2);

    public void setContexts(String var1, Number var2);

    public void setContexts(String var1, Object var2);

    public void setContexts(String var1, String var2);

    public void setContexts(String var1, Collection<?> var2);

    public void setContexts(String var1, Object[] var2);

    public void setExtra(String var1, String var2);

    public void setFingerprint(List<String> var1);

    public void setLevel(SentryLevel var1);

    public void setPropagationContext(PropagationContext var1);

    public void setRequest(Request var1);

    public void setScreen(String var1);

    public void setTag(String var1, String var2);

    public void setTransaction(ITransaction var1);

    public void setTransaction(String var1);

    public void setUser(User var1);

    public Scope.SessionPair startSession();

    public PropagationContext withPropagationContext(Scope.IWithPropagationContext var1);

    public Session withSession(Scope.IWithSession var1);

    public void withTransaction(Scope.IWithTransaction var1);
}

