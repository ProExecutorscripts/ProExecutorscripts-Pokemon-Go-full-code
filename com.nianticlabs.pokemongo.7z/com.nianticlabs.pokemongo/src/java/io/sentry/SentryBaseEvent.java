/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package io.sentry;

import io.sentry.Breadcrumb;
import io.sentry.ILogger;
import io.sentry.JsonObjectReader;
import io.sentry.ObjectWriter;
import io.sentry.exception.ExceptionMechanismException;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.DebugMeta;
import io.sentry.protocol.Request;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.User;
import io.sentry.util.CollectionUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class SentryBaseEvent {
    public static final String DEFAULT_PLATFORM = "java";
    private List<Breadcrumb> breadcrumbs;
    private final Contexts contexts = new Contexts();
    private DebugMeta debugMeta;
    private String dist;
    private String environment;
    private SentryId eventId;
    private Map<String, Object> extra;
    private String platform;
    private String release;
    private Request request;
    private SdkVersion sdk;
    private String serverName;
    private Map<String, String> tags;
    protected transient Throwable throwable;
    private User user;

    protected SentryBaseEvent() {
        this(new SentryId());
    }

    protected SentryBaseEvent(SentryId sentryId) {
        this.eventId = sentryId;
    }

    static /* synthetic */ SentryId access$002(SentryBaseEvent sentryBaseEvent, SentryId sentryId) {
        sentryBaseEvent.eventId = sentryId;
        return sentryId;
    }

    static /* synthetic */ String access$1002(SentryBaseEvent sentryBaseEvent, String string2) {
        sentryBaseEvent.dist = string2;
        return string2;
    }

    static /* synthetic */ List access$1102(SentryBaseEvent sentryBaseEvent, List list) {
        sentryBaseEvent.breadcrumbs = list;
        return list;
    }

    static /* synthetic */ DebugMeta access$1202(SentryBaseEvent sentryBaseEvent, DebugMeta debugMeta) {
        sentryBaseEvent.debugMeta = debugMeta;
        return debugMeta;
    }

    static /* synthetic */ Map access$1302(SentryBaseEvent sentryBaseEvent, Map map2) {
        sentryBaseEvent.extra = map2;
        return map2;
    }

    static /* synthetic */ SdkVersion access$202(SentryBaseEvent sentryBaseEvent, SdkVersion sdkVersion) {
        sentryBaseEvent.sdk = sdkVersion;
        return sdkVersion;
    }

    static /* synthetic */ Request access$302(SentryBaseEvent sentryBaseEvent, Request request) {
        sentryBaseEvent.request = request;
        return request;
    }

    static /* synthetic */ Map access$402(SentryBaseEvent sentryBaseEvent, Map map2) {
        sentryBaseEvent.tags = map2;
        return map2;
    }

    static /* synthetic */ String access$502(SentryBaseEvent sentryBaseEvent, String string2) {
        sentryBaseEvent.release = string2;
        return string2;
    }

    static /* synthetic */ String access$602(SentryBaseEvent sentryBaseEvent, String string2) {
        sentryBaseEvent.environment = string2;
        return string2;
    }

    static /* synthetic */ String access$702(SentryBaseEvent sentryBaseEvent, String string2) {
        sentryBaseEvent.platform = string2;
        return string2;
    }

    static /* synthetic */ User access$802(SentryBaseEvent sentryBaseEvent, User user) {
        sentryBaseEvent.user = user;
        return user;
    }

    static /* synthetic */ String access$902(SentryBaseEvent sentryBaseEvent, String string2) {
        sentryBaseEvent.serverName = string2;
        return string2;
    }

    public void addBreadcrumb(Breadcrumb breadcrumb) {
        if (this.breadcrumbs == null) {
            this.breadcrumbs = new ArrayList();
        }
        this.breadcrumbs.add((Object)breadcrumb);
    }

    public void addBreadcrumb(String string2) {
        this.addBreadcrumb(new Breadcrumb(string2));
    }

    public List<Breadcrumb> getBreadcrumbs() {
        return this.breadcrumbs;
    }

    public Contexts getContexts() {
        return this.contexts;
    }

    public DebugMeta getDebugMeta() {
        return this.debugMeta;
    }

    public String getDist() {
        return this.dist;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public SentryId getEventId() {
        return this.eventId;
    }

    public Object getExtra(String string2) {
        Map<String, Object> map2 = this.extra;
        if (map2 != null) {
            return map2.get((Object)string2);
        }
        return null;
    }

    public Map<String, Object> getExtras() {
        return this.extra;
    }

    public String getPlatform() {
        return this.platform;
    }

    public String getRelease() {
        return this.release;
    }

    public Request getRequest() {
        return this.request;
    }

    public SdkVersion getSdk() {
        return this.sdk;
    }

    public String getServerName() {
        return this.serverName;
    }

    public String getTag(String string2) {
        Map<String, String> map2 = this.tags;
        if (map2 != null) {
            return (String)map2.get((Object)string2);
        }
        return null;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public Throwable getThrowable() {
        Throwable throwable;
        Throwable throwable2 = throwable = this.throwable;
        if (throwable instanceof ExceptionMechanismException) {
            throwable2 = ((ExceptionMechanismException)throwable).getThrowable();
        }
        return throwable2;
    }

    public Throwable getThrowableMechanism() {
        return this.throwable;
    }

    public User getUser() {
        return this.user;
    }

    public void removeExtra(String string2) {
        Map<String, Object> map2 = this.extra;
        if (map2 != null) {
            map2.remove((Object)string2);
        }
    }

    public void removeTag(String string2) {
        Map<String, String> map2 = this.tags;
        if (map2 != null) {
            map2.remove((Object)string2);
        }
    }

    public void setBreadcrumbs(List<Breadcrumb> list) {
        this.breadcrumbs = CollectionUtils.newArrayList(list);
    }

    public void setDebugMeta(DebugMeta debugMeta) {
        this.debugMeta = debugMeta;
    }

    public void setDist(String string2) {
        this.dist = string2;
    }

    public void setEnvironment(String string2) {
        this.environment = string2;
    }

    public void setEventId(SentryId sentryId) {
        this.eventId = sentryId;
    }

    public void setExtra(String string2, Object object) {
        if (this.extra == null) {
            this.extra = new HashMap();
        }
        this.extra.put((Object)string2, object);
    }

    public void setExtras(Map<String, Object> map2) {
        this.extra = CollectionUtils.newHashMap(map2);
    }

    public void setPlatform(String string2) {
        this.platform = string2;
    }

    public void setRelease(String string2) {
        this.release = string2;
    }

    public void setRequest(Request request) {
        this.request = request;
    }

    public void setSdk(SdkVersion sdkVersion) {
        this.sdk = sdkVersion;
    }

    public void setServerName(String string2) {
        this.serverName = string2;
    }

    public void setTag(String string2, String string3) {
        if (this.tags == null) {
            this.tags = new HashMap();
        }
        this.tags.put((Object)string2, (Object)string3);
    }

    public void setTags(Map<String, String> map2) {
        this.tags = CollectionUtils.newHashMap(map2);
    }

    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public static final class Deserializer {
        public boolean deserializeValue(SentryBaseEvent sentryBaseEvent, String object, JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            object.hashCode();
            int n2 = object.hashCode();
            int n3 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 1874684019: {
                    if (!object.equals((Object)"platform")) break;
                    n3 = 13;
                    break;
                }
                case 1095692943: {
                    if (!object.equals((Object)"request")) break;
                    n3 = 12;
                    break;
                }
                case 1090594823: {
                    if (!object.equals((Object)"release")) break;
                    n3 = 11;
                    break;
                }
                case 278118624: {
                    if (!object.equals((Object)"event_id")) break;
                    n3 = 10;
                    break;
                }
                case 96965648: {
                    if (!object.equals((Object)"extra")) break;
                    n3 = 9;
                    break;
                }
                case 3599307: {
                    if (!object.equals((Object)"user")) break;
                    n3 = 8;
                    break;
                }
                case 3552281: {
                    if (!object.equals((Object)"tags")) break;
                    n3 = 7;
                    break;
                }
                case 3083686: {
                    if (!object.equals((Object)"dist")) break;
                    n3 = 6;
                    break;
                }
                case 113722: {
                    if (!object.equals((Object)"sdk")) break;
                    n3 = 5;
                    break;
                }
                case -51457840: {
                    if (!object.equals((Object)"breadcrumbs")) break;
                    n3 = 4;
                    break;
                }
                case -85904877: {
                    if (!object.equals((Object)"environment")) break;
                    n3 = 3;
                    break;
                }
                case -567312220: {
                    if (!object.equals((Object)"contexts")) break;
                    n3 = 2;
                    break;
                }
                case -758770169: {
                    if (!object.equals((Object)"server_name")) break;
                    n3 = 1;
                    break;
                }
                case -1840434063: {
                    if (!object.equals((Object)"debug_meta")) break;
                    n3 = 0;
                }
            }
            switch (n3) {
                default: {
                    return false;
                }
                case 13: {
                    SentryBaseEvent.access$702(sentryBaseEvent, jsonObjectReader.nextStringOrNull());
                    return true;
                }
                case 12: {
                    SentryBaseEvent.access$302(sentryBaseEvent, jsonObjectReader.nextOrNull(iLogger, new Request.Deserializer()));
                    return true;
                }
                case 11: {
                    SentryBaseEvent.access$502(sentryBaseEvent, jsonObjectReader.nextStringOrNull());
                    return true;
                }
                case 10: {
                    SentryBaseEvent.access$002(sentryBaseEvent, jsonObjectReader.nextOrNull(iLogger, new SentryId.Deserializer()));
                    return true;
                }
                case 9: {
                    SentryBaseEvent.access$1302(sentryBaseEvent, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                    return true;
                }
                case 8: {
                    SentryBaseEvent.access$802(sentryBaseEvent, jsonObjectReader.nextOrNull(iLogger, new User.Deserializer()));
                    return true;
                }
                case 7: {
                    SentryBaseEvent.access$402(sentryBaseEvent, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                    return true;
                }
                case 6: {
                    SentryBaseEvent.access$1002(sentryBaseEvent, jsonObjectReader.nextStringOrNull());
                    return true;
                }
                case 5: {
                    SentryBaseEvent.access$202(sentryBaseEvent, jsonObjectReader.nextOrNull(iLogger, new SdkVersion.Deserializer()));
                    return true;
                }
                case 4: {
                    SentryBaseEvent.access$1102(sentryBaseEvent, jsonObjectReader.nextListOrNull(iLogger, new Breadcrumb.Deserializer()));
                    return true;
                }
                case 3: {
                    SentryBaseEvent.access$602(sentryBaseEvent, jsonObjectReader.nextStringOrNull());
                    return true;
                }
                case 2: {
                    object = new Contexts.Deserializer().deserialize(jsonObjectReader, iLogger);
                    sentryBaseEvent.contexts.putAll((Map)object);
                    return true;
                }
                case 1: {
                    SentryBaseEvent.access$902(sentryBaseEvent, jsonObjectReader.nextStringOrNull());
                    return true;
                }
                case 0: 
            }
            SentryBaseEvent.access$1202(sentryBaseEvent, jsonObjectReader.nextOrNull(iLogger, new DebugMeta.Deserializer()));
            return true;
        }
    }

    public static final class JsonKeys {
        public static final String BREADCRUMBS = "breadcrumbs";
        public static final String CONTEXTS = "contexts";
        public static final String DEBUG_META = "debug_meta";
        public static final String DIST = "dist";
        public static final String ENVIRONMENT = "environment";
        public static final String EVENT_ID = "event_id";
        public static final String EXTRA = "extra";
        public static final String PLATFORM = "platform";
        public static final String RELEASE = "release";
        public static final String REQUEST = "request";
        public static final String SDK = "sdk";
        public static final String SERVER_NAME = "server_name";
        public static final String TAGS = "tags";
        public static final String USER = "user";
    }

    public static final class Serializer {
        public void serialize(SentryBaseEvent sentryBaseEvent, ObjectWriter objectWriter, ILogger iLogger) throws IOException {
            if (sentryBaseEvent.eventId != null) {
                objectWriter.name("event_id").value(iLogger, sentryBaseEvent.eventId);
            }
            objectWriter.name("contexts").value(iLogger, sentryBaseEvent.contexts);
            if (sentryBaseEvent.sdk != null) {
                objectWriter.name("sdk").value(iLogger, sentryBaseEvent.sdk);
            }
            if (sentryBaseEvent.request != null) {
                objectWriter.name("request").value(iLogger, sentryBaseEvent.request);
            }
            if (sentryBaseEvent.tags != null && !sentryBaseEvent.tags.isEmpty()) {
                objectWriter.name("tags").value(iLogger, sentryBaseEvent.tags);
            }
            if (sentryBaseEvent.release != null) {
                objectWriter.name("release").value(sentryBaseEvent.release);
            }
            if (sentryBaseEvent.environment != null) {
                objectWriter.name("environment").value(sentryBaseEvent.environment);
            }
            if (sentryBaseEvent.platform != null) {
                objectWriter.name("platform").value(sentryBaseEvent.platform);
            }
            if (sentryBaseEvent.user != null) {
                objectWriter.name("user").value(iLogger, sentryBaseEvent.user);
            }
            if (sentryBaseEvent.serverName != null) {
                objectWriter.name("server_name").value(sentryBaseEvent.serverName);
            }
            if (sentryBaseEvent.dist != null) {
                objectWriter.name("dist").value(sentryBaseEvent.dist);
            }
            if (sentryBaseEvent.breadcrumbs != null && !sentryBaseEvent.breadcrumbs.isEmpty()) {
                objectWriter.name("breadcrumbs").value(iLogger, sentryBaseEvent.breadcrumbs);
            }
            if (sentryBaseEvent.debugMeta != null) {
                objectWriter.name("debug_meta").value(iLogger, sentryBaseEvent.debugMeta);
            }
            if (sentryBaseEvent.extra != null && !sentryBaseEvent.extra.isEmpty()) {
                objectWriter.name("extra").value(iLogger, sentryBaseEvent.extra);
            }
        }
    }
}

