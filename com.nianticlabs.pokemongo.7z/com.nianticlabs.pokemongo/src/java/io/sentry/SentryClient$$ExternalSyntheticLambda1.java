/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.Hint;
import io.sentry.Scope;
import io.sentry.SentryClient;
import io.sentry.SentryEvent;
import io.sentry.Session;

public final class SentryClient$$ExternalSyntheticLambda1
implements Scope.IWithSession {
    public final SentryClient f$0;
    public final SentryEvent f$1;
    public final Hint f$2;

    public /* synthetic */ SentryClient$$ExternalSyntheticLambda1(SentryClient sentryClient, SentryEvent sentryEvent, Hint hint) {
        this.f$0 = sentryClient;
        this.f$1 = sentryEvent;
        this.f$2 = hint;
    }

    @Override
    public final void accept(Session session) {
        this.f$0.lambda$updateSessionData$1$io-sentry-SentryClient(this.f$1, this.f$2, session);
    }
}

