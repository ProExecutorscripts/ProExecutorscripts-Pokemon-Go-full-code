/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.IEnvelopeReader;
import io.sentry.SentryEnvelope;
import java.io.IOException;
import java.io.InputStream;

public final class NoOpEnvelopeReader
implements IEnvelopeReader {
    private static final NoOpEnvelopeReader instance = new NoOpEnvelopeReader();

    private NoOpEnvelopeReader() {
    }

    public static NoOpEnvelopeReader getInstance() {
        return instance;
    }

    @Override
    public SentryEnvelope read(InputStream inputStream) throws IOException {
        return null;
    }
}

