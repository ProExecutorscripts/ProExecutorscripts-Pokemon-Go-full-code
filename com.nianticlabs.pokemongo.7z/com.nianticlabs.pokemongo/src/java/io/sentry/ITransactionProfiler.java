/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package io.sentry;

import io.sentry.ITransaction;
import io.sentry.PerformanceCollectionData;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryOptions;
import java.util.List;

public interface ITransactionProfiler {
    public void bindTransaction(ITransaction var1);

    public void close();

    public boolean isRunning();

    public ProfilingTraceData onTransactionFinish(ITransaction var1, List<PerformanceCollectionData> var2, SentryOptions var3);

    public void start();
}

