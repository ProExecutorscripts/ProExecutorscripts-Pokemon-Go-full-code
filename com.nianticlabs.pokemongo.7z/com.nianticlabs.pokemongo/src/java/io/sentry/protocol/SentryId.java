/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.UUID
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.util.StringUtils;
import java.io.IOException;
import java.util.UUID;

public final class SentryId
implements JsonSerializable {
    public static final SentryId EMPTY_ID = new SentryId(new UUID(0L, 0L));
    private final UUID uuid;

    public SentryId() {
        UUID uUID = null;
        this((UUID)null);
    }

    public SentryId(String string2) {
        this.uuid = this.fromStringSentryId(StringUtils.normalizeUUID(string2));
    }

    public SentryId(UUID uUID) {
        UUID uUID2 = uUID;
        if (uUID == null) {
            uUID2 = UUID.randomUUID();
        }
        this.uuid = uUID2;
    }

    private UUID fromStringSentryId(String string2) {
        String string3 = string2;
        if (string2.length() == 32) {
            string3 = new StringBuilder(string2).insert(8, "-").insert(13, "-").insert(18, "-").insert(23, "-").toString();
        }
        if (string3.length() == 36) {
            return UUID.fromString((String)string3);
        }
        throw new IllegalArgumentException("String representation of SentryId has either 32 (UUID no dashes) or 36 characters long (completed UUID). Received: " + string3);
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (SentryId)object;
            if (this.uuid.compareTo(((SentryId)object).uuid) != 0) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public int hashCode() {
        return this.uuid.hashCode();
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.value(this.toString());
    }

    public String toString() {
        return StringUtils.normalizeUUID(this.uuid.toString()).replace((CharSequence)"-", (CharSequence)"");
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryId> {
        @Override
        public SentryId deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            return new SentryId(jsonObjectReader.nextString());
        }
    }
}

