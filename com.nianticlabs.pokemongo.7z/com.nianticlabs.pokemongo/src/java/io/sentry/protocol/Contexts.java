/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Enumeration
 *  java.util.List
 *  java.util.Map$Entry
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.ObjectWriter;
import io.sentry.SpanContext;
import io.sentry.protocol.App;
import io.sentry.protocol.Browser;
import io.sentry.protocol.Device;
import io.sentry.protocol.Gpu;
import io.sentry.protocol.OperatingSystem;
import io.sentry.protocol.Response;
import io.sentry.protocol.SentryRuntime;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Contexts
extends ConcurrentHashMap<String, Object>
implements JsonSerializable {
    private static final long serialVersionUID = 252445813254943011L;
    private final Object responseLock = new Object();

    public Contexts() {
    }

    public Contexts(Contexts contexts) {
        for (Map.Entry entry : contexts.entrySet()) {
            if (entry == null) continue;
            Object object = entry.getValue();
            if ("app".equals(entry.getKey()) && object instanceof App) {
                this.setApp(new App((App)object));
                continue;
            }
            if ("browser".equals(entry.getKey()) && object instanceof Browser) {
                this.setBrowser(new Browser((Browser)object));
                continue;
            }
            if ("device".equals(entry.getKey()) && object instanceof Device) {
                this.setDevice(new Device((Device)object));
                continue;
            }
            if ("os".equals(entry.getKey()) && object instanceof OperatingSystem) {
                this.setOperatingSystem(new OperatingSystem((OperatingSystem)object));
                continue;
            }
            if ("runtime".equals(entry.getKey()) && object instanceof SentryRuntime) {
                this.setRuntime(new SentryRuntime((SentryRuntime)object));
                continue;
            }
            if ("gpu".equals(entry.getKey()) && object instanceof Gpu) {
                this.setGpu(new Gpu((Gpu)object));
                continue;
            }
            if ("trace".equals(entry.getKey()) && object instanceof SpanContext) {
                this.setTrace(new SpanContext((SpanContext)object));
                continue;
            }
            if ("response".equals(entry.getKey()) && object instanceof Response) {
                this.setResponse(new Response((Response)object));
                continue;
            }
            this.put((String)entry.getKey(), object);
        }
    }

    private <T> T toContextType(String object, Class<T> clazz) {
        object = clazz.isInstance(object = this.get(object)) ? clazz.cast(object) : null;
        return (T)object;
    }

    public App getApp() {
        return this.toContextType("app", App.class);
    }

    public Browser getBrowser() {
        return this.toContextType("browser", Browser.class);
    }

    public Device getDevice() {
        return this.toContextType("device", Device.class);
    }

    public Gpu getGpu() {
        return this.toContextType("gpu", Gpu.class);
    }

    public OperatingSystem getOperatingSystem() {
        return this.toContextType("os", OperatingSystem.class);
    }

    public Response getResponse() {
        return this.toContextType("response", Response.class);
    }

    public SentryRuntime getRuntime() {
        return this.toContextType("runtime", SentryRuntime.class);
    }

    public SpanContext getTrace() {
        return this.toContextType("trace", SpanContext.class);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        Object object2 = Collections.list((Enumeration)this.keys());
        Collections.sort((List)object2);
        for (Object object2 : object2) {
            Object object3 = this.get(object2);
            if (object3 == null) continue;
            objectWriter.name((String)object2).value(iLogger, object3);
        }
        objectWriter.endObject();
    }

    public void setApp(App app) {
        this.put("app", app);
    }

    public void setBrowser(Browser browser) {
        this.put("browser", browser);
    }

    public void setDevice(Device device) {
        this.put("device", device);
    }

    public void setGpu(Gpu gpu) {
        this.put("gpu", gpu);
    }

    public void setOperatingSystem(OperatingSystem operatingSystem) {
        this.put("os", operatingSystem);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setResponse(Response response) {
        Object object;
        Object object2 = object = this.responseLock;
        synchronized (object2) {
            this.put("response", response);
            return;
        }
    }

    public void setRuntime(SentryRuntime sentryRuntime) {
        this.put("runtime", sentryRuntime);
    }

    public void setTrace(SpanContext spanContext) {
        Objects.requireNonNull(spanContext, "traceContext is required");
        this.put("trace", spanContext);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void withResponse(HintUtils.SentryConsumer<Response> sentryConsumer) {
        Object object;
        Object object2 = object = this.responseLock;
        synchronized (object2) {
            Response response = this.getResponse();
            if (response != null) {
                sentryConsumer.accept(response);
            } else {
                response = new Response();
                this.setResponse(response);
                sentryConsumer.accept(response);
            }
            return;
        }
    }

    public static final class Deserializer
    implements JsonDeserializer<Contexts> {
        @Override
        public Contexts deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            Contexts contexts = new Contexts();
            jsonObjectReader.beginObject();
            block20: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1550962648: {
                        if (!string2.equals((Object)"runtime")) break;
                        n3 = 7;
                        break;
                    }
                    case 150940456: {
                        if (!string2.equals((Object)"browser")) break;
                        n3 = 6;
                        break;
                    }
                    case 110620997: {
                        if (!string2.equals((Object)"trace")) break;
                        n3 = 5;
                        break;
                    }
                    case 102572: {
                        if (!string2.equals((Object)"gpu")) break;
                        n3 = 4;
                        break;
                    }
                    case 96801: {
                        if (!string2.equals((Object)"app")) break;
                        n3 = 3;
                        break;
                    }
                    case 3556: {
                        if (!string2.equals((Object)"os")) break;
                        n3 = 2;
                        break;
                    }
                    case -340323263: {
                        if (!string2.equals((Object)"response")) break;
                        n3 = 1;
                        break;
                    }
                    case -1335157162: {
                        if (!string2.equals((Object)"device")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Object object = jsonObjectReader.nextObjectOrNull();
                        if (object == null) continue block20;
                        contexts.put(string2, object);
                        continue block20;
                    }
                    case 7: {
                        contexts.setRuntime(new SentryRuntime.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 6: {
                        contexts.setBrowser(new Browser.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 5: {
                        contexts.setTrace(new SpanContext.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 4: {
                        contexts.setGpu(new Gpu.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 3: {
                        contexts.setApp(new App.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 2: {
                        contexts.setOperatingSystem(new OperatingSystem.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 1: {
                        contexts.setResponse(new Response.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block20;
                    }
                    case 0: 
                }
                contexts.setDevice(new Device.Deserializer().deserialize(jsonObjectReader, iLogger));
            }
            jsonObjectReader.endObject();
            return contexts;
        }
    }
}

