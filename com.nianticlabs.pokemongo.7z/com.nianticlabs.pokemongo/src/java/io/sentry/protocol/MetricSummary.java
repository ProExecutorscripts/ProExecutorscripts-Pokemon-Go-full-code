/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class MetricSummary
implements JsonUnknown,
JsonSerializable {
    private int count;
    private double max;
    private double min;
    private double sum;
    private Map<String, String> tags;
    private Map<String, Object> unknown;

    public MetricSummary() {
    }

    public MetricSummary(double d2, double d3, double d4, int n2, Map<String, String> map2) {
        this.tags = map2;
        this.min = d2;
        this.max = d3;
        this.count = n2;
        this.sum = d4;
        this.unknown = null;
    }

    static /* synthetic */ Map access$002(MetricSummary metricSummary, Map map2) {
        metricSummary.tags = map2;
        return map2;
    }

    public int getCount() {
        return this.count;
    }

    public double getMax() {
        return this.max;
    }

    public double getMin() {
        return this.min;
    }

    public double getSum() {
        return this.sum;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("min").value(this.min);
        objectWriter.name("max").value(this.max);
        objectWriter.name("sum").value(this.sum);
        objectWriter.name("count").value(this.count);
        if (this.tags != null) {
            objectWriter.name("tags");
            objectWriter.value(iLogger, this.tags);
        }
        objectWriter.endObject();
    }

    public void setCount(int n2) {
        this.count = n2;
    }

    public void setMax(double d2) {
        this.max = d2;
    }

    public void setMin(double d2) {
        this.min = d2;
    }

    public void setSum(double d2) {
        this.sum = d2;
    }

    public void setTags(Map<String, String> map2) {
        this.tags = map2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<MetricSummary> {
        @Override
        public MetricSummary deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            MetricSummary metricSummary = new MetricSummary();
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            block14: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 94851343: {
                        if (!string2.equals((Object)"count")) break;
                        n3 = 4;
                        break;
                    }
                    case 3552281: {
                        if (!string2.equals((Object)"tags")) break;
                        n3 = 3;
                        break;
                    }
                    case 114251: {
                        if (!string2.equals((Object)"sum")) break;
                        n3 = 2;
                        break;
                    }
                    case 108114: {
                        if (!string2.equals((Object)"min")) break;
                        n3 = 1;
                        break;
                    }
                    case 107876: {
                        if (!string2.equals((Object)"max")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block14;
                    }
                    case 4: {
                        metricSummary.setCount(jsonObjectReader.nextInt());
                        continue block14;
                    }
                    case 3: {
                        MetricSummary.access$002(metricSummary, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block14;
                    }
                    case 2: {
                        metricSummary.setSum(jsonObjectReader.nextDouble());
                        continue block14;
                    }
                    case 1: {
                        metricSummary.setMin(jsonObjectReader.nextDouble());
                        continue block14;
                    }
                    case 0: 
                }
                metricSummary.setMax(jsonObjectReader.nextDouble());
            }
            metricSummary.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return metricSummary;
        }
    }

    public static final class JsonKeys {
        public static final String COUNT = "count";
        public static final String MAX = "max";
        public static final String MIN = "min";
        public static final String SUM = "sum";
        public static final String TAGS = "tags";
    }
}

