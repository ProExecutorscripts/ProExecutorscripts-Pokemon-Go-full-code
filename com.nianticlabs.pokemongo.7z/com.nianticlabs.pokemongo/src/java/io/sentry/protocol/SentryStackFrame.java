/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLockReason;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryStackFrame
implements JsonUnknown,
JsonSerializable {
    private Boolean _native;
    private String _package;
    private String absPath;
    private Integer colno;
    private String contextLine;
    private String filename;
    private List<Integer> framesOmitted;
    private String function;
    private String imageAddr;
    private Boolean inApp;
    private String instructionAddr;
    private Integer lineno;
    private SentryLockReason lock;
    private String module;
    private String platform;
    private List<String> postContext;
    private List<String> preContext;
    private String rawFunction;
    private String symbol;
    private String symbolAddr;
    private Map<String, Object> unknown;
    private Map<String, String> vars;

    static /* synthetic */ String access$002(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.filename = string2;
        return string2;
    }

    static /* synthetic */ String access$1002(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.platform = string2;
        return string2;
    }

    static /* synthetic */ String access$102(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.function = string2;
        return string2;
    }

    static /* synthetic */ String access$1102(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.imageAddr = string2;
        return string2;
    }

    static /* synthetic */ String access$1202(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.symbolAddr = string2;
        return string2;
    }

    static /* synthetic */ String access$1302(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.instructionAddr = string2;
        return string2;
    }

    static /* synthetic */ String access$1402(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.rawFunction = string2;
        return string2;
    }

    static /* synthetic */ String access$1502(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.symbol = string2;
        return string2;
    }

    static /* synthetic */ SentryLockReason access$1602(SentryStackFrame sentryStackFrame, SentryLockReason sentryLockReason) {
        sentryStackFrame.lock = sentryLockReason;
        return sentryLockReason;
    }

    static /* synthetic */ String access$202(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.module = string2;
        return string2;
    }

    static /* synthetic */ Integer access$302(SentryStackFrame sentryStackFrame, Integer n2) {
        sentryStackFrame.lineno = n2;
        return n2;
    }

    static /* synthetic */ Integer access$402(SentryStackFrame sentryStackFrame, Integer n2) {
        sentryStackFrame.colno = n2;
        return n2;
    }

    static /* synthetic */ String access$502(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.absPath = string2;
        return string2;
    }

    static /* synthetic */ String access$602(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame.contextLine = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$702(SentryStackFrame sentryStackFrame, Boolean bl) {
        sentryStackFrame.inApp = bl;
        return bl;
    }

    static /* synthetic */ String access$802(SentryStackFrame sentryStackFrame, String string2) {
        sentryStackFrame._package = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$902(SentryStackFrame sentryStackFrame, Boolean bl) {
        sentryStackFrame._native = bl;
        return bl;
    }

    public String getAbsPath() {
        return this.absPath;
    }

    public Integer getColno() {
        return this.colno;
    }

    public String getContextLine() {
        return this.contextLine;
    }

    public String getFilename() {
        return this.filename;
    }

    public List<Integer> getFramesOmitted() {
        return this.framesOmitted;
    }

    public String getFunction() {
        return this.function;
    }

    public String getImageAddr() {
        return this.imageAddr;
    }

    public String getInstructionAddr() {
        return this.instructionAddr;
    }

    public Integer getLineno() {
        return this.lineno;
    }

    public SentryLockReason getLock() {
        return this.lock;
    }

    public String getModule() {
        return this.module;
    }

    public String getPackage() {
        return this._package;
    }

    public String getPlatform() {
        return this.platform;
    }

    public List<String> getPostContext() {
        return this.postContext;
    }

    public List<String> getPreContext() {
        return this.preContext;
    }

    public String getRawFunction() {
        return this.rawFunction;
    }

    public String getSymbol() {
        return this.symbol;
    }

    public String getSymbolAddr() {
        return this.symbolAddr;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Map<String, String> getVars() {
        return this.vars;
    }

    public Boolean isInApp() {
        return this.inApp;
    }

    public Boolean isNative() {
        return this._native;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.filename != null) {
            objectWriter.name("filename").value(this.filename);
        }
        if (this.function != null) {
            objectWriter.name("function").value(this.function);
        }
        if (this.module != null) {
            objectWriter.name("module").value(this.module);
        }
        if (this.lineno != null) {
            objectWriter.name("lineno").value((Number)this.lineno);
        }
        if (this.colno != null) {
            objectWriter.name("colno").value((Number)this.colno);
        }
        if (this.absPath != null) {
            objectWriter.name("abs_path").value(this.absPath);
        }
        if (this.contextLine != null) {
            objectWriter.name("context_line").value(this.contextLine);
        }
        if (this.inApp != null) {
            objectWriter.name("in_app").value(this.inApp);
        }
        if (this._package != null) {
            objectWriter.name("package").value(this._package);
        }
        if (this._native != null) {
            objectWriter.name("native").value(this._native);
        }
        if (this.platform != null) {
            objectWriter.name("platform").value(this.platform);
        }
        if (this.imageAddr != null) {
            objectWriter.name("image_addr").value(this.imageAddr);
        }
        if (this.symbolAddr != null) {
            objectWriter.name("symbol_addr").value(this.symbolAddr);
        }
        if (this.instructionAddr != null) {
            objectWriter.name("instruction_addr").value(this.instructionAddr);
        }
        if (this.rawFunction != null) {
            objectWriter.name("raw_function").value(this.rawFunction);
        }
        if (this.symbol != null) {
            objectWriter.name("symbol").value(this.symbol);
        }
        if (this.lock != null) {
            objectWriter.name("lock").value(iLogger, this.lock);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setAbsPath(String string2) {
        this.absPath = string2;
    }

    public void setColno(Integer n2) {
        this.colno = n2;
    }

    public void setContextLine(String string2) {
        this.contextLine = string2;
    }

    public void setFilename(String string2) {
        this.filename = string2;
    }

    public void setFramesOmitted(List<Integer> list) {
        this.framesOmitted = list;
    }

    public void setFunction(String string2) {
        this.function = string2;
    }

    public void setImageAddr(String string2) {
        this.imageAddr = string2;
    }

    public void setInApp(Boolean bl) {
        this.inApp = bl;
    }

    public void setInstructionAddr(String string2) {
        this.instructionAddr = string2;
    }

    public void setLineno(Integer n2) {
        this.lineno = n2;
    }

    public void setLock(SentryLockReason sentryLockReason) {
        this.lock = sentryLockReason;
    }

    public void setModule(String string2) {
        this.module = string2;
    }

    public void setNative(Boolean bl) {
        this._native = bl;
    }

    public void setPackage(String string2) {
        this._package = string2;
    }

    public void setPlatform(String string2) {
        this.platform = string2;
    }

    public void setPostContext(List<String> list) {
        this.postContext = list;
    }

    public void setPreContext(List<String> list) {
        this.preContext = list;
    }

    public void setRawFunction(String string2) {
        this.rawFunction = string2;
    }

    public void setSymbol(String string2) {
        this.symbol = string2;
    }

    public void setSymbolAddr(String string2) {
        this.symbolAddr = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVars(Map<String, String> map2) {
        this.vars = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryStackFrame> {
        @Override
        public SentryStackFrame deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SentryStackFrame sentryStackFrame = new SentryStackFrame();
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            block38: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1874684019: {
                        if (!string2.equals((Object)"platform")) break;
                        n3 = 16;
                        break;
                    }
                    case 1713445842: {
                        if (!string2.equals((Object)"abs_path")) break;
                        n3 = 15;
                        break;
                    }
                    case 1380938712: {
                        if (!string2.equals((Object)"function")) break;
                        n3 = 14;
                        break;
                    }
                    case 1116694660: {
                        if (!string2.equals((Object)"context_line")) break;
                        n3 = 13;
                        break;
                    }
                    case 410194178: {
                        if (!string2.equals((Object)"instruction_addr")) break;
                        n3 = 12;
                        break;
                    }
                    case 94842689: {
                        if (!string2.equals((Object)"colno")) break;
                        n3 = 11;
                        break;
                    }
                    case 3327275: {
                        if (!string2.equals((Object)"lock")) break;
                        n3 = 10;
                        break;
                    }
                    case -330260936: {
                        if (!string2.equals((Object)"symbol_addr")) break;
                        n3 = 9;
                        break;
                    }
                    case -734768633: {
                        if (!string2.equals((Object)"filename")) break;
                        n3 = 8;
                        break;
                    }
                    case -807062458: {
                        if (!string2.equals((Object)"package")) break;
                        n3 = 7;
                        break;
                    }
                    case -887523944: {
                        if (!string2.equals((Object)"symbol")) break;
                        n3 = 6;
                        break;
                    }
                    case -1052618729: {
                        if (!string2.equals((Object)"native")) break;
                        n3 = 5;
                        break;
                    }
                    case -1068784020: {
                        if (!string2.equals((Object)"module")) break;
                        n3 = 4;
                        break;
                    }
                    case -1102671691: {
                        if (!string2.equals((Object)"lineno")) break;
                        n3 = 3;
                        break;
                    }
                    case -1113875953: {
                        if (!string2.equals((Object)"raw_function")) break;
                        n3 = 2;
                        break;
                    }
                    case -1184392185: {
                        if (!string2.equals((Object)"in_app")) break;
                        n3 = 1;
                        break;
                    }
                    case -1443345323: {
                        if (!string2.equals((Object)"image_addr")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block38;
                    }
                    case 16: {
                        SentryStackFrame.access$1002(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 15: {
                        SentryStackFrame.access$502(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 14: {
                        SentryStackFrame.access$102(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 13: {
                        SentryStackFrame.access$602(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 12: {
                        SentryStackFrame.access$1302(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 11: {
                        SentryStackFrame.access$402(sentryStackFrame, jsonObjectReader.nextIntegerOrNull());
                        continue block38;
                    }
                    case 10: {
                        SentryStackFrame.access$1602(sentryStackFrame, jsonObjectReader.nextOrNull(iLogger, new SentryLockReason.Deserializer()));
                        continue block38;
                    }
                    case 9: {
                        SentryStackFrame.access$1202(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 8: {
                        SentryStackFrame.access$002(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 7: {
                        SentryStackFrame.access$802(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 6: {
                        SentryStackFrame.access$1502(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 5: {
                        SentryStackFrame.access$902(sentryStackFrame, jsonObjectReader.nextBooleanOrNull());
                        continue block38;
                    }
                    case 4: {
                        SentryStackFrame.access$202(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 3: {
                        SentryStackFrame.access$302(sentryStackFrame, jsonObjectReader.nextIntegerOrNull());
                        continue block38;
                    }
                    case 2: {
                        SentryStackFrame.access$1402(sentryStackFrame, jsonObjectReader.nextStringOrNull());
                        continue block38;
                    }
                    case 1: {
                        SentryStackFrame.access$702(sentryStackFrame, jsonObjectReader.nextBooleanOrNull());
                        continue block38;
                    }
                    case 0: 
                }
                SentryStackFrame.access$1102(sentryStackFrame, jsonObjectReader.nextStringOrNull());
            }
            sentryStackFrame.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return sentryStackFrame;
        }
    }

    public static final class JsonKeys {
        public static final String ABS_PATH = "abs_path";
        public static final String COLNO = "colno";
        public static final String CONTEXT_LINE = "context_line";
        public static final String FILENAME = "filename";
        public static final String FUNCTION = "function";
        public static final String IMAGE_ADDR = "image_addr";
        public static final String INSTRUCTION_ADDR = "instruction_addr";
        public static final String IN_APP = "in_app";
        public static final String LINENO = "lineno";
        public static final String LOCK = "lock";
        public static final String MODULE = "module";
        public static final String NATIVE = "native";
        public static final String PACKAGE = "package";
        public static final String PLATFORM = "platform";
        public static final String RAW_FUNCTION = "raw_function";
        public static final String SYMBOL = "symbol";
        public static final String SYMBOL_ADDR = "symbol_addr";
    }
}

