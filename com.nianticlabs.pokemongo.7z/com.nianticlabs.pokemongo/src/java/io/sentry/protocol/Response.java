/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Response
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "response";
    private Long bodySize;
    private String cookies;
    private Object data;
    private Map<String, String> headers;
    private Integer statusCode;
    private Map<String, Object> unknown;

    public Response() {
    }

    public Response(Response response) {
        this.cookies = response.cookies;
        this.headers = CollectionUtils.newConcurrentHashMap(response.headers);
        this.unknown = CollectionUtils.newConcurrentHashMap(response.unknown);
        this.statusCode = response.statusCode;
        this.bodySize = response.bodySize;
        this.data = response.data;
    }

    static /* synthetic */ String access$002(Response response, String string2) {
        response.cookies = string2;
        return string2;
    }

    static /* synthetic */ Map access$102(Response response, Map map2) {
        response.headers = map2;
        return map2;
    }

    static /* synthetic */ Integer access$202(Response response, Integer n2) {
        response.statusCode = n2;
        return n2;
    }

    static /* synthetic */ Long access$302(Response response, Long l2) {
        response.bodySize = l2;
        return l2;
    }

    static /* synthetic */ Object access$402(Response response, Object object) {
        response.data = object;
        return object;
    }

    public Long getBodySize() {
        return this.bodySize;
    }

    public String getCookies() {
        return this.cookies;
    }

    public Object getData() {
        return this.data;
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    public Integer getStatusCode() {
        return this.statusCode;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.cookies != null) {
            objectWriter.name("cookies").value(this.cookies);
        }
        if (this.headers != null) {
            objectWriter.name("headers").value(iLogger, this.headers);
        }
        if (this.statusCode != null) {
            objectWriter.name("status_code").value(iLogger, this.statusCode);
        }
        if (this.bodySize != null) {
            objectWriter.name("body_size").value(iLogger, this.bodySize);
        }
        if (this.data != null) {
            objectWriter.name("data").value(iLogger, this.data);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setBodySize(Long l2) {
        this.bodySize = l2;
    }

    public void setCookies(String string2) {
        this.cookies = string2;
    }

    public void setData(Object object) {
        this.data = object;
    }

    public void setHeaders(Map<String, String> map2) {
        this.headers = CollectionUtils.newConcurrentHashMap(map2);
    }

    public void setStatusCode(Integer n2) {
        this.statusCode = n2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Response> {
        @Override
        public Response deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Response response = new Response();
            Map map2 = null;
            block14: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1252988030: {
                        if (!string2.equals((Object)"body_size")) break;
                        n3 = 4;
                        break;
                    }
                    case 952189583: {
                        if (!string2.equals((Object)"cookies")) break;
                        n3 = 3;
                        break;
                    }
                    case 795307910: {
                        if (!string2.equals((Object)"headers")) break;
                        n3 = 2;
                        break;
                    }
                    case 3076010: {
                        if (!string2.equals((Object)"data")) break;
                        n3 = 1;
                        break;
                    }
                    case -891699686: {
                        if (!string2.equals((Object)"status_code")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Map map3 = map2;
                        if (map2 == null) {
                            map3 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)map3, string2);
                        map2 = map3;
                        continue block14;
                    }
                    case 4: {
                        Response.access$302(response, jsonObjectReader.nextLongOrNull());
                        continue block14;
                    }
                    case 3: {
                        Response.access$002(response, jsonObjectReader.nextStringOrNull());
                        continue block14;
                    }
                    case 2: {
                        Map map3 = (Map)jsonObjectReader.nextObjectOrNull();
                        if (map3 == null) continue block14;
                        Response.access$102(response, CollectionUtils.newConcurrentHashMap(map3));
                        continue block14;
                    }
                    case 1: {
                        Response.access$402(response, jsonObjectReader.nextObjectOrNull());
                        continue block14;
                    }
                    case 0: 
                }
                Response.access$202(response, jsonObjectReader.nextIntegerOrNull());
            }
            response.setUnknown(map2);
            jsonObjectReader.endObject();
            return response;
        }
    }

    public static final class JsonKeys {
        public static final String BODY_SIZE = "body_size";
        public static final String COOKIES = "cookies";
        public static final String DATA = "data";
        public static final String HEADERS = "headers";
        public static final String STATUS_CODE = "status_code";
    }
}

