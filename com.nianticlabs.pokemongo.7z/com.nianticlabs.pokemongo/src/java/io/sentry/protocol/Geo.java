/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Geo
implements JsonUnknown,
JsonSerializable {
    private String city;
    private String countryCode;
    private String region;
    private Map<String, Object> unknown;

    public Geo() {
    }

    public Geo(Geo geo) {
        this.city = geo.city;
        this.countryCode = geo.countryCode;
        this.region = geo.region;
    }

    static /* synthetic */ String access$002(Geo geo, String string2) {
        geo.city = string2;
        return string2;
    }

    static /* synthetic */ String access$102(Geo geo, String string2) {
        geo.countryCode = string2;
        return string2;
    }

    static /* synthetic */ String access$202(Geo geo, String string2) {
        geo.region = string2;
        return string2;
    }

    public static Geo fromMap(Map<String, Object> object2) {
        Geo geo = new Geo();
        block10: for (Object object2 : object2.entrySet()) {
            Object object3 = object2.getValue();
            object2 = (String)object2.getKey();
            object2.hashCode();
            int n2 = object2.hashCode();
            int n3 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 1481071862: {
                    if (!object2.equals((Object)"country_code")) break;
                    n3 = 2;
                    break;
                }
                case 3053931: {
                    if (!object2.equals((Object)"city")) break;
                    n3 = 1;
                    break;
                }
                case -934795532: {
                    if (!object2.equals((Object)"region")) break;
                    n3 = 0;
                }
            }
            Object var3_5 = null;
            Object var4_6 = null;
            object2 = null;
            switch (n3) {
                default: {
                    continue block10;
                }
                case 2: {
                    if (object3 instanceof String) {
                        object2 = (String)object3;
                    }
                    geo.countryCode = object2;
                    continue block10;
                }
                case 1: {
                    object2 = var3_5;
                    if (object3 instanceof String) {
                        object2 = (String)object3;
                    }
                    geo.city = object2;
                    continue block10;
                }
                case 0: 
            }
            object2 = var4_6;
            if (object3 instanceof String) {
                object2 = (String)object3;
            }
            geo.region = object2;
        }
        return geo;
    }

    public String getCity() {
        return this.city;
    }

    public String getCountryCode() {
        return this.countryCode;
    }

    public String getRegion() {
        return this.region;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.city != null) {
            objectWriter.name("city").value(this.city);
        }
        if (this.countryCode != null) {
            objectWriter.name("country_code").value(this.countryCode);
        }
        if (this.region != null) {
            objectWriter.name("region").value(this.region);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setCity(String string2) {
        this.city = string2;
    }

    public void setCountryCode(String string2) {
        this.countryCode = string2;
    }

    public void setRegion(String string2) {
        this.region = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Geo> {
        @Override
        public Geo deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Geo geo = new Geo();
            ConcurrentHashMap concurrentHashMap = null;
            block10: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1481071862: {
                        if (!string2.equals((Object)"country_code")) break;
                        n3 = 2;
                        break;
                    }
                    case 3053931: {
                        if (!string2.equals((Object)"city")) break;
                        n3 = 1;
                        break;
                    }
                    case -934795532: {
                        if (!string2.equals((Object)"region")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block10;
                    }
                    case 2: {
                        Geo.access$102(geo, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 1: {
                        Geo.access$002(geo, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 0: 
                }
                Geo.access$202(geo, jsonObjectReader.nextStringOrNull());
            }
            geo.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return geo;
        }
    }

    public static final class JsonKeys {
        public static final String CITY = "city";
        public static final String COUNTRY_CODE = "country_code";
        public static final String REGION = "region";
    }
}

