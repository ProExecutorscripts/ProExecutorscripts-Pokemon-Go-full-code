/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class App
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "app";
    private String appBuild;
    private String appIdentifier;
    private String appName;
    private Date appStartTime;
    private String appVersion;
    private String buildType;
    private String deviceAppHash;
    private Boolean inForeground;
    private Map<String, String> permissions;
    private Map<String, Object> unknown;
    private List<String> viewNames;

    public App() {
    }

    App(App app) {
        this.appBuild = app.appBuild;
        this.appIdentifier = app.appIdentifier;
        this.appName = app.appName;
        this.appStartTime = app.appStartTime;
        this.appVersion = app.appVersion;
        this.buildType = app.buildType;
        this.deviceAppHash = app.deviceAppHash;
        this.permissions = CollectionUtils.newConcurrentHashMap(app.permissions);
        this.inForeground = app.inForeground;
        this.viewNames = CollectionUtils.newArrayList(app.viewNames);
        this.unknown = CollectionUtils.newConcurrentHashMap(app.unknown);
    }

    static /* synthetic */ String access$002(App app, String string2) {
        app.appIdentifier = string2;
        return string2;
    }

    static /* synthetic */ Date access$102(App app, Date date) {
        app.appStartTime = date;
        return date;
    }

    static /* synthetic */ String access$202(App app, String string2) {
        app.deviceAppHash = string2;
        return string2;
    }

    static /* synthetic */ String access$302(App app, String string2) {
        app.buildType = string2;
        return string2;
    }

    static /* synthetic */ String access$402(App app, String string2) {
        app.appName = string2;
        return string2;
    }

    static /* synthetic */ String access$502(App app, String string2) {
        app.appVersion = string2;
        return string2;
    }

    static /* synthetic */ String access$602(App app, String string2) {
        app.appBuild = string2;
        return string2;
    }

    static /* synthetic */ Map access$702(App app, Map map2) {
        app.permissions = map2;
        return map2;
    }

    static /* synthetic */ Boolean access$802(App app, Boolean bl) {
        app.inForeground = bl;
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (App)object;
            if (!(Objects.equals(this.appIdentifier, ((App)object).appIdentifier) && Objects.equals(this.appStartTime, ((App)object).appStartTime) && Objects.equals(this.deviceAppHash, ((App)object).deviceAppHash) && Objects.equals(this.buildType, ((App)object).buildType) && Objects.equals(this.appName, ((App)object).appName) && Objects.equals(this.appVersion, ((App)object).appVersion) && Objects.equals(this.appBuild, ((App)object).appBuild) && Objects.equals(this.permissions, ((App)object).permissions) && Objects.equals(this.inForeground, ((App)object).inForeground) && Objects.equals(this.viewNames, ((App)object).viewNames))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getAppBuild() {
        return this.appBuild;
    }

    public String getAppIdentifier() {
        return this.appIdentifier;
    }

    public String getAppName() {
        return this.appName;
    }

    public Date getAppStartTime() {
        Object object = this.appStartTime;
        object = object != null ? (Date)object.clone() : null;
        return object;
    }

    public String getAppVersion() {
        return this.appVersion;
    }

    public String getBuildType() {
        return this.buildType;
    }

    public String getDeviceAppHash() {
        return this.deviceAppHash;
    }

    public Boolean getInForeground() {
        return this.inForeground;
    }

    public Map<String, String> getPermissions() {
        return this.permissions;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public List<String> getViewNames() {
        return this.viewNames;
    }

    public int hashCode() {
        return Objects.hash(this.appIdentifier, this.appStartTime, this.deviceAppHash, this.buildType, this.appName, this.appVersion, this.appBuild, this.permissions, this.inForeground, this.viewNames);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.appIdentifier != null) {
            objectWriter.name("app_identifier").value(this.appIdentifier);
        }
        if (this.appStartTime != null) {
            objectWriter.name("app_start_time").value(iLogger, this.appStartTime);
        }
        if (this.deviceAppHash != null) {
            objectWriter.name("device_app_hash").value(this.deviceAppHash);
        }
        if (this.buildType != null) {
            objectWriter.name("build_type").value(this.buildType);
        }
        if (this.appName != null) {
            objectWriter.name("app_name").value(this.appName);
        }
        if (this.appVersion != null) {
            objectWriter.name("app_version").value(this.appVersion);
        }
        if (this.appBuild != null) {
            objectWriter.name("app_build").value(this.appBuild);
        }
        if ((iterator = this.permissions) != null && !iterator.isEmpty()) {
            objectWriter.name("permissions").value(iLogger, this.permissions);
        }
        if (this.inForeground != null) {
            objectWriter.name("in_foreground").value(this.inForeground);
        }
        if (this.viewNames != null) {
            objectWriter.name("view_names").value(iLogger, this.viewNames);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setAppBuild(String string2) {
        this.appBuild = string2;
    }

    public void setAppIdentifier(String string2) {
        this.appIdentifier = string2;
    }

    public void setAppName(String string2) {
        this.appName = string2;
    }

    public void setAppStartTime(Date date) {
        this.appStartTime = date;
    }

    public void setAppVersion(String string2) {
        this.appVersion = string2;
    }

    public void setBuildType(String string2) {
        this.buildType = string2;
    }

    public void setDeviceAppHash(String string2) {
        this.deviceAppHash = string2;
    }

    public void setInForeground(Boolean bl) {
        this.inForeground = bl;
    }

    public void setPermissions(Map<String, String> map2) {
        this.permissions = map2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setViewNames(List<String> list) {
        this.viewNames = list;
    }

    public static final class Deserializer
    implements JsonDeserializer<App> {
        @Override
        public App deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            App app = new App();
            List list = null;
            block24: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1826866896: {
                        if (!string2.equals((Object)"app_build")) break;
                        n3 = 9;
                        break;
                    }
                    case 1167648233: {
                        if (!string2.equals((Object)"app_name")) break;
                        n3 = 8;
                        break;
                    }
                    case 1133704324: {
                        if (!string2.equals((Object)"permissions")) break;
                        n3 = 7;
                        break;
                    }
                    case 791585128: {
                        if (!string2.equals((Object)"app_start_time")) break;
                        n3 = 6;
                        break;
                    }
                    case 746297735: {
                        if (!string2.equals((Object)"app_identifier")) break;
                        n3 = 5;
                        break;
                    }
                    case -470395285: {
                        if (!string2.equals((Object)"build_type")) break;
                        n3 = 4;
                        break;
                    }
                    case -650544995: {
                        if (!string2.equals((Object)"in_foreground")) break;
                        n3 = 3;
                        break;
                    }
                    case -901870406: {
                        if (!string2.equals((Object)"app_version")) break;
                        n3 = 2;
                        break;
                    }
                    case -1524619986: {
                        if (!string2.equals((Object)"view_names")) break;
                        n3 = 1;
                        break;
                    }
                    case -1898053579: {
                        if (!string2.equals((Object)"device_app_hash")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        List list2 = list;
                        if (list == null) {
                            list2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)list2, string2);
                        list = list2;
                        continue block24;
                    }
                    case 9: {
                        App.access$602(app, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 8: {
                        App.access$402(app, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 7: {
                        App.access$702(app, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block24;
                    }
                    case 6: {
                        App.access$102(app, jsonObjectReader.nextDateOrNull(iLogger));
                        continue block24;
                    }
                    case 5: {
                        App.access$002(app, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 4: {
                        App.access$302(app, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 3: {
                        App.access$802(app, jsonObjectReader.nextBooleanOrNull());
                        continue block24;
                    }
                    case 2: {
                        App.access$502(app, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 1: {
                        List list2 = (List)jsonObjectReader.nextObjectOrNull();
                        if (list2 == null) continue block24;
                        app.setViewNames((List<String>)list2);
                        continue block24;
                    }
                    case 0: 
                }
                App.access$202(app, jsonObjectReader.nextStringOrNull());
            }
            app.setUnknown((Map<String, Object>)list);
            jsonObjectReader.endObject();
            return app;
        }
    }

    public static final class JsonKeys {
        public static final String APP_BUILD = "app_build";
        public static final String APP_IDENTIFIER = "app_identifier";
        public static final String APP_NAME = "app_name";
        public static final String APP_PERMISSIONS = "permissions";
        public static final String APP_START_TIME = "app_start_time";
        public static final String APP_VERSION = "app_version";
        public static final String BUILD_TYPE = "build_type";
        public static final String DEVICE_APP_HASH = "device_app_hash";
        public static final String IN_FOREGROUND = "in_foreground";
        public static final String VIEW_NAMES = "view_names";
    }
}

