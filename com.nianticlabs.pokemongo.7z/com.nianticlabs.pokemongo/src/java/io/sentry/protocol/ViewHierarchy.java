/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.protocol.ViewHierarchyNode;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class ViewHierarchy
implements JsonUnknown,
JsonSerializable {
    private final String renderingSystem;
    private Map<String, Object> unknown;
    private final List<ViewHierarchyNode> windows;

    public ViewHierarchy(String string2, List<ViewHierarchyNode> list) {
        this.renderingSystem = string2;
        this.windows = list;
    }

    public String getRenderingSystem() {
        return this.renderingSystem;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public List<ViewHierarchyNode> getWindows() {
        return this.windows;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.renderingSystem != null) {
            objectWriter.name("rendering_system").value(this.renderingSystem);
        }
        if (this.windows != null) {
            objectWriter.name("windows").value(iLogger, this.windows);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<ViewHierarchy> {
        @Override
        public ViewHierarchy deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            ((JsonReader)object).beginObject();
            String string2 = null;
            List<ViewHierarchyNode> list = null;
            HashMap hashMap = null;
            while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string3 = ((JsonReader)object).nextName();
                string3.hashCode();
                if (!string3.equals((Object)"rendering_system")) {
                    if (!string3.equals((Object)"windows")) {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)hashMap2, string3);
                        hashMap = hashMap2;
                        continue;
                    }
                    list = ((JsonObjectReader)object).nextListOrNull(iLogger, new ViewHierarchyNode.Deserializer());
                    continue;
                }
                string2 = ((JsonObjectReader)object).nextStringOrNull();
            }
            ((JsonReader)object).endObject();
            object = new ViewHierarchy(string2, list);
            ((ViewHierarchy)object).setUnknown((Map<String, Object>)hashMap);
            return object;
        }
    }

    public static final class JsonKeys {
        public static final String RENDERING_SYSTEM = "rendering_system";
        public static final String WINDOWS = "windows";
    }
}

