/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package io.sentry.protocol;

import java.util.Locale;

public enum TransactionNameSource {
    CUSTOM,
    URL,
    ROUTE,
    VIEW,
    COMPONENT,
    TASK;


    public String apiName() {
        return this.name().toLowerCase(Locale.ROOT);
    }
}

