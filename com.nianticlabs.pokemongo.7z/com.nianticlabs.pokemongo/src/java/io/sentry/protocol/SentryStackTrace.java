/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryStackTrace
implements JsonUnknown,
JsonSerializable {
    private List<SentryStackFrame> frames;
    private Map<String, String> registers;
    private Boolean snapshot;
    private Map<String, Object> unknown;

    public SentryStackTrace() {
    }

    public SentryStackTrace(List<SentryStackFrame> list) {
        this.frames = list;
    }

    static /* synthetic */ List access$002(SentryStackTrace sentryStackTrace, List list) {
        sentryStackTrace.frames = list;
        return list;
    }

    static /* synthetic */ Map access$102(SentryStackTrace sentryStackTrace, Map map2) {
        sentryStackTrace.registers = map2;
        return map2;
    }

    static /* synthetic */ Boolean access$202(SentryStackTrace sentryStackTrace, Boolean bl) {
        sentryStackTrace.snapshot = bl;
        return bl;
    }

    public List<SentryStackFrame> getFrames() {
        return this.frames;
    }

    public Map<String, String> getRegisters() {
        return this.registers;
    }

    public Boolean getSnapshot() {
        return this.snapshot;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.frames != null) {
            objectWriter.name("frames").value(iLogger, this.frames);
        }
        if (this.registers != null) {
            objectWriter.name("registers").value(iLogger, this.registers);
        }
        if (this.snapshot != null) {
            objectWriter.name("snapshot").value(this.snapshot);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setFrames(List<SentryStackFrame> list) {
        this.frames = list;
    }

    public void setRegisters(Map<String, String> map2) {
        this.registers = map2;
    }

    public void setSnapshot(Boolean bl) {
        this.snapshot = bl;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryStackTrace> {
        @Override
        public SentryStackTrace deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SentryStackTrace sentryStackTrace = new SentryStackTrace();
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            block10: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 284874180: {
                        if (!string2.equals((Object)"snapshot")) break;
                        n3 = 2;
                        break;
                    }
                    case 78226992: {
                        if (!string2.equals((Object)"registers")) break;
                        n3 = 1;
                        break;
                    }
                    case -1266514778: {
                        if (!string2.equals((Object)"frames")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block10;
                    }
                    case 2: {
                        SentryStackTrace.access$202(sentryStackTrace, jsonObjectReader.nextBooleanOrNull());
                        continue block10;
                    }
                    case 1: {
                        SentryStackTrace.access$102(sentryStackTrace, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block10;
                    }
                    case 0: 
                }
                SentryStackTrace.access$002(sentryStackTrace, jsonObjectReader.nextListOrNull(iLogger, new SentryStackFrame.Deserializer()));
            }
            sentryStackTrace.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return sentryStackTrace;
        }
    }

    public static final class JsonKeys {
        public static final String FRAMES = "frames";
        public static final String REGISTERS = "registers";
        public static final String SNAPSHOT = "snapshot";
    }
}

