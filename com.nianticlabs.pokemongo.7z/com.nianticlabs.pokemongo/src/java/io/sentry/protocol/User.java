/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.protocol.Geo;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class User
implements JsonUnknown,
JsonSerializable {
    private Map<String, String> data;
    private String email;
    private Geo geo;
    private String id;
    private String ipAddress;
    private String name;
    private String segment;
    private Map<String, Object> unknown;
    private String username;

    public User() {
    }

    public User(User user) {
        this.email = user.email;
        this.username = user.username;
        this.id = user.id;
        this.ipAddress = user.ipAddress;
        this.segment = user.segment;
        this.name = user.name;
        this.geo = user.geo;
        this.data = CollectionUtils.newConcurrentHashMap(user.data);
        this.unknown = CollectionUtils.newConcurrentHashMap(user.unknown);
    }

    static /* synthetic */ String access$002(User user, String string2) {
        user.email = string2;
        return string2;
    }

    static /* synthetic */ String access$102(User user, String string2) {
        user.id = string2;
        return string2;
    }

    static /* synthetic */ String access$202(User user, String string2) {
        user.username = string2;
        return string2;
    }

    static /* synthetic */ String access$302(User user, String string2) {
        user.segment = string2;
        return string2;
    }

    static /* synthetic */ String access$402(User user, String string2) {
        user.ipAddress = string2;
        return string2;
    }

    static /* synthetic */ String access$502(User user, String string2) {
        user.name = string2;
        return string2;
    }

    static /* synthetic */ Geo access$602(User user, Geo geo) {
        user.geo = geo;
        return geo;
    }

    static /* synthetic */ Map access$702(User user, Map map2) {
        user.data = map2;
        return map2;
    }

    public static User fromMap(Map<String, Object> object, SentryOptions sentryOptions) {
        User user = new User();
        Iterator iterator = object.entrySet().iterator();
        object = null;
        block22: while (iterator.hasNext()) {
            ConcurrentHashMap concurrentHashMap = (ConcurrentHashMap)iterator.next();
            Object object22 = concurrentHashMap.getValue();
            Object object32 = concurrentHashMap.getKey();
            object32.hashCode();
            int n2 = object32.hashCode();
            int n3 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 1973722931: {
                    if (!object32.equals((Object)"segment")) break;
                    n3 = 8;
                    break;
                }
                case 1480014044: {
                    if (!object32.equals((Object)"ip_address")) break;
                    n3 = 7;
                    break;
                }
                case 106069776: {
                    if (!object32.equals((Object)"other")) break;
                    n3 = 6;
                    break;
                }
                case 96619420: {
                    if (!object32.equals((Object)"email")) break;
                    n3 = 5;
                    break;
                }
                case 3373707: {
                    if (!object32.equals((Object)"name")) break;
                    n3 = 4;
                    break;
                }
                case 3076010: {
                    if (!object32.equals((Object)"data")) break;
                    n3 = 3;
                    break;
                }
                case 102225: {
                    if (!object32.equals((Object)"geo")) break;
                    n3 = 2;
                    break;
                }
                case 3355: {
                    if (!object32.equals((Object)"id")) break;
                    n3 = 1;
                    break;
                }
                case -265713450: {
                    if (!object32.equals((Object)"username")) break;
                    n3 = 0;
                }
            }
            switch (n3) {
                default: {
                    object32 = object;
                    if (object == null) {
                        object32 = new ConcurrentHashMap();
                    }
                    object32.put((Object)((String)concurrentHashMap.getKey()), concurrentHashMap.getValue());
                    object = object32;
                    continue block22;
                }
                case 8: {
                    object32 = object22 instanceof String ? (String)object22 : null;
                    user.segment = object32;
                    continue block22;
                }
                case 7: {
                    object32 = object22 instanceof String ? (String)object22 : null;
                    user.ipAddress = object32;
                    continue block22;
                }
                case 6: {
                    object32 = object22 instanceof Map ? (Map)object22 : null;
                    if (object32 == null || (concurrentHashMap = user.data) != null && !concurrentHashMap.isEmpty()) continue block22;
                    concurrentHashMap = new ConcurrentHashMap();
                    for (Object object32 : object32.entrySet()) {
                        if (object32.getKey() instanceof String && object32.getValue() != null) {
                            concurrentHashMap.put((Object)((String)object32.getKey()), (Object)object32.getValue().toString());
                            continue;
                        }
                        sentryOptions.getLogger().log(SentryLevel.WARNING, "Invalid key or null value in other map.", new Object[0]);
                    }
                    user.data = concurrentHashMap;
                    continue block22;
                }
                case 5: {
                    object32 = object22 instanceof String ? (String)object22 : null;
                    user.email = object32;
                    continue block22;
                }
                case 4: {
                    object32 = object22 instanceof String ? (String)object22 : null;
                    user.name = object32;
                    continue block22;
                }
                case 3: {
                    object32 = object22 instanceof Map ? (Map)object22 : null;
                    if (object32 == null) continue block22;
                    concurrentHashMap = new ConcurrentHashMap();
                    for (Object object22 : object32.entrySet()) {
                        if (object22.getKey() instanceof String && object22.getValue() != null) {
                            concurrentHashMap.put((Object)((String)object22.getKey()), (Object)object22.getValue().toString());
                            continue;
                        }
                        sentryOptions.getLogger().log(SentryLevel.WARNING, "Invalid key or null value in data map.", new Object[0]);
                    }
                    user.data = concurrentHashMap;
                    continue block22;
                }
                case 2: {
                    object32 = object22 instanceof Map ? (Map)object22 : null;
                    if (object32 == null) continue block22;
                    concurrentHashMap = new ConcurrentHashMap();
                    for (Object object32 : object32.entrySet()) {
                        if (object32.getKey() instanceof String && object32.getValue() != null) {
                            concurrentHashMap.put((Object)((String)object32.getKey()), object32.getValue());
                            continue;
                        }
                        sentryOptions.getLogger().log(SentryLevel.WARNING, "Invalid key type in gep map.", new Object[0]);
                    }
                    user.geo = Geo.fromMap((Map<String, Object>)concurrentHashMap);
                    continue block22;
                }
                case 1: {
                    object32 = object22 instanceof String ? (String)object22 : null;
                    user.id = object32;
                    continue block22;
                }
                case 0: 
            }
            object32 = object22 instanceof String ? (String)object22 : null;
            user.username = object32;
        }
        user.unknown = object;
        return user;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (User)object;
            if (!(Objects.equals(this.email, ((User)object).email) && Objects.equals(this.id, ((User)object).id) && Objects.equals(this.username, ((User)object).username) && Objects.equals(this.segment, ((User)object).segment) && Objects.equals(this.ipAddress, ((User)object).ipAddress))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public Map<String, String> getData() {
        return this.data;
    }

    public String getEmail() {
        return this.email;
    }

    public Geo getGeo() {
        return this.geo;
    }

    public String getId() {
        return this.id;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public String getName() {
        return this.name;
    }

    @Deprecated
    public Map<String, String> getOthers() {
        return this.getData();
    }

    public String getSegment() {
        return this.segment;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getUsername() {
        return this.username;
    }

    public int hashCode() {
        return Objects.hash(this.email, this.id, this.username, this.segment, this.ipAddress);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.email != null) {
            objectWriter.name("email").value(this.email);
        }
        if (this.id != null) {
            objectWriter.name("id").value(this.id);
        }
        if (this.username != null) {
            objectWriter.name("username").value(this.username);
        }
        if (this.segment != null) {
            objectWriter.name("segment").value(this.segment);
        }
        if (this.ipAddress != null) {
            objectWriter.name("ip_address").value(this.ipAddress);
        }
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.geo != null) {
            objectWriter.name("geo");
            this.geo.serialize(objectWriter, iLogger);
        }
        if (this.data != null) {
            objectWriter.name("data").value(iLogger, this.data);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setData(Map<String, String> map2) {
        this.data = CollectionUtils.newConcurrentHashMap(map2);
    }

    public void setEmail(String string2) {
        this.email = string2;
    }

    public void setGeo(Geo geo) {
        this.geo = geo;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIpAddress(String string2) {
        this.ipAddress = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    @Deprecated
    public void setOthers(Map<String, String> map2) {
        this.setData(map2);
    }

    public void setSegment(String string2) {
        this.segment = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setUsername(String string2) {
        this.username = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<User> {
        @Override
        public User deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            User user = new User();
            ConcurrentHashMap concurrentHashMap = null;
            block22: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1973722931: {
                        if (!string2.equals((Object)"segment")) break;
                        n3 = 8;
                        break;
                    }
                    case 1480014044: {
                        if (!string2.equals((Object)"ip_address")) break;
                        n3 = 7;
                        break;
                    }
                    case 106069776: {
                        if (!string2.equals((Object)"other")) break;
                        n3 = 6;
                        break;
                    }
                    case 96619420: {
                        if (!string2.equals((Object)"email")) break;
                        n3 = 5;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 4;
                        break;
                    }
                    case 3076010: {
                        if (!string2.equals((Object)"data")) break;
                        n3 = 3;
                        break;
                    }
                    case 102225: {
                        if (!string2.equals((Object)"geo")) break;
                        n3 = 2;
                        break;
                    }
                    case 3355: {
                        if (!string2.equals((Object)"id")) break;
                        n3 = 1;
                        break;
                    }
                    case -265713450: {
                        if (!string2.equals((Object)"username")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block22;
                    }
                    case 8: {
                        User.access$302(user, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 7: {
                        User.access$402(user, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 6: {
                        if (user.data != null && !user.data.isEmpty()) continue block22;
                        User.access$702(user, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block22;
                    }
                    case 5: {
                        User.access$002(user, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 4: {
                        User.access$502(user, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 3: {
                        User.access$702(user, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block22;
                    }
                    case 2: {
                        User.access$602(user, new Geo.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block22;
                    }
                    case 1: {
                        User.access$102(user, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 0: 
                }
                User.access$202(user, jsonObjectReader.nextStringOrNull());
            }
            user.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return user;
        }
    }

    public static final class JsonKeys {
        public static final String DATA = "data";
        public static final String EMAIL = "email";
        public static final String GEO = "geo";
        public static final String ID = "id";
        public static final String IP_ADDRESS = "ip_address";
        public static final String NAME = "name";
        public static final String OTHER = "other";
        public static final String SEGMENT = "segment";
        public static final String USERNAME = "username";
    }
}

