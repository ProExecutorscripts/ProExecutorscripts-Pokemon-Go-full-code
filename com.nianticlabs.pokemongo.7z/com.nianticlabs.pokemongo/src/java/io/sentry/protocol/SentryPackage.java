/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Objects
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public final class SentryPackage
implements JsonUnknown,
JsonSerializable {
    private String name;
    private Map<String, Object> unknown;
    private String version;

    public SentryPackage(String string2, String string3) {
        this.name = io.sentry.util.Objects.requireNonNull(string2, "name is required.");
        this.version = io.sentry.util.Objects.requireNonNull(string3, "version is required.");
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (SentryPackage)object;
            if (!Objects.equals((Object)this.name, (Object)((SentryPackage)object).name) || !Objects.equals((Object)this.version, (Object)((SentryPackage)object).version)) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVersion() {
        return this.version;
    }

    public int hashCode() {
        return Objects.hash((Object[])new Object[]{this.name, this.version});
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("name").value(this.name);
        objectWriter.name("version").value(this.version);
        Object object = this.unknown;
        if (object != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setName(String string2) {
        this.name = io.sentry.util.Objects.requireNonNull(string2, "name is required.");
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVersion(String string2) {
        this.version = io.sentry.util.Objects.requireNonNull(string2, "version is required.");
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryPackage> {
        @Override
        public SentryPackage deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            ((JsonReader)object).beginObject();
            String string2 = null;
            String string3 = null;
            HashMap hashMap = null;
            while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string4 = ((JsonReader)object).nextName();
                string4.hashCode();
                if (!string4.equals((Object)"name")) {
                    if (!string4.equals((Object)"version")) {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)hashMap2, string4);
                        hashMap = hashMap2;
                        continue;
                    }
                    string3 = ((JsonReader)object).nextString();
                    continue;
                }
                string2 = ((JsonReader)object).nextString();
            }
            ((JsonReader)object).endObject();
            if (string2 != null) {
                if (string3 != null) {
                    object = new SentryPackage(string2, string3);
                    ((SentryPackage)object).setUnknown((Map<String, Object>)hashMap);
                    return object;
                }
                object = new IllegalStateException("Missing required field \"version\"");
                iLogger.log(SentryLevel.ERROR, "Missing required field \"version\"", (Throwable)object);
                throw object;
            }
            object = new IllegalStateException("Missing required field \"name\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"name\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String NAME = "name";
        public static final String VERSION = "version";
    }
}

