/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class TransactionInfo
implements JsonSerializable,
JsonUnknown {
    private final String source;
    private Map<String, Object> unknown;

    public TransactionInfo(String string2) {
        this.source = string2;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.source != null) {
            objectWriter.name("source").value(iLogger, this.source);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<TransactionInfo> {
        @Override
        public TransactionInfo deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
            jsonObjectReader.beginObject();
            String string2 = null;
            ConcurrentHashMap concurrentHashMap = null;
            while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string3 = jsonObjectReader.nextName();
                string3.hashCode();
                if (!string3.equals((Object)"source")) {
                    ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                    if (concurrentHashMap == null) {
                        concurrentHashMap2 = new ConcurrentHashMap();
                    }
                    jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)concurrentHashMap2, string3);
                    concurrentHashMap = concurrentHashMap2;
                    continue;
                }
                string2 = jsonObjectReader.nextStringOrNull();
            }
            object = new TransactionInfo(string2);
            ((TransactionInfo)object).setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return object;
        }
    }

    public static final class JsonKeys {
        public static final String SOURCE = "source";
    }
}

