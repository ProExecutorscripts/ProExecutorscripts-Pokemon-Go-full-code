/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Gpu
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "gpu";
    private String apiType;
    private Integer id;
    private Integer memorySize;
    private Boolean multiThreadedRendering;
    private String name;
    private String npotSupport;
    private Map<String, Object> unknown;
    private String vendorId;
    private String vendorName;
    private String version;

    public Gpu() {
    }

    Gpu(Gpu gpu) {
        this.name = gpu.name;
        this.id = gpu.id;
        this.vendorId = gpu.vendorId;
        this.vendorName = gpu.vendorName;
        this.memorySize = gpu.memorySize;
        this.apiType = gpu.apiType;
        this.multiThreadedRendering = gpu.multiThreadedRendering;
        this.version = gpu.version;
        this.npotSupport = gpu.npotSupport;
        this.unknown = CollectionUtils.newConcurrentHashMap(gpu.unknown);
    }

    static /* synthetic */ String access$002(Gpu gpu, String string2) {
        gpu.name = string2;
        return string2;
    }

    static /* synthetic */ Integer access$102(Gpu gpu, Integer n2) {
        gpu.id = n2;
        return n2;
    }

    static /* synthetic */ String access$202(Gpu gpu, String string2) {
        gpu.vendorId = string2;
        return string2;
    }

    static /* synthetic */ String access$302(Gpu gpu, String string2) {
        gpu.vendorName = string2;
        return string2;
    }

    static /* synthetic */ Integer access$402(Gpu gpu, Integer n2) {
        gpu.memorySize = n2;
        return n2;
    }

    static /* synthetic */ String access$502(Gpu gpu, String string2) {
        gpu.apiType = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$602(Gpu gpu, Boolean bl) {
        gpu.multiThreadedRendering = bl;
        return bl;
    }

    static /* synthetic */ String access$702(Gpu gpu, String string2) {
        gpu.version = string2;
        return string2;
    }

    static /* synthetic */ String access$802(Gpu gpu, String string2) {
        gpu.npotSupport = string2;
        return string2;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (Gpu)object;
            if (!(Objects.equals(this.name, ((Gpu)object).name) && Objects.equals(this.id, ((Gpu)object).id) && Objects.equals(this.vendorId, ((Gpu)object).vendorId) && Objects.equals(this.vendorName, ((Gpu)object).vendorName) && Objects.equals(this.memorySize, ((Gpu)object).memorySize) && Objects.equals(this.apiType, ((Gpu)object).apiType) && Objects.equals(this.multiThreadedRendering, ((Gpu)object).multiThreadedRendering) && Objects.equals(this.version, ((Gpu)object).version) && Objects.equals(this.npotSupport, ((Gpu)object).npotSupport))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getApiType() {
        return this.apiType;
    }

    public Integer getId() {
        return this.id;
    }

    public Integer getMemorySize() {
        return this.memorySize;
    }

    public String getName() {
        return this.name;
    }

    public String getNpotSupport() {
        return this.npotSupport;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVendorId() {
        return this.vendorId;
    }

    public String getVendorName() {
        return this.vendorName;
    }

    public String getVersion() {
        return this.version;
    }

    public int hashCode() {
        return Objects.hash(this.name, this.id, this.vendorId, this.vendorName, this.memorySize, this.apiType, this.multiThreadedRendering, this.version, this.npotSupport);
    }

    public Boolean isMultiThreadedRendering() {
        return this.multiThreadedRendering;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.id != null) {
            objectWriter.name("id").value((Number)this.id);
        }
        if (this.vendorId != null) {
            objectWriter.name("vendor_id").value(this.vendorId);
        }
        if (this.vendorName != null) {
            objectWriter.name("vendor_name").value(this.vendorName);
        }
        if (this.memorySize != null) {
            objectWriter.name("memory_size").value((Number)this.memorySize);
        }
        if (this.apiType != null) {
            objectWriter.name("api_type").value(this.apiType);
        }
        if (this.multiThreadedRendering != null) {
            objectWriter.name("multi_threaded_rendering").value(this.multiThreadedRendering);
        }
        if (this.version != null) {
            objectWriter.name("version").value(this.version);
        }
        if (this.npotSupport != null) {
            objectWriter.name("npot_support").value(this.npotSupport);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setApiType(String string2) {
        this.apiType = string2;
    }

    public void setId(Integer n2) {
        this.id = n2;
    }

    public void setMemorySize(Integer n2) {
        this.memorySize = n2;
    }

    public void setMultiThreadedRendering(Boolean bl) {
        this.multiThreadedRendering = bl;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setNpotSupport(String string2) {
        this.npotSupport = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVendorId(String string2) {
        this.vendorId = string2;
    }

    public void setVendorName(String string2) {
        this.vendorName = string2;
    }

    public void setVersion(String string2) {
        this.version = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Gpu> {
        @Override
        public Gpu deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Gpu gpu = new Gpu();
            ConcurrentHashMap concurrentHashMap = null;
            block22: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1418777727: {
                        if (!string2.equals((Object)"memory_size")) break;
                        n3 = 8;
                        break;
                    }
                    case 967446079: {
                        if (!string2.equals((Object)"api_type")) break;
                        n3 = 7;
                        break;
                    }
                    case 351608024: {
                        if (!string2.equals((Object)"version")) break;
                        n3 = 6;
                        break;
                    }
                    case 59480866: {
                        if (!string2.equals((Object)"vendor_name")) break;
                        n3 = 5;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 4;
                        break;
                    }
                    case 3355: {
                        if (!string2.equals((Object)"id")) break;
                        n3 = 3;
                        break;
                    }
                    case -1009234244: {
                        if (!string2.equals((Object)"multi_threaded_rendering")) break;
                        n3 = 2;
                        break;
                    }
                    case -1085970574: {
                        if (!string2.equals((Object)"vendor_id")) break;
                        n3 = 1;
                        break;
                    }
                    case -1421884745: {
                        if (!string2.equals((Object)"npot_support")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block22;
                    }
                    case 8: {
                        Gpu.access$402(gpu, jsonObjectReader.nextIntegerOrNull());
                        continue block22;
                    }
                    case 7: {
                        Gpu.access$502(gpu, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 6: {
                        Gpu.access$702(gpu, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 5: {
                        Gpu.access$302(gpu, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 4: {
                        Gpu.access$002(gpu, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 3: {
                        Gpu.access$102(gpu, jsonObjectReader.nextIntegerOrNull());
                        continue block22;
                    }
                    case 2: {
                        Gpu.access$602(gpu, jsonObjectReader.nextBooleanOrNull());
                        continue block22;
                    }
                    case 1: {
                        Gpu.access$202(gpu, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 0: 
                }
                Gpu.access$802(gpu, jsonObjectReader.nextStringOrNull());
            }
            gpu.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return gpu;
        }
    }

    public static final class JsonKeys {
        public static final String API_TYPE = "api_type";
        public static final String ID = "id";
        public static final String MEMORY_SIZE = "memory_size";
        public static final String MULTI_THREADED_RENDERING = "multi_threaded_rendering";
        public static final String NAME = "name";
        public static final String NPOT_SUPPORT = "npot_support";
        public static final String VENDOR_ID = "vendor_id";
        public static final String VENDOR_NAME = "vendor_name";
        public static final String VERSION = "version";
    }
}

