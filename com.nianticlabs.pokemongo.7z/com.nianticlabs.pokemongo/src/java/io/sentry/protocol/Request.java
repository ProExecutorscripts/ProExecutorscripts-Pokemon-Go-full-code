/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Request
implements JsonUnknown,
JsonSerializable {
    private String apiTarget;
    private Long bodySize;
    private String cookies;
    private Object data;
    private Map<String, String> env;
    private String fragment;
    private Map<String, String> headers;
    private String method;
    private Map<String, String> other;
    private String queryString;
    private Map<String, Object> unknown;
    private String url;

    public Request() {
    }

    public Request(Request request) {
        this.url = request.url;
        this.cookies = request.cookies;
        this.method = request.method;
        this.queryString = request.queryString;
        this.headers = CollectionUtils.newConcurrentHashMap(request.headers);
        this.env = CollectionUtils.newConcurrentHashMap(request.env);
        this.other = CollectionUtils.newConcurrentHashMap(request.other);
        this.unknown = CollectionUtils.newConcurrentHashMap(request.unknown);
        this.data = request.data;
        this.fragment = request.fragment;
        this.bodySize = request.bodySize;
        this.apiTarget = request.apiTarget;
    }

    static /* synthetic */ String access$002(Request request, String string2) {
        request.url = string2;
        return string2;
    }

    static /* synthetic */ String access$1002(Request request, String string2) {
        request.apiTarget = string2;
        return string2;
    }

    static /* synthetic */ String access$102(Request request, String string2) {
        request.method = string2;
        return string2;
    }

    static /* synthetic */ String access$202(Request request, String string2) {
        request.queryString = string2;
        return string2;
    }

    static /* synthetic */ Object access$302(Request request, Object object) {
        request.data = object;
        return object;
    }

    static /* synthetic */ String access$402(Request request, String string2) {
        request.cookies = string2;
        return string2;
    }

    static /* synthetic */ Map access$502(Request request, Map map2) {
        request.headers = map2;
        return map2;
    }

    static /* synthetic */ Map access$602(Request request, Map map2) {
        request.env = map2;
        return map2;
    }

    static /* synthetic */ Map access$702(Request request, Map map2) {
        request.other = map2;
        return map2;
    }

    static /* synthetic */ String access$802(Request request, String string2) {
        request.fragment = string2;
        return string2;
    }

    static /* synthetic */ Long access$902(Request request, Long l2) {
        request.bodySize = l2;
        return l2;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (Request)object;
            if (!(Objects.equals(this.url, ((Request)object).url) && Objects.equals(this.method, ((Request)object).method) && Objects.equals(this.queryString, ((Request)object).queryString) && Objects.equals(this.cookies, ((Request)object).cookies) && Objects.equals(this.headers, ((Request)object).headers) && Objects.equals(this.env, ((Request)object).env) && Objects.equals(this.bodySize, ((Request)object).bodySize) && Objects.equals(this.fragment, ((Request)object).fragment) && Objects.equals(this.apiTarget, ((Request)object).apiTarget))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getApiTarget() {
        return this.apiTarget;
    }

    public Long getBodySize() {
        return this.bodySize;
    }

    public String getCookies() {
        return this.cookies;
    }

    public Object getData() {
        return this.data;
    }

    public Map<String, String> getEnvs() {
        return this.env;
    }

    public String getFragment() {
        return this.fragment;
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    public String getMethod() {
        return this.method;
    }

    public Map<String, String> getOthers() {
        return this.other;
    }

    public String getQueryString() {
        return this.queryString;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getUrl() {
        return this.url;
    }

    public int hashCode() {
        return Objects.hash(this.url, this.method, this.queryString, this.cookies, this.headers, this.env, this.bodySize, this.fragment, this.apiTarget);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        if (this.url != null) {
            objectWriter.name("url").value(this.url);
        }
        if (this.method != null) {
            objectWriter.name("method").value(this.method);
        }
        if (this.queryString != null) {
            objectWriter.name("query_string").value(this.queryString);
        }
        if (this.data != null) {
            objectWriter.name("data").value(iLogger, this.data);
        }
        if (this.cookies != null) {
            objectWriter.name("cookies").value(this.cookies);
        }
        if (this.headers != null) {
            objectWriter.name("headers").value(iLogger, this.headers);
        }
        if (this.env != null) {
            objectWriter.name("env").value(iLogger, this.env);
        }
        if (this.other != null) {
            objectWriter.name("other").value(iLogger, this.other);
        }
        if (this.fragment != null) {
            objectWriter.name("fragment").value(iLogger, this.fragment);
        }
        if (this.bodySize != null) {
            objectWriter.name("body_size").value(iLogger, this.bodySize);
        }
        if (this.apiTarget != null) {
            objectWriter.name("api_target").value(iLogger, this.apiTarget);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setApiTarget(String string2) {
        this.apiTarget = string2;
    }

    public void setBodySize(Long l2) {
        this.bodySize = l2;
    }

    public void setCookies(String string2) {
        this.cookies = string2;
    }

    public void setData(Object object) {
        this.data = object;
    }

    public void setEnvs(Map<String, String> map2) {
        this.env = CollectionUtils.newConcurrentHashMap(map2);
    }

    public void setFragment(String string2) {
        this.fragment = string2;
    }

    public void setHeaders(Map<String, String> map2) {
        this.headers = CollectionUtils.newConcurrentHashMap(map2);
    }

    public void setMethod(String string2) {
        this.method = string2;
    }

    public void setOthers(Map<String, String> map2) {
        this.other = CollectionUtils.newConcurrentHashMap(map2);
    }

    public void setQueryString(String string2) {
        this.queryString = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setUrl(String string2) {
        this.url = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Request> {
        @Override
        public Request deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Request request = new Request();
            Map map2 = null;
            block26: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1980646230: {
                        if (!string2.equals((Object)"api_target")) break;
                        n3 = 10;
                        break;
                    }
                    case 1595298664: {
                        if (!string2.equals((Object)"query_string")) break;
                        n3 = 9;
                        break;
                    }
                    case 1252988030: {
                        if (!string2.equals((Object)"body_size")) break;
                        n3 = 8;
                        break;
                    }
                    case 952189583: {
                        if (!string2.equals((Object)"cookies")) break;
                        n3 = 7;
                        break;
                    }
                    case 795307910: {
                        if (!string2.equals((Object)"headers")) break;
                        n3 = 6;
                        break;
                    }
                    case 106069776: {
                        if (!string2.equals((Object)"other")) break;
                        n3 = 5;
                        break;
                    }
                    case 3076010: {
                        if (!string2.equals((Object)"data")) break;
                        n3 = 4;
                        break;
                    }
                    case 116079: {
                        if (!string2.equals((Object)"url")) break;
                        n3 = 3;
                        break;
                    }
                    case 100589: {
                        if (!string2.equals((Object)"env")) break;
                        n3 = 2;
                        break;
                    }
                    case -1077554975: {
                        if (!string2.equals((Object)"method")) break;
                        n3 = 1;
                        break;
                    }
                    case -1650269616: {
                        if (!string2.equals((Object)"fragment")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Map map3 = map2;
                        if (map2 == null) {
                            map3 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)map3, string2);
                        map2 = map3;
                        continue block26;
                    }
                    case 10: {
                        Request.access$1002(request, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 9: {
                        Request.access$202(request, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 8: {
                        Request.access$902(request, jsonObjectReader.nextLongOrNull());
                        continue block26;
                    }
                    case 7: {
                        Request.access$402(request, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 6: {
                        Map map3 = (Map)jsonObjectReader.nextObjectOrNull();
                        if (map3 == null) continue block26;
                        Request.access$502(request, CollectionUtils.newConcurrentHashMap(map3));
                        continue block26;
                    }
                    case 5: {
                        Map map3 = (Map)jsonObjectReader.nextObjectOrNull();
                        if (map3 == null) continue block26;
                        Request.access$702(request, CollectionUtils.newConcurrentHashMap(map3));
                        continue block26;
                    }
                    case 4: {
                        Request.access$302(request, jsonObjectReader.nextObjectOrNull());
                        continue block26;
                    }
                    case 3: {
                        Request.access$002(request, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 2: {
                        Map map3 = (Map)jsonObjectReader.nextObjectOrNull();
                        if (map3 == null) continue block26;
                        Request.access$602(request, CollectionUtils.newConcurrentHashMap(map3));
                        continue block26;
                    }
                    case 1: {
                        Request.access$102(request, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 0: 
                }
                Request.access$802(request, jsonObjectReader.nextStringOrNull());
            }
            request.setUnknown(map2);
            jsonObjectReader.endObject();
            return request;
        }
    }

    public static final class JsonKeys {
        public static final String API_TARGET = "api_target";
        public static final String BODY_SIZE = "body_size";
        public static final String COOKIES = "cookies";
        public static final String DATA = "data";
        public static final String ENV = "env";
        public static final String FRAGMENT = "fragment";
        public static final String HEADERS = "headers";
        public static final String METHOD = "method";
        public static final String OTHER = "other";
        public static final String QUERY_STRING = "query_string";
        public static final String URL = "url";
    }
}

