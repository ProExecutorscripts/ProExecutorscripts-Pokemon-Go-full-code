/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class OperatingSystem
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "os";
    private String build;
    private String kernelVersion;
    private String name;
    private String rawDescription;
    private Boolean rooted;
    private Map<String, Object> unknown;
    private String version;

    public OperatingSystem() {
    }

    OperatingSystem(OperatingSystem operatingSystem) {
        this.name = operatingSystem.name;
        this.version = operatingSystem.version;
        this.rawDescription = operatingSystem.rawDescription;
        this.build = operatingSystem.build;
        this.kernelVersion = operatingSystem.kernelVersion;
        this.rooted = operatingSystem.rooted;
        this.unknown = CollectionUtils.newConcurrentHashMap(operatingSystem.unknown);
    }

    static /* synthetic */ String access$002(OperatingSystem operatingSystem, String string2) {
        operatingSystem.name = string2;
        return string2;
    }

    static /* synthetic */ String access$102(OperatingSystem operatingSystem, String string2) {
        operatingSystem.version = string2;
        return string2;
    }

    static /* synthetic */ String access$202(OperatingSystem operatingSystem, String string2) {
        operatingSystem.rawDescription = string2;
        return string2;
    }

    static /* synthetic */ String access$302(OperatingSystem operatingSystem, String string2) {
        operatingSystem.build = string2;
        return string2;
    }

    static /* synthetic */ String access$402(OperatingSystem operatingSystem, String string2) {
        operatingSystem.kernelVersion = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$502(OperatingSystem operatingSystem, Boolean bl) {
        operatingSystem.rooted = bl;
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (OperatingSystem)object;
            if (!(Objects.equals(this.name, ((OperatingSystem)object).name) && Objects.equals(this.version, ((OperatingSystem)object).version) && Objects.equals(this.rawDescription, ((OperatingSystem)object).rawDescription) && Objects.equals(this.build, ((OperatingSystem)object).build) && Objects.equals(this.kernelVersion, ((OperatingSystem)object).kernelVersion) && Objects.equals(this.rooted, ((OperatingSystem)object).rooted))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String getBuild() {
        return this.build;
    }

    public String getKernelVersion() {
        return this.kernelVersion;
    }

    public String getName() {
        return this.name;
    }

    public String getRawDescription() {
        return this.rawDescription;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVersion() {
        return this.version;
    }

    public int hashCode() {
        return Objects.hash(this.name, this.version, this.rawDescription, this.build, this.kernelVersion, this.rooted);
    }

    public Boolean isRooted() {
        return this.rooted;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.version != null) {
            objectWriter.name("version").value(this.version);
        }
        if (this.rawDescription != null) {
            objectWriter.name("raw_description").value(this.rawDescription);
        }
        if (this.build != null) {
            objectWriter.name("build").value(this.build);
        }
        if (this.kernelVersion != null) {
            objectWriter.name("kernel_version").value(this.kernelVersion);
        }
        if (this.rooted != null) {
            objectWriter.name("rooted").value(this.rooted);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setBuild(String string2) {
        this.build = string2;
    }

    public void setKernelVersion(String string2) {
        this.kernelVersion = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setRawDescription(String string2) {
        this.rawDescription = string2;
    }

    public void setRooted(Boolean bl) {
        this.rooted = bl;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVersion(String string2) {
        this.version = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<OperatingSystem> {
        @Override
        public OperatingSystem deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            OperatingSystem operatingSystem = new OperatingSystem();
            ConcurrentHashMap concurrentHashMap = null;
            block16: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2015527638: {
                        if (!string2.equals((Object)"kernel_version")) break;
                        n3 = 5;
                        break;
                    }
                    case 351608024: {
                        if (!string2.equals((Object)"version")) break;
                        n3 = 4;
                        break;
                    }
                    case 94094958: {
                        if (!string2.equals((Object)"build")) break;
                        n3 = 3;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 2;
                        break;
                    }
                    case -339173787: {
                        if (!string2.equals((Object)"raw_description")) break;
                        n3 = 1;
                        break;
                    }
                    case -925311743: {
                        if (!string2.equals((Object)"rooted")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block16;
                    }
                    case 5: {
                        OperatingSystem.access$402(operatingSystem, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 4: {
                        OperatingSystem.access$102(operatingSystem, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 3: {
                        OperatingSystem.access$302(operatingSystem, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 2: {
                        OperatingSystem.access$002(operatingSystem, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 1: {
                        OperatingSystem.access$202(operatingSystem, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 0: 
                }
                OperatingSystem.access$502(operatingSystem, jsonObjectReader.nextBooleanOrNull());
            }
            operatingSystem.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return operatingSystem;
        }
    }

    public static final class JsonKeys {
        public static final String BUILD = "build";
        public static final String KERNEL_VERSION = "kernel_version";
        public static final String NAME = "name";
        public static final String RAW_DESCRIPTION = "raw_description";
        public static final String ROOTED = "rooted";
        public static final String VERSION = "version";
    }
}

