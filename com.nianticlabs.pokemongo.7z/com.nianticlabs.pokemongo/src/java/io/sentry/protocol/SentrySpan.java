/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.math.BigDecimal
 *  java.math.RoundingMode
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.Span;
import io.sentry.SpanId;
import io.sentry.SpanStatus;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.MetricSummary;
import io.sentry.protocol.SentryId;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentrySpan
implements JsonUnknown,
JsonSerializable {
    private final Map<String, Object> data;
    private final String description;
    private final Map<String, MeasurementValue> measurements;
    private final Map<String, List<MetricSummary>> metricsSummaries;
    private final String op;
    private final String origin;
    private final SpanId parentSpanId;
    private final SpanId spanId;
    private final Double startTimestamp;
    private final SpanStatus status;
    private final Map<String, String> tags;
    private final Double timestamp;
    private final SentryId traceId;
    private Map<String, Object> unknown;

    public SentrySpan(Span span) {
        this(span, span.getData());
    }

    public SentrySpan(Span object, Map<String, Object> map2) {
        Objects.requireNonNull(object, "span is required");
        this.description = ((Span)object).getDescription();
        this.op = ((Span)object).getOperation();
        this.spanId = ((Span)object).getSpanId();
        this.parentSpanId = ((Span)object).getParentSpanId();
        this.traceId = ((Span)object).getTraceId();
        this.status = ((Span)object).getStatus();
        this.origin = ((Span)object).getSpanContext().getOrigin();
        Object object2 = CollectionUtils.newConcurrentHashMap(((Span)object).getTags());
        if (object2 == null) {
            object2 = new ConcurrentHashMap();
        }
        this.tags = object2;
        object2 = CollectionUtils.newConcurrentHashMap(((Span)object).getMeasurements());
        if (object2 == null) {
            object2 = new ConcurrentHashMap();
        }
        this.measurements = object2;
        object2 = ((Span)object).getFinishDate() == null ? null : Double.valueOf((double)DateUtils.nanosToSeconds(((Span)object).getStartDate().laterDateNanosTimestampByDiff(((Span)object).getFinishDate())));
        this.timestamp = object2;
        this.startTimestamp = DateUtils.nanosToSeconds(((Span)object).getStartDate().nanoTimestamp());
        this.data = map2;
        object = ((Span)object).getLocalMetricsAggregator();
        this.metricsSummaries = object != null ? ((LocalMetricsAggregator)object).getSummaries() : null;
    }

    public SentrySpan(Double d2, Double d3, SentryId sentryId, SpanId spanId, SpanId spanId2, String string2, String string3, SpanStatus spanStatus, String string4, Map<String, String> map2, Map<String, MeasurementValue> map3, Map<String, List<MetricSummary>> map4, Map<String, Object> map5) {
        this.startTimestamp = d2;
        this.timestamp = d3;
        this.traceId = sentryId;
        this.spanId = spanId;
        this.parentSpanId = spanId2;
        this.op = string2;
        this.description = string3;
        this.status = spanStatus;
        this.origin = string4;
        this.tags = map2;
        this.measurements = map3;
        this.metricsSummaries = map4;
        this.data = map5;
    }

    private BigDecimal doubleToBigDecimal(Double d2) {
        return BigDecimal.valueOf((double)d2).setScale(6, RoundingMode.DOWN);
    }

    public Map<String, Object> getData() {
        return this.data;
    }

    public String getDescription() {
        return this.description;
    }

    public Map<String, MeasurementValue> getMeasurements() {
        return this.measurements;
    }

    public Map<String, List<MetricSummary>> getMetricsSummaries() {
        return this.metricsSummaries;
    }

    public String getOp() {
        return this.op;
    }

    public String getOrigin() {
        return this.origin;
    }

    public SpanId getParentSpanId() {
        return this.parentSpanId;
    }

    public SpanId getSpanId() {
        return this.spanId;
    }

    public Double getStartTimestamp() {
        return this.startTimestamp;
    }

    public SpanStatus getStatus() {
        return this.status;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public Double getTimestamp() {
        return this.timestamp;
    }

    public SentryId getTraceId() {
        return this.traceId;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public boolean isFinished() {
        boolean bl = this.timestamp != null;
        return bl;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        objectWriter.name("start_timestamp").value(iLogger, this.doubleToBigDecimal(this.startTimestamp));
        if (this.timestamp != null) {
            objectWriter.name("timestamp").value(iLogger, this.doubleToBigDecimal(this.timestamp));
        }
        objectWriter.name("trace_id").value(iLogger, this.traceId);
        objectWriter.name("span_id").value(iLogger, this.spanId);
        if (this.parentSpanId != null) {
            objectWriter.name("parent_span_id").value(iLogger, this.parentSpanId);
        }
        objectWriter.name("op").value(this.op);
        if (this.description != null) {
            objectWriter.name("description").value(this.description);
        }
        if (this.status != null) {
            objectWriter.name("status").value(iLogger, this.status);
        }
        if (this.origin != null) {
            objectWriter.name("origin").value(iLogger, this.origin);
        }
        if (!this.tags.isEmpty()) {
            objectWriter.name("tags").value(iLogger, this.tags);
        }
        if (this.data != null) {
            objectWriter.name("data").value(iLogger, this.data);
        }
        if (!this.measurements.isEmpty()) {
            objectWriter.name("measurements").value(iLogger, this.measurements);
        }
        if ((object2 = this.metricsSummaries) != null && !object2.isEmpty()) {
            objectWriter.name("_metrics_summary").value(iLogger, this.metricsSummaries);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentrySpan> {
        private Exception missingRequiredFieldException(String object, ILogger iLogger) {
            String string2 = "Missing required field \"" + object + "\"";
            object = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, (Throwable)object);
            return object;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        @Override
        public SentrySpan deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
            jsonObjectReader.beginObject();
            Map map2 = null;
            Double d2 = null;
            Double d3 = null;
            SentryId sentryId = null;
            Object object2 = null;
            SpanId spanId = null;
            Object object3 = null;
            Object object4 = null;
            Object object5 = null;
            Object object6 = null;
            Map<String, MeasurementValue> map3 = null;
            String string2 = null;
            Map<String, List<MetricSummary>> map4 = null;
            Map map5 = null;
            while (jsonObjectReader.peek() == JsonToken.NAME) {
                Object object7;
                Object object8;
                block46: {
                    block45: {
                        block43: {
                            block44: {
                                object8 = jsonObjectReader.nextName();
                                object8.hashCode();
                                int n2 = object8.hashCode();
                                int n3 = -1;
                                switch (n2) {
                                    default: {
                                        break;
                                    }
                                    case 1270300245: {
                                        if (!object8.equals((Object)"trace_id")) break;
                                        n3 = 12;
                                        break;
                                    }
                                    case 55126294: {
                                        if (!object8.equals((Object)"timestamp")) break;
                                        n3 = 11;
                                        break;
                                    }
                                    case 3552281: {
                                        if (!object8.equals((Object)"tags")) break;
                                        n3 = 10;
                                        break;
                                    }
                                    case 3076010: {
                                        if (!object8.equals((Object)"data")) break;
                                        n3 = 9;
                                        break;
                                    }
                                    case 3553: {
                                        if (!object8.equals((Object)"op")) break;
                                        n3 = 8;
                                        break;
                                    }
                                    case -362243017: {
                                        if (!object8.equals((Object)"measurements")) break;
                                        n3 = 7;
                                        break;
                                    }
                                    case -682561045: {
                                        if (!object8.equals((Object)"_metrics_summary")) break;
                                        n3 = 6;
                                        break;
                                    }
                                    case -892481550: {
                                        if (!object8.equals((Object)"status")) break;
                                        n3 = 5;
                                        break;
                                    }
                                    case -1008619738: {
                                        if (!object8.equals((Object)"origin")) break;
                                        n3 = 4;
                                        break;
                                    }
                                    case -1526966919: {
                                        if (!object8.equals((Object)"start_timestamp")) break;
                                        n3 = 3;
                                        break;
                                    }
                                    case -1724546052: {
                                        if (!object8.equals((Object)"description")) break;
                                        n3 = 2;
                                        break;
                                    }
                                    case -1757797477: {
                                        if (!object8.equals((Object)"parent_span_id")) break;
                                        n3 = 1;
                                        break;
                                    }
                                    case -2011840976: {
                                        if (!object8.equals((Object)"span_id")) break;
                                        n3 = 0;
                                    }
                                }
                                switch (n3) {
                                    default: {
                                        object7 = string2;
                                        if (string2 == null) {
                                            object7 = new ConcurrentHashMap();
                                        }
                                        jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)object7, (String)object8);
                                        string2 = object7;
                                        break;
                                    }
                                    case 12: {
                                        sentryId = new SentryId.Deserializer().deserialize(jsonObjectReader, (ILogger)object);
                                        break;
                                    }
                                    case 11: {
                                        try {
                                            d3 = jsonObjectReader.nextDoubleOrNull();
                                        }
                                        catch (NumberFormatException numberFormatException) {
                                            d3 = jsonObjectReader.nextDateOrNull((ILogger)object);
                                            if (d3 != null) {
                                                d3 = DateUtils.dateToSeconds((Date)d3);
                                                break;
                                            }
                                            d3 = null;
                                        }
                                        break;
                                    }
                                    case 10: {
                                        map2 = (Map)jsonObjectReader.nextObjectOrNull();
                                        break;
                                    }
                                    case 9: {
                                        map5 = (Map)jsonObjectReader.nextObjectOrNull();
                                        break;
                                    }
                                    case 8: {
                                        object3 = jsonObjectReader.nextStringOrNull();
                                        break;
                                    }
                                    case 7: {
                                        map3 = jsonObjectReader.nextMapOrNull((ILogger)object, new MeasurementValue.Deserializer());
                                        break;
                                    }
                                    case 6: {
                                        map4 = jsonObjectReader.nextMapOfListOrNull((ILogger)object, new MetricSummary.Deserializer());
                                        break;
                                    }
                                    case 5: {
                                        object5 = jsonObjectReader.nextOrNull((ILogger)object, new SpanStatus.Deserializer());
                                        object8 = object6;
                                        object6 = object2;
                                        object7 = object3;
                                        break block43;
                                    }
                                    case 4: {
                                        object8 = jsonObjectReader.nextStringOrNull();
                                        break block44;
                                    }
                                    case 3: {
                                        try {
                                            d2 = jsonObjectReader.nextDoubleOrNull();
                                        }
                                        catch (NumberFormatException numberFormatException) {
                                            d2 = jsonObjectReader.nextDateOrNull((ILogger)object);
                                            if (d2 != null) {
                                                d2 = DateUtils.dateToSeconds((Date)d2);
                                                break;
                                            }
                                            d2 = null;
                                        }
                                        break;
                                    }
                                    case 2: {
                                        String string3 = jsonObjectReader.nextStringOrNull();
                                        object7 = object6;
                                        object8 = object5;
                                        object6 = object2;
                                        object4 = object3;
                                        object5 = string3;
                                        object2 = object8;
                                        object3 = object7;
                                        break block45;
                                    }
                                    case 1: {
                                        spanId = jsonObjectReader.nextOrNull((ILogger)object, new SpanId.Deserializer());
                                        object7 = object6;
                                        object6 = object5;
                                        object5 = object4;
                                        object8 = object2;
                                        object4 = object3;
                                        break block46;
                                    }
                                    case 0: {
                                        object2 = new SpanId.Deserializer().deserialize(jsonObjectReader, (ILogger)object);
                                    }
                                }
                                object8 = object6;
                            }
                            object7 = object3;
                            object6 = object2;
                        }
                        object3 = object8;
                        object2 = object5;
                        object5 = object4;
                        object4 = object7;
                    }
                    object8 = object6;
                    object6 = object2;
                    object7 = object3;
                }
                object2 = object8;
                object3 = object4;
                object4 = object5;
                object5 = object6;
                object6 = object7;
            }
            if (d2 == null) {
                throw this.missingRequiredFieldException("start_timestamp", (ILogger)object);
            }
            if (sentryId == null) {
                throw this.missingRequiredFieldException("trace_id", (ILogger)object);
            }
            if (object2 == null) {
                throw this.missingRequiredFieldException("span_id", (ILogger)object);
            }
            if (object3 == null) {
                throw this.missingRequiredFieldException("op", (ILogger)object);
            }
            object = map2 == null ? new HashMap() : map2;
            if (map3 == null) {
                map3 = new Map<String, MeasurementValue>();
            }
            object = new SentrySpan(d2, d3, sentryId, (SpanId)object2, spanId, (String)object3, (String)object4, (SpanStatus)object5, (String)object6, (Map<String, String>)object, map3, map4, (Map<String, Object>)map5);
            ((SentrySpan)object).setUnknown((Map<String, Object>)string2);
            jsonObjectReader.endObject();
            return object;
        }
    }

    public static final class JsonKeys {
        public static final String DATA = "data";
        public static final String DESCRIPTION = "description";
        public static final String MEASUREMENTS = "measurements";
        public static final String METRICS_SUMMARY = "_metrics_summary";
        public static final String OP = "op";
        public static final String ORIGIN = "origin";
        public static final String PARENT_SPAN_ID = "parent_span_id";
        public static final String SPAN_ID = "span_id";
        public static final String START_TIMESTAMP = "start_timestamp";
        public static final String STATUS = "status";
        public static final String TAGS = "tags";
        public static final String TIMESTAMP = "timestamp";
        public static final String TRACE_ID = "trace_id";
    }
}

