/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryRuntime
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "runtime";
    private String name;
    private String rawDescription;
    private Map<String, Object> unknown;
    private String version;

    public SentryRuntime() {
    }

    SentryRuntime(SentryRuntime sentryRuntime) {
        this.name = sentryRuntime.name;
        this.version = sentryRuntime.version;
        this.rawDescription = sentryRuntime.rawDescription;
        this.unknown = CollectionUtils.newConcurrentHashMap(sentryRuntime.unknown);
    }

    static /* synthetic */ String access$002(SentryRuntime sentryRuntime, String string2) {
        sentryRuntime.name = string2;
        return string2;
    }

    static /* synthetic */ String access$102(SentryRuntime sentryRuntime, String string2) {
        sentryRuntime.version = string2;
        return string2;
    }

    static /* synthetic */ String access$202(SentryRuntime sentryRuntime, String string2) {
        sentryRuntime.rawDescription = string2;
        return string2;
    }

    public String getName() {
        return this.name;
    }

    public String getRawDescription() {
        return this.rawDescription;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVersion() {
        return this.version;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.version != null) {
            objectWriter.name("version").value(this.version);
        }
        if (this.rawDescription != null) {
            objectWriter.name("raw_description").value(this.rawDescription);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setRawDescription(String string2) {
        this.rawDescription = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVersion(String string2) {
        this.version = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryRuntime> {
        @Override
        public SentryRuntime deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            SentryRuntime sentryRuntime = new SentryRuntime();
            ConcurrentHashMap concurrentHashMap = null;
            block10: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 351608024: {
                        if (!string2.equals((Object)"version")) break;
                        n3 = 2;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 1;
                        break;
                    }
                    case -339173787: {
                        if (!string2.equals((Object)"raw_description")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block10;
                    }
                    case 2: {
                        SentryRuntime.access$102(sentryRuntime, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 1: {
                        SentryRuntime.access$002(sentryRuntime, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 0: 
                }
                SentryRuntime.access$202(sentryRuntime, jsonObjectReader.nextStringOrNull());
            }
            sentryRuntime.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return sentryRuntime;
        }
    }

    public static final class JsonKeys {
        public static final String NAME = "name";
        public static final String RAW_DESCRIPTION = "raw_description";
        public static final String VERSION = "version";
    }
}

