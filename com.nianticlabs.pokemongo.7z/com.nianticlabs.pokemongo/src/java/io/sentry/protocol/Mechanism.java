/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class Mechanism
implements JsonUnknown,
JsonSerializable {
    private Map<String, Object> data;
    private String description;
    private Boolean handled;
    private String helpLink;
    private Map<String, Object> meta;
    private Boolean synthetic;
    private final transient Thread thread;
    private String type;
    private Map<String, Object> unknown;

    public Mechanism() {
        this(null);
    }

    public Mechanism(Thread thread) {
        this.thread = thread;
    }

    static /* synthetic */ String access$002(Mechanism mechanism, String string2) {
        mechanism.type = string2;
        return string2;
    }

    static /* synthetic */ String access$102(Mechanism mechanism, String string2) {
        mechanism.description = string2;
        return string2;
    }

    static /* synthetic */ String access$202(Mechanism mechanism, String string2) {
        mechanism.helpLink = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$302(Mechanism mechanism, Boolean bl) {
        mechanism.handled = bl;
        return bl;
    }

    static /* synthetic */ Map access$402(Mechanism mechanism, Map map2) {
        mechanism.meta = map2;
        return map2;
    }

    static /* synthetic */ Map access$502(Mechanism mechanism, Map map2) {
        mechanism.data = map2;
        return map2;
    }

    static /* synthetic */ Boolean access$602(Mechanism mechanism, Boolean bl) {
        mechanism.synthetic = bl;
        return bl;
    }

    public Map<String, Object> getData() {
        return this.data;
    }

    public String getDescription() {
        return this.description;
    }

    public String getHelpLink() {
        return this.helpLink;
    }

    public Map<String, Object> getMeta() {
        return this.meta;
    }

    public Boolean getSynthetic() {
        return this.synthetic;
    }

    Thread getThread() {
        return this.thread;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Boolean isHandled() {
        return this.handled;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.type != null) {
            objectWriter.name("type").value(this.type);
        }
        if (this.description != null) {
            objectWriter.name("description").value(this.description);
        }
        if (this.helpLink != null) {
            objectWriter.name("help_link").value(this.helpLink);
        }
        if (this.handled != null) {
            objectWriter.name("handled").value(this.handled);
        }
        if (this.meta != null) {
            objectWriter.name("meta").value(iLogger, this.meta);
        }
        if (this.data != null) {
            objectWriter.name("data").value(iLogger, this.data);
        }
        if (this.synthetic != null) {
            objectWriter.name("synthetic").value(this.synthetic);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setData(Map<String, Object> map2) {
        this.data = CollectionUtils.newHashMap(map2);
    }

    public void setDescription(String string2) {
        this.description = string2;
    }

    public void setHandled(Boolean bl) {
        this.handled = bl;
    }

    public void setHelpLink(String string2) {
        this.helpLink = string2;
    }

    public void setMeta(Map<String, Object> map2) {
        this.meta = CollectionUtils.newHashMap(map2);
    }

    public void setSynthetic(Boolean bl) {
        this.synthetic = bl;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Mechanism> {
        @Override
        public Mechanism deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            Mechanism mechanism = new Mechanism();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            block18: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1297152568: {
                        if (!string2.equals((Object)"help_link")) break;
                        n3 = 6;
                        break;
                    }
                    case 989128517: {
                        if (!string2.equals((Object)"synthetic")) break;
                        n3 = 5;
                        break;
                    }
                    case 692803388: {
                        if (!string2.equals((Object)"handled")) break;
                        n3 = 4;
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 3;
                        break;
                    }
                    case 3347973: {
                        if (!string2.equals((Object)"meta")) break;
                        n3 = 2;
                        break;
                    }
                    case 3076010: {
                        if (!string2.equals((Object)"data")) break;
                        n3 = 1;
                        break;
                    }
                    case -1724546052: {
                        if (!string2.equals((Object)"description")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue block18;
                    }
                    case 6: {
                        Mechanism.access$202(mechanism, jsonObjectReader.nextStringOrNull());
                        continue block18;
                    }
                    case 5: {
                        Mechanism.access$602(mechanism, jsonObjectReader.nextBooleanOrNull());
                        continue block18;
                    }
                    case 4: {
                        Mechanism.access$302(mechanism, jsonObjectReader.nextBooleanOrNull());
                        continue block18;
                    }
                    case 3: {
                        Mechanism.access$002(mechanism, jsonObjectReader.nextStringOrNull());
                        continue block18;
                    }
                    case 2: {
                        Mechanism.access$402(mechanism, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block18;
                    }
                    case 1: {
                        Mechanism.access$502(mechanism, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block18;
                    }
                    case 0: 
                }
                Mechanism.access$102(mechanism, jsonObjectReader.nextStringOrNull());
            }
            jsonObjectReader.endObject();
            mechanism.setUnknown((Map<String, Object>)hashMap);
            return mechanism;
        }
    }

    public static final class JsonKeys {
        public static final String DATA = "data";
        public static final String DESCRIPTION = "description";
        public static final String HANDLED = "handled";
        public static final String HELP_LINK = "help_link";
        public static final String META = "meta";
        public static final String SYNTHETIC = "synthetic";
        public static final String TYPE = "type";
    }
}

