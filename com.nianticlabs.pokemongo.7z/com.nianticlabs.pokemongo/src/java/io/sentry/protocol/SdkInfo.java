/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class SdkInfo
implements JsonUnknown,
JsonSerializable {
    private String sdkName;
    private Map<String, Object> unknown;
    private Integer versionMajor;
    private Integer versionMinor;
    private Integer versionPatchlevel;

    static /* synthetic */ String access$002(SdkInfo sdkInfo, String string2) {
        sdkInfo.sdkName = string2;
        return string2;
    }

    static /* synthetic */ Integer access$102(SdkInfo sdkInfo, Integer n2) {
        sdkInfo.versionMajor = n2;
        return n2;
    }

    static /* synthetic */ Integer access$202(SdkInfo sdkInfo, Integer n2) {
        sdkInfo.versionMinor = n2;
        return n2;
    }

    static /* synthetic */ Integer access$302(SdkInfo sdkInfo, Integer n2) {
        sdkInfo.versionPatchlevel = n2;
        return n2;
    }

    public String getSdkName() {
        return this.sdkName;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Integer getVersionMajor() {
        return this.versionMajor;
    }

    public Integer getVersionMinor() {
        return this.versionMinor;
    }

    public Integer getVersionPatchlevel() {
        return this.versionPatchlevel;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.sdkName != null) {
            objectWriter.name("sdk_name").value(this.sdkName);
        }
        if (this.versionMajor != null) {
            objectWriter.name("version_major").value((Number)this.versionMajor);
        }
        if (this.versionMinor != null) {
            objectWriter.name("version_minor").value((Number)this.versionMinor);
        }
        if (this.versionPatchlevel != null) {
            objectWriter.name("version_patchlevel").value((Number)this.versionPatchlevel);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setSdkName(String string2) {
        this.sdkName = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVersionMajor(Integer n2) {
        this.versionMajor = n2;
    }

    public void setVersionMinor(Integer n2) {
        this.versionMinor = n2;
    }

    public void setVersionPatchlevel(Integer n2) {
        this.versionPatchlevel = n2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SdkInfo> {
        @Override
        public SdkInfo deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SdkInfo sdkInfo = new SdkInfo();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            block12: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1111483790: {
                        if (!string2.equals((Object)"version_minor")) break;
                        n3 = 3;
                        break;
                    }
                    case 1111241618: {
                        if (!string2.equals((Object)"version_major")) break;
                        n3 = 2;
                        break;
                    }
                    case 696101379: {
                        if (!string2.equals((Object)"version_patchlevel")) break;
                        n3 = 1;
                        break;
                    }
                    case 270207856: {
                        if (!string2.equals((Object)"sdk_name")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue block12;
                    }
                    case 3: {
                        SdkInfo.access$202(sdkInfo, jsonObjectReader.nextIntegerOrNull());
                        continue block12;
                    }
                    case 2: {
                        SdkInfo.access$102(sdkInfo, jsonObjectReader.nextIntegerOrNull());
                        continue block12;
                    }
                    case 1: {
                        SdkInfo.access$302(sdkInfo, jsonObjectReader.nextIntegerOrNull());
                        continue block12;
                    }
                    case 0: 
                }
                SdkInfo.access$002(sdkInfo, jsonObjectReader.nextStringOrNull());
            }
            jsonObjectReader.endObject();
            sdkInfo.setUnknown((Map<String, Object>)hashMap);
            return sdkInfo;
        }
    }

    public static final class JsonKeys {
        public static final String SDK_NAME = "sdk_name";
        public static final String VERSION_MAJOR = "version_major";
        public static final String VERSION_MINOR = "version_minor";
        public static final String VERSION_PATCHLEVEL = "version_patchlevel";
    }
}

