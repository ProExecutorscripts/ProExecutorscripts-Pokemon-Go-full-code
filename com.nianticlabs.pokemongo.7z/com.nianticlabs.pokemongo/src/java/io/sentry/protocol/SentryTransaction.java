/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.math.BigDecimal
 *  java.math.RoundingMode
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryTracer;
import io.sentry.Span;
import io.sentry.SpanContext;
import io.sentry.SpanStatus;
import io.sentry.TracesSamplingDecision;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.MetricSummary;
import io.sentry.protocol.SentrySpan;
import io.sentry.protocol.TransactionInfo;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryTransaction
extends SentryBaseEvent
implements JsonUnknown,
JsonSerializable {
    private final Map<String, MeasurementValue> measurements;
    private Map<String, List<MetricSummary>> metricSummaries;
    private final List<SentrySpan> spans;
    private Double startTimestamp;
    private Double timestamp;
    private String transaction;
    private TransactionInfo transactionInfo;
    private final String type;
    private Map<String, Object> unknown;

    public SentryTransaction(SentryTracer object) {
        super(((SentryTracer)object).getEventId());
        Object object22;
        this.spans = new ArrayList();
        this.type = "transaction";
        this.measurements = new HashMap();
        Objects.requireNonNull(object, "sentryTracer is required");
        this.startTimestamp = DateUtils.nanosToSeconds(((SentryTracer)object).getStartDate().nanoTimestamp());
        this.timestamp = DateUtils.nanosToSeconds(((SentryTracer)object).getStartDate().laterDateNanosTimestampByDiff(((SentryTracer)object).getFinishDate()));
        this.transaction = ((SentryTracer)object).getName();
        for (Object object22 : ((SentryTracer)object).getChildren()) {
            if (!Boolean.TRUE.equals((Object)((Span)object22).isSampled())) continue;
            this.spans.add((Object)new SentrySpan((Span)object22));
        }
        object22 = this.getContexts();
        object22.putAll((Map)((SentryTracer)object).getContexts());
        Object object32 = ((SentryTracer)object).getSpanContext();
        ((Contexts)object22).setTrace(new SpanContext(((SpanContext)object32).getTraceId(), ((SpanContext)object32).getSpanId(), ((SpanContext)object32).getParentSpanId(), ((SpanContext)object32).getOperation(), ((SpanContext)object32).getDescription(), ((SpanContext)object32).getSamplingDecision(), ((SpanContext)object32).getStatus(), ((SpanContext)object32).getOrigin()));
        for (Object object32 : ((SpanContext)object32).getTags().entrySet()) {
            this.setTag((String)object32.getKey(), (String)object32.getValue());
        }
        object32 = ((SentryTracer)object).getData();
        if (object32 != null) {
            for (Object object22 : object32.entrySet()) {
                this.setExtra((String)object22.getKey(), object22.getValue());
            }
        }
        this.transactionInfo = new TransactionInfo(((SentryTracer)object).getTransactionNameSource().apiName());
        this.metricSummaries = (object = ((SentryTracer)object).getLocalMetricsAggregator()) != null ? ((LocalMetricsAggregator)object).getSummaries() : null;
    }

    public SentryTransaction(String string2, Double object2, Double d2, List<SentrySpan> list, Map<String, MeasurementValue> map2, Map<String, List<MetricSummary>> map3, TransactionInfo transactionInfo) {
        HashMap hashMap;
        ArrayList arrayList;
        this.spans = arrayList = new ArrayList();
        this.type = "transaction";
        this.measurements = hashMap = new HashMap();
        this.transaction = string2;
        this.startTimestamp = object2;
        this.timestamp = d2;
        arrayList.addAll(list);
        hashMap.putAll(map2);
        for (Object object2 : list) {
            this.measurements.putAll(((SentrySpan)object2).getMeasurements());
        }
        this.transactionInfo = transactionInfo;
        this.metricSummaries = map3;
    }

    static /* synthetic */ String access$002(SentryTransaction sentryTransaction, String string2) {
        sentryTransaction.transaction = string2;
        return string2;
    }

    static /* synthetic */ Double access$102(SentryTransaction sentryTransaction, Double d2) {
        sentryTransaction.startTimestamp = d2;
        return d2;
    }

    static /* synthetic */ Double access$202(SentryTransaction sentryTransaction, Double d2) {
        sentryTransaction.timestamp = d2;
        return d2;
    }

    static /* synthetic */ Map access$502(SentryTransaction sentryTransaction, Map map2) {
        sentryTransaction.metricSummaries = map2;
        return map2;
    }

    static /* synthetic */ TransactionInfo access$602(SentryTransaction sentryTransaction, TransactionInfo transactionInfo) {
        sentryTransaction.transactionInfo = transactionInfo;
        return transactionInfo;
    }

    private BigDecimal doubleToBigDecimal(Double d2) {
        return BigDecimal.valueOf((double)d2).setScale(6, RoundingMode.DOWN);
    }

    public Map<String, MeasurementValue> getMeasurements() {
        return this.measurements;
    }

    public Map<String, List<MetricSummary>> getMetricSummaries() {
        return this.metricSummaries;
    }

    public TracesSamplingDecision getSamplingDecision() {
        SpanContext spanContext = this.getContexts().getTrace();
        if (spanContext == null) {
            return null;
        }
        return spanContext.getSamplingDecision();
    }

    public List<SentrySpan> getSpans() {
        return this.spans;
    }

    public Double getStartTimestamp() {
        return this.startTimestamp;
    }

    public SpanStatus getStatus() {
        JsonSerializable jsonSerializable = this.getContexts().getTrace();
        jsonSerializable = jsonSerializable != null ? jsonSerializable.getStatus() : null;
        return jsonSerializable;
    }

    public Double getTimestamp() {
        return this.timestamp;
    }

    public String getTransaction() {
        return this.transaction;
    }

    public String getType() {
        return "transaction";
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public boolean isFinished() {
        boolean bl = this.timestamp != null;
        return bl;
    }

    public boolean isSampled() {
        TracesSamplingDecision tracesSamplingDecision = this.getSamplingDecision();
        if (tracesSamplingDecision == null) {
            return false;
        }
        return tracesSamplingDecision.getSampled();
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.transaction != null) {
            objectWriter.name("transaction").value(this.transaction);
        }
        objectWriter.name("start_timestamp").value(iLogger, this.doubleToBigDecimal(this.startTimestamp));
        if (this.timestamp != null) {
            objectWriter.name("timestamp").value(iLogger, this.doubleToBigDecimal(this.timestamp));
        }
        if (!this.spans.isEmpty()) {
            objectWriter.name("spans").value(iLogger, this.spans);
        }
        objectWriter.name("type").value("transaction");
        if (!this.measurements.isEmpty()) {
            objectWriter.name("measurements").value(iLogger, this.measurements);
        }
        if ((object2 = this.metricSummaries) != null && !object2.isEmpty()) {
            objectWriter.name("_metrics_summary").value(iLogger, this.metricSummaries);
        }
        objectWriter.name("transaction_info").value(iLogger, this.transactionInfo);
        new SentryBaseEvent.Serializer().serialize(this, objectWriter, iLogger);
        object2 = this.unknown;
        if (object2 != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setMetricSummaries(Map<String, List<MetricSummary>> map2) {
        this.metricSummaries = map2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryTransaction> {
        @Override
        public SentryTransaction deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            SentryTransaction sentryTransaction = new SentryTransaction("", 0.0, null, (List<SentrySpan>)new ArrayList(), (Map<String, MeasurementValue>)new HashMap(), null, new TransactionInfo(TransactionNameSource.CUSTOM.apiName()));
            SentryBaseEvent.Deserializer deserializer = new SentryBaseEvent.Deserializer();
            Date date = null;
            block26: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Date date2;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2141246174: {
                        if (!string2.equals((Object)"transaction")) break;
                        n3 = 7;
                        break;
                    }
                    case 508716399: {
                        if (!string2.equals((Object)"transaction_info")) break;
                        n3 = 6;
                        break;
                    }
                    case 109638249: {
                        if (!string2.equals((Object)"spans")) break;
                        n3 = 5;
                        break;
                    }
                    case 55126294: {
                        if (!string2.equals((Object)"timestamp")) break;
                        n3 = 4;
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 3;
                        break;
                    }
                    case -362243017: {
                        if (!string2.equals((Object)"measurements")) break;
                        n3 = 2;
                        break;
                    }
                    case -682561045: {
                        if (!string2.equals((Object)"_metrics_summary")) break;
                        n3 = 1;
                        break;
                    }
                    case -1526966919: {
                        if (!string2.equals((Object)"start_timestamp")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        if (deserializer.deserializeValue(sentryTransaction, string2, jsonObjectReader, iLogger)) continue block26;
                        date2 = date;
                        if (date == null) {
                            date2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)date2, string2);
                        date = date2;
                        continue block26;
                    }
                    case 7: {
                        SentryTransaction.access$002(sentryTransaction, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 6: {
                        SentryTransaction.access$602(sentryTransaction, new TransactionInfo.Deserializer().deserialize(jsonObjectReader, iLogger));
                        continue block26;
                    }
                    case 5: {
                        date2 = jsonObjectReader.nextListOrNull(iLogger, new SentrySpan.Deserializer());
                        if (date2 == null) continue block26;
                        sentryTransaction.spans.addAll((Collection)date2);
                        continue block26;
                    }
                    case 4: {
                        date2 = jsonObjectReader.nextDoubleOrNull();
                        if (date2 == null) continue block26;
                        try {
                            SentryTransaction.access$202(sentryTransaction, (Double)date2);
                        }
                        catch (NumberFormatException numberFormatException) {
                            date2 = jsonObjectReader.nextDateOrNull(iLogger);
                            if (date2 == null) continue block26;
                            SentryTransaction.access$202(sentryTransaction, DateUtils.dateToSeconds(date2));
                        }
                        continue block26;
                    }
                    case 3: {
                        jsonObjectReader.nextString();
                        continue block26;
                    }
                    case 2: {
                        date2 = jsonObjectReader.nextMapOrNull(iLogger, new MeasurementValue.Deserializer());
                        if (date2 == null) continue block26;
                        sentryTransaction.measurements.putAll((Map)date2);
                        continue block26;
                    }
                    case 1: {
                        SentryTransaction.access$502(sentryTransaction, jsonObjectReader.nextMapOfListOrNull(iLogger, new MetricSummary.Deserializer()));
                        continue block26;
                    }
                    case 0: 
                }
                date2 = jsonObjectReader.nextDoubleOrNull();
                if (date2 == null) continue;
                try {
                    SentryTransaction.access$102(sentryTransaction, (Double)date2);
                }
                catch (NumberFormatException numberFormatException) {
                    date2 = jsonObjectReader.nextDateOrNull(iLogger);
                    if (date2 == null) continue;
                    SentryTransaction.access$102(sentryTransaction, DateUtils.dateToSeconds(date2));
                }
            }
            sentryTransaction.setUnknown((Map<String, Object>)date);
            jsonObjectReader.endObject();
            return sentryTransaction;
        }
    }

    public static final class JsonKeys {
        public static final String MEASUREMENTS = "measurements";
        public static final String METRICS_SUMMARY = "_metrics_summary";
        public static final String SPANS = "spans";
        public static final String START_TIMESTAMP = "start_timestamp";
        public static final String TIMESTAMP = "timestamp";
        public static final String TRANSACTION = "transaction";
        public static final String TRANSACTION_INFO = "transaction_info";
        public static final String TYPE = "type";
    }
}

