/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.protocol.DebugImage;
import io.sentry.protocol.SdkInfo;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class DebugMeta
implements JsonUnknown,
JsonSerializable {
    private List<DebugImage> images;
    private SdkInfo sdkInfo;
    private Map<String, Object> unknown;

    static /* synthetic */ SdkInfo access$002(DebugMeta debugMeta, SdkInfo sdkInfo) {
        debugMeta.sdkInfo = sdkInfo;
        return sdkInfo;
    }

    static /* synthetic */ List access$102(DebugMeta debugMeta, List list) {
        debugMeta.images = list;
        return list;
    }

    public List<DebugImage> getImages() {
        return this.images;
    }

    public SdkInfo getSdkInfo() {
        return this.sdkInfo;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.sdkInfo != null) {
            objectWriter.name("sdk_info").value(iLogger, this.sdkInfo);
        }
        if (this.images != null) {
            objectWriter.name("images").value(iLogger, this.images);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setImages(List<DebugImage> object) {
        object = object != null ? new ArrayList(object) : null;
        this.images = object;
    }

    public void setSdkInfo(SdkInfo sdkInfo) {
        this.sdkInfo = sdkInfo;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<DebugMeta> {
        @Override
        public DebugMeta deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            DebugMeta debugMeta = new DebugMeta();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                if (!string2.equals((Object)"images")) {
                    if (!string2.equals((Object)"sdk_info")) {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue;
                    }
                    DebugMeta.access$002(debugMeta, jsonObjectReader.nextOrNull(iLogger, new SdkInfo.Deserializer()));
                    continue;
                }
                DebugMeta.access$102(debugMeta, jsonObjectReader.nextListOrNull(iLogger, new DebugImage.Deserializer()));
            }
            jsonObjectReader.endObject();
            debugMeta.setUnknown((Map<String, Object>)hashMap);
            return debugMeta;
        }
    }

    public static final class JsonKeys {
        public static final String IMAGES = "images";
        public static final String SDK_INFO = "sdk_info";
    }
}

