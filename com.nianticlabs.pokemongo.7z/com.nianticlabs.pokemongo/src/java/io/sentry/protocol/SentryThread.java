/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLockReason;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryThread
implements JsonUnknown,
JsonSerializable {
    private Boolean crashed;
    private Boolean current;
    private Boolean daemon;
    private Map<String, SentryLockReason> heldLocks;
    private Long id;
    private Boolean main;
    private String name;
    private Integer priority;
    private SentryStackTrace stacktrace;
    private String state;
    private Map<String, Object> unknown;

    static /* synthetic */ Long access$002(SentryThread sentryThread, Long l2) {
        sentryThread.id = l2;
        return l2;
    }

    static /* synthetic */ Integer access$102(SentryThread sentryThread, Integer n2) {
        sentryThread.priority = n2;
        return n2;
    }

    static /* synthetic */ String access$202(SentryThread sentryThread, String string2) {
        sentryThread.name = string2;
        return string2;
    }

    static /* synthetic */ String access$302(SentryThread sentryThread, String string2) {
        sentryThread.state = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$402(SentryThread sentryThread, Boolean bl) {
        sentryThread.crashed = bl;
        return bl;
    }

    static /* synthetic */ Boolean access$502(SentryThread sentryThread, Boolean bl) {
        sentryThread.current = bl;
        return bl;
    }

    static /* synthetic */ Boolean access$602(SentryThread sentryThread, Boolean bl) {
        sentryThread.daemon = bl;
        return bl;
    }

    static /* synthetic */ Boolean access$702(SentryThread sentryThread, Boolean bl) {
        sentryThread.main = bl;
        return bl;
    }

    static /* synthetic */ SentryStackTrace access$802(SentryThread sentryThread, SentryStackTrace sentryStackTrace) {
        sentryThread.stacktrace = sentryStackTrace;
        return sentryStackTrace;
    }

    static /* synthetic */ Map access$902(SentryThread sentryThread, Map map2) {
        sentryThread.heldLocks = map2;
        return map2;
    }

    public Map<String, SentryLockReason> getHeldLocks() {
        return this.heldLocks;
    }

    public Long getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public Integer getPriority() {
        return this.priority;
    }

    public SentryStackTrace getStacktrace() {
        return this.stacktrace;
    }

    public String getState() {
        return this.state;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Boolean isCrashed() {
        return this.crashed;
    }

    public Boolean isCurrent() {
        return this.current;
    }

    public Boolean isDaemon() {
        return this.daemon;
    }

    public Boolean isMain() {
        return this.main;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.id != null) {
            objectWriter.name("id").value((Number)this.id);
        }
        if (this.priority != null) {
            objectWriter.name("priority").value((Number)this.priority);
        }
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.state != null) {
            objectWriter.name("state").value(this.state);
        }
        if (this.crashed != null) {
            objectWriter.name("crashed").value(this.crashed);
        }
        if (this.current != null) {
            objectWriter.name("current").value(this.current);
        }
        if (this.daemon != null) {
            objectWriter.name("daemon").value(this.daemon);
        }
        if (this.main != null) {
            objectWriter.name("main").value(this.main);
        }
        if (this.stacktrace != null) {
            objectWriter.name("stacktrace").value(iLogger, this.stacktrace);
        }
        if (this.heldLocks != null) {
            objectWriter.name("held_locks").value(iLogger, this.heldLocks);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setCrashed(Boolean bl) {
        this.crashed = bl;
    }

    public void setCurrent(Boolean bl) {
        this.current = bl;
    }

    public void setDaemon(Boolean bl) {
        this.daemon = bl;
    }

    public void setHeldLocks(Map<String, SentryLockReason> map2) {
        this.heldLocks = map2;
    }

    public void setId(Long l2) {
        this.id = l2;
    }

    public void setMain(Boolean bl) {
        this.main = bl;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setPriority(Integer n2) {
        this.priority = n2;
    }

    public void setStacktrace(SentryStackTrace sentryStackTrace) {
        this.stacktrace = sentryStackTrace;
    }

    public void setState(String string2) {
        this.state = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryThread> {
        @Override
        public SentryThread deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SentryThread sentryThread = new SentryThread();
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            block24: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2055832509: {
                        if (!string2.equals((Object)"stacktrace")) break;
                        n3 = 9;
                        break;
                    }
                    case 1126940025: {
                        if (!string2.equals((Object)"current")) break;
                        n3 = 8;
                        break;
                    }
                    case 1025385094: {
                        if (!string2.equals((Object)"crashed")) break;
                        n3 = 7;
                        break;
                    }
                    case 109757585: {
                        if (!string2.equals((Object)"state")) break;
                        n3 = 6;
                        break;
                    }
                    case 3373707: {
                        if (!string2.equals((Object)"name")) break;
                        n3 = 5;
                        break;
                    }
                    case 3343801: {
                        if (!string2.equals((Object)"main")) break;
                        n3 = 4;
                        break;
                    }
                    case 3355: {
                        if (!string2.equals((Object)"id")) break;
                        n3 = 3;
                        break;
                    }
                    case -502917346: {
                        if (!string2.equals((Object)"held_locks")) break;
                        n3 = 2;
                        break;
                    }
                    case -1165461084: {
                        if (!string2.equals((Object)"priority")) break;
                        n3 = 1;
                        break;
                    }
                    case -1339353468: {
                        if (!string2.equals((Object)"daemon")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block24;
                    }
                    case 9: {
                        SentryThread.access$802(sentryThread, jsonObjectReader.nextOrNull(iLogger, new SentryStackTrace.Deserializer()));
                        continue block24;
                    }
                    case 8: {
                        SentryThread.access$502(sentryThread, jsonObjectReader.nextBooleanOrNull());
                        continue block24;
                    }
                    case 7: {
                        SentryThread.access$402(sentryThread, jsonObjectReader.nextBooleanOrNull());
                        continue block24;
                    }
                    case 6: {
                        SentryThread.access$302(sentryThread, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 5: {
                        SentryThread.access$202(sentryThread, jsonObjectReader.nextStringOrNull());
                        continue block24;
                    }
                    case 4: {
                        SentryThread.access$702(sentryThread, jsonObjectReader.nextBooleanOrNull());
                        continue block24;
                    }
                    case 3: {
                        SentryThread.access$002(sentryThread, jsonObjectReader.nextLongOrNull());
                        continue block24;
                    }
                    case 2: {
                        ConcurrentHashMap concurrentHashMap2 = jsonObjectReader.nextMapOrNull(iLogger, new SentryLockReason.Deserializer());
                        if (concurrentHashMap2 == null) continue block24;
                        SentryThread.access$902(sentryThread, (Map)new HashMap((Map)concurrentHashMap2));
                        continue block24;
                    }
                    case 1: {
                        SentryThread.access$102(sentryThread, jsonObjectReader.nextIntegerOrNull());
                        continue block24;
                    }
                    case 0: 
                }
                SentryThread.access$602(sentryThread, jsonObjectReader.nextBooleanOrNull());
            }
            sentryThread.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return sentryThread;
        }
    }

    public static final class JsonKeys {
        public static final String CRASHED = "crashed";
        public static final String CURRENT = "current";
        public static final String DAEMON = "daemon";
        public static final String HELD_LOCKS = "held_locks";
        public static final String ID = "id";
        public static final String MAIN = "main";
        public static final String NAME = "name";
        public static final String PRIORITY = "priority";
        public static final String STACKTRACE = "stacktrace";
        public static final String STATE = "state";
    }
}

