/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArrayList
 *  java.util.concurrent.CopyOnWriteArraySet
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryIntegrationPackageStorage;
import io.sentry.SentryLevel;
import io.sentry.protocol.SentryPackage;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public final class SdkVersion
implements JsonUnknown,
JsonSerializable {
    private Set<String> deserializedIntegrations;
    private Set<SentryPackage> deserializedPackages;
    private String name;
    private Map<String, Object> unknown;
    private String version;

    public SdkVersion(String string2, String string3) {
        this.name = Objects.requireNonNull(string2, "name is required.");
        this.version = Objects.requireNonNull(string3, "version is required.");
    }

    static /* synthetic */ Set access$002(SdkVersion sdkVersion, Set set) {
        sdkVersion.deserializedPackages = set;
        return set;
    }

    static /* synthetic */ Set access$102(SdkVersion sdkVersion, Set set) {
        sdkVersion.deserializedIntegrations = set;
        return set;
    }

    public static SdkVersion updateSdkVersion(SdkVersion sdkVersion, String string2, String string3) {
        Objects.requireNonNull(string2, "name is required.");
        Objects.requireNonNull(string3, "version is required.");
        if (sdkVersion == null) {
            sdkVersion = new SdkVersion(string2, string3);
        } else {
            sdkVersion.setName(string2);
            sdkVersion.setVersion(string3);
        }
        return sdkVersion;
    }

    public void addIntegration(String string2) {
        SentryIntegrationPackageStorage.getInstance().addIntegration(string2);
    }

    public void addPackage(String string2, String string3) {
        SentryIntegrationPackageStorage.getInstance().addPackage(string2, string3);
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (SdkVersion)object;
            if (!this.name.equals((Object)((SdkVersion)object).name) || !this.version.equals((Object)((SdkVersion)object).version)) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public Set<String> getIntegrationSet() {
        Set<String> set = this.deserializedIntegrations;
        if (set == null) {
            set = SentryIntegrationPackageStorage.getInstance().getIntegrations();
        }
        return set;
    }

    @Deprecated
    public List<String> getIntegrations() {
        Set<String> set = this.deserializedIntegrations;
        if (set == null) {
            set = SentryIntegrationPackageStorage.getInstance().getIntegrations();
        }
        return new CopyOnWriteArrayList(set);
    }

    public String getName() {
        return this.name;
    }

    public Set<SentryPackage> getPackageSet() {
        Set<SentryPackage> set = this.deserializedPackages;
        if (set == null) {
            set = SentryIntegrationPackageStorage.getInstance().getPackages();
        }
        return set;
    }

    @Deprecated
    public List<SentryPackage> getPackages() {
        Set<SentryPackage> set = this.deserializedPackages;
        if (set == null) {
            set = SentryIntegrationPackageStorage.getInstance().getPackages();
        }
        return new CopyOnWriteArrayList(set);
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVersion() {
        return this.version;
    }

    public int hashCode() {
        return Objects.hash(this.name, this.version);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("name").value(this.name);
        objectWriter.name("version").value(this.version);
        Object object2 = this.getPackageSet();
        Iterator iterator = this.getIntegrationSet();
        if (!object2.isEmpty()) {
            objectWriter.name("packages").value(iLogger, object2);
        }
        if (!iterator.isEmpty()) {
            objectWriter.name("integrations").value(iLogger, iterator);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2).value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setName(String string2) {
        this.name = Objects.requireNonNull(string2, "name is required.");
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVersion(String string2) {
        this.version = Objects.requireNonNull(string2, "version is required.");
    }

    public static final class Deserializer
    implements JsonDeserializer<SdkVersion> {
        @Override
        public SdkVersion deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ((JsonReader)object).beginObject();
            String string2 = null;
            String string3 = null;
            HashMap hashMap = null;
            block12: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string4 = ((JsonReader)object).nextName();
                string4.hashCode();
                int n2 = string4.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1487029535: {
                        if (!string4.equals((Object)"integrations")) break;
                        n3 = 3;
                        break;
                    }
                    case 750867693: {
                        if (!string4.equals((Object)"packages")) break;
                        n3 = 2;
                        break;
                    }
                    case 351608024: {
                        if (!string4.equals((Object)"version")) break;
                        n3 = 1;
                        break;
                    }
                    case 3373707: {
                        if (!string4.equals((Object)"name")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)hashMap2, string4);
                        hashMap = hashMap2;
                        continue block12;
                    }
                    case 3: {
                        HashMap hashMap2 = (HashMap)((JsonObjectReader)object).nextObjectOrNull();
                        if (hashMap2 == null) continue block12;
                        arrayList2.addAll((Collection)hashMap2);
                        continue block12;
                    }
                    case 2: {
                        HashMap hashMap2 = ((JsonObjectReader)object).nextListOrNull(iLogger, new SentryPackage.Deserializer());
                        if (hashMap2 == null) continue block12;
                        arrayList.addAll((Collection)hashMap2);
                        continue block12;
                    }
                    case 1: {
                        string3 = ((JsonReader)object).nextString();
                        continue block12;
                    }
                    case 0: 
                }
                string2 = ((JsonReader)object).nextString();
            }
            ((JsonReader)object).endObject();
            if (string2 != null) {
                if (string3 != null) {
                    object = new SdkVersion(string2, string3);
                    SdkVersion.access$002((SdkVersion)object, (Set)new CopyOnWriteArraySet((Collection)arrayList));
                    SdkVersion.access$102((SdkVersion)object, (Set)new CopyOnWriteArraySet((Collection)arrayList2));
                    ((SdkVersion)object).setUnknown((Map<String, Object>)hashMap);
                    return object;
                }
                object = new IllegalStateException("Missing required field \"version\"");
                iLogger.log(SentryLevel.ERROR, "Missing required field \"version\"", (Throwable)object);
                throw object;
            }
            object = new IllegalStateException("Missing required field \"name\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"name\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String INTEGRATIONS = "integrations";
        public static final String NAME = "name";
        public static final String PACKAGES = "packages";
        public static final String VERSION = "version";
    }
}

