/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class MeasurementValue
implements JsonUnknown,
JsonSerializable {
    public static final String KEY_APP_START_COLD = "app_start_cold";
    public static final String KEY_APP_START_WARM = "app_start_warm";
    public static final String KEY_FRAMES_DELAY = "frames_delay";
    public static final String KEY_FRAMES_FROZEN = "frames_frozen";
    public static final String KEY_FRAMES_SLOW = "frames_slow";
    public static final String KEY_FRAMES_TOTAL = "frames_total";
    public static final String KEY_TIME_TO_FULL_DISPLAY = "time_to_full_display";
    public static final String KEY_TIME_TO_INITIAL_DISPLAY = "time_to_initial_display";
    private final String unit;
    private Map<String, Object> unknown;
    private final Number value;

    public MeasurementValue(Number number, String string2) {
        this.value = number;
        this.unit = string2;
    }

    public MeasurementValue(Number number, String string2, Map<String, Object> map2) {
        this.value = number;
        this.unit = string2;
        this.unknown = map2;
    }

    public String getUnit() {
        return this.unit;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Number getValue() {
        return this.value;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        objectWriter.name("value").value(this.value);
        if (this.unit != null) {
            objectWriter.name("unit").value(this.unit);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<MeasurementValue> {
        @Override
        public MeasurementValue deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            ((JsonReader)object).beginObject();
            Number number = null;
            String string2 = null;
            ConcurrentHashMap concurrentHashMap = null;
            while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string3 = ((JsonReader)object).nextName();
                string3.hashCode();
                if (!string3.equals((Object)"unit")) {
                    if (!string3.equals((Object)"value")) {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string3);
                        concurrentHashMap = concurrentHashMap2;
                        continue;
                    }
                    number = (Number)((JsonObjectReader)object).nextObjectOrNull();
                    continue;
                }
                string2 = ((JsonObjectReader)object).nextStringOrNull();
            }
            ((JsonReader)object).endObject();
            if (number != null) {
                object = new MeasurementValue(number, string2);
                ((MeasurementValue)object).setUnknown((Map<String, Object>)concurrentHashMap);
                return object;
            }
            object = new IllegalStateException("Missing required field \"value\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"value\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String UNIT = "unit";
        public static final String VALUE = "value";
    }
}

