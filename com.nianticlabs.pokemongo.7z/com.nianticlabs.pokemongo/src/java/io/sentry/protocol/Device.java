/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.TimeZone
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

public final class Device
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "device";
    private String[] archs;
    private Float batteryLevel;
    private Float batteryTemperature;
    private Date bootTime;
    private String brand;
    private Boolean charging;
    private String connectionType;
    private String cpuDescription;
    private Long externalFreeStorage;
    private Long externalStorageSize;
    private String family;
    private Long freeMemory;
    private Long freeStorage;
    private String id;
    @Deprecated
    private String language;
    private String locale;
    private Boolean lowMemory;
    private String manufacturer;
    private Long memorySize;
    private String model;
    private String modelId;
    private String name;
    private Boolean online;
    private DeviceOrientation orientation;
    private Integer processorCount;
    private Double processorFrequency;
    private Float screenDensity;
    private Integer screenDpi;
    private Integer screenHeightPixels;
    private Integer screenWidthPixels;
    private Boolean simulator;
    private Long storageSize;
    private TimeZone timezone;
    private Map<String, Object> unknown;
    private Long usableMemory;

    public Device() {
    }

    Device(Device device) {
        this.name = device.name;
        this.manufacturer = device.manufacturer;
        this.brand = device.brand;
        this.family = device.family;
        this.model = device.model;
        this.modelId = device.modelId;
        this.charging = device.charging;
        this.online = device.online;
        this.orientation = device.orientation;
        this.simulator = device.simulator;
        this.memorySize = device.memorySize;
        this.freeMemory = device.freeMemory;
        this.usableMemory = device.usableMemory;
        this.lowMemory = device.lowMemory;
        this.storageSize = device.storageSize;
        this.freeStorage = device.freeStorage;
        this.externalStorageSize = device.externalStorageSize;
        this.externalFreeStorage = device.externalFreeStorage;
        this.screenWidthPixels = device.screenWidthPixels;
        this.screenHeightPixels = device.screenHeightPixels;
        this.screenDensity = device.screenDensity;
        this.screenDpi = device.screenDpi;
        this.bootTime = device.bootTime;
        this.id = device.id;
        this.language = device.language;
        this.connectionType = device.connectionType;
        this.batteryTemperature = device.batteryTemperature;
        this.batteryLevel = device.batteryLevel;
        Object object = device.archs;
        Object var3_3 = null;
        object = object != null ? (String[])object.clone() : null;
        this.archs = object;
        this.locale = device.locale;
        TimeZone timeZone = device.timezone;
        object = var3_3;
        if (timeZone != null) {
            object = (TimeZone)timeZone.clone();
        }
        this.timezone = object;
        this.processorCount = device.processorCount;
        this.processorFrequency = device.processorFrequency;
        this.cpuDescription = device.cpuDescription;
        this.unknown = CollectionUtils.newConcurrentHashMap(device.unknown);
    }

    static /* synthetic */ String access$002(Device device, String string2) {
        device.name = string2;
        return string2;
    }

    static /* synthetic */ DeviceOrientation access$1002(Device device, DeviceOrientation deviceOrientation) {
        device.orientation = deviceOrientation;
        return deviceOrientation;
    }

    static /* synthetic */ String access$102(Device device, String string2) {
        device.manufacturer = string2;
        return string2;
    }

    static /* synthetic */ Boolean access$1102(Device device, Boolean bl) {
        device.simulator = bl;
        return bl;
    }

    static /* synthetic */ Long access$1202(Device device, Long l2) {
        device.memorySize = l2;
        return l2;
    }

    static /* synthetic */ Long access$1302(Device device, Long l2) {
        device.freeMemory = l2;
        return l2;
    }

    static /* synthetic */ Long access$1402(Device device, Long l2) {
        device.usableMemory = l2;
        return l2;
    }

    static /* synthetic */ Boolean access$1502(Device device, Boolean bl) {
        device.lowMemory = bl;
        return bl;
    }

    static /* synthetic */ Long access$1602(Device device, Long l2) {
        device.storageSize = l2;
        return l2;
    }

    static /* synthetic */ Long access$1702(Device device, Long l2) {
        device.freeStorage = l2;
        return l2;
    }

    static /* synthetic */ Long access$1802(Device device, Long l2) {
        device.externalStorageSize = l2;
        return l2;
    }

    static /* synthetic */ Long access$1902(Device device, Long l2) {
        device.externalFreeStorage = l2;
        return l2;
    }

    static /* synthetic */ Integer access$2002(Device device, Integer n2) {
        device.screenWidthPixels = n2;
        return n2;
    }

    static /* synthetic */ String access$202(Device device, String string2) {
        device.brand = string2;
        return string2;
    }

    static /* synthetic */ Integer access$2102(Device device, Integer n2) {
        device.screenHeightPixels = n2;
        return n2;
    }

    static /* synthetic */ Float access$2202(Device device, Float f2) {
        device.screenDensity = f2;
        return f2;
    }

    static /* synthetic */ Integer access$2302(Device device, Integer n2) {
        device.screenDpi = n2;
        return n2;
    }

    static /* synthetic */ Date access$2402(Device device, Date date) {
        device.bootTime = date;
        return date;
    }

    static /* synthetic */ TimeZone access$2502(Device device, TimeZone timeZone) {
        device.timezone = timeZone;
        return timeZone;
    }

    static /* synthetic */ String access$2602(Device device, String string2) {
        device.id = string2;
        return string2;
    }

    static /* synthetic */ String access$2702(Device device, String string2) {
        device.language = string2;
        return string2;
    }

    static /* synthetic */ String access$2802(Device device, String string2) {
        device.connectionType = string2;
        return string2;
    }

    static /* synthetic */ Float access$2902(Device device, Float f2) {
        device.batteryTemperature = f2;
        return f2;
    }

    static /* synthetic */ String access$3002(Device device, String string2) {
        device.locale = string2;
        return string2;
    }

    static /* synthetic */ String access$302(Device device, String string2) {
        device.family = string2;
        return string2;
    }

    static /* synthetic */ Integer access$3102(Device device, Integer n2) {
        device.processorCount = n2;
        return n2;
    }

    static /* synthetic */ Double access$3202(Device device, Double d2) {
        device.processorFrequency = d2;
        return d2;
    }

    static /* synthetic */ String access$3302(Device device, String string2) {
        device.cpuDescription = string2;
        return string2;
    }

    static /* synthetic */ String access$402(Device device, String string2) {
        device.model = string2;
        return string2;
    }

    static /* synthetic */ String access$502(Device device, String string2) {
        device.modelId = string2;
        return string2;
    }

    static /* synthetic */ String[] access$602(Device device, String[] stringArray) {
        device.archs = stringArray;
        return stringArray;
    }

    static /* synthetic */ Float access$702(Device device, Float f2) {
        device.batteryLevel = f2;
        return f2;
    }

    static /* synthetic */ Boolean access$802(Device device, Boolean bl) {
        device.charging = bl;
        return bl;
    }

    static /* synthetic */ Boolean access$902(Device device, Boolean bl) {
        device.online = bl;
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (Device)object;
            if (!(Objects.equals(this.name, ((Device)object).name) && Objects.equals(this.manufacturer, ((Device)object).manufacturer) && Objects.equals(this.brand, ((Device)object).brand) && Objects.equals(this.family, ((Device)object).family) && Objects.equals(this.model, ((Device)object).model) && Objects.equals(this.modelId, ((Device)object).modelId) && Arrays.equals((Object[])this.archs, (Object[])((Device)object).archs) && Objects.equals(this.batteryLevel, ((Device)object).batteryLevel) && Objects.equals(this.charging, ((Device)object).charging) && Objects.equals(this.online, ((Device)object).online) && this.orientation == ((Device)object).orientation && Objects.equals(this.simulator, ((Device)object).simulator) && Objects.equals(this.memorySize, ((Device)object).memorySize) && Objects.equals(this.freeMemory, ((Device)object).freeMemory) && Objects.equals(this.usableMemory, ((Device)object).usableMemory) && Objects.equals(this.lowMemory, ((Device)object).lowMemory) && Objects.equals(this.storageSize, ((Device)object).storageSize) && Objects.equals(this.freeStorage, ((Device)object).freeStorage) && Objects.equals(this.externalStorageSize, ((Device)object).externalStorageSize) && Objects.equals(this.externalFreeStorage, ((Device)object).externalFreeStorage) && Objects.equals(this.screenWidthPixels, ((Device)object).screenWidthPixels) && Objects.equals(this.screenHeightPixels, ((Device)object).screenHeightPixels) && Objects.equals(this.screenDensity, ((Device)object).screenDensity) && Objects.equals(this.screenDpi, ((Device)object).screenDpi) && Objects.equals(this.bootTime, ((Device)object).bootTime) && Objects.equals(this.id, ((Device)object).id) && Objects.equals(this.language, ((Device)object).language) && Objects.equals(this.locale, ((Device)object).locale) && Objects.equals(this.connectionType, ((Device)object).connectionType) && Objects.equals(this.batteryTemperature, ((Device)object).batteryTemperature) && Objects.equals(this.processorCount, ((Device)object).processorCount) && Objects.equals(this.processorFrequency, ((Device)object).processorFrequency) && Objects.equals(this.cpuDescription, ((Device)object).cpuDescription))) {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public String[] getArchs() {
        return this.archs;
    }

    public Float getBatteryLevel() {
        return this.batteryLevel;
    }

    public Float getBatteryTemperature() {
        return this.batteryTemperature;
    }

    public Date getBootTime() {
        Object object = this.bootTime;
        object = object != null ? (Date)object.clone() : null;
        return object;
    }

    public String getBrand() {
        return this.brand;
    }

    public String getConnectionType() {
        return this.connectionType;
    }

    public String getCpuDescription() {
        return this.cpuDescription;
    }

    public Long getExternalFreeStorage() {
        return this.externalFreeStorage;
    }

    public Long getExternalStorageSize() {
        return this.externalStorageSize;
    }

    public String getFamily() {
        return this.family;
    }

    public Long getFreeMemory() {
        return this.freeMemory;
    }

    public Long getFreeStorage() {
        return this.freeStorage;
    }

    public String getId() {
        return this.id;
    }

    public String getLanguage() {
        return this.language;
    }

    public String getLocale() {
        return this.locale;
    }

    public String getManufacturer() {
        return this.manufacturer;
    }

    public Long getMemorySize() {
        return this.memorySize;
    }

    public String getModel() {
        return this.model;
    }

    public String getModelId() {
        return this.modelId;
    }

    public String getName() {
        return this.name;
    }

    public DeviceOrientation getOrientation() {
        return this.orientation;
    }

    public Integer getProcessorCount() {
        return this.processorCount;
    }

    public Double getProcessorFrequency() {
        return this.processorFrequency;
    }

    public Float getScreenDensity() {
        return this.screenDensity;
    }

    public Integer getScreenDpi() {
        return this.screenDpi;
    }

    public Integer getScreenHeightPixels() {
        return this.screenHeightPixels;
    }

    public Integer getScreenWidthPixels() {
        return this.screenWidthPixels;
    }

    public Long getStorageSize() {
        return this.storageSize;
    }

    public TimeZone getTimezone() {
        return this.timezone;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public Long getUsableMemory() {
        return this.usableMemory;
    }

    public int hashCode() {
        return Objects.hash(this.name, this.manufacturer, this.brand, this.family, this.model, this.modelId, this.batteryLevel, this.charging, this.online, this.orientation, this.simulator, this.memorySize, this.freeMemory, this.usableMemory, this.lowMemory, this.storageSize, this.freeStorage, this.externalStorageSize, this.externalFreeStorage, this.screenWidthPixels, this.screenHeightPixels, this.screenDensity, this.screenDpi, this.bootTime, this.timezone, this.id, this.language, this.locale, this.connectionType, this.batteryTemperature, this.processorCount, this.processorFrequency, this.cpuDescription) * 31 + Arrays.hashCode((Object[])this.archs);
    }

    public Boolean isCharging() {
        return this.charging;
    }

    public Boolean isLowMemory() {
        return this.lowMemory;
    }

    public Boolean isOnline() {
        return this.online;
    }

    public Boolean isSimulator() {
        return this.simulator;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        if (this.name != null) {
            objectWriter.name("name").value(this.name);
        }
        if (this.manufacturer != null) {
            objectWriter.name("manufacturer").value(this.manufacturer);
        }
        if (this.brand != null) {
            objectWriter.name("brand").value(this.brand);
        }
        if (this.family != null) {
            objectWriter.name("family").value(this.family);
        }
        if (this.model != null) {
            objectWriter.name("model").value(this.model);
        }
        if (this.modelId != null) {
            objectWriter.name("model_id").value(this.modelId);
        }
        if (this.archs != null) {
            objectWriter.name("archs").value(iLogger, this.archs);
        }
        if (this.batteryLevel != null) {
            objectWriter.name("battery_level").value((Number)this.batteryLevel);
        }
        if (this.charging != null) {
            objectWriter.name("charging").value(this.charging);
        }
        if (this.online != null) {
            objectWriter.name("online").value(this.online);
        }
        if (this.orientation != null) {
            objectWriter.name("orientation").value(iLogger, this.orientation);
        }
        if (this.simulator != null) {
            objectWriter.name("simulator").value(this.simulator);
        }
        if (this.memorySize != null) {
            objectWriter.name("memory_size").value((Number)this.memorySize);
        }
        if (this.freeMemory != null) {
            objectWriter.name("free_memory").value((Number)this.freeMemory);
        }
        if (this.usableMemory != null) {
            objectWriter.name("usable_memory").value((Number)this.usableMemory);
        }
        if (this.lowMemory != null) {
            objectWriter.name("low_memory").value(this.lowMemory);
        }
        if (this.storageSize != null) {
            objectWriter.name("storage_size").value((Number)this.storageSize);
        }
        if (this.freeStorage != null) {
            objectWriter.name("free_storage").value((Number)this.freeStorage);
        }
        if (this.externalStorageSize != null) {
            objectWriter.name("external_storage_size").value((Number)this.externalStorageSize);
        }
        if (this.externalFreeStorage != null) {
            objectWriter.name("external_free_storage").value((Number)this.externalFreeStorage);
        }
        if (this.screenWidthPixels != null) {
            objectWriter.name("screen_width_pixels").value((Number)this.screenWidthPixels);
        }
        if (this.screenHeightPixels != null) {
            objectWriter.name("screen_height_pixels").value((Number)this.screenHeightPixels);
        }
        if (this.screenDensity != null) {
            objectWriter.name("screen_density").value((Number)this.screenDensity);
        }
        if (this.screenDpi != null) {
            objectWriter.name("screen_dpi").value((Number)this.screenDpi);
        }
        if (this.bootTime != null) {
            objectWriter.name("boot_time").value(iLogger, this.bootTime);
        }
        if (this.timezone != null) {
            objectWriter.name("timezone").value(iLogger, this.timezone);
        }
        if (this.id != null) {
            objectWriter.name("id").value(this.id);
        }
        if (this.language != null) {
            objectWriter.name("language").value(this.language);
        }
        if (this.connectionType != null) {
            objectWriter.name("connection_type").value(this.connectionType);
        }
        if (this.batteryTemperature != null) {
            objectWriter.name("battery_temperature").value((Number)this.batteryTemperature);
        }
        if (this.locale != null) {
            objectWriter.name("locale").value(this.locale);
        }
        if (this.processorCount != null) {
            objectWriter.name("processor_count").value((Number)this.processorCount);
        }
        if (this.processorFrequency != null) {
            objectWriter.name("processor_frequency").value((Number)this.processorFrequency);
        }
        if (this.cpuDescription != null) {
            objectWriter.name("cpu_description").value(this.cpuDescription);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setArchs(String[] stringArray) {
        this.archs = stringArray;
    }

    public void setBatteryLevel(Float f2) {
        this.batteryLevel = f2;
    }

    public void setBatteryTemperature(Float f2) {
        this.batteryTemperature = f2;
    }

    public void setBootTime(Date date) {
        this.bootTime = date;
    }

    public void setBrand(String string2) {
        this.brand = string2;
    }

    public void setCharging(Boolean bl) {
        this.charging = bl;
    }

    public void setConnectionType(String string2) {
        this.connectionType = string2;
    }

    public void setCpuDescription(String string2) {
        this.cpuDescription = string2;
    }

    public void setExternalFreeStorage(Long l2) {
        this.externalFreeStorage = l2;
    }

    public void setExternalStorageSize(Long l2) {
        this.externalStorageSize = l2;
    }

    public void setFamily(String string2) {
        this.family = string2;
    }

    public void setFreeMemory(Long l2) {
        this.freeMemory = l2;
    }

    public void setFreeStorage(Long l2) {
        this.freeStorage = l2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setLanguage(String string2) {
        this.language = string2;
    }

    public void setLocale(String string2) {
        this.locale = string2;
    }

    public void setLowMemory(Boolean bl) {
        this.lowMemory = bl;
    }

    public void setManufacturer(String string2) {
        this.manufacturer = string2;
    }

    public void setMemorySize(Long l2) {
        this.memorySize = l2;
    }

    public void setModel(String string2) {
        this.model = string2;
    }

    public void setModelId(String string2) {
        this.modelId = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setOnline(Boolean bl) {
        this.online = bl;
    }

    public void setOrientation(DeviceOrientation deviceOrientation) {
        this.orientation = deviceOrientation;
    }

    public void setProcessorCount(Integer n2) {
        this.processorCount = n2;
    }

    public void setProcessorFrequency(Double d2) {
        this.processorFrequency = d2;
    }

    public void setScreenDensity(Float f2) {
        this.screenDensity = f2;
    }

    public void setScreenDpi(Integer n2) {
        this.screenDpi = n2;
    }

    public void setScreenHeightPixels(Integer n2) {
        this.screenHeightPixels = n2;
    }

    public void setScreenWidthPixels(Integer n2) {
        this.screenWidthPixels = n2;
    }

    public void setSimulator(Boolean bl) {
        this.simulator = bl;
    }

    public void setStorageSize(Long l2) {
        this.storageSize = l2;
    }

    public void setTimezone(TimeZone timeZone) {
        this.timezone = timeZone;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setUsableMemory(Long l2) {
        this.usableMemory = l2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Device> {
        @Override
        public Device deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Device device = new Device();
            List list = null;
            block72: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Object[] objectArray = jsonObjectReader.nextName();
                objectArray.hashCode();
                int n2 = objectArray.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1556284978: {
                        if (!objectArray.equals((Object)"screen_height_pixels")) break;
                        n3 = 33;
                        break;
                    }
                    case 1524159400: {
                        if (!objectArray.equals((Object)"free_storage")) break;
                        n3 = 32;
                        break;
                    }
                    case 1450613660: {
                        if (!objectArray.equals((Object)"external_free_storage")) break;
                        n3 = 31;
                        break;
                    }
                    case 1436115569: {
                        if (!objectArray.equals((Object)"charging")) break;
                        n3 = 30;
                        break;
                    }
                    case 1418777727: {
                        if (!objectArray.equals((Object)"memory_size")) break;
                        n3 = 29;
                        break;
                    }
                    case 1331465768: {
                        if (!objectArray.equals((Object)"usable_memory")) break;
                        n3 = 28;
                        break;
                    }
                    case 897428293: {
                        if (!objectArray.equals((Object)"storage_size")) break;
                        n3 = 27;
                        break;
                    }
                    case 823882553: {
                        if (!objectArray.equals((Object)"external_storage_size")) break;
                        n3 = 26;
                        break;
                    }
                    case 817830969: {
                        if (!objectArray.equals((Object)"screen_width_pixels")) break;
                        n3 = 25;
                        break;
                    }
                    case 731866107: {
                        if (!objectArray.equals((Object)"connection_type")) break;
                        n3 = 24;
                        break;
                    }
                    case 244497903: {
                        if (!objectArray.equals((Object)"processor_frequency")) break;
                        n3 = 23;
                        break;
                    }
                    case 115746789: {
                        if (!objectArray.equals((Object)"cpu_description")) break;
                        n3 = 22;
                        break;
                    }
                    case 104069929: {
                        if (!objectArray.equals((Object)"model")) break;
                        n3 = 21;
                        break;
                    }
                    case 93997959: {
                        if (!objectArray.equals((Object)"brand")) break;
                        n3 = 20;
                        break;
                    }
                    case 93076189: {
                        if (!objectArray.equals((Object)"archs")) break;
                        n3 = 19;
                        break;
                    }
                    case 59142220: {
                        if (!objectArray.equals((Object)"low_memory")) break;
                        n3 = 18;
                        break;
                    }
                    case 3373707: {
                        if (!objectArray.equals((Object)"name")) break;
                        n3 = 17;
                        break;
                    }
                    case 3355: {
                        if (!objectArray.equals((Object)"id")) break;
                        n3 = 16;
                        break;
                    }
                    case -136523212: {
                        if (!objectArray.equals((Object)"free_memory")) break;
                        n3 = 15;
                        break;
                    }
                    case -417046774: {
                        if (!objectArray.equals((Object)"screen_dpi")) break;
                        n3 = 14;
                        break;
                    }
                    case -568274923: {
                        if (!objectArray.equals((Object)"screen_density")) break;
                        n3 = 13;
                        break;
                    }
                    case -619038223: {
                        if (!objectArray.equals((Object)"model_id")) break;
                        n3 = 12;
                        break;
                    }
                    case -877252910: {
                        if (!objectArray.equals((Object)"battery_level")) break;
                        n3 = 11;
                        break;
                    }
                    case -1012222381: {
                        if (!objectArray.equals((Object)"online")) break;
                        n3 = 10;
                        break;
                    }
                    case -1097462182: {
                        if (!objectArray.equals((Object)"locale")) break;
                        n3 = 9;
                        break;
                    }
                    case -1281860764: {
                        if (!objectArray.equals((Object)"family")) break;
                        n3 = 8;
                        break;
                    }
                    case -1410521534: {
                        if (!objectArray.equals((Object)"battery_temperature")) break;
                        n3 = 7;
                        break;
                    }
                    case -1439500848: {
                        if (!objectArray.equals((Object)"orientation")) break;
                        n3 = 6;
                        break;
                    }
                    case -1608004830: {
                        if (!objectArray.equals((Object)"processor_count")) break;
                        n3 = 5;
                        break;
                    }
                    case -1613589672: {
                        if (!objectArray.equals((Object)"language")) break;
                        n3 = 4;
                        break;
                    }
                    case -1969347631: {
                        if (!objectArray.equals((Object)"manufacturer")) break;
                        n3 = 3;
                        break;
                    }
                    case -1981332476: {
                        if (!objectArray.equals((Object)"simulator")) break;
                        n3 = 2;
                        break;
                    }
                    case -2012489734: {
                        if (!objectArray.equals((Object)"boot_time")) break;
                        n3 = 1;
                        break;
                    }
                    case -2076227591: {
                        if (!objectArray.equals((Object)"timezone")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        List list2 = list;
                        if (list == null) {
                            list2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)list2, (String)objectArray);
                        list = list2;
                        continue block72;
                    }
                    case 33: {
                        Device.access$2102(device, jsonObjectReader.nextIntegerOrNull());
                        continue block72;
                    }
                    case 32: {
                        Device.access$1702(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 31: {
                        Device.access$1902(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 30: {
                        Device.access$802(device, jsonObjectReader.nextBooleanOrNull());
                        continue block72;
                    }
                    case 29: {
                        Device.access$1202(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 28: {
                        Device.access$1402(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 27: {
                        Device.access$1602(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 26: {
                        Device.access$1802(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 25: {
                        Device.access$2002(device, jsonObjectReader.nextIntegerOrNull());
                        continue block72;
                    }
                    case 24: {
                        Device.access$2802(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 23: {
                        Device.access$3202(device, jsonObjectReader.nextDoubleOrNull());
                        continue block72;
                    }
                    case 22: {
                        Device.access$3302(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 21: {
                        Device.access$402(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 20: {
                        Device.access$202(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 19: {
                        List list2 = (List)jsonObjectReader.nextObjectOrNull();
                        if (list2 == null) continue block72;
                        objectArray = new String[list2.size()];
                        list2.toArray(objectArray);
                        Device.access$602(device, (String[])objectArray);
                        continue block72;
                    }
                    case 18: {
                        Device.access$1502(device, jsonObjectReader.nextBooleanOrNull());
                        continue block72;
                    }
                    case 17: {
                        Device.access$002(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 16: {
                        Device.access$2602(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 15: {
                        Device.access$1302(device, jsonObjectReader.nextLongOrNull());
                        continue block72;
                    }
                    case 14: {
                        Device.access$2302(device, jsonObjectReader.nextIntegerOrNull());
                        continue block72;
                    }
                    case 13: {
                        Device.access$2202(device, jsonObjectReader.nextFloatOrNull());
                        continue block72;
                    }
                    case 12: {
                        Device.access$502(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 11: {
                        Device.access$702(device, jsonObjectReader.nextFloatOrNull());
                        continue block72;
                    }
                    case 10: {
                        Device.access$902(device, jsonObjectReader.nextBooleanOrNull());
                        continue block72;
                    }
                    case 9: {
                        Device.access$3002(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 8: {
                        Device.access$302(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 7: {
                        Device.access$2902(device, jsonObjectReader.nextFloatOrNull());
                        continue block72;
                    }
                    case 6: {
                        Device.access$1002(device, jsonObjectReader.nextOrNull(iLogger, new DeviceOrientation.Deserializer()));
                        continue block72;
                    }
                    case 5: {
                        Device.access$3102(device, jsonObjectReader.nextIntegerOrNull());
                        continue block72;
                    }
                    case 4: {
                        Device.access$2702(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 3: {
                        Device.access$102(device, jsonObjectReader.nextStringOrNull());
                        continue block72;
                    }
                    case 2: {
                        Device.access$1102(device, jsonObjectReader.nextBooleanOrNull());
                        continue block72;
                    }
                    case 1: {
                        if (jsonObjectReader.peek() != JsonToken.STRING) continue block72;
                        Device.access$2402(device, jsonObjectReader.nextDateOrNull(iLogger));
                        continue block72;
                    }
                    case 0: 
                }
                Device.access$2502(device, jsonObjectReader.nextTimeZoneOrNull(iLogger));
            }
            device.setUnknown((Map<String, Object>)list);
            jsonObjectReader.endObject();
            return device;
        }
    }

    public static enum DeviceOrientation implements JsonSerializable
    {
        PORTRAIT,
        LANDSCAPE;


        @Override
        public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
            objectWriter.value(this.toString().toLowerCase(Locale.ROOT));
        }

        public static final class Deserializer
        implements JsonDeserializer<DeviceOrientation> {
            @Override
            public DeviceOrientation deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
                return DeviceOrientation.valueOf(jsonObjectReader.nextString().toUpperCase(Locale.ROOT));
            }
        }
    }

    public static final class JsonKeys {
        public static final String ARCHS = "archs";
        public static final String BATTERY_LEVEL = "battery_level";
        public static final String BATTERY_TEMPERATURE = "battery_temperature";
        public static final String BOOT_TIME = "boot_time";
        public static final String BRAND = "brand";
        public static final String CHARGING = "charging";
        public static final String CONNECTION_TYPE = "connection_type";
        public static final String CPU_DESCRIPTION = "cpu_description";
        public static final String EXTERNAL_FREE_STORAGE = "external_free_storage";
        public static final String EXTERNAL_STORAGE_SIZE = "external_storage_size";
        public static final String FAMILY = "family";
        public static final String FREE_MEMORY = "free_memory";
        public static final String FREE_STORAGE = "free_storage";
        public static final String ID = "id";
        public static final String LANGUAGE = "language";
        public static final String LOCALE = "locale";
        public static final String LOW_MEMORY = "low_memory";
        public static final String MANUFACTURER = "manufacturer";
        public static final String MEMORY_SIZE = "memory_size";
        public static final String MODEL = "model";
        public static final String MODEL_ID = "model_id";
        public static final String NAME = "name";
        public static final String ONLINE = "online";
        public static final String ORIENTATION = "orientation";
        public static final String PROCESSOR_COUNT = "processor_count";
        public static final String PROCESSOR_FREQUENCY = "processor_frequency";
        public static final String SCREEN_DENSITY = "screen_density";
        public static final String SCREEN_DPI = "screen_dpi";
        public static final String SCREEN_HEIGHT_PIXELS = "screen_height_pixels";
        public static final String SCREEN_WIDTH_PIXELS = "screen_width_pixels";
        public static final String SIMULATOR = "simulator";
        public static final String STORAGE_SIZE = "storage_size";
        public static final String TIMEZONE = "timezone";
        public static final String USABLE_MEMORY = "usable_memory";
    }
}

