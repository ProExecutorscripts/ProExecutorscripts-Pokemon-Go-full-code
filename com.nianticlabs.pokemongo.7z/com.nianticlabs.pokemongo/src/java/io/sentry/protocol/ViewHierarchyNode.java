/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ViewHierarchyNode
implements JsonUnknown,
JsonSerializable {
    private Double alpha;
    private List<ViewHierarchyNode> children;
    private Double height;
    private String identifier;
    private String renderingSystem;
    private String tag;
    private String type;
    private Map<String, Object> unknown;
    private String visibility;
    private Double width;
    private Double x;
    private Double y;

    static /* synthetic */ String access$002(ViewHierarchyNode viewHierarchyNode, String string2) {
        viewHierarchyNode.renderingSystem = string2;
        return string2;
    }

    static /* synthetic */ List access$1002(ViewHierarchyNode viewHierarchyNode, List list) {
        viewHierarchyNode.children = list;
        return list;
    }

    static /* synthetic */ String access$102(ViewHierarchyNode viewHierarchyNode, String string2) {
        viewHierarchyNode.type = string2;
        return string2;
    }

    static /* synthetic */ String access$202(ViewHierarchyNode viewHierarchyNode, String string2) {
        viewHierarchyNode.identifier = string2;
        return string2;
    }

    static /* synthetic */ String access$302(ViewHierarchyNode viewHierarchyNode, String string2) {
        viewHierarchyNode.tag = string2;
        return string2;
    }

    static /* synthetic */ Double access$402(ViewHierarchyNode viewHierarchyNode, Double d2) {
        viewHierarchyNode.width = d2;
        return d2;
    }

    static /* synthetic */ Double access$502(ViewHierarchyNode viewHierarchyNode, Double d2) {
        viewHierarchyNode.height = d2;
        return d2;
    }

    static /* synthetic */ Double access$602(ViewHierarchyNode viewHierarchyNode, Double d2) {
        viewHierarchyNode.x = d2;
        return d2;
    }

    static /* synthetic */ Double access$702(ViewHierarchyNode viewHierarchyNode, Double d2) {
        viewHierarchyNode.y = d2;
        return d2;
    }

    static /* synthetic */ String access$802(ViewHierarchyNode viewHierarchyNode, String string2) {
        viewHierarchyNode.visibility = string2;
        return string2;
    }

    static /* synthetic */ Double access$902(ViewHierarchyNode viewHierarchyNode, Double d2) {
        viewHierarchyNode.alpha = d2;
        return d2;
    }

    public Double getAlpha() {
        return this.alpha;
    }

    public List<ViewHierarchyNode> getChildren() {
        return this.children;
    }

    public Double getHeight() {
        return this.height;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public String getRenderingSystem() {
        return this.renderingSystem;
    }

    public String getTag() {
        return this.tag;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getVisibility() {
        return this.visibility;
    }

    public Double getWidth() {
        return this.width;
    }

    public Double getX() {
        return this.x;
    }

    public Double getY() {
        return this.y;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        if (this.renderingSystem != null) {
            objectWriter.name("rendering_system").value(this.renderingSystem);
        }
        if (this.type != null) {
            objectWriter.name("type").value(this.type);
        }
        if (this.identifier != null) {
            objectWriter.name("identifier").value(this.identifier);
        }
        if (this.tag != null) {
            objectWriter.name("tag").value(this.tag);
        }
        if (this.width != null) {
            objectWriter.name("width").value((Number)this.width);
        }
        if (this.height != null) {
            objectWriter.name("height").value((Number)this.height);
        }
        if (this.x != null) {
            objectWriter.name("x").value((Number)this.x);
        }
        if (this.y != null) {
            objectWriter.name("y").value((Number)this.y);
        }
        if (this.visibility != null) {
            objectWriter.name("visibility").value(this.visibility);
        }
        if (this.alpha != null) {
            objectWriter.name("alpha").value((Number)this.alpha);
        }
        if ((object = this.children) != null && !object.isEmpty()) {
            objectWriter.name("children").value(iLogger, this.children);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setAlpha(Double d2) {
        this.alpha = d2;
    }

    public void setChildren(List<ViewHierarchyNode> list) {
        this.children = list;
    }

    public void setHeight(Double d2) {
        this.height = d2;
    }

    public void setIdentifier(String string2) {
        this.identifier = string2;
    }

    public void setRenderingSystem(String string2) {
        this.renderingSystem = string2;
    }

    public void setTag(String string2) {
        this.tag = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setVisibility(String string2) {
        this.visibility = string2;
    }

    public void setWidth(Double d2) {
        this.width = d2;
    }

    public void setX(Double d2) {
        this.x = d2;
    }

    public void setY(Double d2) {
        this.y = d2;
    }

    public static final class Deserializer
    implements JsonDeserializer<ViewHierarchyNode> {
        @Override
        public ViewHierarchyNode deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            ViewHierarchyNode viewHierarchyNode = new ViewHierarchyNode();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            block26: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1941332754: {
                        if (!string2.equals((Object)"visibility")) break;
                        n3 = 10;
                        break;
                    }
                    case 1659526655: {
                        if (!string2.equals((Object)"children")) break;
                        n3 = 9;
                        break;
                    }
                    case 113126854: {
                        if (!string2.equals((Object)"width")) break;
                        n3 = 8;
                        break;
                    }
                    case 92909918: {
                        if (!string2.equals((Object)"alpha")) break;
                        n3 = 7;
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 6;
                        break;
                    }
                    case 114586: {
                        if (!string2.equals((Object)"tag")) break;
                        n3 = 5;
                        break;
                    }
                    case 121: {
                        if (!string2.equals((Object)"y")) break;
                        n3 = 4;
                        break;
                    }
                    case 120: {
                        if (!string2.equals((Object)"x")) break;
                        n3 = 3;
                        break;
                    }
                    case -1221029593: {
                        if (!string2.equals((Object)"height")) break;
                        n3 = 2;
                        break;
                    }
                    case -1618432855: {
                        if (!string2.equals((Object)"identifier")) break;
                        n3 = 1;
                        break;
                    }
                    case -1784982718: {
                        if (!string2.equals((Object)"rendering_system")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue block26;
                    }
                    case 10: {
                        ViewHierarchyNode.access$802(viewHierarchyNode, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 9: {
                        ViewHierarchyNode.access$1002(viewHierarchyNode, jsonObjectReader.nextListOrNull(iLogger, this));
                        continue block26;
                    }
                    case 8: {
                        ViewHierarchyNode.access$402(viewHierarchyNode, jsonObjectReader.nextDoubleOrNull());
                        continue block26;
                    }
                    case 7: {
                        ViewHierarchyNode.access$902(viewHierarchyNode, jsonObjectReader.nextDoubleOrNull());
                        continue block26;
                    }
                    case 6: {
                        ViewHierarchyNode.access$102(viewHierarchyNode, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 5: {
                        ViewHierarchyNode.access$302(viewHierarchyNode, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 4: {
                        ViewHierarchyNode.access$702(viewHierarchyNode, jsonObjectReader.nextDoubleOrNull());
                        continue block26;
                    }
                    case 3: {
                        ViewHierarchyNode.access$602(viewHierarchyNode, jsonObjectReader.nextDoubleOrNull());
                        continue block26;
                    }
                    case 2: {
                        ViewHierarchyNode.access$502(viewHierarchyNode, jsonObjectReader.nextDoubleOrNull());
                        continue block26;
                    }
                    case 1: {
                        ViewHierarchyNode.access$202(viewHierarchyNode, jsonObjectReader.nextStringOrNull());
                        continue block26;
                    }
                    case 0: 
                }
                ViewHierarchyNode.access$002(viewHierarchyNode, jsonObjectReader.nextStringOrNull());
            }
            jsonObjectReader.endObject();
            viewHierarchyNode.setUnknown((Map<String, Object>)hashMap);
            return viewHierarchyNode;
        }
    }

    public static final class JsonKeys {
        public static final String ALPHA = "alpha";
        public static final String CHILDREN = "children";
        public static final String HEIGHT = "height";
        public static final String IDENTIFIER = "identifier";
        public static final String RENDERING_SYSTEM = "rendering_system";
        public static final String TAG = "tag";
        public static final String TYPE = "type";
        public static final String VISIBILITY = "visibility";
        public static final String WIDTH = "width";
        public static final String X = "x";
        public static final String Y = "y";
    }
}

