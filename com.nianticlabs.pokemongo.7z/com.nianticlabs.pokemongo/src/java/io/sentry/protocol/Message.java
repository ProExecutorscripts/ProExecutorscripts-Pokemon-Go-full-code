/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Message
implements JsonUnknown,
JsonSerializable {
    private String formatted;
    private String message;
    private List<String> params;
    private Map<String, Object> unknown;

    static /* synthetic */ String access$002(Message message, String string2) {
        message.formatted = string2;
        return string2;
    }

    static /* synthetic */ String access$102(Message message, String string2) {
        message.message = string2;
        return string2;
    }

    static /* synthetic */ List access$202(Message message, List list) {
        message.params = list;
        return list;
    }

    public String getFormatted() {
        return this.formatted;
    }

    public String getMessage() {
        return this.message;
    }

    public List<String> getParams() {
        return this.params;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.formatted != null) {
            objectWriter.name("formatted").value(this.formatted);
        }
        if (this.message != null) {
            objectWriter.name("message").value(this.message);
        }
        if ((iterator = this.params) != null && !iterator.isEmpty()) {
            objectWriter.name("params").value(iLogger, this.params);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setFormatted(String string2) {
        this.formatted = string2;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setParams(List<String> list) {
        this.params = CollectionUtils.newArrayList(list);
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<Message> {
        @Override
        public Message deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            Message message = new Message();
            List list = null;
            block10: while (jsonObjectReader.peek() == JsonToken.NAME) {
                List list2;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1811591356: {
                        if (!string2.equals((Object)"formatted")) break;
                        n3 = 2;
                        break;
                    }
                    case 954925063: {
                        if (!string2.equals((Object)"message")) break;
                        n3 = 1;
                        break;
                    }
                    case -995427962: {
                        if (!string2.equals((Object)"params")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        list2 = list;
                        if (list == null) {
                            list2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)list2, string2);
                        list = list2;
                        continue block10;
                    }
                    case 2: {
                        Message.access$002(message, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 1: {
                        Message.access$102(message, jsonObjectReader.nextStringOrNull());
                        continue block10;
                    }
                    case 0: 
                }
                list2 = (List)jsonObjectReader.nextObjectOrNull();
                if (list2 == null) continue;
                Message.access$202(message, list2);
            }
            message.setUnknown((Map<String, Object>)list);
            jsonObjectReader.endObject();
            return message;
        }
    }

    public static final class JsonKeys {
        public static final String FORMATTED = "formatted";
        public static final String MESSAGE = "message";
        public static final String PARAMS = "params";
    }
}

