/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.protocol.Mechanism;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class SentryException
implements JsonUnknown,
JsonSerializable {
    private Mechanism mechanism;
    private String module;
    private SentryStackTrace stacktrace;
    private Long threadId;
    private String type;
    private Map<String, Object> unknown;
    private String value;

    static /* synthetic */ String access$002(SentryException sentryException, String string2) {
        sentryException.type = string2;
        return string2;
    }

    static /* synthetic */ String access$102(SentryException sentryException, String string2) {
        sentryException.value = string2;
        return string2;
    }

    static /* synthetic */ String access$202(SentryException sentryException, String string2) {
        sentryException.module = string2;
        return string2;
    }

    static /* synthetic */ Long access$302(SentryException sentryException, Long l2) {
        sentryException.threadId = l2;
        return l2;
    }

    static /* synthetic */ SentryStackTrace access$402(SentryException sentryException, SentryStackTrace sentryStackTrace) {
        sentryException.stacktrace = sentryStackTrace;
        return sentryStackTrace;
    }

    static /* synthetic */ Mechanism access$502(SentryException sentryException, Mechanism mechanism) {
        sentryException.mechanism = mechanism;
        return mechanism;
    }

    public Mechanism getMechanism() {
        return this.mechanism;
    }

    public String getModule() {
        return this.module;
    }

    public SentryStackTrace getStacktrace() {
        return this.stacktrace;
    }

    public Long getThreadId() {
        return this.threadId;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getValue() {
        return this.value;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        if (this.type != null) {
            objectWriter.name("type").value(this.type);
        }
        if (this.value != null) {
            objectWriter.name("value").value(this.value);
        }
        if (this.module != null) {
            objectWriter.name("module").value(this.module);
        }
        if (this.threadId != null) {
            objectWriter.name("thread_id").value((Number)this.threadId);
        }
        if (this.stacktrace != null) {
            objectWriter.name("stacktrace").value(iLogger, this.stacktrace);
        }
        if (this.mechanism != null) {
            objectWriter.name("mechanism").value(iLogger, this.mechanism);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setMechanism(Mechanism mechanism) {
        this.mechanism = mechanism;
    }

    public void setModule(String string2) {
        this.module = string2;
    }

    public void setStacktrace(SentryStackTrace sentryStackTrace) {
        this.stacktrace = sentryStackTrace;
    }

    public void setThreadId(Long l2) {
        this.threadId = l2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setValue(String string2) {
        this.value = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryException> {
        @Override
        public SentryException deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SentryException sentryException = new SentryException();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            block16: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2055832509: {
                        if (!string2.equals((Object)"stacktrace")) break;
                        n3 = 5;
                        break;
                    }
                    case 1225089881: {
                        if (!string2.equals((Object)"mechanism")) break;
                        n3 = 4;
                        break;
                    }
                    case 111972721: {
                        if (!string2.equals((Object)"value")) break;
                        n3 = 3;
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 2;
                        break;
                    }
                    case -1068784020: {
                        if (!string2.equals((Object)"module")) break;
                        n3 = 1;
                        break;
                    }
                    case -1562235024: {
                        if (!string2.equals((Object)"thread_id")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue block16;
                    }
                    case 5: {
                        SentryException.access$402(sentryException, jsonObjectReader.nextOrNull(iLogger, new SentryStackTrace.Deserializer()));
                        continue block16;
                    }
                    case 4: {
                        SentryException.access$502(sentryException, jsonObjectReader.nextOrNull(iLogger, new Mechanism.Deserializer()));
                        continue block16;
                    }
                    case 3: {
                        SentryException.access$102(sentryException, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 2: {
                        SentryException.access$002(sentryException, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 1: {
                        SentryException.access$202(sentryException, jsonObjectReader.nextStringOrNull());
                        continue block16;
                    }
                    case 0: 
                }
                SentryException.access$302(sentryException, jsonObjectReader.nextLongOrNull());
            }
            jsonObjectReader.endObject();
            sentryException.setUnknown((Map<String, Object>)hashMap);
            return sentryException;
        }
    }

    public static final class JsonKeys {
        public static final String MECHANISM = "mechanism";
        public static final String MODULE = "module";
        public static final String STACKTRACE = "stacktrace";
        public static final String THREAD_ID = "thread_id";
        public static final String TYPE = "type";
        public static final String VALUE = "value";
    }
}

