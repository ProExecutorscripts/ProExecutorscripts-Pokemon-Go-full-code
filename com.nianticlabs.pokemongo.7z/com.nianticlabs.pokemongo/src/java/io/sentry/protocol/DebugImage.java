/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 */
package io.sentry.protocol;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class DebugImage
implements JsonUnknown,
JsonSerializable {
    public static final String JVM = "jvm";
    public static final String PROGUARD = "proguard";
    private String arch;
    private String codeFile;
    private String codeId;
    private String debugFile;
    private String debugId;
    private String imageAddr;
    private Long imageSize;
    private String type;
    private Map<String, Object> unknown;
    private String uuid;

    static /* synthetic */ String access$002(DebugImage debugImage, String string2) {
        debugImage.uuid = string2;
        return string2;
    }

    static /* synthetic */ String access$102(DebugImage debugImage, String string2) {
        debugImage.type = string2;
        return string2;
    }

    static /* synthetic */ String access$202(DebugImage debugImage, String string2) {
        debugImage.debugId = string2;
        return string2;
    }

    static /* synthetic */ String access$302(DebugImage debugImage, String string2) {
        debugImage.debugFile = string2;
        return string2;
    }

    static /* synthetic */ String access$402(DebugImage debugImage, String string2) {
        debugImage.codeId = string2;
        return string2;
    }

    static /* synthetic */ String access$502(DebugImage debugImage, String string2) {
        debugImage.codeFile = string2;
        return string2;
    }

    static /* synthetic */ String access$602(DebugImage debugImage, String string2) {
        debugImage.imageAddr = string2;
        return string2;
    }

    static /* synthetic */ Long access$702(DebugImage debugImage, Long l2) {
        debugImage.imageSize = l2;
        return l2;
    }

    static /* synthetic */ String access$802(DebugImage debugImage, String string2) {
        debugImage.arch = string2;
        return string2;
    }

    public String getArch() {
        return this.arch;
    }

    public String getCodeFile() {
        return this.codeFile;
    }

    public String getCodeId() {
        return this.codeId;
    }

    public String getDebugFile() {
        return this.debugFile;
    }

    public String getDebugId() {
        return this.debugId;
    }

    public String getImageAddr() {
        return this.imageAddr;
    }

    public Long getImageSize() {
        return this.imageSize;
    }

    public String getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getUuid() {
        return this.uuid;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        if (this.uuid != null) {
            objectWriter.name("uuid").value(this.uuid);
        }
        if (this.type != null) {
            objectWriter.name("type").value(this.type);
        }
        if (this.debugId != null) {
            objectWriter.name("debug_id").value(this.debugId);
        }
        if (this.debugFile != null) {
            objectWriter.name("debug_file").value(this.debugFile);
        }
        if (this.codeId != null) {
            objectWriter.name("code_id").value(this.codeId);
        }
        if (this.codeFile != null) {
            objectWriter.name("code_file").value(this.codeFile);
        }
        if (this.imageAddr != null) {
            objectWriter.name("image_addr").value(this.imageAddr);
        }
        if (this.imageSize != null) {
            objectWriter.name("image_size").value((Number)this.imageSize);
        }
        if (this.arch != null) {
            objectWriter.name("arch").value(this.arch);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setArch(String string2) {
        this.arch = string2;
    }

    public void setCodeFile(String string2) {
        this.codeFile = string2;
    }

    public void setCodeId(String string2) {
        this.codeId = string2;
    }

    public void setDebugFile(String string2) {
        this.debugFile = string2;
    }

    public void setDebugId(String string2) {
        this.debugId = string2;
    }

    public void setImageAddr(String string2) {
        this.imageAddr = string2;
    }

    public void setImageSize(long l2) {
        this.imageSize = l2;
    }

    public void setImageSize(Long l2) {
        this.imageSize = l2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public void setUuid(String string2) {
        this.uuid = string2;
    }

    public static final class Deserializer
    implements JsonDeserializer<DebugImage> {
        @Override
        public DebugImage deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            DebugImage debugImage = new DebugImage();
            jsonObjectReader.beginObject();
            HashMap hashMap = null;
            block22: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 941842605: {
                        if (!string2.equals((Object)"code_id")) break;
                        n3 = 8;
                        break;
                    }
                    case 547804807: {
                        if (!string2.equals((Object)"debug_id")) break;
                        n3 = 7;
                        break;
                    }
                    case 3601339: {
                        if (!string2.equals((Object)"uuid")) break;
                        n3 = 6;
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 5;
                        break;
                    }
                    case 3002454: {
                        if (!string2.equals((Object)"arch")) break;
                        n3 = 4;
                        break;
                    }
                    case -1127437170: {
                        if (!string2.equals((Object)"code_file")) break;
                        n3 = 3;
                        break;
                    }
                    case -1442803611: {
                        if (!string2.equals((Object)"image_size")) break;
                        n3 = 2;
                        break;
                    }
                    case -1443345323: {
                        if (!string2.equals((Object)"image_addr")) break;
                        n3 = 1;
                        break;
                    }
                    case -1840639000: {
                        if (!string2.equals((Object)"debug_file")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        HashMap hashMap2 = hashMap;
                        if (hashMap == null) {
                            hashMap2 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)hashMap2, string2);
                        hashMap = hashMap2;
                        continue block22;
                    }
                    case 8: {
                        DebugImage.access$402(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 7: {
                        DebugImage.access$202(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 6: {
                        DebugImage.access$002(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 5: {
                        DebugImage.access$102(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 4: {
                        DebugImage.access$802(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 3: {
                        DebugImage.access$502(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 2: {
                        DebugImage.access$702(debugImage, jsonObjectReader.nextLongOrNull());
                        continue block22;
                    }
                    case 1: {
                        DebugImage.access$602(debugImage, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 0: 
                }
                DebugImage.access$302(debugImage, jsonObjectReader.nextStringOrNull());
            }
            jsonObjectReader.endObject();
            debugImage.setUnknown((Map<String, Object>)hashMap);
            return debugImage;
        }
    }

    public static final class JsonKeys {
        public static final String ARCH = "arch";
        public static final String CODE_FILE = "code_file";
        public static final String CODE_ID = "code_id";
        public static final String DEBUG_FILE = "debug_file";
        public static final String DEBUG_ID = "debug_id";
        public static final String IMAGE_ADDR = "image_addr";
        public static final String IMAGE_SIZE = "image_size";
        public static final String TYPE = "type";
        public static final String UUID = "uuid";
    }
}

