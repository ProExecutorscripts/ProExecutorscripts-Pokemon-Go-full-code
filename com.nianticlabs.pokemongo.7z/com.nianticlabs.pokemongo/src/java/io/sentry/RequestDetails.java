/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URI
 *  java.net.URL
 *  java.util.Map
 */
package io.sentry;

import io.sentry.util.Objects;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Map;

public final class RequestDetails {
    private final Map<String, String> headers;
    private final URL url;

    public RequestDetails(String string2, Map<String, String> map2) {
        Objects.requireNonNull(string2, "url is required");
        Objects.requireNonNull(map2, "headers is required");
        try {
            this.url = URI.create((String)string2).toURL();
            this.headers = map2;
            return;
        }
        catch (MalformedURLException malformedURLException) {
            throw new IllegalArgumentException("Failed to compose the Sentry's server URL.", (Throwable)malformedURLException);
        }
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    public URL getUrl() {
        return this.url;
    }
}

