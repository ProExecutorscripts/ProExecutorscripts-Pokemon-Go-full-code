/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry;

import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.HostnameCache;
import io.sentry.JsonSerializable;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.SentryExceptionFactory;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryStackTraceFactory;
import io.sentry.SentryThreadFactory;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.Cached;
import io.sentry.protocol.DebugImage;
import io.sentry.protocol.DebugMeta;
import io.sentry.protocol.SentryException;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class MainEventProcessor
implements EventProcessor,
Closeable {
    private volatile HostnameCache hostnameCache = null;
    private final SentryOptions options;
    private final SentryExceptionFactory sentryExceptionFactory;
    private final SentryThreadFactory sentryThreadFactory;

    public MainEventProcessor(SentryOptions sentryOptions) {
        this.options = sentryOptions = Objects.requireNonNull(sentryOptions, "The SentryOptions is required.");
        SentryStackTraceFactory sentryStackTraceFactory = new SentryStackTraceFactory(sentryOptions);
        this.sentryExceptionFactory = new SentryExceptionFactory(sentryStackTraceFactory);
        this.sentryThreadFactory = new SentryThreadFactory(sentryStackTraceFactory, sentryOptions);
    }

    MainEventProcessor(SentryOptions sentryOptions, SentryThreadFactory sentryThreadFactory, SentryExceptionFactory sentryExceptionFactory) {
        this.options = Objects.requireNonNull(sentryOptions, "The SentryOptions is required.");
        this.sentryThreadFactory = Objects.requireNonNull(sentryThreadFactory, "The SentryThreadFactory is required.");
        this.sentryExceptionFactory = Objects.requireNonNull(sentryExceptionFactory, "The SentryExceptionFactory is required.");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void ensureHostnameCache() {
        if (this.hostnameCache != null) return;
        MainEventProcessor mainEventProcessor = this;
        synchronized (mainEventProcessor) {
            if (this.hostnameCache != null) return;
            this.hostnameCache = HostnameCache.getInstance();
            return;
        }
    }

    private boolean isCachedHint(Hint hint) {
        return HintUtils.hasType(hint, Cached.class);
    }

    private void mergeUser(SentryBaseEvent sentryBaseEvent) {
        User user;
        User user2 = user = sentryBaseEvent.getUser();
        if (user == null) {
            user2 = new User();
            sentryBaseEvent.setUser(user2);
        }
        if (user2.getIpAddress() == null) {
            user2.setIpAddress("{{auto}}");
        }
    }

    private void processNonCachedEvent(SentryBaseEvent sentryBaseEvent) {
        this.setRelease(sentryBaseEvent);
        this.setEnvironment(sentryBaseEvent);
        this.setServerName(sentryBaseEvent);
        this.setDist(sentryBaseEvent);
        this.setSdk(sentryBaseEvent);
        this.setTags(sentryBaseEvent);
        this.mergeUser(sentryBaseEvent);
    }

    private void setCommons(SentryBaseEvent sentryBaseEvent) {
        this.setPlatform(sentryBaseEvent);
    }

    private void setDebugMeta(SentryBaseEvent sentryBaseEvent) {
        JsonSerializable jsonSerializable;
        JsonSerializable jsonSerializable2;
        ArrayList arrayList = new ArrayList();
        if (this.options.getProguardUuid() != null) {
            jsonSerializable2 = new DebugImage();
            ((DebugImage)jsonSerializable2).setType("proguard");
            ((DebugImage)jsonSerializable2).setUuid(this.options.getProguardUuid());
            arrayList.add((Object)jsonSerializable2);
        }
        for (String string2 : this.options.getBundleIds()) {
            jsonSerializable = new DebugImage();
            ((DebugImage)jsonSerializable).setType("jvm");
            ((DebugImage)jsonSerializable).setDebugId(string2);
            arrayList.add((Object)jsonSerializable);
        }
        if (!arrayList.isEmpty()) {
            jsonSerializable2 = jsonSerializable = sentryBaseEvent.getDebugMeta();
            if (jsonSerializable == null) {
                jsonSerializable2 = new DebugMeta();
            }
            if (((DebugMeta)jsonSerializable2).getImages() == null) {
                ((DebugMeta)jsonSerializable2).setImages((List<DebugImage>)arrayList);
            } else {
                ((DebugMeta)jsonSerializable2).getImages().addAll((Collection)arrayList);
            }
            sentryBaseEvent.setDebugMeta((DebugMeta)jsonSerializable2);
        }
    }

    private void setDist(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getDist() == null) {
            sentryBaseEvent.setDist(this.options.getDist());
        }
    }

    private void setEnvironment(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getEnvironment() == null) {
            sentryBaseEvent.setEnvironment(this.options.getEnvironment());
        }
    }

    private void setExceptions(SentryEvent sentryEvent) {
        Throwable throwable = sentryEvent.getThrowableMechanism();
        if (throwable != null) {
            sentryEvent.setExceptions(this.sentryExceptionFactory.getSentryExceptions(throwable));
        }
    }

    private void setModules(SentryEvent sentryEvent) {
        Map<String, String> map2 = this.options.getModulesLoader().getOrLoadModules();
        if (map2 == null) {
            return;
        }
        Map<String, String> map3 = sentryEvent.getModules();
        if (map3 == null) {
            sentryEvent.setModules(map2);
        } else {
            map3.putAll(map2);
        }
    }

    private void setPlatform(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getPlatform() == null) {
            sentryBaseEvent.setPlatform("java");
        }
    }

    private void setRelease(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getRelease() == null) {
            sentryBaseEvent.setRelease(this.options.getRelease());
        }
    }

    private void setSdk(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getSdk() == null) {
            sentryBaseEvent.setSdk(this.options.getSdkVersion());
        }
    }

    private void setServerName(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getServerName() == null) {
            sentryBaseEvent.setServerName(this.options.getServerName());
        }
        if (this.options.isAttachServerName() && sentryBaseEvent.getServerName() == null) {
            this.ensureHostnameCache();
            if (this.hostnameCache != null) {
                sentryBaseEvent.setServerName(this.hostnameCache.getHostname());
            }
        }
    }

    private void setTags(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getTags() == null) {
            sentryBaseEvent.setTags((Map<String, String>)new HashMap(this.options.getTags()));
        } else {
            for (Map.Entry entry : this.options.getTags().entrySet()) {
                if (sentryBaseEvent.getTags().containsKey(entry.getKey())) continue;
                sentryBaseEvent.setTag((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }

    private void setThreads(SentryEvent sentryEvent, Hint object) {
        if (sentryEvent.getThreads() == null) {
            List<SentryException> list = sentryEvent.getExceptions();
            Iterator iterator = null;
            Iterator iterator2 = null;
            Iterator iterator3 = iterator;
            if (list != null) {
                iterator3 = iterator;
                if (!list.isEmpty()) {
                    iterator = list.iterator();
                    while (true) {
                        iterator3 = iterator2;
                        if (!iterator.hasNext()) break;
                        SentryException sentryException = (SentryException)iterator.next();
                        if (sentryException.getMechanism() == null || sentryException.getThreadId() == null) continue;
                        iterator3 = iterator2;
                        if (iterator2 == null) {
                            iterator3 = new ArrayList();
                        }
                        iterator3.add((Object)sentryException.getThreadId());
                        iterator2 = iterator3;
                    }
                }
            }
            if (!this.options.isAttachThreads() && !HintUtils.hasType((Hint)object, AbnormalExit.class)) {
                if (this.options.isAttachStacktrace() && (list == null || list.isEmpty()) && !this.isCachedHint((Hint)object)) {
                    sentryEvent.setThreads(this.sentryThreadFactory.getCurrentThread());
                }
            } else {
                boolean bl = (object = HintUtils.getSentrySdkHint((Hint)object)) instanceof AbnormalExit ? ((AbnormalExit)object).ignoreCurrentThread() : false;
                sentryEvent.setThreads(this.sentryThreadFactory.getCurrentThreads((List<Long>)iterator3, bl));
            }
        }
    }

    private boolean shouldApplyScopeData(SentryBaseEvent sentryBaseEvent, Hint hint) {
        if (HintUtils.shouldApplyScopeData(hint)) {
            return true;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Event was cached so not applying data relevant to the current app execution/version: %s", sentryBaseEvent.getEventId());
        return false;
    }

    public void close() throws IOException {
        if (this.hostnameCache != null) {
            this.hostnameCache.close();
        }
    }

    HostnameCache getHostnameCache() {
        return this.hostnameCache;
    }

    boolean isClosed() {
        if (this.hostnameCache != null) {
            return this.hostnameCache.isClosed();
        }
        return true;
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        this.setCommons(sentryEvent);
        this.setExceptions(sentryEvent);
        this.setDebugMeta(sentryEvent);
        this.setModules(sentryEvent);
        if (this.shouldApplyScopeData(sentryEvent, hint)) {
            this.processNonCachedEvent(sentryEvent);
            this.setThreads(sentryEvent, hint);
        }
        return sentryEvent;
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        this.setCommons(sentryTransaction);
        this.setDebugMeta(sentryTransaction);
        if (this.shouldApplyScopeData(sentryTransaction, hint)) {
            this.processNonCachedEvent(sentryTransaction);
        }
        return sentryTransaction;
    }
}

