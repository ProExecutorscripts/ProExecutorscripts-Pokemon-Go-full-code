/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.List
 */
package io.sentry;

import io.sentry.ITransaction;
import io.sentry.ITransactionProfiler;
import io.sentry.PerformanceCollectionData;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryOptions;
import java.util.List;

public final class NoOpTransactionProfiler
implements ITransactionProfiler {
    private static final NoOpTransactionProfiler instance = new NoOpTransactionProfiler();

    private NoOpTransactionProfiler() {
    }

    public static NoOpTransactionProfiler getInstance() {
        return instance;
    }

    @Override
    public void bindTransaction(ITransaction iTransaction) {
    }

    @Override
    public void close() {
    }

    @Override
    public boolean isRunning() {
        return false;
    }

    @Override
    public ProfilingTraceData onTransactionFinish(ITransaction iTransaction, List<PerformanceCollectionData> list, SentryOptions sentryOptions) {
        return null;
    }

    @Override
    public void start() {
    }
}

