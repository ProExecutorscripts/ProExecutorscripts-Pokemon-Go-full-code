/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.Span;
import io.sentry.util.LazyEvaluator;

public final class Span$$ExternalSyntheticLambda0
implements LazyEvaluator.Evaluator {
    public final Object evaluate() {
        return Span.lambda$new$0();
    }
}

