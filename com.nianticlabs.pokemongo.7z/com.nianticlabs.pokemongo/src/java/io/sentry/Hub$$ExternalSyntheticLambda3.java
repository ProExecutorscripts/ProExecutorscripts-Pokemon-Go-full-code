/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry;

import io.sentry.Hub;
import io.sentry.ISentryExecutorService;

public final class Hub$$ExternalSyntheticLambda3
implements Runnable {
    public final Hub f$0;
    public final ISentryExecutorService f$1;

    public /* synthetic */ Hub$$ExternalSyntheticLambda3(Hub hub, ISentryExecutorService iSentryExecutorService) {
        this.f$0 = hub;
        this.f$1 = iSentryExecutorService;
    }

    public final void run() {
        this.f$0.lambda$close$1$io-sentry-Hub(this.f$1);
    }
}

