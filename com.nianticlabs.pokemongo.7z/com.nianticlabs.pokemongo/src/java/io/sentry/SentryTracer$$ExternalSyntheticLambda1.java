/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.SentryTracer;
import io.sentry.Span;
import io.sentry.SpanFinishedCallback;

public final class SentryTracer$$ExternalSyntheticLambda1
implements SpanFinishedCallback {
    public final SentryTracer f$0;

    public /* synthetic */ SentryTracer$$ExternalSyntheticLambda1(SentryTracer sentryTracer) {
        this.f$0 = sentryTracer;
    }

    @Override
    public final void execute(Span span) {
        this.f$0.lambda$createChild$2$io-sentry-SentryTracer(span);
    }
}

