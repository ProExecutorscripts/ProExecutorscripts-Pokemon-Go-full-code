/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.System
 *  java.util.Date
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.SentryDate;
import java.util.Date;

public final class SentryNanotimeDate
extends SentryDate {
    private final Date date;
    private final long nanos;

    public SentryNanotimeDate() {
        this(DateUtils.getCurrentDateTime(), System.nanoTime());
    }

    public SentryNanotimeDate(Date date, long l2) {
        this.date = date;
        this.nanos = l2;
    }

    private long nanotimeDiff(SentryNanotimeDate sentryNanotimeDate, SentryNanotimeDate sentryNanotimeDate2) {
        long l2 = sentryNanotimeDate2.nanos;
        long l3 = sentryNanotimeDate.nanos;
        return sentryNanotimeDate.nanoTimestamp() + (l2 - l3);
    }

    @Override
    public int compareTo(SentryDate sentryDate) {
        if (sentryDate instanceof SentryNanotimeDate) {
            long l2;
            sentryDate = (SentryNanotimeDate)sentryDate;
            long l3 = this.date.getTime();
            if (l3 == (l2 = ((SentryNanotimeDate)sentryDate).date.getTime())) {
                return Long.valueOf((long)this.nanos).compareTo(Long.valueOf((long)((SentryNanotimeDate)sentryDate).nanos));
            }
            return Long.valueOf((long)l3).compareTo(Long.valueOf((long)l2));
        }
        return super.compareTo(sentryDate);
    }

    @Override
    public long diff(SentryDate sentryDate) {
        if (sentryDate instanceof SentryNanotimeDate) {
            sentryDate = (SentryNanotimeDate)sentryDate;
            return this.nanos - ((SentryNanotimeDate)sentryDate).nanos;
        }
        return super.diff(sentryDate);
    }

    @Override
    public long laterDateNanosTimestampByDiff(SentryDate sentryDate) {
        if (sentryDate != null && sentryDate instanceof SentryNanotimeDate) {
            SentryNanotimeDate sentryNanotimeDate = (SentryNanotimeDate)sentryDate;
            if (this.compareTo(sentryDate) < 0) {
                return this.nanotimeDiff(this, sentryNanotimeDate);
            }
            return this.nanotimeDiff(sentryNanotimeDate, this);
        }
        return super.laterDateNanosTimestampByDiff(sentryDate);
    }

    @Override
    public long nanoTimestamp() {
        return DateUtils.dateToNanos(this.date);
    }
}

