/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.util.concurrent.Callable
 *  java.util.function.Supplier
 */
package io.sentry;

import io.sentry.IHub;
import io.sentry.Sentry;
import io.sentry.SentryWrapper$$ExternalSyntheticLambda0;
import io.sentry.SentryWrapper$$ExternalSyntheticLambda1;
import java.util.concurrent.Callable;
import java.util.function.Supplier;

public final class SentryWrapper {
    static /* synthetic */ Object lambda$wrapCallable$0(IHub object, Callable callable) throws Exception {
        IHub iHub = Sentry.getCurrentHub();
        Sentry.setCurrentHub((IHub)object);
        try {
            object = callable.call();
            return object;
        }
        finally {
            Sentry.setCurrentHub(iHub);
        }
    }

    static /* synthetic */ Object lambda$wrapSupplier$1(IHub object, Supplier supplier) {
        IHub iHub = Sentry.getCurrentHub();
        Sentry.setCurrentHub((IHub)object);
        try {
            object = supplier.get();
            return object;
        }
        finally {
            Sentry.setCurrentHub(iHub);
        }
    }

    public static <U> Callable<U> wrapCallable(Callable<U> callable) {
        return new SentryWrapper$$ExternalSyntheticLambda1(Sentry.getCurrentHub().clone(), callable);
    }

    public static <U> Supplier<U> wrapSupplier(Supplier<U> supplier) {
        return new SentryWrapper$$ExternalSyntheticLambda0(Sentry.getCurrentHub().clone(), supplier);
    }
}

