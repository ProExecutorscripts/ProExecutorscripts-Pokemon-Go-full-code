/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.BufferedWriter
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.Attachment;
import io.sentry.CheckIn;
import io.sentry.ILogger;
import io.sentry.ISerializer;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda0;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda1;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda10;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda11;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda12;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda13;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda14;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda15;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda16;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda17;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda18;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda19;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda2;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda20;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda21;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda22;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda23;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda3;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda4;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda5;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda6;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda7;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda8;
import io.sentry.SentryEnvelopeItem$$ExternalSyntheticLambda9;
import io.sentry.SentryEnvelopeItemHeader;
import io.sentry.SentryEvent;
import io.sentry.SentryItemType;
import io.sentry.Session;
import io.sentry.UserFeedback;
import io.sentry.clientreport.ClientReport;
import io.sentry.exception.SentryEnvelopeException;
import io.sentry.metrics.EncodedMetrics;
import io.sentry.protocol.SentryTransaction;
import io.sentry.util.FileUtils;
import io.sentry.util.JsonSerializationUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.Base64;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private byte[] data;
    private final Callable<byte[]> dataFactory;
    private final SentryEnvelopeItemHeader header;

    SentryEnvelopeItem(SentryEnvelopeItemHeader sentryEnvelopeItemHeader, Callable<byte[]> callable) {
        this.header = Objects.requireNonNull(sentryEnvelopeItemHeader, "SentryEnvelopeItemHeader is required.");
        this.dataFactory = Objects.requireNonNull(callable, "DataFactory is required.");
        this.data = null;
    }

    SentryEnvelopeItem(SentryEnvelopeItemHeader sentryEnvelopeItemHeader, byte[] byArray) {
        this.header = Objects.requireNonNull(sentryEnvelopeItemHeader, "SentryEnvelopeItemHeader is required.");
        this.data = byArray;
        this.dataFactory = null;
    }

    private static void ensureAttachmentSizeLimit(long l2, long l3, String string2) throws SentryEnvelopeException {
        if (l2 <= l3) {
            return;
        }
        throw new SentryEnvelopeException(String.format((String)"Dropping attachment with filename '%s', because the size of the passed bytes with %d bytes is bigger than the maximum allowed attachment size of %d bytes.", (Object[])new Object[]{string2, l2, l3}));
    }

    public static SentryEnvelopeItem fromAttachment(ISerializer object, ILogger iLogger, Attachment attachment, long l2) {
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda6(attachment, l2, (ISerializer)object, iLogger));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.Attachment, new SentryEnvelopeItem$$ExternalSyntheticLambda7((CachedItem)object), attachment.getContentType(), attachment.getFilename(), attachment.getAttachmentType()), new SentryEnvelopeItem$$ExternalSyntheticLambda8((CachedItem)object));
    }

    public static SentryEnvelopeItem fromCheckIn(ISerializer object, CheckIn checkIn) {
        Objects.requireNonNull(object, "ISerializer is required.");
        Objects.requireNonNull(checkIn, "CheckIn is required.");
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda17((ISerializer)object, checkIn));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.CheckIn, new SentryEnvelopeItem$$ExternalSyntheticLambda18((CachedItem)object), "application/json", null), new SentryEnvelopeItem$$ExternalSyntheticLambda19((CachedItem)object));
    }

    public static SentryEnvelopeItem fromClientReport(ISerializer object, ClientReport clientReport) throws IOException {
        Objects.requireNonNull(object, "ISerializer is required.");
        Objects.requireNonNull(clientReport, "ClientReport is required.");
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda9((ISerializer)object, clientReport));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.resolve(clientReport), new SentryEnvelopeItem$$ExternalSyntheticLambda10((CachedItem)object), "application/json", null), new SentryEnvelopeItem$$ExternalSyntheticLambda12((CachedItem)object));
    }

    public static SentryEnvelopeItem fromEvent(ISerializer object, SentryBaseEvent sentryBaseEvent) throws IOException {
        Objects.requireNonNull(object, "ISerializer is required.");
        Objects.requireNonNull(sentryBaseEvent, "SentryEvent is required.");
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda0((ISerializer)object, sentryBaseEvent));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.resolve(sentryBaseEvent), new SentryEnvelopeItem$$ExternalSyntheticLambda11((CachedItem)object), "application/json", null), new SentryEnvelopeItem$$ExternalSyntheticLambda16((CachedItem)object));
    }

    public static SentryEnvelopeItem fromMetrics(EncodedMetrics object) {
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda3((EncodedMetrics)object));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.Statsd, new SentryEnvelopeItem$$ExternalSyntheticLambda4((CachedItem)object), "application/octet-stream", null), new SentryEnvelopeItem$$ExternalSyntheticLambda5((CachedItem)object));
    }

    public static SentryEnvelopeItem fromProfilingTrace(ProfilingTraceData object, long l2, ISerializer iSerializer) throws SentryEnvelopeException {
        File file = ((ProfilingTraceData)object).getTraceFile();
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda13(file, l2, (ProfilingTraceData)object, iSerializer));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.Profile, new SentryEnvelopeItem$$ExternalSyntheticLambda14((CachedItem)object), "application-json", file.getName()), new SentryEnvelopeItem$$ExternalSyntheticLambda15((CachedItem)object));
    }

    public static SentryEnvelopeItem fromSession(ISerializer object, Session session) throws IOException {
        Objects.requireNonNull(object, "ISerializer is required.");
        Objects.requireNonNull(session, "Session is required.");
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda23((ISerializer)object, session));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.Session, new SentryEnvelopeItem$$ExternalSyntheticLambda1((CachedItem)object), "application/json", null), new SentryEnvelopeItem$$ExternalSyntheticLambda2((CachedItem)object));
    }

    public static SentryEnvelopeItem fromUserFeedback(ISerializer object, UserFeedback userFeedback) {
        Objects.requireNonNull(object, "ISerializer is required.");
        Objects.requireNonNull(userFeedback, "UserFeedback is required.");
        object = new CachedItem(new SentryEnvelopeItem$$ExternalSyntheticLambda20((ISerializer)object, userFeedback));
        return new SentryEnvelopeItem(new SentryEnvelopeItemHeader(SentryItemType.UserFeedback, new SentryEnvelopeItem$$ExternalSyntheticLambda21((CachedItem)object), "application/json", null), new SentryEnvelopeItem$$ExternalSyntheticLambda22((CachedItem)object));
    }

    static /* synthetic */ byte[] lambda$fromAttachment$15(Attachment attachment, long l2, ISerializer object, ILogger iLogger) throws Exception {
        if (attachment.getBytes() != null) {
            object = attachment.getBytes();
            SentryEnvelopeItem.ensureAttachmentSizeLimit(((Object)object).length, l2, attachment.getFilename());
            return object;
        }
        if (attachment.getSerializable() != null) {
            if ((object = (Object)JsonSerializationUtils.bytesFrom((ISerializer)object, iLogger, attachment.getSerializable())) != null) {
                SentryEnvelopeItem.ensureAttachmentSizeLimit(((Object)object).length, l2, attachment.getFilename());
                return object;
            }
        } else if (attachment.getPathname() != null) {
            return FileUtils.readBytesFromFile(attachment.getPathname(), l2);
        }
        throw new SentryEnvelopeException(String.format((String)"Couldn't attach the attachment %s.\nPlease check that either bytes, serializable or a path is set.", (Object[])new Object[]{attachment.getFilename()}));
    }

    static /* synthetic */ Integer lambda$fromAttachment$16(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromAttachment$17(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    static /* synthetic */ Integer lambda$fromCheckIn$10(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromCheckIn$11(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    /*
     * Exception decompiling
     */
    static /* synthetic */ byte[] lambda$fromCheckIn$9(ISerializer var0, CheckIn var1_3) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:63)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    static /* synthetic */ byte[] lambda$fromClientReport$21(ISerializer var0, ClientReport var1_3) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:63)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static /* synthetic */ Integer lambda$fromClientReport$22(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromClientReport$23(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    /*
     * Exception decompiling
     */
    static /* synthetic */ byte[] lambda$fromEvent$3(ISerializer var0, SentryBaseEvent var1_3) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:63)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static /* synthetic */ Integer lambda$fromEvent$4(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromEvent$5(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    static /* synthetic */ byte[] lambda$fromMetrics$12(EncodedMetrics encodedMetrics) throws Exception {
        return encodedMetrics.encodeToStatsd();
    }

    static /* synthetic */ Integer lambda$fromMetrics$13(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromMetrics$14(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static /* synthetic */ byte[] lambda$fromProfilingTrace$18(File file, long l2, ProfilingTraceData object, ISerializer iSerializer) throws Exception {
        Throwable throwable622222;
        block17: {
            if (!file.exists()) {
                throw new SentryEnvelopeException(String.format((String)"Dropping profiling trace data, because the file '%s' doesn't exists", (Object[])new Object[]{file.getName()}));
            }
            String string2 = Base64.encodeToString(FileUtils.readBytesFromFile(file.getPath(), l2), 3);
            if (string2.isEmpty()) throw new SentryEnvelopeException("Profiling trace file is empty");
            object.setSampledProfile(string2);
            object.readDeviceCpuFrequencies();
            string2 = new ByteArrayOutputStream();
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)string2, UTF_8);
            BufferedWriter bufferedWriter = new BufferedWriter((Writer)outputStreamWriter);
            iSerializer.serialize(object, (Writer)bufferedWriter);
            object = string2.toByteArray();
            bufferedWriter.close();
            string2.close();
            file.delete();
            return object;
            catch (Throwable throwable2) {
                try {
                    bufferedWriter.close();
                    throw throwable2;
                }
                catch (Throwable throwable3) {
                    try {
                        throwable2.addSuppressed(throwable3);
                        throw throwable2;
                    }
                    catch (Throwable throwable4) {
                        try {
                            string2.close();
                            throw throwable4;
                        }
                        catch (Throwable throwable5) {
                            try {
                                throwable4.addSuppressed(throwable5);
                                throw throwable4;
                            }
                            catch (Throwable throwable622222) {
                                break block17;
                            }
                            catch (IOException iOException) {
                                object = new SentryEnvelopeException(String.format((String)"Failed to serialize profiling trace data\n%s", (Object[])new Object[]{iOException.getMessage()}));
                                throw object;
                            }
                        }
                    }
                }
            }
        }
        file.delete();
        throw throwable622222;
    }

    static /* synthetic */ Integer lambda$fromProfilingTrace$19(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromProfilingTrace$20(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    /*
     * Exception decompiling
     */
    static /* synthetic */ byte[] lambda$fromSession$0(ISerializer var0, Session var1_3) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:63)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static /* synthetic */ Integer lambda$fromSession$1(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromSession$2(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    /*
     * Exception decompiling
     */
    static /* synthetic */ byte[] lambda$fromUserFeedback$6(ISerializer var0, UserFeedback var1_3) throws Exception {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:63)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static /* synthetic */ Integer lambda$fromUserFeedback$7(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes().length;
    }

    static /* synthetic */ byte[] lambda$fromUserFeedback$8(CachedItem cachedItem) throws Exception {
        return cachedItem.getBytes();
    }

    public ClientReport getClientReport(ISerializer object) throws Exception {
        SentryEnvelopeItemHeader sentryEnvelopeItemHeader = this.header;
        if (sentryEnvelopeItemHeader != null && sentryEnvelopeItemHeader.getType() == SentryItemType.ClientReport) {
            sentryEnvelopeItemHeader = new BufferedReader((Reader)new InputStreamReader((InputStream)new ByteArrayInputStream(this.getData()), UTF_8));
            try {
                object = object.deserialize((Reader)sentryEnvelopeItemHeader, ClientReport.class);
                return object;
            }
            finally {
                sentryEnvelopeItemHeader.close();
            }
        }
        return null;
    }

    public byte[] getData() throws Exception {
        Callable<byte[]> callable;
        if (this.data == null && (callable = this.dataFactory) != null) {
            this.data = (byte[])callable.call();
        }
        return this.data;
    }

    public SentryEvent getEvent(ISerializer object) throws Exception {
        SentryEnvelopeItemHeader sentryEnvelopeItemHeader = this.header;
        if (sentryEnvelopeItemHeader != null && sentryEnvelopeItemHeader.getType() == SentryItemType.Event) {
            sentryEnvelopeItemHeader = new BufferedReader((Reader)new InputStreamReader((InputStream)new ByteArrayInputStream(this.getData()), UTF_8));
            try {
                object = object.deserialize((Reader)sentryEnvelopeItemHeader, SentryEvent.class);
                return object;
            }
            finally {
                sentryEnvelopeItemHeader.close();
            }
        }
        return null;
    }

    public SentryEnvelopeItemHeader getHeader() {
        return this.header;
    }

    public SentryTransaction getTransaction(ISerializer object) throws Exception {
        SentryEnvelopeItemHeader sentryEnvelopeItemHeader = this.header;
        if (sentryEnvelopeItemHeader != null && sentryEnvelopeItemHeader.getType() == SentryItemType.Transaction) {
            sentryEnvelopeItemHeader = new BufferedReader((Reader)new InputStreamReader((InputStream)new ByteArrayInputStream(this.getData()), UTF_8));
            try {
                object = object.deserialize((Reader)sentryEnvelopeItemHeader, SentryTransaction.class);
                return object;
            }
            finally {
                sentryEnvelopeItemHeader.close();
            }
        }
        return null;
    }

    private static class CachedItem {
        private byte[] bytes;
        private final Callable<byte[]> dataFactory;

        public CachedItem(Callable<byte[]> callable) {
            this.dataFactory = callable;
        }

        private static byte[] orEmptyArray(byte[] byArray) {
            if (byArray == null) {
                byArray = new byte[]{};
            }
            return byArray;
        }

        public byte[] getBytes() throws Exception {
            Callable<byte[]> callable;
            if (this.bytes == null && (callable = this.dataFactory) != null) {
                this.bytes = (byte[])callable.call();
            }
            return CachedItem.orEmptyArray(this.bytes);
        }
    }
}

