/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

public final class BuildConfig {
    public static final String SENTRY_JAVA_SDK_NAME = "sentry.java";
    public static final String VERSION_NAME = "7.8.0";

    private BuildConfig() {
    }
}

