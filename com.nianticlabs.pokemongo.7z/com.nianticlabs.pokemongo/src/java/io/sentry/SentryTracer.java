/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.Map
 *  java.util.Timer
 *  java.util.TimerTask
 *  java.util.concurrent.CopyOnWriteArrayList
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry;

import io.sentry.Baggage;
import io.sentry.BaggageHeader;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.IScope;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.Instrumenter;
import io.sentry.MeasurementUnit;
import io.sentry.NoOpSpan;
import io.sentry.PerformanceCollectionData;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryDate;
import io.sentry.SentryLevel;
import io.sentry.SentryTraceHeader;
import io.sentry.SentryTracer$$ExternalSyntheticLambda0;
import io.sentry.SentryTracer$$ExternalSyntheticLambda1;
import io.sentry.SentryTracer$$ExternalSyntheticLambda2;
import io.sentry.SentryTracer$$ExternalSyntheticLambda3;
import io.sentry.Span;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.TracesSamplingDecision;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.TransactionPerformanceCollector;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.protocol.User;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryTracer
implements ITransaction {
    private final Baggage baggage;
    private final List<Span> children;
    private final Contexts contexts;
    private volatile TimerTask deadlineTimeoutTask;
    private final SentryId eventId = new SentryId();
    private FinishStatus finishStatus;
    private final IHub hub;
    private volatile TimerTask idleTimeoutTask;
    private final Instrumenter instrumenter;
    private final AtomicBoolean isDeadlineTimerRunning;
    private final AtomicBoolean isIdleFinishTimerRunning;
    private String name;
    private final Span root;
    private volatile Timer timer = null;
    private final Object timerLock;
    private TransactionNameSource transactionNameSource;
    private final TransactionOptions transactionOptions;
    private final TransactionPerformanceCollector transactionPerformanceCollector;

    public SentryTracer(TransactionContext transactionContext, IHub iHub) {
        this(transactionContext, iHub, new TransactionOptions(), null);
    }

    public SentryTracer(TransactionContext transactionContext, IHub iHub, TransactionOptions transactionOptions) {
        this(transactionContext, iHub, transactionOptions, null);
    }

    SentryTracer(TransactionContext transactionContext, IHub iHub, TransactionOptions transactionOptions, TransactionPerformanceCollector transactionPerformanceCollector) {
        this.children = new CopyOnWriteArrayList();
        this.finishStatus = FinishStatus.NOT_FINISHED;
        this.timerLock = new Object();
        this.isIdleFinishTimerRunning = new AtomicBoolean(false);
        this.isDeadlineTimerRunning = new AtomicBoolean(false);
        this.contexts = new Contexts();
        Objects.requireNonNull(transactionContext, "context is required");
        Objects.requireNonNull(iHub, "hub is required");
        this.root = new Span(transactionContext, this, iHub, transactionOptions.getStartTimestamp(), transactionOptions);
        this.name = transactionContext.getName();
        this.instrumenter = transactionContext.getInstrumenter();
        this.hub = iHub;
        this.transactionPerformanceCollector = transactionPerformanceCollector;
        this.transactionNameSource = transactionContext.getTransactionNameSource();
        this.transactionOptions = transactionOptions;
        this.baggage = transactionContext.getBaggage() != null ? transactionContext.getBaggage() : new Baggage(iHub.getOptions().getLogger());
        if (transactionPerformanceCollector != null && Boolean.TRUE.equals((Object)this.isProfileSampled())) {
            transactionPerformanceCollector.start(this);
        }
        if (transactionOptions.getIdleTimeout() != null || transactionOptions.getDeadlineTimeout() != null) {
            this.timer = new Timer(true);
            this.scheduleDeadlineTimeout();
            this.scheduleFinish();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void cancelDeadlineTimer() {
        Object object;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            if (this.deadlineTimeoutTask != null) {
                this.deadlineTimeoutTask.cancel();
                this.isDeadlineTimerRunning.set(false);
                this.deadlineTimeoutTask = null;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void cancelIdleTimer() {
        Object object;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            if (this.idleTimeoutTask != null) {
                this.idleTimeoutTask.cancel();
                this.isIdleFinishTimerRunning.set(false);
                this.idleTimeoutTask = null;
            }
            return;
        }
    }

    private ISpan createChild(SpanId object, String object2, String string2, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        if (this.root.isFinished()) {
            return NoOpSpan.getInstance();
        }
        if (!this.instrumenter.equals((Object)instrumenter)) {
            return NoOpSpan.getInstance();
        }
        if (this.children.size() < this.hub.getOptions().getMaxSpans()) {
            Objects.requireNonNull(object, "parentSpanId is required");
            Objects.requireNonNull(object2, "operation is required");
            this.cancelIdleTimer();
            object2 = new Span(this.root.getTraceId(), (SpanId)object, this, (String)object2, this.hub, sentryDate, spanOptions, new SentryTracer$$ExternalSyntheticLambda1(this));
            ((Span)object2).setDescription(string2);
            ((Span)object2).setData("thread.id", String.valueOf((long)Thread.currentThread().getId()));
            object = this.hub.getOptions().getMainThreadChecker().isMainThread() ? "main" : Thread.currentThread().getName();
            ((Span)object2).setData("thread.name", object);
            this.children.add(object2);
            object = this.transactionPerformanceCollector;
            if (object != null) {
                object.onSpanStarted((ISpan)object2);
            }
            return object2;
        }
        this.hub.getOptions().getLogger().log(SentryLevel.WARNING, "Span operation: %s, description: %s dropped due to limit reached. Returning NoOpSpan.", object2, string2);
        return NoOpSpan.getInstance();
    }

    private ISpan createChild(SpanId spanId, String string2, String string3, SpanOptions spanOptions) {
        return this.createChild(spanId, string2, string3, null, Instrumenter.SENTRY, spanOptions);
    }

    private ISpan createChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        if (this.root.isFinished()) {
            return NoOpSpan.getInstance();
        }
        if (!this.instrumenter.equals((Object)instrumenter)) {
            return NoOpSpan.getInstance();
        }
        if (this.children.size() < this.hub.getOptions().getMaxSpans()) {
            return this.root.startChild(string2, string3, sentryDate, instrumenter, spanOptions);
        }
        this.hub.getOptions().getLogger().log(SentryLevel.WARNING, "Span operation: %s, description: %s dropped due to limit reached. Returning NoOpSpan.", string2, string3);
        return NoOpSpan.getInstance();
    }

    private boolean hasAllChildrenFinished() {
        ArrayList arrayList = new ArrayList(this.children);
        if (!arrayList.isEmpty()) {
            arrayList = arrayList.iterator();
            while (arrayList.hasNext()) {
                if (((Span)arrayList.next()).isFinished()) continue;
                return false;
            }
        }
        return true;
    }

    static /* synthetic */ void lambda$updateBaggageValues$3(AtomicReference atomicReference, IScope iScope) {
        atomicReference.set((Object)iScope.getUser());
    }

    private void onDeadlineTimeoutReached() {
        SpanStatus spanStatus = this.getStatus();
        if (spanStatus == null) {
            spanStatus = SpanStatus.DEADLINE_EXCEEDED;
        }
        boolean bl = this.transactionOptions.getIdleTimeout() != null;
        this.forceFinish(spanStatus, bl, null);
        this.isDeadlineTimerRunning.set(false);
    }

    private void onIdleTimeoutReached() {
        SpanStatus spanStatus = this.getStatus();
        if (spanStatus == null) {
            spanStatus = SpanStatus.OK;
        }
        this.finish(spanStatus);
        this.isIdleFinishTimerRunning.set(false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void scheduleDeadlineTimeout() {
        Object object;
        Long l2 = this.transactionOptions.getDeadlineTimeout();
        if (l2 == null) return;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            TimerTask timerTask;
            if (this.timer == null) return;
            this.cancelDeadlineTimer();
            this.isDeadlineTimerRunning.set(true);
            this.deadlineTimeoutTask = timerTask = new TimerTask(this){
                final SentryTracer this$0;
                {
                    this.this$0 = sentryTracer;
                }

                public void run() {
                    this.this$0.onDeadlineTimeoutReached();
                }
            };
            try {
                this.timer.schedule(this.deadlineTimeoutTask, l2.longValue());
            }
            catch (Throwable throwable) {
                this.hub.getOptions().getLogger().log(SentryLevel.WARNING, "Failed to schedule finish timer", throwable);
                this.onDeadlineTimeoutReached();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void updateBaggageValues() {
        SentryTracer sentryTracer = this;
        synchronized (sentryTracer) {
            if (this.baggage.isMutable()) {
                AtomicReference atomicReference = new AtomicReference();
                IHub iHub = this.hub;
                SentryTracer$$ExternalSyntheticLambda3 sentryTracer$$ExternalSyntheticLambda3 = new SentryTracer$$ExternalSyntheticLambda3(atomicReference);
                iHub.configureScope(sentryTracer$$ExternalSyntheticLambda3);
                this.baggage.setValuesFromTransaction(this, (User)atomicReference.get(), this.hub.getOptions(), this.getSamplingDecision());
                this.baggage.freeze();
            }
            return;
        }
    }

    @Override
    public void finish() {
        this.finish(this.getStatus());
    }

    @Override
    public void finish(SpanStatus spanStatus) {
        this.finish(spanStatus, null);
    }

    @Override
    public void finish(SpanStatus spanStatus, SentryDate sentryDate) {
        this.finish(spanStatus, sentryDate, true, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void finish(SpanStatus object, SentryDate object2, boolean bl, Hint hint) {
        Object object3 = this.root.getFinishDate();
        if (object2 == null) {
            object2 = object3;
        }
        object3 = object2;
        if (object2 == null) {
            object3 = this.hub.getOptions().getDateProvider().now();
        }
        for (Span span : this.children) {
            if (!span.getOptions().isIdle()) continue;
            object2 = object != null ? object : this.getSpanContext().status;
            span.finish((SpanStatus)object2, (SentryDate)object3);
        }
        this.finishStatus = FinishStatus.finishing((SpanStatus)object);
        if (!(this.root.isFinished() || this.transactionOptions.isWaitForChildren() && !this.hasAllChildrenFinished())) {
            object = this.transactionPerformanceCollector;
            object2 = object != null ? object.stop(this) : null;
            object = Boolean.TRUE.equals((Object)this.isSampled()) && Boolean.TRUE.equals((Object)this.isProfileSampled()) ? this.hub.getOptions().getTransactionProfiler().onTransactionFinish(this, (List<PerformanceCollectionData>)object2, this.hub.getOptions()) : null;
            if (object2 != null) {
                object2.clear();
            }
            this.root.finish(this.finishStatus.spanStatus, (SentryDate)object3);
            this.hub.configureScope(new SentryTracer$$ExternalSyntheticLambda0(this));
            object3 = new SentryTransaction(this);
            object2 = this.transactionOptions.getTransactionFinishedCallback();
            if (object2 != null) {
                object2.execute(this);
            }
            if (this.timer != null) {
                Object object4 = object2 = this.timerLock;
                synchronized (object4) {
                    if (this.timer != null) {
                        this.cancelIdleTimer();
                        this.cancelDeadlineTimer();
                        this.timer.cancel();
                        this.timer = null;
                    }
                }
            }
            if (bl && this.children.isEmpty() && this.transactionOptions.getIdleTimeout() != null) {
                this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "Dropping idle transaction %s because it has no child spans", this.name);
                return;
            }
            ((SentryTransaction)object3).getMeasurements().putAll(this.root.getMeasurements());
            this.hub.captureTransaction((SentryTransaction)object3, this.traceContext(), hint, (ProfilingTraceData)object);
        }
    }

    @Override
    public void forceFinish(SpanStatus spanStatus, boolean bl, Hint hint) {
        if (this.isFinished()) {
            return;
        }
        SentryDate sentryDate = this.hub.getOptions().getDateProvider().now();
        ListIterator listIterator = this.children;
        listIterator = listIterator.listIterator(listIterator.size());
        while (listIterator.hasPrevious()) {
            Span span = (Span)listIterator.previous();
            span.setSpanFinishedCallback(null);
            span.finish(spanStatus, sentryDate);
        }
        this.finish(spanStatus, sentryDate, bl, hint);
    }

    public List<Span> getChildren() {
        return this.children;
    }

    @Override
    public Contexts getContexts() {
        return this.contexts;
    }

    @Override
    public Object getData(String string2) {
        return this.root.getData(string2);
    }

    public Map<String, Object> getData() {
        return this.root.getData();
    }

    TimerTask getDeadlineTimeoutTask() {
        return this.deadlineTimeoutTask;
    }

    @Override
    public String getDescription() {
        return this.root.getDescription();
    }

    @Override
    public SentryId getEventId() {
        return this.eventId;
    }

    @Override
    public SentryDate getFinishDate() {
        return this.root.getFinishDate();
    }

    TimerTask getIdleTimeoutTask() {
        return this.idleTimeoutTask;
    }

    @Override
    public Span getLatestActiveSpan() {
        ArrayList arrayList = new ArrayList(this.children);
        if (!arrayList.isEmpty()) {
            for (int i2 = arrayList.size() - 1; i2 >= 0; --i2) {
                if (((Span)arrayList.get(i2)).isFinished()) continue;
                return (Span)arrayList.get(i2);
            }
        }
        return null;
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        return this.root.getLocalMetricsAggregator();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getOperation() {
        return this.root.getOperation();
    }

    Span getRoot() {
        return this.root;
    }

    @Override
    public TracesSamplingDecision getSamplingDecision() {
        return this.root.getSamplingDecision();
    }

    @Override
    public SpanContext getSpanContext() {
        return this.root.getSpanContext();
    }

    @Override
    public List<Span> getSpans() {
        return this.children;
    }

    @Override
    public SentryDate getStartDate() {
        return this.root.getStartDate();
    }

    @Override
    public SpanStatus getStatus() {
        return this.root.getStatus();
    }

    @Override
    public String getTag(String string2) {
        return this.root.getTag(string2);
    }

    @Override
    public Throwable getThrowable() {
        return this.root.getThrowable();
    }

    Timer getTimer() {
        return this.timer;
    }

    @Override
    public TransactionNameSource getTransactionNameSource() {
        return this.transactionNameSource;
    }

    AtomicBoolean isDeadlineTimerRunning() {
        return this.isDeadlineTimerRunning;
    }

    AtomicBoolean isFinishTimerRunning() {
        return this.isIdleFinishTimerRunning;
    }

    @Override
    public boolean isFinished() {
        return this.root.isFinished();
    }

    @Override
    public boolean isNoOp() {
        return false;
    }

    @Override
    public Boolean isProfileSampled() {
        return this.root.isProfileSampled();
    }

    @Override
    public Boolean isSampled() {
        return this.root.isSampled();
    }

    /* synthetic */ void lambda$createChild$2$io-sentry-SentryTracer(Span object) {
        TransactionPerformanceCollector transactionPerformanceCollector = this.transactionPerformanceCollector;
        if (transactionPerformanceCollector != null) {
            transactionPerformanceCollector.onSpanFinished((ISpan)object);
        }
        object = this.finishStatus;
        if (this.transactionOptions.getIdleTimeout() != null) {
            if (!this.transactionOptions.isWaitForChildren() || this.hasAllChildrenFinished()) {
                this.scheduleFinish();
            }
        } else if (((FinishStatus)object).isFinishing) {
            this.finish(((FinishStatus)object).spanStatus);
        }
    }

    /* synthetic */ void lambda$finish$0$io-sentry-SentryTracer(IScope iScope, ITransaction iTransaction) {
        if (iTransaction == this) {
            iScope.clearTransaction();
        }
    }

    /* synthetic */ void lambda$finish$1$io-sentry-SentryTracer(IScope iScope) {
        iScope.withTransaction(new SentryTracer$$ExternalSyntheticLambda2(this, iScope));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void scheduleFinish() {
        Object object;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            Long l2;
            if (this.timer != null && (l2 = this.transactionOptions.getIdleTimeout()) != null) {
                TimerTask timerTask;
                this.cancelIdleTimer();
                this.isIdleFinishTimerRunning.set(true);
                this.idleTimeoutTask = timerTask = new TimerTask(this){
                    final SentryTracer this$0;
                    {
                        this.this$0 = sentryTracer;
                    }

                    public void run() {
                        this.this$0.onIdleTimeoutReached();
                    }
                };
                try {
                    this.timer.schedule(this.idleTimeoutTask, l2.longValue());
                }
                catch (Throwable throwable) {
                    this.hub.getOptions().getLogger().log(SentryLevel.WARNING, "Failed to schedule finish timer", throwable);
                    this.onIdleTimeoutReached();
                }
            }
            return;
        }
    }

    @Override
    public void setContext(String string2, Object object) {
        this.contexts.put(string2, object);
    }

    @Override
    public void setData(String string2, Object object) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Data %s cannot be set", string2);
            return;
        }
        this.root.setData(string2, object);
    }

    @Override
    public void setDescription(String string2) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Description %s cannot be set", string2);
            return;
        }
        this.root.setDescription(string2);
    }

    @Override
    public void setMeasurement(String string2, Number number) {
        this.root.setMeasurement(string2, number);
    }

    @Override
    public void setMeasurement(String string2, Number number, MeasurementUnit measurementUnit) {
        this.root.setMeasurement(string2, number, measurementUnit);
    }

    public void setMeasurementFromChild(String string2, Number number) {
        if (!this.root.getMeasurements().containsKey((Object)string2)) {
            this.setMeasurement(string2, number);
        }
    }

    public void setMeasurementFromChild(String string2, Number number, MeasurementUnit measurementUnit) {
        if (!this.root.getMeasurements().containsKey((Object)string2)) {
            this.setMeasurement(string2, number, measurementUnit);
        }
    }

    @Override
    public void setName(String string2) {
        this.setName(string2, TransactionNameSource.CUSTOM);
    }

    @Override
    public void setName(String string2, TransactionNameSource transactionNameSource) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Name %s cannot be set", string2);
            return;
        }
        this.name = string2;
        this.transactionNameSource = transactionNameSource;
    }

    @Override
    public void setOperation(String string2) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Operation %s cannot be set", string2);
            return;
        }
        this.root.setOperation(string2);
    }

    @Override
    public void setStatus(SpanStatus object) {
        if (this.root.isFinished()) {
            ILogger iLogger = this.hub.getOptions().getLogger();
            SentryLevel sentryLevel = SentryLevel.DEBUG;
            object = object == null ? "null" : object.name();
            iLogger.log(sentryLevel, "The transaction is already finished. Status %s cannot be set", object);
            return;
        }
        this.root.setStatus((SpanStatus)object);
    }

    @Override
    public void setTag(String string2, String string3) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Tag %s cannot be set", string2);
            return;
        }
        this.root.setTag(string2, string3);
    }

    @Override
    public void setThrowable(Throwable throwable) {
        if (this.root.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The transaction is already finished. Throwable cannot be set", new Object[0]);
            return;
        }
        this.root.setThrowable(throwable);
    }

    ISpan startChild(SpanId spanId, String string2, String string3) {
        return this.startChild(spanId, string2, string3, new SpanOptions());
    }

    ISpan startChild(SpanId spanId, String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter) {
        return this.createChild(spanId, string2, string3, sentryDate, instrumenter, new SpanOptions());
    }

    ISpan startChild(SpanId spanId, String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        return this.createChild(spanId, string2, string3, sentryDate, instrumenter, spanOptions);
    }

    ISpan startChild(SpanId spanId, String string2, String string3, SpanOptions spanOptions) {
        return this.createChild(spanId, string2, string3, spanOptions);
    }

    @Override
    public ISpan startChild(String string2) {
        String string3 = null;
        return this.startChild(string2, null);
    }

    @Override
    public ISpan startChild(String string2, String string3) {
        return this.startChild(string2, string3, null, Instrumenter.SENTRY, new SpanOptions());
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate) {
        return this.createChild(string2, string3, sentryDate, Instrumenter.SENTRY, new SpanOptions());
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter) {
        return this.startChild(string2, string3, sentryDate, instrumenter, new SpanOptions());
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        return this.createChild(string2, string3, sentryDate, instrumenter, spanOptions);
    }

    @Override
    public ISpan startChild(String string2, String string3, SpanOptions spanOptions) {
        return this.createChild(string2, string3, null, Instrumenter.SENTRY, spanOptions);
    }

    @Override
    public BaggageHeader toBaggageHeader(List<String> list) {
        if (this.hub.getOptions().isTraceSampling()) {
            this.updateBaggageValues();
            return BaggageHeader.fromBaggageAndOutgoingHeader(this.baggage, list);
        }
        return null;
    }

    @Override
    public SentryTraceHeader toSentryTrace() {
        return this.root.toSentryTrace();
    }

    @Override
    public TraceContext traceContext() {
        if (this.hub.getOptions().isTraceSampling()) {
            this.updateBaggageValues();
            return this.baggage.toTraceContext();
        }
        return null;
    }

    @Override
    public boolean updateEndDate(SentryDate sentryDate) {
        return this.root.updateEndDate(sentryDate);
    }

    private static final class FinishStatus {
        static final FinishStatus NOT_FINISHED = FinishStatus.notFinished();
        private final boolean isFinishing;
        private final SpanStatus spanStatus;

        private FinishStatus(boolean bl, SpanStatus spanStatus) {
            this.isFinishing = bl;
            this.spanStatus = spanStatus;
        }

        static FinishStatus finishing(SpanStatus spanStatus) {
            return new FinishStatus(true, spanStatus);
        }

        private static FinishStatus notFinished() {
            return new FinishStatus(false, null);
        }
    }
}

