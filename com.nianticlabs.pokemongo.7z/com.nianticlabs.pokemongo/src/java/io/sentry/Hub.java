/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.DataCategory;
import io.sentry.Hint;
import io.sentry.Hub$$ExternalSyntheticLambda0;
import io.sentry.Hub$$ExternalSyntheticLambda1;
import io.sentry.Hub$$ExternalSyntheticLambda2;
import io.sentry.Hub$$ExternalSyntheticLambda3;
import io.sentry.IHub;
import io.sentry.IMetricsAggregator;
import io.sentry.IScope;
import io.sentry.ISentryClient;
import io.sentry.ISentryExecutorService;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.Integration;
import io.sentry.NoOpScope;
import io.sentry.NoOpSentryClient;
import io.sentry.NoOpTransaction;
import io.sentry.ProfilingTraceData;
import io.sentry.PropagationContext;
import io.sentry.SamplingContext;
import io.sentry.Scope;
import io.sentry.ScopeCallback;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryClient;
import io.sentry.SentryCrashLastRunState;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryTraceHeader;
import io.sentry.SentryTracer;
import io.sentry.Session;
import io.sentry.SpanContext;
import io.sentry.Stack;
import io.sentry.TraceContext;
import io.sentry.TracesSampler;
import io.sentry.TracesSamplingDecision;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.TransactionPerformanceCollector;
import io.sentry.UserFeedback;
import io.sentry.clientreport.DiscardReason;
import io.sentry.hints.SessionEndHint;
import io.sentry.hints.SessionStartHint;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.metrics.MetricsApi;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.transport.RateLimiter;
import io.sentry.util.ExceptionUtils;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import io.sentry.util.Pair;
import io.sentry.util.TracingUtils;
import java.io.Closeable;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class Hub
implements IHub,
MetricsApi.IMetricsInterface {
    private volatile boolean isEnabled;
    private volatile SentryId lastEventId;
    private final MetricsApi metricsApi;
    private final SentryOptions options;
    private final Stack stack;
    private final Map<Throwable, Pair<WeakReference<ISpan>, String>> throwableToSpan = Collections.synchronizedMap((Map)new WeakHashMap());
    private final TracesSampler tracesSampler;
    private final TransactionPerformanceCollector transactionPerformanceCollector;

    public Hub(SentryOptions sentryOptions) {
        this(sentryOptions, Hub.createRootStackItem(sentryOptions));
    }

    private Hub(SentryOptions sentryOptions, Stack.StackItem stackItem) {
        this(sentryOptions, new Stack(sentryOptions.getLogger(), stackItem));
    }

    private Hub(SentryOptions sentryOptions, Stack stack) {
        Hub.validateOptions(sentryOptions);
        this.options = sentryOptions;
        this.tracesSampler = new TracesSampler(sentryOptions);
        this.stack = stack;
        this.lastEventId = SentryId.EMPTY_ID;
        this.transactionPerformanceCollector = sentryOptions.getTransactionPerformanceCollector();
        this.isEnabled = true;
        this.metricsApi = new MetricsApi(this);
    }

    private void assignTraceContext(SentryEvent sentryEvent) {
        Object object;
        if (this.options.isTracingEnabled() && sentryEvent.getThrowable() != null && (object = (Pair)this.throwableToSpan.get((Object)ExceptionUtils.findRootCause(sentryEvent.getThrowable()))) != null) {
            Object object2 = (WeakReference)((Pair)object).getFirst();
            if (sentryEvent.getContexts().getTrace() == null && object2 != null && (object2 = (ISpan)object2.get()) != null) {
                sentryEvent.getContexts().setTrace(object2.getSpanContext());
            }
            object = (String)((Pair)object).getSecond();
            if (sentryEvent.getTransaction() == null && object != null) {
                sentryEvent.setTransaction((String)object);
            }
        }
    }

    private IScope buildLocalScope(IScope iScope, ScopeCallback scopeCallback) {
        if (scopeCallback != null) {
            try {
                IScope iScope2 = iScope.clone();
                scopeCallback.run(iScope2);
                return iScope2;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'ScopeCallback' callback.", throwable);
            }
        }
        return iScope;
    }

    private SentryId captureEventInternal(SentryEvent sentryEvent, Hint object, ScopeCallback object2) {
        Object object3;
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureEvent' call is a no-op.", new Object[0]);
            object3 = sentryId;
        } else if (sentryEvent == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "captureEvent called with null parameter.", new Object[0]);
            object3 = sentryId;
        } else {
            object3 = sentryId;
            this.assignTraceContext(sentryEvent);
            object3 = sentryId;
            Stack.StackItem stackItem = this.stack.peek();
            object3 = sentryId;
            object2 = this.buildLocalScope(stackItem.getScope(), (ScopeCallback)object2);
            object3 = sentryId;
            object3 = object = stackItem.getClient().captureEvent(sentryEvent, (IScope)object2, (Hint)object);
            try {
                this.lastEventId = object;
                object3 = object;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing event with id: " + sentryEvent.getEventId(), throwable);
            }
        }
        return object3;
    }

    private SentryId captureExceptionInternal(Throwable object, Hint object2, ScopeCallback object3) {
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureException' call is a no-op.", new Object[0]);
            object = sentryId;
        } else if (object == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "captureException called with null parameter.", new Object[0]);
            object = sentryId;
        } else {
            try {
                Stack.StackItem stackItem = this.stack.peek();
                SentryEvent sentryEvent = new SentryEvent((Throwable)object);
                this.assignTraceContext(sentryEvent);
                object3 = this.buildLocalScope(stackItem.getScope(), (ScopeCallback)object3);
                object2 = stackItem.getClient().captureEvent(sentryEvent, (IScope)object3, (Hint)object2);
                object = object2;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing exception: " + object.getMessage(), throwable);
                object = sentryId;
            }
        }
        this.lastEventId = object;
        return object;
    }

    private SentryId captureMessageInternal(String object, SentryLevel jsonSerializable, ScopeCallback object2) {
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureMessage' call is a no-op.", new Object[0]);
            object = sentryId;
        } else if (object == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "captureMessage called with null parameter.", new Object[0]);
            object = sentryId;
        } else {
            try {
                Stack.StackItem stackItem = this.stack.peek();
                object2 = this.buildLocalScope(stackItem.getScope(), (ScopeCallback)object2);
                jsonSerializable = stackItem.getClient().captureMessage((String)object, (SentryLevel)jsonSerializable, (IScope)object2);
                object = jsonSerializable;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing message: " + (String)object, throwable);
                object = sentryId;
            }
        }
        this.lastEventId = object;
        return object;
    }

    private static Stack.StackItem createRootStackItem(SentryOptions sentryOptions) {
        Hub.validateOptions(sentryOptions);
        Scope scope2 = new Scope(sentryOptions);
        return new Stack.StackItem(sentryOptions, new SentryClient(sentryOptions), scope2);
    }

    private ITransaction createTransaction(TransactionContext object, TransactionOptions transactionOptions) {
        Objects.requireNonNull(object, "transactionContext is required");
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'startTransaction' returns a no-op.", new Object[0]);
            object = NoOpTransaction.getInstance();
        } else if (!this.options.getInstrumenter().equals((Object)((TransactionContext)object).getInstrumenter())) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Returning no-op for instrumenter %s as the SDK has been configured to use instrumenter %s", new Object[]{((TransactionContext)object).getInstrumenter(), this.options.getInstrumenter()});
            object = NoOpTransaction.getInstance();
        } else if (!this.options.isTracingEnabled()) {
            this.options.getLogger().log(SentryLevel.INFO, "Tracing is disabled and this 'startTransaction' returns a no-op.", new Object[0]);
            object = NoOpTransaction.getInstance();
        } else {
            Object object2 = new SamplingContext((TransactionContext)object, transactionOptions.getCustomSamplingContext());
            object2 = this.tracesSampler.sample((SamplingContext)object2);
            ((SpanContext)object).setSamplingDecision((TracesSamplingDecision)object2);
            object = new SentryTracer((TransactionContext)object, this, transactionOptions, this.transactionPerformanceCollector);
            if (((TracesSamplingDecision)object2).getSampled().booleanValue() && ((TracesSamplingDecision)object2).getProfileSampled().booleanValue()) {
                object2 = this.options.getTransactionProfiler();
                if (!object2.isRunning()) {
                    object2.start();
                    object2.bindTransaction((ITransaction)object);
                } else if (transactionOptions.isAppStartTransaction()) {
                    object2.bindTransaction((ITransaction)object);
                }
            }
        }
        if (transactionOptions.isBindToScope()) {
            this.configureScope(new Hub$$ExternalSyntheticLambda1((ITransaction)object));
        }
        return object;
    }

    static /* synthetic */ void lambda$close$0(IScope iScope) {
        iScope.clear();
    }

    static /* synthetic */ void lambda$continueTrace$3(PropagationContext propagationContext, IScope iScope) {
        iScope.setPropagationContext(propagationContext);
    }

    static /* synthetic */ void lambda$createTransaction$2(ITransaction iTransaction, IScope iScope) {
        iScope.setTransaction(iTransaction);
    }

    private static void validateOptions(SentryOptions sentryOptions) {
        Objects.requireNonNull(sentryOptions, "SentryOptions is required.");
        if (sentryOptions.getDsn() != null && !sentryOptions.getDsn().isEmpty()) {
            return;
        }
        throw new IllegalArgumentException("Hub requires a DSN to be instantiated. Considering using the NoOpHub if no DSN is available.");
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
        this.addBreadcrumb(breadcrumb, new Hint());
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb, Hint hint) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'addBreadcrumb' call is a no-op.", new Object[0]);
        } else if (breadcrumb == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "addBreadcrumb called with null parameter.", new Object[0]);
        } else {
            this.stack.peek().getScope().addBreadcrumb(breadcrumb, hint);
        }
    }

    @Override
    public void bindClient(ISentryClient iSentryClient) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'bindClient' call is a no-op.", new Object[0]);
        } else {
            Stack.StackItem stackItem = this.stack.peek();
            if (iSentryClient != null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "New client bound to scope.", new Object[0]);
                stackItem.setClient(iSentryClient);
            } else {
                this.options.getLogger().log(SentryLevel.DEBUG, "NoOp client bound to scope.", new Object[0]);
                stackItem.setClient(NoOpSentryClient.getInstance());
            }
        }
    }

    @Override
    public SentryId captureCheckIn(CheckIn jsonSerializable) {
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureCheckIn' call is a no-op.", new Object[0]);
            jsonSerializable = sentryId;
        } else {
            try {
                Stack.StackItem stackItem = this.stack.peek();
                jsonSerializable = stackItem.getClient().captureCheckIn((CheckIn)jsonSerializable, stackItem.getScope(), null);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing check-in for slug", throwable);
                jsonSerializable = sentryId;
            }
        }
        this.lastEventId = jsonSerializable;
        return jsonSerializable;
    }

    @Override
    public SentryId captureEnvelope(SentryEnvelope object, Hint object2) {
        Objects.requireNonNull(object, "SentryEnvelope is required.");
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureEnvelope' call is a no-op.", new Object[0]);
            object = sentryId;
        } else {
            try {
                object2 = this.stack.peek().getClient().captureEnvelope((SentryEnvelope)object, (Hint)object2);
                object = sentryId;
                if (object2 != null) {
                    object = object2;
                }
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing envelope.", throwable);
                object = sentryId;
            }
        }
        return object;
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint) {
        return this.captureEventInternal(sentryEvent, hint, null);
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint, ScopeCallback scopeCallback) {
        return this.captureEventInternal(sentryEvent, hint, scopeCallback);
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint) {
        return this.captureExceptionInternal(throwable, hint, null);
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint, ScopeCallback scopeCallback) {
        return this.captureExceptionInternal(throwable, hint, scopeCallback);
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel) {
        return this.captureMessageInternal(string2, sentryLevel, null);
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel, ScopeCallback scopeCallback) {
        return this.captureMessageInternal(string2, sentryLevel, scopeCallback);
    }

    @Override
    public SentryId captureTransaction(SentryTransaction jsonSerializable, TraceContext jsonSerializable2, Hint hint, ProfilingTraceData profilingTraceData) {
        Objects.requireNonNull(jsonSerializable, "transaction is required");
        SentryId sentryId = SentryId.EMPTY_ID;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureTransaction' call is a no-op.", new Object[0]);
            jsonSerializable = sentryId;
        } else if (!((SentryTransaction)jsonSerializable).isFinished()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Transaction: %s is not finished and this 'captureTransaction' call is a no-op.", ((SentryBaseEvent)((Object)jsonSerializable)).getEventId());
            jsonSerializable = sentryId;
        } else if (!Boolean.TRUE.equals((Object)((SentryTransaction)jsonSerializable).isSampled())) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Transaction %s was dropped due to sampling decision.", ((SentryBaseEvent)((Object)jsonSerializable)).getEventId());
            if (this.options.getBackpressureMonitor().getDownsampleFactor() > 0) {
                this.options.getClientReportRecorder().recordLostEvent(DiscardReason.BACKPRESSURE, DataCategory.Transaction);
                jsonSerializable = sentryId;
            } else {
                this.options.getClientReportRecorder().recordLostEvent(DiscardReason.SAMPLE_RATE, DataCategory.Transaction);
                jsonSerializable = sentryId;
            }
        } else {
            try {
                Stack.StackItem stackItem = this.stack.peek();
                jsonSerializable2 = stackItem.getClient().captureTransaction((SentryTransaction)jsonSerializable, (TraceContext)jsonSerializable2, stackItem.getScope(), hint, profilingTraceData);
                jsonSerializable = jsonSerializable2;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing transaction with id: " + ((SentryBaseEvent)((Object)jsonSerializable)).getEventId(), throwable);
                jsonSerializable = sentryId;
            }
        }
        return jsonSerializable;
    }

    @Override
    public void captureUserFeedback(UserFeedback userFeedback) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'captureUserFeedback' call is a no-op.", new Object[0]);
        } else {
            try {
                this.stack.peek().getClient().captureUserFeedback(userFeedback);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error while capturing captureUserFeedback: " + userFeedback.toString(), throwable);
            }
        }
    }

    @Override
    public void clearBreadcrumbs() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'clearBreadcrumbs' call is a no-op.", new Object[0]);
        } else {
            this.stack.peek().getScope().clearBreadcrumbs();
        }
    }

    @Override
    public IHub clone() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Disabled Hub cloned.", new Object[0]);
        }
        return new Hub(this.options, new Stack(this.stack));
    }

    @Override
    public void close() {
        this.close(false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close(boolean bl) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'close' call is a no-op.", new Object[0]);
            return;
        }
        try {
            for (Integration integration : this.options.getIntegrations()) {
                boolean bl2 = integration instanceof Closeable;
                if (!bl2) continue;
                try {
                    ((Closeable)integration).close();
                }
                catch (IOException iOException) {
                    this.options.getLogger().log(SentryLevel.WARNING, "Failed to close the integration {}.", new Object[]{integration, iOException});
                }
            }
            Object object = new Hub$$ExternalSyntheticLambda2();
            this.configureScope((ScopeCallback)object);
            this.options.getTransactionProfiler().close();
            this.options.getTransactionPerformanceCollector().close();
            object = this.options.getExecutorService();
            if (bl) {
                Object object2 = new Hub$$ExternalSyntheticLambda3(this, (ISentryExecutorService)object);
                object.submit((Runnable)object2);
            } else {
                object.close(this.options.getShutdownTimeoutMillis());
            }
            this.stack.peek().getClient().close(bl);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error while closing the Hub.", throwable);
        }
        this.isEnabled = false;
    }

    @Override
    public void configureScope(ScopeCallback scopeCallback) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'configureScope' call is a no-op.", new Object[0]);
        } else {
            try {
                scopeCallback.run(this.stack.peek().getScope());
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'configureScope' callback.", throwable);
            }
        }
    }

    @Override
    public TransactionContext continueTrace(String object, List<String> list) {
        object = PropagationContext.fromHeaders(this.getOptions().getLogger(), (String)object, list);
        this.configureScope(new Hub$$ExternalSyntheticLambda0((PropagationContext)object));
        if (this.options.isTracingEnabled()) {
            return TransactionContext.fromPropagationContext((PropagationContext)object);
        }
        return null;
    }

    @Override
    public void endSession() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'endSession' call is a no-op.", new Object[0]);
        } else {
            Stack.StackItem stackItem = this.stack.peek();
            Session session = stackItem.getScope().endSession();
            if (session != null) {
                Hint hint = HintUtils.createWithTypeCheckHint(new SessionEndHint());
                stackItem.getClient().captureSession(session, hint);
            }
        }
    }

    @Override
    public void flush(long l2) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'flush' call is a no-op.", new Object[0]);
        } else {
            try {
                this.stack.peek().getClient().flush(l2);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'client.flush'.", throwable);
            }
        }
    }

    @Override
    public BaggageHeader getBaggage() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'getBaggage' call is a no-op.", new Object[0]);
        } else {
            TracingUtils.TracingHeaders tracingHeaders = TracingUtils.trace(this, null, this.getSpan());
            if (tracingHeaders != null) {
                return tracingHeaders.getBaggageHeader();
            }
        }
        return null;
    }

    @Override
    public Map<String, String> getDefaultTagsForMetrics() {
        if (!this.options.isEnableDefaultTagsForMetrics()) {
            return Collections.emptyMap();
        }
        HashMap hashMap = new HashMap();
        String string2 = this.options.getRelease();
        if (string2 != null) {
            hashMap.put((Object)"release", (Object)string2);
        }
        if ((string2 = this.options.getEnvironment()) != null) {
            hashMap.put((Object)"environment", (Object)string2);
        }
        if ((string2 = this.stack.peek().getScope().getTransactionName()) != null) {
            hashMap.put((Object)"transaction", (Object)string2);
        }
        return Collections.unmodifiableMap((Map)hashMap);
    }

    @Override
    public SentryId getLastEventId() {
        return this.lastEventId;
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        if (!this.options.isEnableSpanLocalMetricAggregation()) {
            return null;
        }
        ISpan iSpan = this.getSpan();
        if (iSpan != null) {
            return iSpan.getLocalMetricsAggregator();
        }
        return null;
    }

    @Override
    public IMetricsAggregator getMetricsAggregator() {
        return this.stack.peek().getClient().getMetricsAggregator();
    }

    @Override
    public SentryOptions getOptions() {
        return this.stack.peek().getOptions();
    }

    @Override
    public RateLimiter getRateLimiter() {
        return this.stack.peek().getClient().getRateLimiter();
    }

    @Override
    public ISpan getSpan() {
        ISpan iSpan;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'getSpan' call is a no-op.", new Object[0]);
            iSpan = null;
        } else {
            iSpan = this.stack.peek().getScope().getSpan();
        }
        return iSpan;
    }

    SpanContext getSpanContext(Throwable object) {
        Objects.requireNonNull(object, "throwable is required");
        object = ExceptionUtils.findRootCause((Throwable)object);
        object = (Pair)this.throwableToSpan.get(object);
        if (object != null && (object = (WeakReference)((Pair)object).getFirst()) != null && (object = (ISpan)object.get()) != null) {
            return object.getSpanContext();
        }
        return null;
    }

    @Override
    public SentryTraceHeader getTraceparent() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'getTraceparent' call is a no-op.", new Object[0]);
        } else {
            TracingUtils.TracingHeaders tracingHeaders = TracingUtils.trace(this, null, this.getSpan());
            if (tracingHeaders != null) {
                return tracingHeaders.getSentryTraceHeader();
            }
        }
        return null;
    }

    @Override
    public ITransaction getTransaction() {
        ITransaction iTransaction;
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'getTransaction' call is a no-op.", new Object[0]);
            iTransaction = null;
        } else {
            iTransaction = this.stack.peek().getScope().getTransaction();
        }
        return iTransaction;
    }

    @Override
    public Boolean isCrashedLastRun() {
        return SentryCrashLastRunState.getInstance().isCrashedLastRun(this.options.getCacheDirPath(), this.options.isEnableAutoSessionTracking() ^ true);
    }

    @Override
    public boolean isEnabled() {
        return this.isEnabled;
    }

    @Override
    public boolean isHealthy() {
        return this.stack.peek().getClient().isHealthy();
    }

    /* synthetic */ void lambda$close$1$io-sentry-Hub(ISentryExecutorService iSentryExecutorService) {
        iSentryExecutorService.close(this.options.getShutdownTimeoutMillis());
    }

    @Override
    public MetricsApi metrics() {
        return this.metricsApi;
    }

    @Override
    public void popScope() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'popScope' call is a no-op.", new Object[0]);
        } else {
            this.stack.pop();
        }
    }

    @Override
    public void pushScope() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'pushScope' call is a no-op.", new Object[0]);
        } else {
            Stack.StackItem stackItem = this.stack.peek();
            stackItem = new Stack.StackItem(this.options, stackItem.getClient(), stackItem.getScope().clone());
            this.stack.push(stackItem);
        }
    }

    @Override
    public void removeExtra(String string2) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'removeExtra' call is a no-op.", new Object[0]);
        } else if (string2 == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "removeExtra called with null parameter.", new Object[0]);
        } else {
            this.stack.peek().getScope().removeExtra(string2);
        }
    }

    @Override
    public void removeTag(String string2) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'removeTag' call is a no-op.", new Object[0]);
        } else if (string2 == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "removeTag called with null parameter.", new Object[0]);
        } else {
            this.stack.peek().getScope().removeTag(string2);
        }
    }

    @Override
    public void reportFullyDisplayed() {
        if (this.options.isEnableTimeToFullDisplayTracing()) {
            this.options.getFullyDisplayedReporter().reportFullyDrawn();
        }
    }

    @Override
    public void setExtra(String string2, String string3) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setExtra' call is a no-op.", new Object[0]);
        } else if (string2 != null && string3 != null) {
            this.stack.peek().getScope().setExtra(string2, string3);
        } else {
            this.options.getLogger().log(SentryLevel.WARNING, "setExtra called with null parameter.", new Object[0]);
        }
    }

    @Override
    public void setFingerprint(List<String> list) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setFingerprint' call is a no-op.", new Object[0]);
        } else if (list == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "setFingerprint called with null parameter.", new Object[0]);
        } else {
            this.stack.peek().getScope().setFingerprint(list);
        }
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setLevel' call is a no-op.", new Object[0]);
        } else {
            this.stack.peek().getScope().setLevel(sentryLevel);
        }
    }

    @Override
    public void setSpanContext(Throwable throwable, ISpan iSpan, String string2) {
        Objects.requireNonNull(throwable, "throwable is required");
        Objects.requireNonNull(iSpan, "span is required");
        Objects.requireNonNull(string2, "transactionName is required");
        throwable = ExceptionUtils.findRootCause(throwable);
        if (!this.throwableToSpan.containsKey((Object)throwable)) {
            this.throwableToSpan.put((Object)throwable, new Pair<WeakReference, String>(new WeakReference((Object)iSpan), string2));
        }
    }

    @Override
    public void setTag(String string2, String string3) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setTag' call is a no-op.", new Object[0]);
        } else if (string2 != null && string3 != null) {
            this.stack.peek().getScope().setTag(string2, string3);
        } else {
            this.options.getLogger().log(SentryLevel.WARNING, "setTag called with null parameter.", new Object[0]);
        }
    }

    @Override
    public void setTransaction(String string2) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setTransaction' call is a no-op.", new Object[0]);
        } else if (string2 != null) {
            this.stack.peek().getScope().setTransaction(string2);
        } else {
            this.options.getLogger().log(SentryLevel.WARNING, "Transaction cannot be null", new Object[0]);
        }
    }

    @Override
    public void setUser(User user) {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'setUser' call is a no-op.", new Object[0]);
        } else {
            this.stack.peek().getScope().setUser(user);
        }
    }

    @Override
    public void startSession() {
        if (!this.isEnabled()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Instance is disabled and this 'startSession' call is a no-op.", new Object[0]);
        } else {
            Stack.StackItem stackItem = this.stack.peek();
            Scope.SessionPair sessionPair = stackItem.getScope().startSession();
            if (sessionPair != null) {
                Hint hint;
                if (sessionPair.getPrevious() != null) {
                    hint = HintUtils.createWithTypeCheckHint(new SessionEndHint());
                    stackItem.getClient().captureSession(sessionPair.getPrevious(), hint);
                }
                hint = HintUtils.createWithTypeCheckHint(new SessionStartHint());
                stackItem.getClient().captureSession(sessionPair.getCurrent(), hint);
            } else {
                this.options.getLogger().log(SentryLevel.WARNING, "Session could not be started.", new Object[0]);
            }
        }
    }

    @Override
    public ISpan startSpanForMetric(String string2, String string3) {
        ISpan iSpan = this.getSpan();
        if (iSpan != null) {
            return iSpan.startChild(string2, string3);
        }
        return null;
    }

    @Override
    public ITransaction startTransaction(TransactionContext transactionContext, TransactionOptions transactionOptions) {
        return this.createTransaction(transactionContext, transactionOptions);
    }

    @Override
    @Deprecated
    public SentryTraceHeader traceHeaders() {
        return this.getTraceparent();
    }

    @Override
    public void withScope(ScopeCallback scopeCallback) {
        if (!this.isEnabled()) {
            try {
                scopeCallback.run(NoOpScope.getInstance());
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'withScope' callback.", throwable);
            }
        } else {
            this.pushScope();
            try {
                scopeCallback.run(this.stack.peek().getScope());
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'withScope' callback.", throwable);
            }
            this.popScope();
        }
    }
}

