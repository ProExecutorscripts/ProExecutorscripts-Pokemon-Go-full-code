/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArraySet
 */
package io.sentry;

import io.sentry.protocol.SentryPackage;
import io.sentry.util.Objects;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

public final class SentryIntegrationPackageStorage {
    private static volatile SentryIntegrationPackageStorage INSTANCE;
    private final Set<String> integrations = new CopyOnWriteArraySet();
    private final Set<SentryPackage> packages = new CopyOnWriteArraySet();

    private SentryIntegrationPackageStorage() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SentryIntegrationPackageStorage getInstance() {
        if (INSTANCE != null) return INSTANCE;
        Class<SentryIntegrationPackageStorage> clazz = SentryIntegrationPackageStorage.class;
        synchronized (SentryIntegrationPackageStorage.class) {
            SentryIntegrationPackageStorage sentryIntegrationPackageStorage;
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = sentryIntegrationPackageStorage = new SentryIntegrationPackageStorage();
            // ** MonitorExit[var1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    public void addIntegration(String string2) {
        Objects.requireNonNull(string2, "integration is required.");
        this.integrations.add((Object)string2);
    }

    public void addPackage(String object, String string2) {
        Objects.requireNonNull(object, "name is required.");
        Objects.requireNonNull(string2, "version is required.");
        object = new SentryPackage((String)object, string2);
        this.packages.add(object);
    }

    public void clearStorage() {
        this.integrations.clear();
        this.packages.clear();
    }

    public Set<String> getIntegrations() {
        return this.integrations;
    }

    public Set<SentryPackage> getPackages() {
        return this.packages;
    }
}

