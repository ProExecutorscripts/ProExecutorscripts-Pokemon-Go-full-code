/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

public final class MemoryCollectionData {
    final long timestampMillis;
    final long usedHeapMemory;
    final long usedNativeMemory;

    public MemoryCollectionData(long l2, long l3) {
        this(l2, l3, -1L);
    }

    public MemoryCollectionData(long l2, long l3, long l4) {
        this.timestampMillis = l2;
        this.usedHeapMemory = l3;
        this.usedNativeMemory = l4;
    }

    public long getTimestampMillis() {
        return this.timestampMillis;
    }

    public long getUsedHeapMemory() {
        return this.usedHeapMemory;
    }

    public long getUsedNativeMemory() {
        return this.usedNativeMemory;
    }
}

