/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.BufferedReader
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 */
package io.sentry;

import io.sentry.DirectoryProcessor;
import io.sentry.Hint;
import io.sentry.IEnvelopeReader;
import io.sentry.IEnvelopeSender;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISerializer;
import io.sentry.OutboxSender$$ExternalSyntheticLambda0;
import io.sentry.OutboxSender$$ExternalSyntheticLambda1;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryEvent;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.TraceContext;
import io.sentry.TracesSamplingDecision;
import io.sentry.hints.Flushable;
import io.sentry.hints.Resettable;
import io.sentry.hints.Retryable;
import io.sentry.hints.SubmissionResult;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.util.CollectionUtils;
import io.sentry.util.HintUtils;
import io.sentry.util.LogUtils;
import io.sentry.util.Objects;
import io.sentry.util.SampleRateUtils;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class OutboxSender
extends DirectoryProcessor
implements IEnvelopeSender {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private final IEnvelopeReader envelopeReader;
    private final IHub hub;
    private final ILogger logger;
    private final ISerializer serializer;

    public OutboxSender(IHub iHub, IEnvelopeReader iEnvelopeReader, ISerializer iSerializer, ILogger iLogger, long l2, int n2) {
        super(iHub, iLogger, l2, n2);
        this.hub = Objects.requireNonNull(iHub, "Hub is required.");
        this.envelopeReader = Objects.requireNonNull(iEnvelopeReader, "Envelope reader is required.");
        this.serializer = Objects.requireNonNull(iSerializer, "Serializer is required.");
        this.logger = Objects.requireNonNull(iLogger, "Logger is required.");
    }

    private TracesSamplingDecision extractSamplingDecision(TraceContext object) {
        Boolean bl;
        block4: {
            bl = true;
            if (object != null && (object = ((TraceContext)object).getSampleRate()) != null) {
                try {
                    Object object2 = Double.parseDouble((String)object);
                    if (!SampleRateUtils.isValidTracesSampleRate(object2, false)) {
                        this.logger.log(SentryLevel.ERROR, "Invalid sample rate parsed from TraceContext: %s", object);
                        break block4;
                    }
                    object2 = new TracesSamplingDecision(bl, (Double)object2);
                    return object2;
                }
                catch (Exception exception) {
                    this.logger.log(SentryLevel.ERROR, "Unable to parse sample rate from TraceContext: %s", object);
                }
            }
        }
        return new TracesSamplingDecision(bl);
    }

    static /* synthetic */ void lambda$processEnvelope$1(Resettable resettable) {
        resettable.reset();
    }

    private void logEnvelopeItemNull(SentryEnvelopeItem sentryEnvelopeItem, int n2) {
        this.logger.log(SentryLevel.ERROR, "Item %d of type %s returned null by the parser.", n2, sentryEnvelopeItem.getHeader().getType());
    }

    private void logItemCaptured(int n2) {
        this.logger.log(SentryLevel.DEBUG, "Item %d is being captured.", n2);
    }

    private void logTimeout(SentryId sentryId) {
        this.logger.log(SentryLevel.WARNING, "Timed out waiting for event id submission: %s", sentryId);
    }

    private void logUnexpectedEventId(SentryEnvelope sentryEnvelope, SentryId sentryId, int n2) {
        this.logger.log(SentryLevel.ERROR, "Item %d of has a different event id (%s) to the envelope header (%s)", n2, sentryEnvelope.getHeader().getEventId(), sentryId);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void processEnvelope(SentryEnvelope var1_1, Hint var2_2) throws IOException {
        this.logger.log(SentryLevel.DEBUG, "Processing Envelope with %d item(s)", new Object[]{CollectionUtils.size(var1_1.getItems())});
        var4_3 = var1_1.getItems().iterator();
        var3_4 = 0;
        while (var4_3.hasNext()) {
            block31: {
                block32: {
                    block29: {
                        block30: {
                            block28: {
                                var5_5 = (SentryEnvelopeItem)var4_3.next();
                                ++var3_4;
                                if (var5_5.getHeader() == null) {
                                    this.logger.log(SentryLevel.ERROR, "Item %d has no header", new Object[]{var3_4});
                                    continue;
                                }
                                if (!SentryItemType.Event.equals(var5_5.getHeader().getType())) break block30;
                                var7_13 = new ByteArrayInputStream(var5_5.getData());
                                var8_14 = new InputStreamReader((InputStream)var7_13, OutboxSender.UTF_8);
                                var6_10 /* !! */  = new BufferedReader((Reader)var8_14);
                                var7_13 = this.serializer.deserialize((Reader)var6_10 /* !! */ , SentryEvent.class);
                                if (var7_13 != null) ** GOTO lbl21
                                this.logEnvelopeItemNull((SentryEnvelopeItem)var5_5, var3_4);
                                ** GOTO lbl38
lbl21:
                                // 1 sources

                                if (var7_13.getSdk() != null) {
                                    HintUtils.setIsFromHybridSdk(var2_2, var7_13.getSdk().getName());
                                }
                                if (var1_1.getHeader().getEventId() == null || var1_1.getHeader().getEventId().equals(var7_13.getEventId())) break block28;
                                this.logUnexpectedEventId(var1_1, var7_13.getEventId(), var3_4);
                                var6_10 /* !! */ .close();
                                continue;
                            }
                            this.hub.captureEvent((SentryEvent)var7_13, var2_2);
                            this.logItemCaptured(var3_4);
                            if (this.waitFlush(var2_2)) ** GOTO lbl38
                            this.logTimeout(var7_13.getEventId());
                            var6_10 /* !! */ .close();
                            break;
lbl38:
                            // 2 sources

                            var6_10 /* !! */ .close();
                            catch (Throwable var5_6) {
                                try {
                                    var6_10 /* !! */ .close();
                                    ** GOTO lbl47
                                }
                                catch (Throwable var6_11) {
                                    try {
                                        var5_6.addSuppressed(var6_11);
lbl47:
                                        // 2 sources

                                        throw var5_6;
                                    }
                                    catch (Throwable var5_7) {
                                        this.logger.log(SentryLevel.ERROR, "Item failed to process.", var5_7);
                                    }
                                }
                            }
                            break block31;
                        }
                        if (!SentryItemType.Transaction.equals(var5_5.getHeader().getType())) break block32;
                        var8_14 = new ByteArrayInputStream(var5_5.getData());
                        var7_13 = new InputStreamReader((InputStream)var8_14, OutboxSender.UTF_8);
                        var6_10 /* !! */  = new BufferedReader((Reader)var7_13);
                        var7_13 = this.serializer.deserialize((Reader)var6_10 /* !! */ , SentryTransaction.class);
                        if (var7_13 != null) ** GOTO lbl63
                        this.logEnvelopeItemNull((SentryEnvelopeItem)var5_5, var3_4);
                        ** GOTO lbl81
lbl63:
                        // 1 sources

                        if (var1_1.getHeader().getEventId() == null || var1_1.getHeader().getEventId().equals(var7_13.getEventId())) break block29;
                        this.logUnexpectedEventId(var1_1, var7_13.getEventId(), var3_4);
                        var6_10 /* !! */ .close();
                        continue;
                    }
                    var5_5 = var1_1.getHeader().getTraceContext();
                    if (var7_13.getContexts().getTrace() != null) {
                        var7_13.getContexts().getTrace().setSamplingDecision(this.extractSamplingDecision((TraceContext)var5_5));
                    }
                    this.hub.captureTransaction((SentryTransaction)var7_13, (TraceContext)var5_5, var2_2);
                    this.logItemCaptured(var3_4);
                    if (this.waitFlush(var2_2)) ** GOTO lbl81
                    this.logTimeout(var7_13.getEventId());
                    var6_10 /* !! */ .close();
                    break;
lbl81:
                    // 2 sources

                    var6_10 /* !! */ .close();
                    catch (Throwable var5_8) {
                        try {
                            var6_10 /* !! */ .close();
                            ** GOTO lbl90
                        }
                        catch (Throwable var6_12) {
                            try {
                                var5_8.addSuppressed(var6_12);
lbl90:
                                // 2 sources

                                throw var5_8;
                            }
                            catch (Throwable var5_9) {
                                this.logger.log(SentryLevel.ERROR, "Item failed to process.", var5_9);
                            }
                        }
                    }
                    break block31;
                }
                var6_10 /* !! */  = new SentryEnvelope(var1_1.getHeader().getEventId(), var1_1.getHeader().getSdkVersion(), (SentryEnvelopeItem)var5_5);
                this.hub.captureEnvelope((SentryEnvelope)var6_10 /* !! */ , var2_2);
                this.logger.log(SentryLevel.DEBUG, "%s item %d is being captured.", new Object[]{var5_5.getHeader().getType().getItemType(), var3_4});
                if (!this.waitFlush(var2_2)) {
                    this.logger.log(SentryLevel.WARNING, "Timed out waiting for item type submission: %s", new Object[]{var5_5.getHeader().getType().getItemType()});
                    break;
                }
            }
            if ((var5_5 = HintUtils.getSentrySdkHint(var2_2)) instanceof SubmissionResult && !((SubmissionResult)var5_5).isSuccess()) {
                this.logger.log(SentryLevel.WARNING, "Envelope had a failed capture at item %d. No more items will be sent.", new Object[]{var3_4});
                break;
            }
            HintUtils.runIfHasType(var2_2, Resettable.class, new OutboxSender$$ExternalSyntheticLambda1());
        }
    }

    private boolean waitFlush(Hint object) {
        if ((object = HintUtils.getSentrySdkHint((Hint)object)) instanceof Flushable) {
            return ((Flushable)object).waitFlush();
        }
        LogUtils.logNotInstanceOf(Flushable.class, object, this.logger);
        return true;
    }

    @Override
    protected boolean isRelevantFileName(String string2) {
        boolean bl = string2 != null && !string2.startsWith("session") && !string2.startsWith("previous_session") && !string2.startsWith("startup_crash");
        return bl;
    }

    /* synthetic */ void lambda$processFile$0$io-sentry-OutboxSender(File file, Retryable retryable) {
        if (!retryable.isRetry()) {
            try {
                if (!file.delete()) {
                    this.logger.log(SentryLevel.ERROR, "Failed to delete: %s", file.getAbsolutePath());
                }
            }
            catch (RuntimeException runtimeException) {
                this.logger.log(SentryLevel.ERROR, runtimeException, "Failed to delete: %s", file.getAbsolutePath());
            }
        }
    }

    @Override
    public void processEnvelopeFile(String string2, Hint hint) {
        Objects.requireNonNull(string2, "Path is required.");
        this.processFile(new File(string2), hint);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    protected void processFile(File object, Hint hint) {
        Throwable throwable422222;
        block13: {
            Object object2;
            Object object3;
            block14: {
                block12: {
                    Objects.requireNonNull(object, "File is required.");
                    if (!this.isRelevantFileName(object.getName())) {
                        this.logger.log(SentryLevel.DEBUG, "File '%s' should be ignored.", object.getAbsolutePath());
                        return;
                    }
                    object3 = new FileInputStream(object);
                    object2 = new BufferedInputStream((InputStream)object3);
                    object3 = this.envelopeReader.read((InputStream)object2);
                    if (object3 == null) {
                        this.logger.log(SentryLevel.ERROR, "Stream from path %s resulted in a null envelope.", object.getAbsolutePath());
                        break block12;
                    }
                    this.processEnvelope((SentryEnvelope)object3, hint);
                    this.logger.log(SentryLevel.DEBUG, "File '%s' is done.", object.getAbsolutePath());
                }
                object2.close();
                object3 = Retryable.class;
                object2 = this.logger;
                object = new OutboxSender$$ExternalSyntheticLambda0(this, (File)object);
                break block14;
                catch (Throwable throwable2) {
                    try {
                        object2.close();
                        throw throwable2;
                    }
                    catch (Throwable throwable3) {
                        try {
                            throwable2.addSuppressed(throwable3);
                            throw throwable2;
                        }
                        catch (Throwable throwable422222) {
                            break block13;
                        }
                        catch (IOException iOException) {
                            this.logger.log(SentryLevel.ERROR, "Error processing envelope.", iOException);
                            object3 = Retryable.class;
                            object2 = this.logger;
                            object = new OutboxSender$$ExternalSyntheticLambda0(this, (File)object);
                        }
                    }
                }
            }
            HintUtils.runIfHasTypeLogIfNot(hint, object3, (ILogger)object2, object);
            return;
        }
        HintUtils.runIfHasTypeLogIfNot(hint, Retryable.class, this.logger, new OutboxSender$$ExternalSyntheticLambda0(this, (File)object));
        throw throwable422222;
    }
}

