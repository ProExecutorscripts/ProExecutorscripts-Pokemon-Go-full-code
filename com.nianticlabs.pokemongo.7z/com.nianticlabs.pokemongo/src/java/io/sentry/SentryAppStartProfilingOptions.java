/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryOptions;
import io.sentry.TracesSamplingDecision;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryAppStartProfilingOptions
implements JsonUnknown,
JsonSerializable {
    boolean isProfilingEnabled;
    Double profileSampleRate;
    boolean profileSampled;
    String profilingTracesDirPath;
    int profilingTracesHz;
    Double traceSampleRate;
    boolean traceSampled;
    private Map<String, Object> unknown;

    public SentryAppStartProfilingOptions() {
        this.traceSampled = false;
        this.traceSampleRate = null;
        this.profileSampled = false;
        this.profileSampleRate = null;
        this.profilingTracesDirPath = null;
        this.isProfilingEnabled = false;
        this.profilingTracesHz = 0;
    }

    SentryAppStartProfilingOptions(SentryOptions sentryOptions, TracesSamplingDecision tracesSamplingDecision) {
        this.traceSampled = tracesSamplingDecision.getSampled();
        this.traceSampleRate = tracesSamplingDecision.getSampleRate();
        this.profileSampled = tracesSamplingDecision.getProfileSampled();
        this.profileSampleRate = tracesSamplingDecision.getProfileSampleRate();
        this.profilingTracesDirPath = sentryOptions.getProfilingTracesDirPath();
        this.isProfilingEnabled = sentryOptions.isProfilingEnabled();
        this.profilingTracesHz = sentryOptions.getProfilingTracesHz();
    }

    public Double getProfileSampleRate() {
        return this.profileSampleRate;
    }

    public String getProfilingTracesDirPath() {
        return this.profilingTracesDirPath;
    }

    public int getProfilingTracesHz() {
        return this.profilingTracesHz;
    }

    public Double getTraceSampleRate() {
        return this.traceSampleRate;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public boolean isProfileSampled() {
        return this.profileSampled;
    }

    public boolean isProfilingEnabled() {
        return this.isProfilingEnabled;
    }

    public boolean isTraceSampled() {
        return this.traceSampled;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        objectWriter.beginObject();
        objectWriter.name("profile_sampled").value(iLogger, this.profileSampled);
        objectWriter.name("profile_sample_rate").value(iLogger, this.profileSampleRate);
        objectWriter.name("trace_sampled").value(iLogger, this.traceSampled);
        objectWriter.name("trace_sample_rate").value(iLogger, this.traceSampleRate);
        objectWriter.name("profiling_traces_dir_path").value(iLogger, this.profilingTracesDirPath);
        objectWriter.name("is_profiling_enabled").value(iLogger, this.isProfilingEnabled);
        objectWriter.name("profiling_traces_hz").value(iLogger, this.profilingTracesHz);
        Object object = this.unknown;
        if (object != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setProfileSampleRate(Double d2) {
        this.profileSampleRate = d2;
    }

    public void setProfileSampled(boolean bl) {
        this.profileSampled = bl;
    }

    public void setProfilingEnabled(boolean bl) {
        this.isProfilingEnabled = bl;
    }

    public void setProfilingTracesDirPath(String string2) {
        this.profilingTracesDirPath = string2;
    }

    public void setProfilingTracesHz(int n2) {
        this.profilingTracesHz = n2;
    }

    public void setTraceSampleRate(Double d2) {
        this.traceSampleRate = d2;
    }

    public void setTraceSampled(boolean bl) {
        this.traceSampled = bl;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryAppStartProfilingOptions> {
        @Override
        public SentryAppStartProfilingOptions deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            SentryAppStartProfilingOptions sentryAppStartProfilingOptions = new SentryAppStartProfilingOptions();
            Double d2 = null;
            block18: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Object object;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2140552383: {
                        if (!string2.equals((Object)"profile_sample_rate")) break;
                        n3 = 6;
                        break;
                    }
                    case 1653938779: {
                        if (!string2.equals((Object)"trace_sample_rate")) break;
                        n3 = 5;
                        break;
                    }
                    case 1583866442: {
                        if (!string2.equals((Object)"profiling_traces_hz")) break;
                        n3 = 4;
                        break;
                    }
                    case -69617820: {
                        if (!string2.equals((Object)"profile_sampled")) break;
                        n3 = 3;
                        break;
                    }
                    case -116896685: {
                        if (!string2.equals((Object)"is_profiling_enabled")) break;
                        n3 = 2;
                        break;
                    }
                    case -450071601: {
                        if (!string2.equals((Object)"profiling_traces_dir_path")) break;
                        n3 = 1;
                        break;
                    }
                    case -566246656: {
                        if (!string2.equals((Object)"trace_sampled")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        object = d2;
                        if (d2 == null) {
                            object = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)object, string2);
                        d2 = object;
                        continue block18;
                    }
                    case 6: {
                        object = jsonObjectReader.nextDoubleOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.profileSampleRate = object;
                        continue block18;
                    }
                    case 5: {
                        object = jsonObjectReader.nextDoubleOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.traceSampleRate = object;
                        continue block18;
                    }
                    case 4: {
                        object = jsonObjectReader.nextIntegerOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.profilingTracesHz = object.intValue();
                        continue block18;
                    }
                    case 3: {
                        object = jsonObjectReader.nextBooleanOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.profileSampled = object.booleanValue();
                        continue block18;
                    }
                    case 2: {
                        object = jsonObjectReader.nextBooleanOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.isProfilingEnabled = object.booleanValue();
                        continue block18;
                    }
                    case 1: {
                        object = jsonObjectReader.nextStringOrNull();
                        if (object == null) continue block18;
                        sentryAppStartProfilingOptions.profilingTracesDirPath = object;
                        continue block18;
                    }
                    case 0: 
                }
                object = jsonObjectReader.nextBooleanOrNull();
                if (object == null) continue;
                sentryAppStartProfilingOptions.traceSampled = object.booleanValue();
            }
            sentryAppStartProfilingOptions.setUnknown((Map<String, Object>)d2);
            jsonObjectReader.endObject();
            return sentryAppStartProfilingOptions;
        }
    }

    public static final class JsonKeys {
        public static final String IS_PROFILING_ENABLED = "is_profiling_enabled";
        public static final String PROFILE_SAMPLED = "profile_sampled";
        public static final String PROFILE_SAMPLE_RATE = "profile_sample_rate";
        public static final String PROFILING_TRACES_DIR_PATH = "profiling_traces_dir_path";
        public static final String PROFILING_TRACES_HZ = "profiling_traces_hz";
        public static final String TRACE_SAMPLED = "trace_sampled";
        public static final String TRACE_SAMPLE_RATE = "trace_sample_rate";
    }
}

