/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.User;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class TraceContext
implements JsonUnknown,
JsonSerializable {
    private final String environment;
    private final String publicKey;
    private final String release;
    private final String sampleRate;
    private final String sampled;
    private final SentryId traceId;
    private final String transaction;
    private Map<String, Object> unknown;
    private final String userId;
    private final String userSegment;

    TraceContext(SentryId sentryId, String string2) {
        this(sentryId, string2, null, null, null, null, null, null, null);
    }

    TraceContext(SentryId sentryId, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) {
        this.traceId = sentryId;
        this.publicKey = string2;
        this.release = string3;
        this.environment = string4;
        this.userId = string5;
        this.userSegment = string6;
        this.transaction = string7;
        this.sampleRate = string8;
        this.sampled = string9;
    }

    private static String getUserId(SentryOptions sentryOptions, User user) {
        if (sentryOptions.isSendDefaultPii() && user != null) {
            return user.getId();
        }
        return null;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public String getPublicKey() {
        return this.publicKey;
    }

    public String getRelease() {
        return this.release;
    }

    public String getSampleRate() {
        return this.sampleRate;
    }

    public String getSampled() {
        return this.sampled;
    }

    public SentryId getTraceId() {
        return this.traceId;
    }

    public String getTransaction() {
        return this.transaction;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public String getUserId() {
        return this.userId;
    }

    public String getUserSegment() {
        return this.userSegment;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        objectWriter.name("trace_id").value(iLogger, this.traceId);
        objectWriter.name("public_key").value(this.publicKey);
        if (this.release != null) {
            objectWriter.name("release").value(this.release);
        }
        if (this.environment != null) {
            objectWriter.name("environment").value(this.environment);
        }
        if (this.userId != null) {
            objectWriter.name("user_id").value(this.userId);
        }
        if (this.userSegment != null) {
            objectWriter.name("user_segment").value(this.userSegment);
        }
        if (this.transaction != null) {
            objectWriter.name("transaction").value(this.transaction);
        }
        if (this.sampleRate != null) {
            objectWriter.name("sample_rate").value(this.sampleRate);
        }
        if (this.sampled != null) {
            objectWriter.name("sampled").value(this.sampled);
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<TraceContext> {
        private Exception missingRequiredFieldException(String string2, ILogger iLogger) {
            string2 = "Missing required field \"" + string2 + "\"";
            IllegalStateException illegalStateException = new IllegalStateException(string2);
            iLogger.log(SentryLevel.ERROR, string2, illegalStateException);
            return illegalStateException;
        }

        /*
         * Unable to fully structure code
         */
        @Override
        public TraceContext deserialize(JsonObjectReader var1_1, ILogger var2_2) throws Exception {
            block29: {
                block30: {
                    var1_1.beginObject();
                    var15_3 = null;
                    var5_4 = null;
                    var14_5 = null;
                    var13_12 = var8_11 = (var9_10 = (var10_9 = (var11_8 = (var12_7 = (var7_6 = var14_5)))));
                    var6_13 = var13_12;
                    while (var1_1.peek() == JsonToken.NAME) {
                        var17_17 = var1_1.nextName();
                        var17_17.hashCode();
                        var4_15 = var17_17.hashCode();
                        var3_14 = -1;
                        switch (var4_15) {
                            default: {
                                break;
                            }
                            case 2141246174: {
                                if (!var17_17.equals((Object)"transaction")) break;
                                var3_14 = 9;
                                break;
                            }
                            case 1904812937: {
                                if (!var17_17.equals((Object)"public_key")) break;
                                var3_14 = 8;
                                break;
                            }
                            case 1864843258: {
                                if (!var17_17.equals((Object)"sampled")) break;
                                var3_14 = 7;
                                break;
                            }
                            case 1270300245: {
                                if (!var17_17.equals((Object)"trace_id")) break;
                                var3_14 = 6;
                                break;
                            }
                            case 1090594823: {
                                if (!var17_17.equals((Object)"release")) break;
                                var3_14 = 5;
                                break;
                            }
                            case 153193045: {
                                if (!var17_17.equals((Object)"sample_rate")) break;
                                var3_14 = 4;
                                break;
                            }
                            case 3599307: {
                                if (!var17_17.equals((Object)"user")) break;
                                var3_14 = 3;
                                break;
                            }
                            case -85904877: {
                                if (!var17_17.equals((Object)"environment")) break;
                                var3_14 = 2;
                                break;
                            }
                            case -147132913: {
                                if (!var17_17.equals((Object)"user_id")) break;
                                var3_14 = 1;
                                break;
                            }
                            case -795593025: {
                                if (!var17_17.equals((Object)"user_segment")) break;
                                var3_14 = 0;
                            }
                        }
                        switch (var3_14) {
                            default: {
                                var16_16 = var6_13;
                                if (var6_13 == null) {
                                    var16_16 = new ConcurrentHashMap();
                                }
                                var1_1.nextUnknown((ILogger)var2_2, (Map<String, Object>)var16_16, var17_17);
                                var6_13 = var16_16;
                                break;
                            }
                            case 9: {
                                var9_10 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 8: {
                                var12_7 = var1_1.nextString();
                                break;
                            }
                            case 7: {
                                var13_12 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 6: {
                                var14_5 = new SentryId.Deserializer().deserialize(var1_1, (ILogger)var2_2);
                                break;
                            }
                            case 5: {
                                var11_8 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 4: {
                                var8_11 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 3: {
                                var15_3 = var1_1.nextOrNull((ILogger)var2_2, new TraceContextUser.Deserializer());
                                break;
                            }
                            case 2: {
                                var10_9 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 1: {
                                var5_4 = var1_1.nextStringOrNull();
                                break;
                            }
                            case 0: {
                                var7_6 = var1_1.nextStringOrNull();
                                break;
                            }
                        }
                    }
                    if (var14_5 == null) break block29;
                    if (var12_7 == null) break block30;
                    var16_16 = var5_4;
                    if (var15_3 == null) ** GOTO lbl-1000
                    var2_2 = var5_4;
                    if (var5_4 == null) {
                        var2_2 = var15_3.getId();
                    }
                    var16_16 = var2_2;
                    if (var7_6 == null) {
                        var5_4 = var15_3.getSegment();
                        var16_16 = var2_2;
                        var2_2 = var5_4;
                    } else lbl-1000:
                    // 2 sources

                    {
                        var2_2 = var7_6;
                    }
                    var2_2 = new TraceContext((SentryId)var14_5, var12_7, var11_8, var10_9, (String)var16_16, (String)var2_2, var9_10, var8_11, var13_12);
                    var2_2.setUnknown((Map<String, Object>)var6_13);
                    var1_1.endObject();
                    return var2_2;
                }
                throw this.missingRequiredFieldException("public_key", (ILogger)var2_2);
            }
            throw this.missingRequiredFieldException("trace_id", (ILogger)var2_2);
        }
    }

    public static final class JsonKeys {
        public static final String ENVIRONMENT = "environment";
        public static final String PUBLIC_KEY = "public_key";
        public static final String RELEASE = "release";
        public static final String SAMPLED = "sampled";
        public static final String SAMPLE_RATE = "sample_rate";
        public static final String TRACE_ID = "trace_id";
        public static final String TRANSACTION = "transaction";
        public static final String USER = "user";
        public static final String USER_ID = "user_id";
        public static final String USER_SEGMENT = "user_segment";
    }

    @Deprecated
    private static final class TraceContextUser
    implements JsonUnknown {
        private String id;
        private String segment;
        private Map<String, Object> unknown;

        private TraceContextUser(String string2, String string3) {
            this.id = string2;
            this.segment = string3;
        }

        public String getId() {
            return this.id;
        }

        public String getSegment() {
            return this.segment;
        }

        @Override
        public Map<String, Object> getUnknown() {
            return this.unknown;
        }

        @Override
        public void setUnknown(Map<String, Object> map2) {
            this.unknown = map2;
        }

        public static final class Deserializer
        implements JsonDeserializer<TraceContextUser> {
            @Override
            public TraceContextUser deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
                String string2;
                jsonObjectReader.beginObject();
                String string3 = null;
                String string4 = string2 = null;
                while (jsonObjectReader.peek() == JsonToken.NAME) {
                    String string5 = jsonObjectReader.nextName();
                    string5.hashCode();
                    if (!string5.equals((Object)"id")) {
                        if (!string5.equals((Object)"segment")) {
                            String string6 = string4;
                            if (string4 == null) {
                                string6 = new ConcurrentHashMap();
                            }
                            jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)string6, string5);
                            string4 = string6;
                            continue;
                        }
                        string2 = jsonObjectReader.nextStringOrNull();
                        continue;
                    }
                    string3 = jsonObjectReader.nextStringOrNull();
                }
                object = new TraceContextUser(string3, string2);
                ((TraceContextUser)object).setUnknown((Map<String, Object>)string4);
                jsonObjectReader.endObject();
                return object;
            }
        }

        public static final class JsonKeys {
            public static final String ID = "id";
            public static final String SEGMENT = "segment";
        }
    }
}

