/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.List
 */
package io.sentry;

import java.util.Arrays;
import java.util.List;

public final class IpAddressUtils {
    public static final String DEFAULT_IP_ADDRESS = "{{auto}}";
    private static final List<String> DEFAULT_IP_ADDRESS_VALID_VALUES = Arrays.asList((Object[])new String[]{"{{auto}}", "{{ auto }}"});

    private IpAddressUtils() {
    }

    public static boolean isDefault(String string2) {
        boolean bl = string2 != null && DEFAULT_IP_ADDRESS_VALID_VALUES.contains((Object)string2);
        return bl;
    }
}

