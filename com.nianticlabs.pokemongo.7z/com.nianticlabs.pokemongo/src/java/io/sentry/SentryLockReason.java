/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryLockReason
implements JsonUnknown,
JsonSerializable {
    public static final int ANY = 15;
    public static final int BLOCKED = 8;
    public static final int LOCKED = 1;
    public static final int SLEEPING = 4;
    public static final int WAITING = 2;
    private String address;
    private String className;
    private String packageName;
    private Long threadId;
    private int type;
    private Map<String, Object> unknown;

    public SentryLockReason() {
    }

    public SentryLockReason(SentryLockReason sentryLockReason) {
        this.type = sentryLockReason.type;
        this.address = sentryLockReason.address;
        this.packageName = sentryLockReason.packageName;
        this.className = sentryLockReason.className;
        this.threadId = sentryLockReason.threadId;
        this.unknown = CollectionUtils.newConcurrentHashMap(sentryLockReason.unknown);
    }

    static /* synthetic */ int access$002(SentryLockReason sentryLockReason, int n2) {
        sentryLockReason.type = n2;
        return n2;
    }

    static /* synthetic */ String access$102(SentryLockReason sentryLockReason, String string2) {
        sentryLockReason.address = string2;
        return string2;
    }

    static /* synthetic */ String access$202(SentryLockReason sentryLockReason, String string2) {
        sentryLockReason.packageName = string2;
        return string2;
    }

    static /* synthetic */ String access$302(SentryLockReason sentryLockReason, String string2) {
        sentryLockReason.className = string2;
        return string2;
    }

    static /* synthetic */ Long access$402(SentryLockReason sentryLockReason, Long l2) {
        sentryLockReason.threadId = l2;
        return l2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null && this.getClass() == object.getClass()) {
            object = (SentryLockReason)object;
            return Objects.equals(this.address, ((SentryLockReason)object).address);
        }
        return false;
    }

    public String getAddress() {
        return this.address;
    }

    public String getClassName() {
        return this.className;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public Long getThreadId() {
        return this.threadId;
    }

    public int getType() {
        return this.type;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public int hashCode() {
        return Objects.hash(this.address);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        objectWriter.name("type").value(this.type);
        if (this.address != null) {
            objectWriter.name("address").value(this.address);
        }
        if (this.packageName != null) {
            objectWriter.name("package_name").value(this.packageName);
        }
        if (this.className != null) {
            objectWriter.name("class_name").value(this.className);
        }
        if (this.threadId != null) {
            objectWriter.name("thread_id").value((Number)this.threadId);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setAddress(String string2) {
        this.address = string2;
    }

    public void setClassName(String string2) {
        this.className = string2;
    }

    public void setPackageName(String string2) {
        this.packageName = string2;
    }

    public void setThreadId(Long l2) {
        this.threadId = l2;
    }

    public void setType(int n2) {
        this.type = n2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryLockReason> {
        @Override
        public SentryLockReason deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            SentryLockReason sentryLockReason = new SentryLockReason();
            jsonObjectReader.beginObject();
            ConcurrentHashMap concurrentHashMap = null;
            block14: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 3575610: {
                        if (!string2.equals((Object)"type")) break;
                        n3 = 4;
                        break;
                    }
                    case -290474766: {
                        if (!string2.equals((Object)"class_name")) break;
                        n3 = 3;
                        break;
                    }
                    case -1147692044: {
                        if (!string2.equals((Object)"address")) break;
                        n3 = 2;
                        break;
                    }
                    case -1562235024: {
                        if (!string2.equals((Object)"thread_id")) break;
                        n3 = 1;
                        break;
                    }
                    case -1877165340: {
                        if (!string2.equals((Object)"package_name")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        ConcurrentHashMap concurrentHashMap2 = concurrentHashMap;
                        if (concurrentHashMap == null) {
                            concurrentHashMap2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)concurrentHashMap2, string2);
                        concurrentHashMap = concurrentHashMap2;
                        continue block14;
                    }
                    case 4: {
                        SentryLockReason.access$002(sentryLockReason, jsonObjectReader.nextInt());
                        continue block14;
                    }
                    case 3: {
                        SentryLockReason.access$302(sentryLockReason, jsonObjectReader.nextStringOrNull());
                        continue block14;
                    }
                    case 2: {
                        SentryLockReason.access$102(sentryLockReason, jsonObjectReader.nextStringOrNull());
                        continue block14;
                    }
                    case 1: {
                        SentryLockReason.access$402(sentryLockReason, jsonObjectReader.nextLongOrNull());
                        continue block14;
                    }
                    case 0: 
                }
                SentryLockReason.access$202(sentryLockReason, jsonObjectReader.nextStringOrNull());
            }
            sentryLockReason.setUnknown((Map<String, Object>)concurrentHashMap);
            jsonObjectReader.endObject();
            return sentryLockReason;
        }
    }

    public static final class JsonKeys {
        public static final String ADDRESS = "address";
        public static final String CLASS_NAME = "class_name";
        public static final String PACKAGE_NAME = "package_name";
        public static final String THREAD_ID = "thread_id";
        public static final String TYPE = "type";
    }
}

