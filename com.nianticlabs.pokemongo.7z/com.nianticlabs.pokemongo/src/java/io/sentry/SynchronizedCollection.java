/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Iterator
 */
package io.sentry;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;

class SynchronizedCollection<E>
implements Collection<E>,
Serializable {
    private static final long serialVersionUID = 2412805092710877986L;
    private final Collection<E> collection;
    final Object lock;

    SynchronizedCollection(Collection<E> collection) {
        if (collection != null) {
            this.collection = collection;
            this.lock = this;
            return;
        }
        throw new NullPointerException("Collection must not be null.");
    }

    SynchronizedCollection(Collection<E> collection, Object object) {
        if (collection != null) {
            if (object != null) {
                this.collection = collection;
                this.lock = object;
                return;
            }
            throw new NullPointerException("Lock must not be null.");
        }
        throw new NullPointerException("Collection must not be null.");
    }

    public static <T> SynchronizedCollection<T> synchronizedCollection(Collection<T> collection) {
        return new SynchronizedCollection<T>(collection);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean add(E e2) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().add(e2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean addAll(Collection<? extends E> collection) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().addAll(collection);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void clear() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            this.decorated().clear();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean contains(Object object) {
        Object object2;
        Object object3 = object2 = this.lock;
        synchronized (object3) {
            return this.decorated().contains(object);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean containsAll(Collection<?> collection) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().containsAll(collection);
        }
    }

    protected Collection<E> decorated() {
        return this.collection;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean equals(Object object) {
        Object object2;
        Object object3 = object2 = this.lock;
        synchronized (object3) {
            Throwable throwable2;
            block5: {
                boolean bl;
                block4: {
                    bl = true;
                    if (object != this) break block4;
                    try {
                        return true;
                    }
                    catch (Throwable throwable2) {
                        break block5;
                    }
                }
                boolean bl2 = bl;
                if (object == this) return bl2;
                {
                    if (!this.decorated().equals(object)) return false;
                    return bl;
                }
            }
            throw throwable2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int hashCode() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().hashCode();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean isEmpty() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().isEmpty();
        }
    }

    public Iterator<E> iterator() {
        return this.decorated().iterator();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean remove(Object object) {
        Object object2;
        Object object3 = object2 = this.lock;
        synchronized (object3) {
            return this.decorated().remove(object);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean removeAll(Collection<?> collection) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().removeAll(collection);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean retainAll(Collection<?> collection) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().retainAll(collection);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public int size() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().size();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Object[] toArray() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().toArray();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public <T> T[] toArray(T[] objectArray) {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().toArray(objectArray);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String toString() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            return this.decorated().toString();
        }
    }
}

