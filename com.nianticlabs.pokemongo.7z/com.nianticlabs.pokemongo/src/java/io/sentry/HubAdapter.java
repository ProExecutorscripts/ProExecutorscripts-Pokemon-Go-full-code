/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ISentryClient;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.ProfilingTraceData;
import io.sentry.ScopeCallback;
import io.sentry.Sentry;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryTraceHeader;
import io.sentry.TraceContext;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.UserFeedback;
import io.sentry.metrics.MetricsApi;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.transport.RateLimiter;
import java.util.List;

public final class HubAdapter
implements IHub {
    private static final HubAdapter INSTANCE = new HubAdapter();

    private HubAdapter() {
    }

    public static HubAdapter getInstance() {
        return INSTANCE;
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
        this.addBreadcrumb(breadcrumb, new Hint());
    }

    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb, Hint hint) {
        Sentry.addBreadcrumb(breadcrumb, hint);
    }

    @Override
    public void bindClient(ISentryClient iSentryClient) {
        Sentry.bindClient(iSentryClient);
    }

    @Override
    public SentryId captureCheckIn(CheckIn checkIn) {
        return Sentry.captureCheckIn(checkIn);
    }

    @Override
    public SentryId captureEnvelope(SentryEnvelope sentryEnvelope, Hint hint) {
        return Sentry.getCurrentHub().captureEnvelope(sentryEnvelope, hint);
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint) {
        return Sentry.captureEvent(sentryEvent, hint);
    }

    @Override
    public SentryId captureEvent(SentryEvent sentryEvent, Hint hint, ScopeCallback scopeCallback) {
        return Sentry.captureEvent(sentryEvent, hint, scopeCallback);
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint) {
        return Sentry.captureException(throwable, hint);
    }

    @Override
    public SentryId captureException(Throwable throwable, Hint hint, ScopeCallback scopeCallback) {
        return Sentry.captureException(throwable, hint, scopeCallback);
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel) {
        return Sentry.captureMessage(string2, sentryLevel);
    }

    @Override
    public SentryId captureMessage(String string2, SentryLevel sentryLevel, ScopeCallback scopeCallback) {
        return Sentry.captureMessage(string2, sentryLevel, scopeCallback);
    }

    @Override
    public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext, Hint hint, ProfilingTraceData profilingTraceData) {
        return Sentry.getCurrentHub().captureTransaction(sentryTransaction, traceContext, hint, profilingTraceData);
    }

    @Override
    public void captureUserFeedback(UserFeedback userFeedback) {
        Sentry.captureUserFeedback(userFeedback);
    }

    @Override
    public void clearBreadcrumbs() {
        Sentry.clearBreadcrumbs();
    }

    @Override
    public IHub clone() {
        return Sentry.getCurrentHub().clone();
    }

    @Override
    public void close() {
        Sentry.close();
    }

    @Override
    public void close(boolean bl) {
        Sentry.close();
    }

    @Override
    public void configureScope(ScopeCallback scopeCallback) {
        Sentry.configureScope(scopeCallback);
    }

    @Override
    public TransactionContext continueTrace(String string2, List<String> list) {
        return Sentry.continueTrace(string2, list);
    }

    @Override
    public void endSession() {
        Sentry.endSession();
    }

    @Override
    public void flush(long l2) {
        Sentry.flush(l2);
    }

    @Override
    public BaggageHeader getBaggage() {
        return Sentry.getBaggage();
    }

    @Override
    public SentryId getLastEventId() {
        return Sentry.getLastEventId();
    }

    @Override
    public SentryOptions getOptions() {
        return Sentry.getCurrentHub().getOptions();
    }

    @Override
    public RateLimiter getRateLimiter() {
        return Sentry.getCurrentHub().getRateLimiter();
    }

    @Override
    public ISpan getSpan() {
        return Sentry.getCurrentHub().getSpan();
    }

    @Override
    public SentryTraceHeader getTraceparent() {
        return Sentry.getTraceparent();
    }

    @Override
    public ITransaction getTransaction() {
        return Sentry.getCurrentHub().getTransaction();
    }

    @Override
    public Boolean isCrashedLastRun() {
        return Sentry.isCrashedLastRun();
    }

    @Override
    public boolean isEnabled() {
        return Sentry.isEnabled();
    }

    @Override
    public boolean isHealthy() {
        return Sentry.isHealthy();
    }

    @Override
    public MetricsApi metrics() {
        return Sentry.getCurrentHub().metrics();
    }

    @Override
    public void popScope() {
        Sentry.popScope();
    }

    @Override
    public void pushScope() {
        Sentry.pushScope();
    }

    @Override
    public void removeExtra(String string2) {
        Sentry.removeExtra(string2);
    }

    @Override
    public void removeTag(String string2) {
        Sentry.removeTag(string2);
    }

    @Override
    public void reportFullyDisplayed() {
        Sentry.reportFullyDisplayed();
    }

    @Override
    public void setExtra(String string2, String string3) {
        Sentry.setExtra(string2, string3);
    }

    @Override
    public void setFingerprint(List<String> list) {
        Sentry.setFingerprint(list);
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
        Sentry.setLevel(sentryLevel);
    }

    @Override
    public void setSpanContext(Throwable throwable, ISpan iSpan, String string2) {
        Sentry.getCurrentHub().setSpanContext(throwable, iSpan, string2);
    }

    @Override
    public void setTag(String string2, String string3) {
        Sentry.setTag(string2, string3);
    }

    @Override
    public void setTransaction(String string2) {
        Sentry.setTransaction(string2);
    }

    @Override
    public void setUser(User user) {
        Sentry.setUser(user);
    }

    @Override
    public void startSession() {
        Sentry.startSession();
    }

    @Override
    public ITransaction startTransaction(TransactionContext transactionContext, TransactionOptions transactionOptions) {
        return Sentry.startTransaction(transactionContext, transactionOptions);
    }

    @Override
    @Deprecated
    public SentryTraceHeader traceHeaders() {
        return Sentry.traceHeaders();
    }

    @Override
    public void withScope(ScopeCallback scopeCallback) {
        Sentry.withScope(scopeCallback);
    }
}

