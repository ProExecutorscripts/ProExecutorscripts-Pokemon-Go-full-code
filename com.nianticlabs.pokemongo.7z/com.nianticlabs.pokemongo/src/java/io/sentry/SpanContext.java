/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.SpanId;
import io.sentry.SpanStatus;
import io.sentry.TracesSamplingDecision;
import io.sentry.protocol.SentryId;
import io.sentry.util.CollectionUtils;
import io.sentry.util.Objects;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SpanContext
implements JsonUnknown,
JsonSerializable {
    public static final String TYPE = "trace";
    protected String description;
    protected String op;
    protected String origin = "manual";
    private final SpanId parentSpanId;
    private transient TracesSamplingDecision samplingDecision;
    private final SpanId spanId;
    protected SpanStatus status;
    protected Map<String, String> tags = new ConcurrentHashMap();
    private final SentryId traceId;
    private Map<String, Object> unknown;

    public SpanContext(SpanContext map2) {
        this.traceId = map2.traceId;
        this.spanId = map2.spanId;
        this.parentSpanId = map2.parentSpanId;
        this.samplingDecision = map2.samplingDecision;
        this.op = map2.op;
        this.description = map2.description;
        this.status = map2.status;
        map2 = CollectionUtils.newConcurrentHashMap(map2.tags);
        if (map2 != null) {
            this.tags = map2;
        }
    }

    public SpanContext(SentryId sentryId, SpanId spanId, SpanId spanId2, String string2, String string3, TracesSamplingDecision tracesSamplingDecision, SpanStatus spanStatus, String string4) {
        this.traceId = Objects.requireNonNull(sentryId, "traceId is required");
        this.spanId = Objects.requireNonNull(spanId, "spanId is required");
        this.op = Objects.requireNonNull(string2, "operation is required");
        this.parentSpanId = spanId2;
        this.samplingDecision = tracesSamplingDecision;
        this.description = string3;
        this.status = spanStatus;
        this.origin = string4;
    }

    public SpanContext(SentryId sentryId, SpanId spanId, String string2, SpanId spanId2, TracesSamplingDecision tracesSamplingDecision) {
        this(sentryId, spanId, spanId2, string2, null, tracesSamplingDecision, null, "manual");
    }

    public SpanContext(String string2) {
        this(new SentryId(), new SpanId(), string2, null, null);
    }

    public SpanContext(String string2, TracesSamplingDecision tracesSamplingDecision) {
        this(new SentryId(), new SpanId(), string2, null, tracesSamplingDecision);
    }

    public boolean equals(Object object) {
        boolean bl = true;
        if (this == object) {
            return true;
        }
        if (!(object instanceof SpanContext)) {
            return false;
        }
        object = (SpanContext)object;
        if (!(this.traceId.equals(((SpanContext)object).traceId) && this.spanId.equals(((SpanContext)object).spanId) && Objects.equals(this.parentSpanId, ((SpanContext)object).parentSpanId) && this.op.equals((Object)((SpanContext)object).op) && Objects.equals(this.description, ((SpanContext)object).description) && this.status == ((SpanContext)object).status)) {
            bl = false;
        }
        return bl;
    }

    public String getDescription() {
        return this.description;
    }

    public String getOperation() {
        return this.op;
    }

    public String getOrigin() {
        return this.origin;
    }

    public SpanId getParentSpanId() {
        return this.parentSpanId;
    }

    public Boolean getProfileSampled() {
        TracesSamplingDecision tracesSamplingDecision = this.samplingDecision;
        if (tracesSamplingDecision == null) {
            return null;
        }
        return tracesSamplingDecision.getProfileSampled();
    }

    public Boolean getSampled() {
        TracesSamplingDecision tracesSamplingDecision = this.samplingDecision;
        if (tracesSamplingDecision == null) {
            return null;
        }
        return tracesSamplingDecision.getSampled();
    }

    public TracesSamplingDecision getSamplingDecision() {
        return this.samplingDecision;
    }

    public SpanId getSpanId() {
        return this.spanId;
    }

    public SpanStatus getStatus() {
        return this.status;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public SentryId getTraceId() {
        return this.traceId;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public int hashCode() {
        return Objects.hash(this.traceId, this.spanId, this.parentSpanId, this.op, this.description, this.status);
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        objectWriter.name("trace_id");
        this.traceId.serialize(objectWriter, iLogger);
        objectWriter.name("span_id");
        this.spanId.serialize(objectWriter, iLogger);
        if (this.parentSpanId != null) {
            objectWriter.name("parent_span_id");
            this.parentSpanId.serialize(objectWriter, iLogger);
        }
        objectWriter.name("op").value(this.op);
        if (this.description != null) {
            objectWriter.name("description").value(this.description);
        }
        if (this.status != null) {
            objectWriter.name("status").value(iLogger, this.status);
        }
        if (this.origin != null) {
            objectWriter.name("origin").value(iLogger, this.origin);
        }
        if (!this.tags.isEmpty()) {
            objectWriter.name("tags").value(iLogger, this.tags);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setDescription(String string2) {
        this.description = string2;
    }

    public void setOperation(String string2) {
        this.op = Objects.requireNonNull(string2, "operation is required");
    }

    public void setOrigin(String string2) {
        this.origin = string2;
    }

    public void setSampled(Boolean bl) {
        if (bl == null) {
            this.setSamplingDecision(null);
        } else {
            this.setSamplingDecision(new TracesSamplingDecision(bl));
        }
    }

    public void setSampled(Boolean bl, Boolean bl2) {
        if (bl == null) {
            this.setSamplingDecision(null);
        } else if (bl2 == null) {
            this.setSamplingDecision(new TracesSamplingDecision(bl));
        } else {
            this.setSamplingDecision(new TracesSamplingDecision(bl, null, bl2, null));
        }
    }

    public void setSamplingDecision(TracesSamplingDecision tracesSamplingDecision) {
        this.samplingDecision = tracesSamplingDecision;
    }

    public void setStatus(SpanStatus spanStatus) {
        this.status = spanStatus;
    }

    public void setTag(String string2, String string3) {
        Objects.requireNonNull(string2, "name is required");
        Objects.requireNonNull(string3, "value is required");
        this.tags.put((Object)string2, (Object)string3);
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SpanContext> {
        @Override
        public SpanContext deserialize(JsonObjectReader object, ILogger object2) throws Exception {
            Object object3;
            ConcurrentHashMap concurrentHashMap;
            ConcurrentHashMap concurrentHashMap2;
            ConcurrentHashMap concurrentHashMap3;
            Object object4;
            ConcurrentHashMap concurrentHashMap4;
            ((JsonReader)object).beginObject();
            ConcurrentHashMap concurrentHashMap5 = null;
            SentryId sentryId = null;
            ConcurrentHashMap concurrentHashMap6 = concurrentHashMap4 = (object4 = (concurrentHashMap3 = (concurrentHashMap2 = (concurrentHashMap = (object3 = null)))));
            Object object5 = concurrentHashMap;
            concurrentHashMap = concurrentHashMap5;
            block20: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string2 = ((JsonReader)object).nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1270300245: {
                        if (!string2.equals((Object)"trace_id")) break;
                        n3 = 7;
                        break;
                    }
                    case 3552281: {
                        if (!string2.equals((Object)"tags")) break;
                        n3 = 6;
                        break;
                    }
                    case 3553: {
                        if (!string2.equals((Object)"op")) break;
                        n3 = 5;
                        break;
                    }
                    case -892481550: {
                        if (!string2.equals((Object)"status")) break;
                        n3 = 4;
                        break;
                    }
                    case -1008619738: {
                        if (!string2.equals((Object)"origin")) break;
                        n3 = 3;
                        break;
                    }
                    case -1724546052: {
                        if (!string2.equals((Object)"description")) break;
                        n3 = 2;
                        break;
                    }
                    case -1757797477: {
                        if (!string2.equals((Object)"parent_span_id")) break;
                        n3 = 1;
                        break;
                    }
                    case -2011840976: {
                        if (!string2.equals((Object)"span_id")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        concurrentHashMap5 = concurrentHashMap2;
                        if (concurrentHashMap2 == null) {
                            concurrentHashMap5 = new ConcurrentHashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown((ILogger)object2, (Map<String, Object>)concurrentHashMap5, string2);
                        concurrentHashMap2 = concurrentHashMap5;
                        continue block20;
                    }
                    case 7: {
                        sentryId = new SentryId.Deserializer().deserialize((JsonObjectReader)object, (ILogger)object2);
                        continue block20;
                    }
                    case 6: {
                        concurrentHashMap6 = CollectionUtils.newConcurrentHashMap((Map)((JsonObjectReader)object).nextObjectOrNull());
                        continue block20;
                    }
                    case 5: {
                        concurrentHashMap = ((JsonReader)object).nextString();
                        continue block20;
                    }
                    case 4: {
                        object4 = ((JsonObjectReader)object).nextOrNull((ILogger)object2, new SpanStatus.Deserializer());
                        continue block20;
                    }
                    case 3: {
                        concurrentHashMap4 = ((JsonReader)object).nextString();
                        continue block20;
                    }
                    case 2: {
                        concurrentHashMap3 = ((JsonReader)object).nextString();
                        continue block20;
                    }
                    case 1: {
                        object5 = ((JsonObjectReader)object).nextOrNull((ILogger)object2, new SpanId.Deserializer());
                        continue block20;
                    }
                    case 0: 
                }
                object3 = new SpanId.Deserializer().deserialize((JsonObjectReader)object, (ILogger)object2);
            }
            if (sentryId != null) {
                if (object3 != null) {
                    object2 = concurrentHashMap == null ? "" : concurrentHashMap;
                    object2 = new SpanContext(sentryId, (SpanId)object3, (String)object2, (SpanId)object5, null);
                    ((SpanContext)object2).setDescription((String)concurrentHashMap3);
                    ((SpanContext)object2).setStatus((SpanStatus)object4);
                    ((SpanContext)object2).setOrigin((String)concurrentHashMap4);
                    if (concurrentHashMap6 != null) {
                        ((SpanContext)object2).tags = concurrentHashMap6;
                    }
                    ((SpanContext)object2).setUnknown((Map<String, Object>)concurrentHashMap2);
                    ((JsonReader)object).endObject();
                    return object2;
                }
                object = new IllegalStateException("Missing required field \"span_id\"");
                object2.log(SentryLevel.ERROR, "Missing required field \"span_id\"", (Throwable)object);
                throw object;
            }
            object = new IllegalStateException("Missing required field \"trace_id\"");
            object2.log(SentryLevel.ERROR, "Missing required field \"trace_id\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String DESCRIPTION = "description";
        public static final String OP = "op";
        public static final String ORIGIN = "origin";
        public static final String PARENT_SPAN_ID = "parent_span_id";
        public static final String SPAN_ID = "span_id";
        public static final String STATUS = "status";
        public static final String TAGS = "tags";
        public static final String TRACE_ID = "trace_id";
    }
}

