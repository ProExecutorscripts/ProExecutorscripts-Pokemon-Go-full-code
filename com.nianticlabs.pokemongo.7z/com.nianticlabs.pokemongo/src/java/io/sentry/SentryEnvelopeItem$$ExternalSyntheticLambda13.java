/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.ISerializer;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryEnvelopeItem;
import java.io.File;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem$$ExternalSyntheticLambda13
implements Callable {
    public final File f$0;
    public final long f$1;
    public final ProfilingTraceData f$2;
    public final ISerializer f$3;

    public /* synthetic */ SentryEnvelopeItem$$ExternalSyntheticLambda13(File file, long l2, ProfilingTraceData profilingTraceData, ISerializer iSerializer) {
        this.f$0 = file;
        this.f$1 = l2;
        this.f$2 = profilingTraceData;
        this.f$3 = iSerializer;
    }

    public final Object call() {
        return SentryEnvelopeItem.lambda$fromProfilingTrace$18(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

