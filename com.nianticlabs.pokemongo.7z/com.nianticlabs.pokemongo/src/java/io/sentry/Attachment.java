/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

import io.sentry.JsonSerializable;
import io.sentry.protocol.ViewHierarchy;
import java.io.File;

public final class Attachment {
    private static final String DEFAULT_ATTACHMENT_TYPE = "event.attachment";
    private static final String VIEW_HIERARCHY_ATTACHMENT_TYPE = "event.view_hierarchy";
    private final boolean addToTransactions;
    private String attachmentType;
    private byte[] bytes;
    private final String contentType;
    private final String filename;
    private String pathname;
    private final JsonSerializable serializable;

    public Attachment(JsonSerializable jsonSerializable, String string2, String string3, String string4, boolean bl) {
        this.bytes = null;
        this.serializable = jsonSerializable;
        this.filename = string2;
        this.contentType = string3;
        this.attachmentType = string4;
        this.addToTransactions = bl;
    }

    public Attachment(String string2) {
        this(string2, new File(string2).getName());
    }

    public Attachment(String string2, String string3) {
        this(string2, string3, null);
    }

    public Attachment(String string2, String string3, String string4) {
        this(string2, string3, string4, DEFAULT_ATTACHMENT_TYPE, false);
    }

    public Attachment(String string2, String string3, String string4, String string5, boolean bl) {
        this.pathname = string2;
        this.filename = string3;
        this.serializable = null;
        this.contentType = string4;
        this.attachmentType = string5;
        this.addToTransactions = bl;
    }

    public Attachment(String string2, String string3, String string4, boolean bl) {
        this.attachmentType = DEFAULT_ATTACHMENT_TYPE;
        this.pathname = string2;
        this.filename = string3;
        this.serializable = null;
        this.contentType = string4;
        this.addToTransactions = bl;
    }

    public Attachment(String string2, String string3, String string4, boolean bl, String string5) {
        this.pathname = string2;
        this.filename = string3;
        this.serializable = null;
        this.contentType = string4;
        this.addToTransactions = bl;
        this.attachmentType = string5;
    }

    public Attachment(byte[] byArray, String string2) {
        this(byArray, string2, null);
    }

    public Attachment(byte[] byArray, String string2, String string3) {
        this(byArray, string2, string3, false);
    }

    public Attachment(byte[] byArray, String string2, String string3, String string4, boolean bl) {
        this.bytes = byArray;
        this.serializable = null;
        this.filename = string2;
        this.contentType = string3;
        this.attachmentType = string4;
        this.addToTransactions = bl;
    }

    public Attachment(byte[] byArray, String string2, String string3, boolean bl) {
        this(byArray, string2, string3, DEFAULT_ATTACHMENT_TYPE, bl);
    }

    public static Attachment fromScreenshot(byte[] byArray) {
        return new Attachment(byArray, "screenshot.png", "image/png", false);
    }

    public static Attachment fromThreadDump(byte[] byArray) {
        return new Attachment(byArray, "thread-dump.txt", "text/plain", false);
    }

    public static Attachment fromViewHierarchy(ViewHierarchy viewHierarchy) {
        return new Attachment(viewHierarchy, "view-hierarchy.json", "application/json", VIEW_HIERARCHY_ATTACHMENT_TYPE, false);
    }

    public String getAttachmentType() {
        return this.attachmentType;
    }

    public byte[] getBytes() {
        return this.bytes;
    }

    public String getContentType() {
        return this.contentType;
    }

    public String getFilename() {
        return this.filename;
    }

    public String getPathname() {
        return this.pathname;
    }

    public JsonSerializable getSerializable() {
        return this.serializable;
    }

    boolean isAddToTransactions() {
        return this.addToTransactions;
    }
}

