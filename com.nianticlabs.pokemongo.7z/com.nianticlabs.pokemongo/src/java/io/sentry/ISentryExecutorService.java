/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.RejectedExecutionException
 */
package io.sentry;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

public interface ISentryExecutorService {
    public void close(long var1);

    public boolean isClosed();

    public Future<?> schedule(Runnable var1, long var2) throws RejectedExecutionException;

    public Future<?> submit(Runnable var1) throws RejectedExecutionException;

    public <T> Future<T> submit(Callable<T> var1) throws RejectedExecutionException;
}

