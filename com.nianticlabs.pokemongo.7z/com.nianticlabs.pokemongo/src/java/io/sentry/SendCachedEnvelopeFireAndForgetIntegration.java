/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry;

import io.sentry.DataCategory;
import io.sentry.DirectoryProcessor;
import io.sentry.IConnectionStatusProvider;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.SendCachedEnvelopeFireAndForgetIntegration$$ExternalSyntheticLambda0;
import io.sentry.SendCachedEnvelopeFireAndForgetIntegration$SendFireAndForgetFactory$$ExternalSyntheticLambda0;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.transport.RateLimiter;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SendCachedEnvelopeFireAndForgetIntegration
implements Integration,
IConnectionStatusProvider.IConnectionStatusObserver,
Closeable {
    private IConnectionStatusProvider connectionStatusProvider;
    private final SendFireAndForgetFactory factory;
    private IHub hub;
    private final AtomicBoolean isClosed;
    private final AtomicBoolean isInitialized = new AtomicBoolean(false);
    private SentryOptions options;
    private SendFireAndForget sender;

    public SendCachedEnvelopeFireAndForgetIntegration(SendFireAndForgetFactory sendFireAndForgetFactory) {
        this.isClosed = new AtomicBoolean(false);
        this.factory = Objects.requireNonNull(sendFireAndForgetFactory, "SendFireAndForgetFactory is required");
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void sendCachedEnvelopes(IHub iHub, SentryOptions sentryOptions) {
        SendCachedEnvelopeFireAndForgetIntegration sendCachedEnvelopeFireAndForgetIntegration = this;
        synchronized (sendCachedEnvelopeFireAndForgetIntegration) {
            void var2_4;
            try {
                ISentryExecutorService iSentryExecutorService = var2_4.getExecutorService();
                SendCachedEnvelopeFireAndForgetIntegration$$ExternalSyntheticLambda0 sendCachedEnvelopeFireAndForgetIntegration$$ExternalSyntheticLambda0 = new SendCachedEnvelopeFireAndForgetIntegration$$ExternalSyntheticLambda0(this, (SentryOptions)var2_4, iHub);
                iSentryExecutorService.submit(sendCachedEnvelopeFireAndForgetIntegration$$ExternalSyntheticLambda0);
            }
            catch (Throwable throwable) {
                var2_4.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Cached events will not be sent", throwable);
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                var2_4.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Cached events will not be sent. Did you call Sentry.close()?", rejectedExecutionException);
            }
            return;
        }
    }

    public void close() throws IOException {
        this.isClosed.set(true);
        IConnectionStatusProvider iConnectionStatusProvider = this.connectionStatusProvider;
        if (iConnectionStatusProvider != null) {
            iConnectionStatusProvider.removeConnectionStatusObserver(this);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendCachedEnvelopes$0$io-sentry-SendCachedEnvelopeFireAndForgetIntegration(SentryOptions sentryOptions, IHub object) {
        try {
            IConnectionStatusProvider iConnectionStatusProvider;
            if (this.isClosed.get()) {
                sentryOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeFireAndForgetIntegration, not trying to send after closing.", new Object[0]);
                return;
            }
            if (!this.isInitialized.getAndSet(true)) {
                this.connectionStatusProvider = iConnectionStatusProvider = sentryOptions.getConnectionStatusProvider();
                iConnectionStatusProvider.addConnectionStatusObserver(this);
                this.sender = this.factory.create((IHub)object, sentryOptions);
            }
            if ((iConnectionStatusProvider = this.connectionStatusProvider) != null && iConnectionStatusProvider.getConnectionStatus() == IConnectionStatusProvider.ConnectionStatus.DISCONNECTED) {
                sentryOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeFireAndForgetIntegration, no connection.", new Object[0]);
                return;
            }
            if ((object = object.getRateLimiter()) != null && ((RateLimiter)object).isActiveForCategory(DataCategory.All)) {
                sentryOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeFireAndForgetIntegration, rate limiting active.", new Object[0]);
                return;
            }
            object = this.sender;
            if (object == null) {
                sentryOptions.getLogger().log(SentryLevel.ERROR, "SendFireAndForget factory is null.", new Object[0]);
                return;
            }
            object.send();
            return;
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed trying to send cached events.", throwable);
        }
    }

    @Override
    public void onConnectionStatusChanged(IConnectionStatusProvider.ConnectionStatus object) {
        SentryOptions sentryOptions;
        object = this.hub;
        if (object != null && (sentryOptions = this.options) != null) {
            this.sendCachedEnvelopes((IHub)object, sentryOptions);
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        this.hub = Objects.requireNonNull(iHub, "Hub is required");
        this.options = Objects.requireNonNull(sentryOptions, "SentryOptions is required");
        String string2 = sentryOptions.getCacheDirPath();
        if (!this.factory.hasValidPath(string2, sentryOptions.getLogger())) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "No cache dir path is defined in options.", new Object[0]);
            return;
        }
        sentryOptions.getLogger().log(SentryLevel.DEBUG, "SendCachedEventFireAndForgetIntegration installed.", new Object[0]);
        IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        this.sendCachedEnvelopes(iHub, sentryOptions);
    }

    public static interface SendFireAndForget {
        public void send();
    }

    public static interface SendFireAndForgetDirPath {
        public String getDirPath();
    }

    public static interface SendFireAndForgetFactory {
        public static /* synthetic */ void lambda$processDir$0(ILogger iLogger, String string2, DirectoryProcessor directoryProcessor, File file) {
            iLogger.log(SentryLevel.DEBUG, "Started processing cached files from %s", string2);
            directoryProcessor.processDirectory(file);
            iLogger.log(SentryLevel.DEBUG, "Finished processing cached files from %s", string2);
        }

        public SendFireAndForget create(IHub var1, SentryOptions var2);

        default public boolean hasValidPath(String string2, ILogger iLogger) {
            if (string2 != null && !string2.isEmpty()) {
                return true;
            }
            iLogger.log(SentryLevel.INFO, "No cached dir path is defined in options.", new Object[0]);
            return false;
        }

        default public SendFireAndForget processDir(DirectoryProcessor directoryProcessor, String string2, ILogger iLogger) {
            return new SendCachedEnvelopeFireAndForgetIntegration$SendFireAndForgetFactory$$ExternalSyntheticLambda0(iLogger, string2, directoryProcessor, new File(string2));
        }
    }
}

