/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.SentryEnvelope;
import java.io.IOException;
import java.io.InputStream;

public interface IEnvelopeReader {
    public SentryEnvelope read(InputStream var1) throws IOException;
}

