/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.SentryDate;
import io.sentry.SentryDateProvider;
import io.sentry.SentryNanotimeDate;

public final class SentryNanotimeDateProvider
implements SentryDateProvider {
    @Override
    public SentryDate now() {
        return new SentryNanotimeDate();
    }
}

