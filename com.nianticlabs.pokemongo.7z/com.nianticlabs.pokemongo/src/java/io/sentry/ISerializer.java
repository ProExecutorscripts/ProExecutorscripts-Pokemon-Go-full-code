/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry;

import io.sentry.JsonDeserializer;
import io.sentry.SentryEnvelope;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;

public interface ISerializer {
    public <T> T deserialize(Reader var1, Class<T> var2);

    public <T, R> T deserializeCollection(Reader var1, Class<T> var2, JsonDeserializer<R> var3);

    public SentryEnvelope deserializeEnvelope(InputStream var1);

    public String serialize(Map<String, Object> var1) throws Exception;

    public void serialize(SentryEnvelope var1, OutputStream var2) throws Exception;

    public <T> void serialize(T var1, Writer var2) throws IOException;
}

