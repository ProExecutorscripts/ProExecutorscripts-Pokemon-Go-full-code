/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.hints.SubmissionResult;
import io.sentry.transport.AsyncHttpTransport;
import io.sentry.transport.TransportResult;
import io.sentry.util.HintUtils;

public final class AsyncHttpTransport$EnvelopeSender$$ExternalSyntheticLambda0
implements HintUtils.SentryConsumer {
    public final AsyncHttpTransport.EnvelopeSender f$0;
    public final TransportResult f$1;

    public /* synthetic */ AsyncHttpTransport$EnvelopeSender$$ExternalSyntheticLambda0(AsyncHttpTransport.EnvelopeSender envelopeSender, TransportResult transportResult) {
        this.f$0 = envelopeSender;
        this.f$1 = transportResult;
    }

    public final void accept(Object object) {
        this.f$0.lambda$run$0$io-sentry-transport-AsyncHttpTransport$EnvelopeSender(this.f$1, (SubmissionResult)object);
    }
}

