/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.transport;

import io.sentry.Hint;
import io.sentry.SentryEnvelope;
import io.sentry.transport.ITransport;
import io.sentry.transport.RateLimiter;
import java.io.IOException;

public final class NoOpTransport
implements ITransport {
    private static final NoOpTransport instance = new NoOpTransport();

    private NoOpTransport() {
    }

    public static NoOpTransport getInstance() {
        return instance;
    }

    public void close() throws IOException {
    }

    @Override
    public void close(boolean bl) throws IOException {
    }

    @Override
    public void flush(long l2) {
    }

    @Override
    public RateLimiter getRateLimiter() {
        return null;
    }

    @Override
    public void send(SentryEnvelope sentryEnvelope, Hint hint) throws IOException {
    }
}

