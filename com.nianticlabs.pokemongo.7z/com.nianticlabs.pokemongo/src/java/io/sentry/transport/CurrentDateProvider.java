/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.System
 */
package io.sentry.transport;

import io.sentry.transport.ICurrentDateProvider;

public final class CurrentDateProvider
implements ICurrentDateProvider {
    private static final ICurrentDateProvider instance = new CurrentDateProvider();

    private CurrentDateProvider() {
    }

    public static ICurrentDateProvider getInstance() {
        return instance;
    }

    @Override
    public final long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }
}

