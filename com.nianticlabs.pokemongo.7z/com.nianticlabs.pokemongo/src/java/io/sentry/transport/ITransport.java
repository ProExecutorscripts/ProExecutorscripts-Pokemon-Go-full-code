/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.Hint;
import io.sentry.SentryEnvelope;
import io.sentry.transport.RateLimiter;
import java.io.Closeable;
import java.io.IOException;

public interface ITransport
extends Closeable {
    public void close(boolean var1) throws IOException;

    public void flush(long var1);

    public RateLimiter getRateLimiter();

    default public boolean isHealthy() {
        return true;
    }

    default public void send(SentryEnvelope sentryEnvelope) throws IOException {
        this.send(sentryEnvelope, new Hint());
    }

    public void send(SentryEnvelope var1, Hint var2) throws IOException;
}

