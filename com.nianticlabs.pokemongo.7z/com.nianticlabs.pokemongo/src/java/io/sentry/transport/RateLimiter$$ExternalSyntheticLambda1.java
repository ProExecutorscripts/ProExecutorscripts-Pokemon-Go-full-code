/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.hints.Retryable;
import io.sentry.transport.RateLimiter;
import io.sentry.util.HintUtils;

public final class RateLimiter$$ExternalSyntheticLambda1
implements HintUtils.SentryConsumer {
    public final boolean f$0;

    public /* synthetic */ RateLimiter$$ExternalSyntheticLambda1(boolean bl) {
        this.f$0 = bl;
    }

    public final void accept(Object object) {
        RateLimiter.lambda$markHintWhenSendingFailed$1(this.f$0, (Retryable)object);
    }
}

