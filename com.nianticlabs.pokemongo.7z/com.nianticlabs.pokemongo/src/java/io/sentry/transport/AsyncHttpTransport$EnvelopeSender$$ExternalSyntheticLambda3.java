/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.hints.Retryable;
import io.sentry.transport.AsyncHttpTransport;
import io.sentry.util.HintUtils;

public final class AsyncHttpTransport$EnvelopeSender$$ExternalSyntheticLambda3
implements HintUtils.SentryConsumer {
    public final void accept(Object object) {
        AsyncHttpTransport.EnvelopeSender.lambda$flush$3((Retryable)object);
    }
}

