/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.Future
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.RejectedExecutionHandler
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.ThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.transport;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.SentryDate;
import io.sentry.SentryDateProvider;
import io.sentry.SentryLevel;
import io.sentry.transport.ReusableCountLatch;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

final class QueuedThreadPoolExecutor
extends ThreadPoolExecutor {
    private static final long RECENT_THRESHOLD = DateUtils.millisToNanos(2000L);
    private final SentryDateProvider dateProvider;
    private SentryDate lastRejectTimestamp = null;
    private final ILogger logger;
    private final int maxQueueSize;
    private final ReusableCountLatch unfinishedTasksCount = new ReusableCountLatch();

    public QueuedThreadPoolExecutor(int n2, int n3, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler, ILogger iLogger, SentryDateProvider sentryDateProvider) {
        super(n2, n2, 0L, TimeUnit.MILLISECONDS, (BlockingQueue)new LinkedBlockingQueue(), threadFactory, rejectedExecutionHandler);
        this.maxQueueSize = n3;
        this.logger = iLogger;
        this.dateProvider = sentryDateProvider;
    }

    protected void afterExecute(Runnable runnable, Throwable throwable) {
        try {
            super.afterExecute(runnable, throwable);
            return;
        }
        finally {
            this.unfinishedTasksCount.decrement();
        }
    }

    public boolean didRejectRecently() {
        SentryDate sentryDate = this.lastRejectTimestamp;
        boolean bl = false;
        if (sentryDate == null) {
            return false;
        }
        if (this.dateProvider.now().diff(sentryDate) < RECENT_THRESHOLD) {
            bl = true;
        }
        return bl;
    }

    public boolean isSchedulingAllowed() {
        boolean bl = this.unfinishedTasksCount.getCount() < this.maxQueueSize;
        return bl;
    }

    public Future<?> submit(Runnable runnable) {
        if (this.isSchedulingAllowed()) {
            this.unfinishedTasksCount.increment();
            return super.submit(runnable);
        }
        this.lastRejectTimestamp = this.dateProvider.now();
        this.logger.log(SentryLevel.WARNING, "Submit cancelled", new Object[0]);
        return new CancelledFuture();
    }

    void waitTillIdle(long l2) {
        try {
            this.unfinishedTasksCount.waitTillZero(l2, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException interruptedException) {
            this.logger.log(SentryLevel.ERROR, "Failed to wait till idle", interruptedException);
            Thread.currentThread().interrupt();
        }
    }

    static final class CancelledFuture<T>
    implements Future<T> {
        CancelledFuture() {
        }

        public boolean cancel(boolean bl) {
            return true;
        }

        public T get() {
            throw new CancellationException();
        }

        public T get(long l2, TimeUnit timeUnit) {
            throw new CancellationException();
        }

        public boolean isCancelled() {
            return true;
        }

        public boolean isDone() {
            return true;
        }
    }
}

