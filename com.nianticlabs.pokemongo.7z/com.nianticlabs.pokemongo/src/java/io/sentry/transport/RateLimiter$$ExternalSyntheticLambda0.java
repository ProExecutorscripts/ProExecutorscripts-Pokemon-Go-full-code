/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.hints.SubmissionResult;
import io.sentry.transport.RateLimiter;
import io.sentry.util.HintUtils;

public final class RateLimiter$$ExternalSyntheticLambda0
implements HintUtils.SentryConsumer {
    public final void accept(Object object) {
        RateLimiter.lambda$markHintWhenSendingFailed$0((SubmissionResult)object);
    }
}

