/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 */
package io.sentry.transport;

import io.sentry.SentryEnvelope;
import io.sentry.transport.AsyncHttpTransport;
import io.sentry.util.HintUtils;

public final class AsyncHttpTransport$EnvelopeSender$$ExternalSyntheticLambda4
implements HintUtils.SentryHintFallback {
    public final AsyncHttpTransport.EnvelopeSender f$0;
    public final SentryEnvelope f$1;

    public /* synthetic */ AsyncHttpTransport$EnvelopeSender$$ExternalSyntheticLambda4(AsyncHttpTransport.EnvelopeSender envelopeSender, SentryEnvelope sentryEnvelope) {
        this.f$0 = envelopeSender;
        this.f$1 = sentryEnvelope;
    }

    public final void accept(Object object, Class clazz) {
        this.f$0.lambda$flush$4$io-sentry-transport-AsyncHttpTransport$EnvelopeSender(this.f$1, object, clazz);
    }
}

