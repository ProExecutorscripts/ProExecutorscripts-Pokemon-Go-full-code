/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.SentryTracer;
import java.util.concurrent.atomic.AtomicReference;

public final class SentryTracer$$ExternalSyntheticLambda3
implements ScopeCallback {
    public final AtomicReference f$0;

    public /* synthetic */ SentryTracer$$ExternalSyntheticLambda3(AtomicReference atomicReference) {
        this.f$0 = atomicReference;
    }

    @Override
    public final void run(IScope iScope) {
        SentryTracer.lambda$updateBaggageValues$3(this.f$0, iScope);
    }
}

