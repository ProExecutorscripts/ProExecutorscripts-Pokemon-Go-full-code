/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.CopyOnWriteArrayList
 *  java.util.concurrent.CopyOnWriteArraySet
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.config.PropertiesProvider;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public final class ExternalOptions {
    private static final String PROXY_PORT_DEFAULT = "80";
    private Set<String> bundleIds;
    private final List<String> contextTags;
    private SentryOptions.Cron cron;
    private Boolean debug;
    private String dist;
    private String dsn;
    private Boolean enableBackpressureHandling;
    private Boolean enableDeduplication;
    private Boolean enablePrettySerializationOutput;
    private Boolean enableTracing;
    private Boolean enableUncaughtExceptionHandler;
    private Boolean enabled;
    private String environment;
    private Long idleTimeout;
    private List<String> ignoredCheckIns;
    private final Set<Class<? extends Throwable>> ignoredExceptionsForType;
    private final List<String> inAppExcludes;
    private final List<String> inAppIncludes;
    private SentryOptions.RequestSize maxRequestBodySize;
    private Boolean printUncaughtStackTrace;
    private Double profilesSampleRate;
    private String proguardUuid;
    private SentryOptions.Proxy proxy;
    private String release;
    private Boolean sendClientReports;
    private Boolean sendModules;
    private String serverName;
    private final Map<String, String> tags = new ConcurrentHashMap();
    private List<String> tracePropagationTargets = null;
    private Double tracesSampleRate;

    public ExternalOptions() {
        this.inAppExcludes = new CopyOnWriteArrayList();
        this.inAppIncludes = new CopyOnWriteArrayList();
        this.contextTags = new CopyOnWriteArrayList();
        this.ignoredExceptionsForType = new CopyOnWriteArraySet();
        this.bundleIds = new CopyOnWriteArraySet();
    }

    public static ExternalOptions from(PropertiesProvider propertiesProvider, ILogger object) {
        Iterator iterator2;
        ExternalOptions externalOptions = new ExternalOptions();
        externalOptions.setDsn(propertiesProvider.getProperty("dsn"));
        externalOptions.setEnvironment(propertiesProvider.getProperty("environment"));
        externalOptions.setRelease(propertiesProvider.getProperty("release"));
        externalOptions.setDist(propertiesProvider.getProperty("dist"));
        externalOptions.setServerName(propertiesProvider.getProperty("servername"));
        externalOptions.setEnableUncaughtExceptionHandler(propertiesProvider.getBooleanProperty("uncaught.handler.enabled"));
        externalOptions.setPrintUncaughtStackTrace(propertiesProvider.getBooleanProperty("uncaught.handler.print-stacktrace"));
        externalOptions.setEnableTracing(propertiesProvider.getBooleanProperty("enable-tracing"));
        externalOptions.setTracesSampleRate(propertiesProvider.getDoubleProperty("traces-sample-rate"));
        externalOptions.setProfilesSampleRate(propertiesProvider.getDoubleProperty("profiles-sample-rate"));
        externalOptions.setDebug(propertiesProvider.getBooleanProperty("debug"));
        externalOptions.setEnableDeduplication(propertiesProvider.getBooleanProperty("enable-deduplication"));
        externalOptions.setSendClientReports(propertiesProvider.getBooleanProperty("send-client-reports"));
        Object object22 = propertiesProvider.getProperty("max-request-body-size");
        if (object22 != null) {
            externalOptions.setMaxRequestBodySize(SentryOptions.RequestSize.valueOf(object22.toUpperCase(Locale.ROOT)));
        }
        for (Iterator iterator2 : propertiesProvider.getMap("tags").entrySet()) {
            externalOptions.setTag((String)iterator2.getKey(), (String)iterator2.getValue());
        }
        iterator2 = propertiesProvider.getProperty("proxy.host");
        String string2 = propertiesProvider.getProperty("proxy.user");
        object22 = propertiesProvider.getProperty("proxy.pass");
        Object object3 = propertiesProvider.getProperty("proxy.port", PROXY_PORT_DEFAULT);
        if (iterator2 != null) {
            externalOptions.setProxy(new SentryOptions.Proxy((String)iterator2, (String)object3, string2, (String)object22));
        }
        object22 = propertiesProvider.getList("in-app-includes").iterator();
        while (object22.hasNext()) {
            externalOptions.addInAppInclude((String)object22.next());
        }
        object22 = propertiesProvider.getList("in-app-excludes").iterator();
        while (object22.hasNext()) {
            externalOptions.addInAppExclude((String)object22.next());
        }
        object22 = propertiesProvider.getProperty("trace-propagation-targets") != null ? propertiesProvider.getList("trace-propagation-targets") : null;
        iterator2 = object22;
        if (object22 == null) {
            iterator2 = object22;
            if (propertiesProvider.getProperty("tracing-origins") != null) {
                iterator2 = propertiesProvider.getList("tracing-origins");
            }
        }
        if (iterator2 != null) {
            object22 = iterator2.iterator();
            while (object22.hasNext()) {
                externalOptions.addTracePropagationTarget((String)object22.next());
            }
        }
        object22 = propertiesProvider.getList("context-tags").iterator();
        while (object22.hasNext()) {
            externalOptions.addContextTag((String)object22.next());
        }
        externalOptions.setProguardUuid(propertiesProvider.getProperty("proguard-uuid"));
        object22 = propertiesProvider.getList("bundle-ids").iterator();
        while (object22.hasNext()) {
            externalOptions.addBundleId((String)object22.next());
        }
        externalOptions.setIdleTimeout(propertiesProvider.getLongProperty("idle-timeout"));
        externalOptions.setEnabled(propertiesProvider.getBooleanProperty("enabled"));
        externalOptions.setEnablePrettySerializationOutput(propertiesProvider.getBooleanProperty("enable-pretty-serialization-output"));
        externalOptions.setSendModules(propertiesProvider.getBooleanProperty("send-modules"));
        externalOptions.setIgnoredCheckIns(propertiesProvider.getList("ignored-checkins"));
        externalOptions.setEnableBackpressureHandling(propertiesProvider.getBooleanProperty("enable-backpressure-handling"));
        for (Object object22 : propertiesProvider.getList("ignored-exceptions-for-type")) {
            try {
                string2 = Class.forName((String)object22);
                if (Throwable.class.isAssignableFrom((Class)string2)) {
                    externalOptions.addIgnoredExceptionForType((Class<? extends Throwable>)string2);
                    continue;
                }
                object.log(SentryLevel.WARNING, "Skipping setting %s as ignored-exception-for-type. Reason: %s does not extend Throwable", object22, object22);
            }
            catch (ClassNotFoundException classNotFoundException) {
                object.log(SentryLevel.WARNING, "Skipping setting %s as ignored-exception-for-type. Reason: %s class is not found", object22, object22);
            }
        }
        string2 = propertiesProvider.getLongProperty("cron.default-checkin-margin");
        iterator2 = propertiesProvider.getLongProperty("cron.default-max-runtime");
        object = propertiesProvider.getProperty("cron.default-timezone");
        object22 = propertiesProvider.getLongProperty("cron.default-failure-issue-threshold");
        propertiesProvider = propertiesProvider.getLongProperty("cron.default-recovery-threshold");
        if (string2 != null || iterator2 != null || object != null || object22 != null || propertiesProvider != null) {
            object3 = new SentryOptions.Cron();
            ((SentryOptions.Cron)object3).setDefaultCheckinMargin((Long)string2);
            ((SentryOptions.Cron)object3).setDefaultMaxRuntime((Long)iterator2);
            ((SentryOptions.Cron)object3).setDefaultTimezone((String)object);
            ((SentryOptions.Cron)object3).setDefaultFailureIssueThreshold((Long)object22);
            ((SentryOptions.Cron)object3).setDefaultRecoveryThreshold((Long)propertiesProvider);
            externalOptions.setCron((SentryOptions.Cron)object3);
        }
        return externalOptions;
    }

    public void addBundleId(String string2) {
        this.bundleIds.add((Object)string2);
    }

    public void addContextTag(String string2) {
        this.contextTags.add((Object)string2);
    }

    public void addIgnoredExceptionForType(Class<? extends Throwable> clazz) {
        this.ignoredExceptionsForType.add(clazz);
    }

    public void addInAppExclude(String string2) {
        this.inAppExcludes.add((Object)string2);
    }

    public void addInAppInclude(String string2) {
        this.inAppIncludes.add((Object)string2);
    }

    public void addTracePropagationTarget(String string2) {
        if (this.tracePropagationTargets == null) {
            this.tracePropagationTargets = new CopyOnWriteArrayList();
        }
        if (!string2.isEmpty()) {
            this.tracePropagationTargets.add((Object)string2);
        }
    }

    @Deprecated
    public void addTracingOrigin(String string2) {
        this.addTracePropagationTarget(string2);
    }

    public Set<String> getBundleIds() {
        return this.bundleIds;
    }

    public List<String> getContextTags() {
        return this.contextTags;
    }

    public SentryOptions.Cron getCron() {
        return this.cron;
    }

    public Boolean getDebug() {
        return this.debug;
    }

    public String getDist() {
        return this.dist;
    }

    public String getDsn() {
        return this.dsn;
    }

    public Boolean getEnableDeduplication() {
        return this.enableDeduplication;
    }

    public Boolean getEnableTracing() {
        return this.enableTracing;
    }

    public Boolean getEnableUncaughtExceptionHandler() {
        return this.enableUncaughtExceptionHandler;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public Long getIdleTimeout() {
        return this.idleTimeout;
    }

    public List<String> getIgnoredCheckIns() {
        return this.ignoredCheckIns;
    }

    public Set<Class<? extends Throwable>> getIgnoredExceptionsForType() {
        return this.ignoredExceptionsForType;
    }

    public List<String> getInAppExcludes() {
        return this.inAppExcludes;
    }

    public List<String> getInAppIncludes() {
        return this.inAppIncludes;
    }

    public SentryOptions.RequestSize getMaxRequestBodySize() {
        return this.maxRequestBodySize;
    }

    public Boolean getPrintUncaughtStackTrace() {
        return this.printUncaughtStackTrace;
    }

    public Double getProfilesSampleRate() {
        return this.profilesSampleRate;
    }

    public String getProguardUuid() {
        return this.proguardUuid;
    }

    public SentryOptions.Proxy getProxy() {
        return this.proxy;
    }

    public String getRelease() {
        return this.release;
    }

    public Boolean getSendClientReports() {
        return this.sendClientReports;
    }

    public String getServerName() {
        return this.serverName;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public List<String> getTracePropagationTargets() {
        return this.tracePropagationTargets;
    }

    public Double getTracesSampleRate() {
        return this.tracesSampleRate;
    }

    @Deprecated
    public List<String> getTracingOrigins() {
        return this.tracePropagationTargets;
    }

    public Boolean isEnableBackpressureHandling() {
        return this.enableBackpressureHandling;
    }

    public Boolean isEnablePrettySerializationOutput() {
        return this.enablePrettySerializationOutput;
    }

    public Boolean isEnabled() {
        return this.enabled;
    }

    public Boolean isSendModules() {
        return this.sendModules;
    }

    public void setCron(SentryOptions.Cron cron) {
        this.cron = cron;
    }

    public void setDebug(Boolean bl) {
        this.debug = bl;
    }

    public void setDist(String string2) {
        this.dist = string2;
    }

    public void setDsn(String string2) {
        this.dsn = string2;
    }

    public void setEnableBackpressureHandling(Boolean bl) {
        this.enableBackpressureHandling = bl;
    }

    public void setEnableDeduplication(Boolean bl) {
        this.enableDeduplication = bl;
    }

    public void setEnablePrettySerializationOutput(Boolean bl) {
        this.enablePrettySerializationOutput = bl;
    }

    public void setEnableTracing(Boolean bl) {
        this.enableTracing = bl;
    }

    public void setEnableUncaughtExceptionHandler(Boolean bl) {
        this.enableUncaughtExceptionHandler = bl;
    }

    public void setEnabled(Boolean bl) {
        this.enabled = bl;
    }

    public void setEnvironment(String string2) {
        this.environment = string2;
    }

    public void setIdleTimeout(Long l2) {
        this.idleTimeout = l2;
    }

    public void setIgnoredCheckIns(List<String> list) {
        this.ignoredCheckIns = list;
    }

    public void setMaxRequestBodySize(SentryOptions.RequestSize requestSize) {
        this.maxRequestBodySize = requestSize;
    }

    public void setPrintUncaughtStackTrace(Boolean bl) {
        this.printUncaughtStackTrace = bl;
    }

    public void setProfilesSampleRate(Double d2) {
        this.profilesSampleRate = d2;
    }

    public void setProguardUuid(String string2) {
        this.proguardUuid = string2;
    }

    public void setProxy(SentryOptions.Proxy proxy2) {
        this.proxy = proxy2;
    }

    public void setRelease(String string2) {
        this.release = string2;
    }

    public void setSendClientReports(Boolean bl) {
        this.sendClientReports = bl;
    }

    public void setSendModules(Boolean bl) {
        this.sendModules = bl;
    }

    public void setServerName(String string2) {
        this.serverName = string2;
    }

    public void setTag(String string2, String string3) {
        this.tags.put((Object)string2, (Object)string3);
    }

    public void setTracesSampleRate(Double d2) {
        this.tracesSampleRate = d2;
    }
}

