/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Executors
 *  java.util.concurrent.Future
 *  java.util.concurrent.ScheduledExecutorService
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.TimeUnit
 */
package io.sentry;

import io.sentry.ISentryExecutorService;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public final class SentryExecutorService
implements ISentryExecutorService {
    private final ScheduledExecutorService executorService;

    public SentryExecutorService() {
        this(Executors.newSingleThreadScheduledExecutor((ThreadFactory)new SentryExecutorServiceThreadFactory()));
    }

    SentryExecutorService(ScheduledExecutorService scheduledExecutorService) {
        this.executorService = scheduledExecutorService;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void close(long l2) {
        ScheduledExecutorService scheduledExecutorService;
        ScheduledExecutorService scheduledExecutorService2 = scheduledExecutorService = this.executorService;
        synchronized (scheduledExecutorService2) {
            if (!this.executorService.isShutdown()) {
                this.executorService.shutdown();
                try {
                    if (!this.executorService.awaitTermination(l2, TimeUnit.MILLISECONDS)) {
                        this.executorService.shutdownNow();
                    }
                }
                catch (InterruptedException interruptedException) {
                    this.executorService.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public boolean isClosed() {
        ScheduledExecutorService scheduledExecutorService;
        ScheduledExecutorService scheduledExecutorService2 = scheduledExecutorService = this.executorService;
        synchronized (scheduledExecutorService2) {
            return this.executorService.isShutdown();
        }
    }

    @Override
    public Future<?> schedule(Runnable runnable, long l2) {
        return this.executorService.schedule(runnable, l2, TimeUnit.MILLISECONDS);
    }

    @Override
    public Future<?> submit(Runnable runnable) {
        return this.executorService.submit(runnable);
    }

    @Override
    public <T> Future<T> submit(Callable<T> callable) {
        return this.executorService.submit(callable);
    }

    private static final class SentryExecutorServiceThreadFactory
    implements ThreadFactory {
        private int cnt;

        private SentryExecutorServiceThreadFactory() {
        }

        public Thread newThread(Runnable runnable) {
            StringBuilder stringBuilder = new StringBuilder("SentryExecutorServiceThreadFactory-");
            int n2 = this.cnt;
            this.cnt = n2 + 1;
            runnable = new Thread(runnable, stringBuilder.append(n2).toString());
            runnable.setDaemon(true);
            return runnable;
        }
    }
}

