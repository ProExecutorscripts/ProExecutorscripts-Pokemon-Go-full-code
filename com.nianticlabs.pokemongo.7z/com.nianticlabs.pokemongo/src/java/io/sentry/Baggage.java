/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.UnsupportedEncodingException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URLDecoder
 *  java.net.URLEncoder
 *  java.text.DecimalFormat
 *  java.text.DecimalFormatSymbols
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.TreeSet
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.Dsn;
import io.sentry.HubAdapter;
import io.sentry.ILogger;
import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.PropagationContext;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SpanContext;
import io.sentry.TraceContext;
import io.sentry.TracesSamplingDecision;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.protocol.User;
import io.sentry.util.SampleRateUtils;
import io.sentry.util.StringUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public final class Baggage {
    static final String CHARSET = "UTF-8";
    static final Integer MAX_BAGGAGE_LIST_MEMBER_COUNT;
    static final Integer MAX_BAGGAGE_STRING_LENGTH;
    static final String SENTRY_BAGGAGE_PREFIX = "sentry-";
    final Map<String, String> keyValues;
    final ILogger logger;
    private boolean mutable;
    final String thirdPartyHeader;

    static {
        MAX_BAGGAGE_STRING_LENGTH = 8192;
        MAX_BAGGAGE_LIST_MEMBER_COUNT = 64;
    }

    public Baggage(Baggage baggage) {
        this(baggage.keyValues, baggage.thirdPartyHeader, baggage.mutable, baggage.logger);
    }

    public Baggage(ILogger iLogger) {
        this((Map<String, String>)new HashMap(), null, true, iLogger);
    }

    public Baggage(Map<String, String> map2, String string2, boolean bl, ILogger iLogger) {
        this.keyValues = map2;
        this.logger = iLogger;
        this.mutable = bl;
        this.thirdPartyHeader = string2;
    }

    private static String decode(String string2) throws UnsupportedEncodingException {
        return URLDecoder.decode((String)string2, (String)CHARSET);
    }

    private String encode(String string2) throws UnsupportedEncodingException {
        return URLEncoder.encode((String)string2, (String)CHARSET).replaceAll("\\+", "%20");
    }

    public static Baggage fromEvent(SentryEvent sentryEvent, SentryOptions object) {
        Baggage baggage = new Baggage(((SentryOptions)object).getLogger());
        Object object2 = sentryEvent.getContexts().getTrace();
        object2 = object2 != null ? ((SpanContext)object2).getTraceId().toString() : null;
        baggage.setTraceId((String)object2);
        baggage.setPublicKey(new Dsn(((SentryOptions)object).getDsn()).getPublicKey());
        baggage.setRelease(sentryEvent.getRelease());
        baggage.setEnvironment(sentryEvent.getEnvironment());
        object = sentryEvent.getUser();
        object = object != null ? Baggage.getSegment((User)object) : null;
        baggage.setUserSegment((String)object);
        baggage.setTransaction(sentryEvent.getTransaction());
        baggage.setSampleRate(null);
        baggage.setSampled(null);
        baggage.freeze();
        return baggage;
    }

    public static Baggage fromHeader(String string2) {
        return Baggage.fromHeader(string2, false, HubAdapter.getInstance().getOptions().getLogger());
    }

    public static Baggage fromHeader(String string2, ILogger iLogger) {
        return Baggage.fromHeader(string2, false, iLogger);
    }

    public static Baggage fromHeader(String string2, boolean bl, ILogger iLogger) {
        HashMap hashMap = new HashMap();
        ArrayList arrayList = new ArrayList();
        boolean bl2 = true;
        if (string2 != null) {
            try {
                String[] stringArray = string2.split(",", -1);
                int n2 = stringArray.length;
                return n2;
            }
            finally {
                bl2 = true;
            }
        }
        string2 = arrayList.isEmpty() ? null : StringUtils.join(",", (Iterable<? extends CharSequence>)arrayList);
        return new Baggage((Map<String, String>)hashMap, string2, bl2, iLogger);
    }

    public static Baggage fromHeader(List<String> list) {
        return Baggage.fromHeader(list, false, HubAdapter.getInstance().getOptions().getLogger());
    }

    public static Baggage fromHeader(List<String> list, ILogger iLogger) {
        return Baggage.fromHeader(list, false, iLogger);
    }

    public static Baggage fromHeader(List<String> object, boolean bl, ILogger iLogger) {
        if (object != null) {
            return Baggage.fromHeader(StringUtils.join(",", object), bl, iLogger);
        }
        object = null;
        return Baggage.fromHeader(null, bl, iLogger);
    }

    private static String getSegment(User map2) {
        if (map2.getSegment() != null) {
            return map2.getSegment();
        }
        if ((map2 = map2.getData()) != null) {
            return (String)map2.get((Object)"segment");
        }
        return null;
    }

    private static boolean isHighQualityTransactionName(TransactionNameSource transactionNameSource) {
        boolean bl = transactionNameSource != null && !TransactionNameSource.URL.equals((Object)transactionNameSource);
        return bl;
    }

    private static Double sampleRate(TracesSamplingDecision tracesSamplingDecision) {
        if (tracesSamplingDecision == null) {
            return null;
        }
        return tracesSamplingDecision.getSampleRate();
    }

    private static String sampleRateToString(Double d2) {
        if (!SampleRateUtils.isValidTracesSampleRate(d2, false)) {
            return null;
        }
        return new DecimalFormat("#.################", DecimalFormatSymbols.getInstance((Locale)Locale.ROOT)).format((Object)d2);
    }

    private static Boolean sampled(TracesSamplingDecision tracesSamplingDecision) {
        if (tracesSamplingDecision == null) {
            return null;
        }
        return tracesSamplingDecision.getSampled();
    }

    public void freeze() {
        this.mutable = false;
    }

    public String get(String string2) {
        if (string2 == null) {
            return null;
        }
        return (String)this.keyValues.get((Object)string2);
    }

    public String getEnvironment() {
        return this.get("sentry-environment");
    }

    public String getPublicKey() {
        return this.get("sentry-public_key");
    }

    public String getRelease() {
        return this.get("sentry-release");
    }

    public String getSampleRate() {
        return this.get("sentry-sample_rate");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Double getSampleRateDouble() {
        String string2 = this.getSampleRate();
        if (string2 == null) return null;
        try {
            double d2 = Double.parseDouble((String)string2);
            if (!SampleRateUtils.isValidTracesSampleRate(d2, false)) return null;
            return d2;
        }
        catch (NumberFormatException numberFormatException) {
            return null;
        }
    }

    public String getSampled() {
        return this.get("sentry-sampled");
    }

    public String getThirdPartyHeader() {
        return this.thirdPartyHeader;
    }

    public String getTraceId() {
        return this.get("sentry-trace_id");
    }

    public String getTransaction() {
        return this.get("sentry-transaction");
    }

    public Map<String, Object> getUnknown() {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        for (Object object : this.keyValues.entrySet()) {
            String string2 = (String)object.getKey();
            object = (String)object.getValue();
            if (DSCKeys.ALL.contains((Object)string2) || object == null) continue;
            concurrentHashMap.put((Object)string2.replaceFirst(SENTRY_BAGGAGE_PREFIX, ""), object);
        }
        return concurrentHashMap;
    }

    public String getUserId() {
        return this.get("sentry-user_id");
    }

    public String getUserSegment() {
        return this.get("sentry-user_segment");
    }

    public boolean isMutable() {
        return this.mutable;
    }

    public void set(String string2, String string3) {
        if (this.mutable) {
            this.keyValues.put((Object)string2, (Object)string3);
        }
    }

    public void setEnvironment(String string2) {
        this.set("sentry-environment", string2);
    }

    public void setPublicKey(String string2) {
        this.set("sentry-public_key", string2);
    }

    public void setRelease(String string2) {
        this.set("sentry-release", string2);
    }

    public void setSampleRate(String string2) {
        this.set("sentry-sample_rate", string2);
    }

    public void setSampled(String string2) {
        this.set("sentry-sampled", string2);
    }

    public void setTraceId(String string2) {
        this.set("sentry-trace_id", string2);
    }

    public void setTransaction(String string2) {
        this.set("sentry-transaction", string2);
    }

    public void setUserId(String string2) {
        this.set("sentry-user_id", string2);
    }

    public void setUserSegment(String string2) {
        this.set("sentry-user_segment", string2);
    }

    public void setValuesFromScope(IScope object, SentryOptions sentryOptions) {
        PropagationContext propagationContext = object.getPropagationContext();
        object = object.getUser();
        this.setTraceId(propagationContext.getTraceId().toString());
        this.setPublicKey(new Dsn(sentryOptions.getDsn()).getPublicKey());
        this.setRelease(sentryOptions.getRelease());
        this.setEnvironment(sentryOptions.getEnvironment());
        object = object != null ? Baggage.getSegment((User)object) : null;
        this.setUserSegment((String)object);
        this.setTransaction(null);
        this.setSampleRate(null);
        this.setSampled(null);
    }

    public void setValuesFromTransaction(ITransaction iTransaction, User object, SentryOptions sentryOptions, TracesSamplingDecision tracesSamplingDecision) {
        this.setTraceId(iTransaction.getSpanContext().getTraceId().toString());
        this.setPublicKey(new Dsn(sentryOptions.getDsn()).getPublicKey());
        this.setRelease(sentryOptions.getRelease());
        this.setEnvironment(sentryOptions.getEnvironment());
        sentryOptions = null;
        object = object != null ? Baggage.getSegment((User)object) : null;
        this.setUserSegment((String)object);
        object = sentryOptions;
        if (Baggage.isHighQualityTransactionName(iTransaction.getTransactionNameSource())) {
            object = iTransaction.getName();
        }
        this.setTransaction((String)object);
        this.setSampleRate(Baggage.sampleRateToString(Baggage.sampleRate(tracesSamplingDecision)));
        this.setSampled(StringUtils.toString(Baggage.sampled(tracesSamplingDecision)));
    }

    public String toHeaderString(String string2) {
        int n2;
        StringBuilder stringBuilder = new StringBuilder();
        if (string2 != null && !string2.isEmpty()) {
            stringBuilder.append(string2);
            n2 = StringUtils.countOf(string2, ',') + 1;
            string2 = ",";
        } else {
            string2 = "";
            n2 = 0;
        }
        for (String string3 : new TreeSet((Collection)this.keyValues.keySet())) {
            int n3;
            Object object;
            String string4;
            block16: {
                string4 = (String)this.keyValues.get((Object)string3);
                if (string4 == null) continue;
                object = MAX_BAGGAGE_LIST_MEMBER_COUNT;
                if (n2 >= object) {
                    this.logger.log(SentryLevel.ERROR, "Not adding baggage value %s as the total number of list members would exceed the maximum of %s.", string3, object);
                    continue;
                }
                n3 = n2;
                object = this.encode(string3);
                n3 = n2;
                String string5 = this.encode(string4);
                n3 = n2;
                n3 = n2;
                StringBuilder stringBuilder2 = new StringBuilder();
                n3 = n2;
                object = stringBuilder2.append(string2).append((String)object).append("=").append(string5).toString();
                n3 = n2;
                int n4 = object.length();
                n3 = n2;
                int n5 = stringBuilder.length();
                n3 = n2;
                stringBuilder2 = MAX_BAGGAGE_STRING_LENGTH;
                n3 = n2++;
                if (n5 + n4 <= stringBuilder2.intValue()) break block16;
                n3 = n2;
                this.logger.log(SentryLevel.ERROR, "Not adding baggage value %s as the total header value length would exceed the maximum of %s.", string3, stringBuilder2);
            }
            n3 = n2;
            try {
                stringBuilder.append((String)object);
                string2 = ",";
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.ERROR, throwable, "Unable to encode baggage key value pair (key=%s,value=%s).", string3, string4);
                n2 = n3;
            }
        }
        return stringBuilder.toString();
    }

    public TraceContext toTraceContext() {
        String string2 = this.getTraceId();
        Object object = this.getPublicKey();
        if (string2 != null && object != null) {
            object = new TraceContext(new SentryId(string2), (String)object, this.getRelease(), this.getEnvironment(), this.getUserId(), this.getUserSegment(), this.getTransaction(), this.getSampleRate(), this.getSampled());
            ((TraceContext)object).setUnknown(this.getUnknown());
            return object;
        }
        return null;
    }

    public static final class DSCKeys {
        public static final List<String> ALL = Arrays.asList((Object[])new String[]{"sentry-trace_id", "sentry-public_key", "sentry-release", "sentry-user_id", "sentry-environment", "sentry-user_segment", "sentry-transaction", "sentry-sample_rate", "sentry-sampled"});
        public static final String ENVIRONMENT = "sentry-environment";
        public static final String PUBLIC_KEY = "sentry-public_key";
        public static final String RELEASE = "sentry-release";
        public static final String SAMPLED = "sentry-sampled";
        public static final String SAMPLE_RATE = "sentry-sample_rate";
        public static final String TRACE_ID = "sentry-trace_id";
        public static final String TRANSACTION = "sentry-transaction";
        public static final String USER_ID = "sentry-user_id";
        public static final String USER_SEGMENT = "sentry-user_segment";
    }
}

