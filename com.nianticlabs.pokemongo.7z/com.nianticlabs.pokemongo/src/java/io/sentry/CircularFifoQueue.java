/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.Serializable
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.AbstractCollection
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.NoSuchElementException
 *  java.util.Queue
 */
package io.sentry;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

final class CircularFifoQueue<E>
extends AbstractCollection<E>
implements Queue<E>,
Serializable {
    private static final long serialVersionUID = -8423413834657610406L;
    private transient E[] elements;
    private transient int end = 0;
    private transient boolean full = false;
    private final int maxElements;
    private transient int start = 0;

    public CircularFifoQueue() {
        this(32);
    }

    CircularFifoQueue(int n2) {
        if (n2 > 0) {
            Object[] objectArray = new Object[n2];
            this.elements = objectArray;
            this.maxElements = objectArray.length;
            return;
        }
        throw new IllegalArgumentException("The size must be greater than 0");
    }

    public CircularFifoQueue(Collection<? extends E> collection) {
        this(collection.size());
        this.addAll(collection);
    }

    static /* synthetic */ boolean access$102(CircularFifoQueue circularFifoQueue, boolean bl) {
        circularFifoQueue.full = bl;
        return bl;
    }

    static /* synthetic */ int access$202(CircularFifoQueue circularFifoQueue, int n2) {
        circularFifoQueue.end = n2;
        return n2;
    }

    static /* synthetic */ int access$500(CircularFifoQueue circularFifoQueue) {
        return circularFifoQueue.maxElements;
    }

    static /* synthetic */ int access$600(CircularFifoQueue circularFifoQueue, int n2) {
        return circularFifoQueue.decrement(n2);
    }

    private int decrement(int n2) {
        int n3;
        n2 = n3 = n2 - 1;
        if (n3 < 0) {
            n2 = this.maxElements - 1;
        }
        return n2;
    }

    private int increment(int n2) {
        int n3;
        n2 = n3 = n2 + 1;
        if (n3 >= this.maxElements) {
            n2 = 0;
        }
        return n2;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.elements = new Object[this.maxElements];
        int n2 = objectInputStream.readInt();
        for (int i2 = 0; i2 < n2; ++i2) {
            this.elements[i2] = objectInputStream.readObject();
        }
        this.start = 0;
        boolean bl = n2 == this.maxElements;
        this.full = bl;
        this.end = bl ? 0 : n2;
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeInt(this.size());
        Iterator<E> iterator = this.iterator();
        while (iterator.hasNext()) {
            objectOutputStream.writeObject(iterator.next());
        }
    }

    public boolean add(E e2) {
        if (e2 != null) {
            int n2;
            if (this.isAtFullCapacity()) {
                this.remove();
            }
            E[] EArray = this.elements;
            int n3 = this.end;
            this.end = n2 = n3 + 1;
            EArray[n3] = e2;
            if (n2 >= this.maxElements) {
                this.end = 0;
            }
            if (this.end == this.start) {
                this.full = true;
            }
            return true;
        }
        throw new NullPointerException("Attempted to add null object to queue");
    }

    public void clear() {
        this.full = false;
        this.start = 0;
        this.end = 0;
        Arrays.fill((Object[])this.elements, null);
    }

    public E element() {
        if (!this.isEmpty()) {
            return this.peek();
        }
        throw new NoSuchElementException("queue is empty");
    }

    public E get(int n2) {
        int n3 = this.size();
        if (n2 >= 0 && n2 < n3) {
            n3 = this.start;
            int n4 = this.maxElements;
            return this.elements[(n3 + n2) % n4];
        }
        throw new NoSuchElementException(String.format((String)"The specified index (%1$d) is outside the available range [0, %2$d)", (Object[])new Object[]{n2, n3}));
    }

    public boolean isAtFullCapacity() {
        boolean bl = this.size() == this.maxElements;
        return bl;
    }

    public boolean isEmpty() {
        boolean bl = this.size() == 0;
        return bl;
    }

    public boolean isFull() {
        return false;
    }

    public Iterator<E> iterator() {
        return new Iterator<E>(this){
            private int index;
            private boolean isFirst;
            private int lastReturnedIndex;
            final CircularFifoQueue this$0;
            {
                this.this$0 = circularFifoQueue;
                this.index = circularFifoQueue.start;
                this.lastReturnedIndex = -1;
                this.isFirst = circularFifoQueue.full;
            }

            public boolean hasNext() {
                boolean bl = this.isFirst || this.index != this.this$0.end;
                return bl;
            }

            public E next() {
                if (this.hasNext()) {
                    int n2;
                    this.isFirst = false;
                    this.lastReturnedIndex = n2 = this.index;
                    this.index = this.this$0.increment(n2);
                    return this.this$0.elements[this.lastReturnedIndex];
                }
                throw new NoSuchElementException();
            }

            /*
             * Unable to fully structure code
             */
            public void remove() {
                block5: {
                    var1_1 = this.lastReturnedIndex;
                    if (var1_1 == -1) break block5;
                    if (var1_1 == CircularFifoQueue.access$000(this.this$0)) {
                        this.this$0.remove();
                        this.lastReturnedIndex = -1;
                        return;
                    }
                    var1_1 = var2_2 = this.lastReturnedIndex + 1;
                    if (CircularFifoQueue.access$000(this.this$0) >= this.lastReturnedIndex) ** GOTO lbl-1000
                    var1_1 = var2_2;
                    if (var2_2 < CircularFifoQueue.access$200(this.this$0)) {
                        System.arraycopy((Object)CircularFifoQueue.access$400(this.this$0), (int)var2_2, (Object)CircularFifoQueue.access$400(this.this$0), (int)this.lastReturnedIndex, (int)(CircularFifoQueue.access$200(this.this$0) - var2_2));
                    } else lbl-1000:
                    // 4 sources

                    {
                        while (var1_1 != CircularFifoQueue.access$200(this.this$0)) {
                            if (var1_1 >= CircularFifoQueue.access$500(this.this$0)) {
                                CircularFifoQueue.access$400((CircularFifoQueue)this.this$0)[var1_1 - 1] = CircularFifoQueue.access$400(this.this$0)[0];
                                var1_1 = 0;
                                continue;
                            }
                            CircularFifoQueue.access$400((CircularFifoQueue)this.this$0)[CircularFifoQueue.access$600((CircularFifoQueue)this.this$0, (int)var1_1)] = CircularFifoQueue.access$400(this.this$0)[var1_1];
                            var1_1 = CircularFifoQueue.access$300(this.this$0, var1_1);
                        }
                    }
                    this.lastReturnedIndex = -1;
                    var3_3 = this.this$0;
                    CircularFifoQueue.access$202(var3_3, CircularFifoQueue.access$600(var3_3, CircularFifoQueue.access$200(var3_3)));
                    CircularFifoQueue.access$400((CircularFifoQueue)this.this$0)[CircularFifoQueue.access$200((CircularFifoQueue)this.this$0)] = null;
                    CircularFifoQueue.access$102(this.this$0, false);
                    this.index = CircularFifoQueue.access$600(this.this$0, this.index);
                    return;
                }
                throw new IllegalStateException();
            }
        };
    }

    public int maxSize() {
        return this.maxElements;
    }

    public boolean offer(E e2) {
        return this.add(e2);
    }

    public E peek() {
        if (this.isEmpty()) {
            return null;
        }
        return this.elements[this.start];
    }

    public E poll() {
        if (this.isEmpty()) {
            return null;
        }
        return this.remove();
    }

    public E remove() {
        if (!this.isEmpty()) {
            E[] EArray = this.elements;
            int n2 = this.start;
            E e2 = EArray[n2];
            if (e2 != null) {
                int n3;
                this.start = n3 = n2 + 1;
                EArray[n2] = null;
                if (n3 >= this.maxElements) {
                    this.start = 0;
                }
                this.full = false;
            }
            return e2;
        }
        throw new NoSuchElementException("queue is empty");
    }

    public int size() {
        int n2 = this.end;
        int n3 = this.start;
        n3 = n2 < n3 ? this.maxElements - n3 + n2 : (n2 == n3 ? (this.full ? this.maxElements : 0) : n2 - n3);
        return n3;
    }
}

