/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.cache;

import io.sentry.SentryLevel;
import io.sentry.cache.PersistingScopeObserver;

public final class PersistingScopeObserver$$ExternalSyntheticLambda0
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final SentryLevel f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda0(PersistingScopeObserver persistingScopeObserver, SentryLevel sentryLevel) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = sentryLevel;
    }

    public final void run() {
        this.f$0.lambda$setLevel$6$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

