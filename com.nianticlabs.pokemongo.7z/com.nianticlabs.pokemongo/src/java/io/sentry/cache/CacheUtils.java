/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.BufferedWriter
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 */
package io.sentry.cache;

import io.sentry.JsonDeserializer;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;

final class CacheUtils {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");

    CacheUtils() {
    }

    static void delete(SentryOptions sentryOptions, String string2, String string3) {
        if ((string2 = CacheUtils.ensureCacheDir(sentryOptions, string2)) == null) {
            sentryOptions.getLogger().log(SentryLevel.INFO, "Cache dir is not set, cannot delete from scope cache", new Object[0]);
            return;
        }
        if ((string2 = new File((File)string2, string3)).exists()) {
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "Deleting %s from scope cache", string3);
            if (!string2.delete()) {
                sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to delete: %s", string2.getAbsolutePath());
            }
        }
    }

    private static File ensureCacheDir(SentryOptions object, String string2) {
        if ((object = ((SentryOptions)object).getCacheDirPath()) == null) {
            return null;
        }
        object = new File((String)object, string2);
        object.mkdirs();
        return object;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    static <T, R> T read(SentryOptions var0, String var1_1, String var2_4, Class<T> var3_5, JsonDeserializer<R> var4_7) {
        block13: {
            block12: {
                block11: {
                    if ((var1_1 = CacheUtils.ensureCacheDir(var0, var1_1)) == null) {
                        var0.getLogger().log(SentryLevel.INFO, "Cache dir is not set, cannot read from scope cache", new Object[0]);
                        return null;
                    }
                    var7_8 = new File((File)var1_1, var2_4);
                    if (!var7_8.exists()) break block12;
                    var6_10 = new FileInputStream(var7_8);
                    var5_9 = new InputStreamReader((InputStream)var6_10, CacheUtils.UTF_8);
                    var1_1 = new BufferedReader((Reader)var5_9);
                    if (var4_7 != null) break block11;
                    var3_5 /* !! */  = var0.getSerializer().deserialize((Reader)var1_1, var3_5 /* !! */ );
                    var1_1.close();
                    return (T)var3_5 /* !! */ ;
                }
                var3_5 /* !! */  = var0.getSerializer().deserializeCollection((Reader)var1_1, var3_5 /* !! */ , var4_7);
                var1_1.close();
                return (T)var3_5 /* !! */ ;
                catch (Throwable var3_6) {
                    try {
                        var1_1.close();
                        ** GOTO lbl29
                    }
                    catch (Throwable var1_2) {
                        try {
                            var3_6.addSuppressed(var1_2);
lbl29:
                            // 2 sources

                            throw var3_6;
                        }
                        catch (Throwable var1_3) {
                            var0.getLogger().log(SentryLevel.ERROR, var1_3, "Error reading entity from scope cache: %s", new Object[]{var2_4});
                        }
                    }
                }
                break block13;
            }
            var0.getLogger().log(SentryLevel.DEBUG, "No entry stored for %s", new Object[]{var2_4});
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static <T> void store(SentryOptions sentryOptions, T t2, String string2, String string3) {
        if ((string2 = CacheUtils.ensureCacheDir(sentryOptions, string2)) == null) {
            sentryOptions.getLogger().log(SentryLevel.INFO, "Cache dir is not set, cannot store in scope cache", new Object[0]);
            return;
        }
        File file = new File((File)string2, string3);
        if (file.exists()) {
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "Overwriting %s in scope cache", string3);
            if (!file.delete()) {
                sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to delete: %s", file.getAbsolutePath());
            }
        }
        string2 = new FileOutputStream(file);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)string2, UTF_8);
        file = new BufferedWriter((Writer)outputStreamWriter);
        sentryOptions.getSerializer().serialize(t2, (Writer)file);
        file.close();
        string2.close();
        return;
        catch (Throwable throwable) {
            try {
                file.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    try {
                        string2.close();
                        throw throwable3;
                    }
                    catch (Throwable throwable4) {
                        try {
                            throwable3.addSuppressed(throwable4);
                            throw throwable3;
                        }
                        catch (Throwable throwable5) {
                            sentryOptions.getLogger().log(SentryLevel.ERROR, throwable5, "Error persisting entity: %s", string3);
                        }
                    }
                }
            }
        }
    }
}

