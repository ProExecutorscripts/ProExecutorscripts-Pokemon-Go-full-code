/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry.cache;

import io.sentry.IOptionsObserver;
import io.sentry.JsonDeserializer;
import io.sentry.SentryOptions;
import io.sentry.cache.CacheUtils;
import io.sentry.protocol.SdkVersion;
import java.util.Map;

public final class PersistingOptionsObserver
implements IOptionsObserver {
    public static final String DIST_FILENAME = "dist.json";
    public static final String ENVIRONMENT_FILENAME = "environment.json";
    public static final String OPTIONS_CACHE = ".options-cache";
    public static final String PROGUARD_UUID_FILENAME = "proguard-uuid.json";
    public static final String RELEASE_FILENAME = "release.json";
    public static final String SDK_VERSION_FILENAME = "sdk-version.json";
    public static final String TAGS_FILENAME = "tags.json";
    private final SentryOptions options;

    public PersistingOptionsObserver(SentryOptions sentryOptions) {
        this.options = sentryOptions;
    }

    private void delete(String string2) {
        CacheUtils.delete(this.options, OPTIONS_CACHE, string2);
    }

    public static <T> T read(SentryOptions sentryOptions, String string2, Class<T> clazz) {
        return PersistingOptionsObserver.read(sentryOptions, string2, clazz, null);
    }

    public static <T, R> T read(SentryOptions sentryOptions, String string2, Class<T> clazz, JsonDeserializer<R> jsonDeserializer) {
        return CacheUtils.read(sentryOptions, OPTIONS_CACHE, string2, clazz, jsonDeserializer);
    }

    private <T> void store(T t2, String string2) {
        CacheUtils.store(this.options, t2, OPTIONS_CACHE, string2);
    }

    @Override
    public void setDist(String string2) {
        if (string2 == null) {
            this.delete(DIST_FILENAME);
        } else {
            this.store(string2, DIST_FILENAME);
        }
    }

    @Override
    public void setEnvironment(String string2) {
        if (string2 == null) {
            this.delete(ENVIRONMENT_FILENAME);
        } else {
            this.store(string2, ENVIRONMENT_FILENAME);
        }
    }

    @Override
    public void setProguardUuid(String string2) {
        if (string2 == null) {
            this.delete(PROGUARD_UUID_FILENAME);
        } else {
            this.store(string2, PROGUARD_UUID_FILENAME);
        }
    }

    @Override
    public void setRelease(String string2) {
        if (string2 == null) {
            this.delete(RELEASE_FILENAME);
        } else {
            this.store(string2, RELEASE_FILENAME);
        }
    }

    @Override
    public void setSdkVersion(SdkVersion sdkVersion) {
        if (sdkVersion == null) {
            this.delete(SDK_VERSION_FILENAME);
        } else {
            this.store(sdkVersion, SDK_VERSION_FILENAME);
        }
    }

    @Override
    public void setTags(Map<String, String> map2) {
        this.store(map2, TAGS_FILENAME);
    }
}

