/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.Map
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;
import java.util.Map;

public final class PersistingScopeObserver$$ExternalSyntheticLambda3
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final Map f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda3(PersistingScopeObserver persistingScopeObserver, Map map2) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = map2;
    }

    public final void run() {
        this.f$0.lambda$setTags$2$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

