/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 */
package io.sentry.cache;

import io.sentry.Hint;
import io.sentry.SentryEnvelope;

public interface IEnvelopeCache
extends Iterable<SentryEnvelope> {
    public void discard(SentryEnvelope var1);

    default public void store(SentryEnvelope sentryEnvelope) {
        this.store(sentryEnvelope, new Hint());
    }

    public void store(SentryEnvelope var1, Hint var2);
}

