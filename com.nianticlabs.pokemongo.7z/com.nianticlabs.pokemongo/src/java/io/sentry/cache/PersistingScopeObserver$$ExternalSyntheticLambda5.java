/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.Collection
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;
import java.util.Collection;

public final class PersistingScopeObserver$$ExternalSyntheticLambda5
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final Collection f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda5(PersistingScopeObserver persistingScopeObserver, Collection collection) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = collection;
    }

    public final void run() {
        this.f$0.lambda$setFingerprint$5$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

