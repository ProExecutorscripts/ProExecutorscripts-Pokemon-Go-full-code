/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Comparator
 *  java.util.Iterator
 */
package io.sentry.cache;

import io.sentry.ISerializer;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.cache.CacheStrategy$$ExternalSyntheticLambda0;
import io.sentry.clientreport.DiscardReason;
import io.sentry.util.Objects;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

abstract class CacheStrategy {
    protected static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    protected final File directory;
    private final int maxSize;
    protected final SentryOptions options;
    protected final ISerializer serializer;

    CacheStrategy(SentryOptions sentryOptions, String string2, int n2) {
        Objects.requireNonNull(string2, "Directory is required.");
        this.options = Objects.requireNonNull(sentryOptions, "SentryOptions is required.");
        this.serializer = sentryOptions.getSerializer();
        this.directory = new File(string2);
        this.maxSize = n2;
    }

    private SentryEnvelope buildNewEnvelope(SentryEnvelope sentryEnvelope, SentryEnvelopeItem sentryEnvelopeItem) {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = sentryEnvelope.getItems().iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((SentryEnvelopeItem)iterator.next()));
        }
        arrayList.add((Object)sentryEnvelopeItem);
        return new SentryEnvelope(sentryEnvelope.getHeader(), (Iterable<SentryEnvelopeItem>)arrayList);
    }

    private Session getFirstSession(SentryEnvelope sentryEnvelope) {
        for (SentryEnvelopeItem sentryEnvelopeItem : sentryEnvelope.getItems()) {
            if (!this.isSessionType(sentryEnvelopeItem)) continue;
            return this.readSession(sentryEnvelopeItem);
        }
        return null;
    }

    private boolean isSessionType(SentryEnvelopeItem sentryEnvelopeItem) {
        if (sentryEnvelopeItem == null) {
            return false;
        }
        return sentryEnvelopeItem.getHeader().getType().equals(SentryItemType.Session);
    }

    private boolean isValidEnvelope(SentryEnvelope sentryEnvelope) {
        return sentryEnvelope.getItems().iterator().hasNext();
    }

    private boolean isValidSession(Session session) {
        boolean bl = session.getStatus().equals((Object)Session.State.Ok);
        boolean bl2 = false;
        if (!bl) {
            return false;
        }
        if (session.getSessionId() != null) {
            bl2 = true;
        }
        return bl2;
    }

    static /* synthetic */ int lambda$sortFilesOldestToNewest$0(File file, File file2) {
        return Long.compare((long)file.lastModified(), (long)file2.lastModified());
    }

    private void moveInitFlagIfNecessary(File object, File[] fileArray) {
        if ((object = this.readEnvelope((File)object)) != null && this.isValidEnvelope((SentryEnvelope)object)) {
            this.options.getClientReportRecorder().recordLostEnvelope(DiscardReason.CACHE_OVERFLOW, (SentryEnvelope)object);
            Session session = this.getFirstSession((SentryEnvelope)object);
            if (session != null && this.isValidSession(session) && (object = session.getInit()) != null && object.booleanValue()) {
                for (File file : fileArray) {
                    SentryEnvelope sentryEnvelope;
                    block9: {
                        Session session2;
                        SentryEnvelopeItem sentryEnvelopeItem;
                        sentryEnvelope = this.readEnvelope(file);
                        if (sentryEnvelope == null || !this.isValidEnvelope(sentryEnvelope)) continue;
                        Iterator iterator = sentryEnvelope.getItems().iterator();
                        while (true) {
                            boolean bl = iterator.hasNext();
                            object = null;
                            sentryEnvelopeItem = null;
                            if (!bl) break block9;
                            object = (SentryEnvelopeItem)iterator.next();
                            if (!this.isSessionType((SentryEnvelopeItem)object) || (session2 = this.readSession((SentryEnvelopeItem)object)) == null || !this.isValidSession(session2)) continue;
                            object = session2.getInit();
                            if (object != null && object.booleanValue()) {
                                this.options.getLogger().log(SentryLevel.ERROR, "Session %s has 2 times the init flag.", session.getSessionId());
                                return;
                            }
                            if (session.getSessionId() != null && session.getSessionId().equals((Object)session2.getSessionId())) break;
                        }
                        session2.setInitAsTrue();
                        object = sentryEnvelopeItem;
                        sentryEnvelopeItem = SentryEnvelopeItem.fromSession(this.serializer, session2);
                        object = sentryEnvelopeItem;
                        try {
                            iterator.remove();
                            object = sentryEnvelopeItem;
                        }
                        catch (IOException iOException) {
                            this.options.getLogger().log(SentryLevel.ERROR, iOException, "Failed to create new envelope item for the session %s", session.getSessionId());
                        }
                    }
                    if (object == null) continue;
                    object = this.buildNewEnvelope(sentryEnvelope, (SentryEnvelopeItem)object);
                    long l2 = file.lastModified();
                    if (!file.delete()) {
                        this.options.getLogger().log(SentryLevel.WARNING, "File can't be deleted: %s", file.getAbsolutePath());
                    }
                    this.saveNewEnvelope((SentryEnvelope)object, file, l2);
                    break;
                }
            }
        }
    }

    /*
     * Exception decompiling
     */
    private SentryEnvelope readEnvelope(File var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private Session readSession(SentryEnvelopeItem var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void saveNewEnvelope(SentryEnvelope sentryEnvelope, File file, long l2) {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        this.serializer.serialize(sentryEnvelope, (OutputStream)fileOutputStream);
        file.setLastModified(l2);
        fileOutputStream.close();
        return;
        catch (Throwable throwable) {
            try {
                fileOutputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Failed to serialize the new envelope to the disk.", throwable3);
                }
            }
        }
    }

    private void sortFilesOldestToNewest(File[] fileArray) {
        if (fileArray.length > 1) {
            Arrays.sort((Object[])fileArray, (Comparator)new CacheStrategy$$ExternalSyntheticLambda0());
        }
    }

    protected boolean isDirectoryValid() {
        if (this.directory.isDirectory() && this.directory.canWrite() && this.directory.canRead()) {
            return true;
        }
        this.options.getLogger().log(SentryLevel.ERROR, "The directory for caching files is inaccessible.: %s", this.directory.getAbsolutePath());
        return false;
    }

    protected void rotateCacheIfNeeded(File[] fileArray) {
        int n2 = fileArray.length;
        if (n2 >= this.maxSize) {
            this.options.getLogger().log(SentryLevel.WARNING, "Cache folder if full (respecting maxSize). Rotating files", new Object[0]);
            int n3 = n2 - this.maxSize + 1;
            this.sortFilesOldestToNewest(fileArray);
            File[] fileArray2 = (File[])Arrays.copyOfRange((Object[])fileArray, (int)n3, (int)n2);
            for (n2 = 0; n2 < n3; ++n2) {
                File file = fileArray[n2];
                this.moveInitFlagIfNecessary(file, fileArray2);
                if (file.delete()) continue;
                this.options.getLogger().log(SentryLevel.WARNING, "File can't be deleted: %s", file.getAbsolutePath());
            }
        }
    }
}

