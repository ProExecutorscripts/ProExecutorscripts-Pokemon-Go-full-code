/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FilenameFilter
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.cache;

import io.sentry.cache.EnvelopeCache;
import java.io.File;
import java.io.FilenameFilter;

public final class EnvelopeCache$$ExternalSyntheticLambda0
implements FilenameFilter {
    public final boolean accept(File file, String string2) {
        return EnvelopeCache.lambda$allEnvelopeFiles$0(file, string2);
    }
}

