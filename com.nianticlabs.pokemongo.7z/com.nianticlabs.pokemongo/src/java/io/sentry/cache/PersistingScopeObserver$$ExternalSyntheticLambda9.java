/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;
import io.sentry.protocol.User;

public final class PersistingScopeObserver$$ExternalSyntheticLambda9
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final User f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda9(PersistingScopeObserver persistingScopeObserver, User user) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = user;
    }

    public final void run() {
        this.f$0.lambda$setUser$0$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

