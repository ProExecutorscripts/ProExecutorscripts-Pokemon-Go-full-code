/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.BufferedReader
 *  java.io.BufferedWriter
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.FilenameFilter
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.UUID
 *  java.util.WeakHashMap
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.cache;

import io.sentry.DateUtils;
import io.sentry.Hint;
import io.sentry.SentryCrashLastRunState;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryItemType;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.UncaughtExceptionHandlerIntegration;
import io.sentry.cache.CacheStrategy;
import io.sentry.cache.EnvelopeCache$$ExternalSyntheticLambda0;
import io.sentry.cache.IEnvelopeCache;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.SessionEnd;
import io.sentry.hints.SessionStart;
import io.sentry.transport.NoOpEnvelopeCache;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class EnvelopeCache
extends CacheStrategy
implements IEnvelopeCache {
    public static final String CRASH_MARKER_FILE = "last_crash";
    public static final String NATIVE_CRASH_MARKER_FILE = ".sentry-native/last_crash";
    public static final String PREFIX_CURRENT_SESSION_FILE = "session";
    public static final String PREFIX_PREVIOUS_SESSION_FILE = "previous_session";
    public static final String STARTUP_CRASH_MARKER_FILE = "startup_crash";
    public static final String SUFFIX_ENVELOPE_FILE = ".envelope";
    static final String SUFFIX_SESSION_FILE = ".json";
    private final Map<SentryEnvelope, String> fileNameMap = new WeakHashMap();
    private final CountDownLatch previousSessionLatch = new CountDownLatch(1);

    public EnvelopeCache(SentryOptions sentryOptions, String string2, int n2) {
        super(sentryOptions, string2, n2);
    }

    private File[] allEnvelopeFiles() {
        File[] fileArray;
        if (this.isDirectoryValid() && (fileArray = this.directory.listFiles((FilenameFilter)new EnvelopeCache$$ExternalSyntheticLambda0())) != null) {
            return fileArray;
        }
        return new File[0];
    }

    public static IEnvelopeCache create(SentryOptions sentryOptions) {
        String string2 = sentryOptions.getCacheDirPath();
        int n2 = sentryOptions.getMaxCacheItems();
        if (string2 == null) {
            sentryOptions.getLogger().log(SentryLevel.WARNING, "cacheDirPath is null, returning NoOpEnvelopeCache", new Object[0]);
            return NoOpEnvelopeCache.getInstance();
        }
        return new EnvelopeCache(sentryOptions, string2, n2);
    }

    public static File getCurrentSessionFile(String string2) {
        return new File(string2, "session.json");
    }

    private File getEnvelopeFile(SentryEnvelope object) {
        EnvelopeCache envelopeCache = this;
        synchronized (envelopeCache) {
            block5: {
                if (this.fileNameMap.containsKey(object)) {
                    object = (String)this.fileNameMap.get(object);
                    break block5;
                }
                Object object2 = new StringBuilder();
                object2 = object2.append((Object)UUID.randomUUID()).append(SUFFIX_ENVELOPE_FILE).toString();
                this.fileNameMap.put(object, object2);
                object = object2;
            }
            object = new File(this.directory.getAbsolutePath(), (String)object);
            return object;
        }
    }

    public static File getPreviousSessionFile(String string2) {
        return new File(string2, "previous_session.json");
    }

    static /* synthetic */ boolean lambda$allEnvelopeFiles$0(File file, String string2) {
        return string2.endsWith(SUFFIX_ENVELOPE_FILE);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void tryEndPreviousSession(Hint var1_1) {
        block16: {
            block17: {
                block13: {
                    block15: {
                        block14: {
                            if (!((var1_1 = HintUtils.getSentrySdkHint((Hint)var1_1)) instanceof AbnormalExit)) break block16;
                            var4_4 = EnvelopeCache.getPreviousSessionFile(this.directory.getAbsolutePath());
                            if (!var4_4.exists()) break block17;
                            this.options.getLogger().log(SentryLevel.WARNING, "Previous session is not ended, we'd need to end it.", new Object[0]);
                            var5_8 = new FileInputStream(var4_4);
                            var2_6 /* !! */  = new InputStreamReader((InputStream)var5_8, EnvelopeCache.UTF_8);
                            var3_5 = new BufferedReader((Reader)var2_6 /* !! */ );
                            var5_8 = this.serializer.deserialize((Reader)var3_5, Session.class);
                            if (var5_8 == null) break block13;
                            var6_9 = (AbnormalExit)var1_1;
                            var1_1 = var6_9.timestamp();
                            if (var1_1 == null) break block14;
                            var2_6 /* !! */  = DateUtils.getDateTime(var1_1.longValue());
                            var7_10 = var5_8.getStarted();
                            if (var7_10 == null) ** GOTO lbl23
                            var1_1 = var2_6 /* !! */ ;
                            if (!var2_6 /* !! */ .before(var7_10)) break block15;
lbl23:
                            // 2 sources

                            this.options.getLogger().log(SentryLevel.WARNING, "Abnormal exit happened before previous session start, not ending the session.", new Object[0]);
                            var3_5.close();
                            return;
                        }
                        var1_1 = null;
                    }
                    var2_6 /* !! */  = var6_9.mechanism();
                    var5_8.update(Session.State.Abnormal, null, true, (String)var2_6 /* !! */ );
                    var5_8.end((Date)var1_1);
                    this.writeSessionToDisk(var4_4, (Session)var5_8);
                }
                var3_5.close();
                catch (Throwable var1_2) {
                    try {
                        var3_5.close();
                        ** GOTO lbl47
                    }
                    catch (Throwable var2_7) {
                        try {
                            var1_2.addSuppressed(var2_7);
lbl47:
                            // 2 sources

                            throw var1_2;
                        }
                        catch (Throwable var1_3) {
                            this.options.getLogger().log(SentryLevel.ERROR, "Error processing previous session.", var1_3);
                        }
                    }
                }
                break block16;
            }
            this.options.getLogger().log(SentryLevel.DEBUG, "No previous session file to end.", new Object[0]);
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void updateCurrentSession(File var1_1, SentryEnvelope var2_4) {
        block12: {
            block10: {
                block11: {
                    block9: {
                        if (!(var2_4 = var2_4.getItems()).iterator().hasNext()) break block10;
                        var3_6 = (SentryEnvelopeItem)var2_4.iterator().next();
                        if (!SentryItemType.Session.equals(var3_6.getHeader().getType())) break block11;
                        var5_8 = new ByteArrayInputStream(var3_6.getData());
                        var4_7 /* !! */  = new InputStreamReader((InputStream)var5_8, EnvelopeCache.UTF_8);
                        var2_4 = new BufferedReader((Reader)var4_7 /* !! */ );
                        var4_7 /* !! */  = this.serializer.deserialize((Reader)var2_4, Session.class);
                        if (var4_7 /* !! */  != null) ** GOTO lbl14
                        this.options.getLogger().log(SentryLevel.ERROR, "Item of type %s returned null by the parser.", new Object[]{var3_6.getHeader().getType()});
                        break block9;
lbl14:
                        // 1 sources

                        this.writeSessionToDisk(var1_1, (Session)var4_7 /* !! */ );
                    }
                    var2_4.close();
                    catch (Throwable var1_2) {
                        try {
                            var2_4.close();
                            ** GOTO lbl26
                        }
                        catch (Throwable var2_5) {
                            try {
                                var1_2.addSuppressed(var2_5);
lbl26:
                                // 2 sources

                                throw var1_2;
                            }
                            catch (Throwable var1_3) {
                                this.options.getLogger().log(SentryLevel.ERROR, "Item failed to process.", var1_3);
                            }
                        }
                    }
                    break block12;
                }
                this.options.getLogger().log(SentryLevel.INFO, "Current envelope has a different envelope type %s", new Object[]{var3_6.getHeader().getType()});
                break block12;
            }
            this.options.getLogger().log(SentryLevel.INFO, "Current envelope %s is empty", new Object[]{var1_1.getAbsolutePath()});
        }
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void writeCrashMarkerFile() {
        File file = new File(this.options.getCacheDirPath(), CRASH_MARKER_FILE);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(DateUtils.getTimestamp(DateUtils.getCurrentDateTime()).getBytes(UTF_8));
        fileOutputStream.flush();
        fileOutputStream.close();
        return;
        catch (Throwable throwable) {
            try {
                fileOutputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Error writing the crash marker file to the disk", throwable3);
                }
            }
        }
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void writeEnvelopeToDisk(File file, SentryEnvelope sentryEnvelope) {
        if (file.exists()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Overwriting envelope to offline storage: %s", file.getAbsolutePath());
            if (!file.delete()) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to delete: %s", file.getAbsolutePath());
            }
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        this.serializer.serialize(sentryEnvelope, (OutputStream)fileOutputStream);
        fileOutputStream.close();
        return;
        catch (Throwable throwable) {
            try {
                fileOutputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.options.getLogger().log(SentryLevel.ERROR, throwable3, "Error writing Envelope %s to offline storage", file.getAbsolutePath());
                }
            }
        }
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void writeSessionToDisk(File file, Session session) {
        if (file.exists()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Overwriting session to offline storage: %s", session.getSessionId());
            if (!file.delete()) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to delete: %s", file.getAbsolutePath());
            }
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)fileOutputStream, UTF_8);
        file = new BufferedWriter((Writer)outputStreamWriter);
        this.serializer.serialize(session, (Writer)file);
        file.close();
        fileOutputStream.close();
        return;
        catch (Throwable throwable) {
            try {
                file.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    try {
                        fileOutputStream.close();
                        throw throwable3;
                    }
                    catch (Throwable throwable4) {
                        try {
                            throwable3.addSuppressed(throwable4);
                            throw throwable3;
                        }
                        catch (Throwable throwable5) {
                            this.options.getLogger().log(SentryLevel.ERROR, throwable5, "Error writing Session to offline storage: %s", session.getSessionId());
                        }
                    }
                }
            }
        }
    }

    @Override
    public void discard(SentryEnvelope sentryEnvelope) {
        Objects.requireNonNull(sentryEnvelope, "Envelope is required.");
        sentryEnvelope = this.getEnvelopeFile(sentryEnvelope);
        if (sentryEnvelope.exists()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Discarding envelope from cache: %s", sentryEnvelope.getAbsolutePath());
            if (!sentryEnvelope.delete()) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to delete envelope: %s", sentryEnvelope.getAbsolutePath());
            }
        } else {
            this.options.getLogger().log(SentryLevel.DEBUG, "Envelope was not cached: %s", sentryEnvelope.getAbsolutePath());
        }
    }

    public void flushPreviousSession() {
        this.previousSessionLatch.countDown();
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Iterator<SentryEnvelope> iterator() {
        File[] fileArray = this.allEnvelopeFiles();
        ArrayList arrayList = new ArrayList(fileArray.length);
        for (File file : fileArray) {
            FileInputStream fileInputStream = new FileInputStream(file);
            BufferedInputStream bufferedInputStream = new BufferedInputStream((InputStream)fileInputStream);
            arrayList.add((Object)this.serializer.deserializeEnvelope((InputStream)bufferedInputStream));
            bufferedInputStream.close();
            continue;
            catch (Throwable throwable) {
                try {
                    bufferedInputStream.close();
                    throw throwable;
                }
                catch (Throwable throwable2) {
                    try {
                        throwable.addSuppressed(throwable2);
                        throw throwable;
                    }
                    catch (IOException iOException) {
                        this.options.getLogger().log(SentryLevel.ERROR, String.format((String)"Error while reading cached envelope from file %s", (Object[])new Object[]{file.getAbsolutePath()}), iOException);
                    }
                    catch (FileNotFoundException fileNotFoundException) {
                        this.options.getLogger().log(SentryLevel.DEBUG, "Envelope file '%s' disappeared while converting all cached files to envelopes.", file.getAbsolutePath());
                    }
                }
            }
        }
        return arrayList.iterator();
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void store(SentryEnvelope sentryEnvelope, Hint hint) {
        Objects.requireNonNull(sentryEnvelope, "Envelope is required.");
        this.rotateCacheIfNeeded(this.allEnvelopeFiles());
        File file = EnvelopeCache.getCurrentSessionFile(this.directory.getAbsolutePath());
        File file2 = EnvelopeCache.getPreviousSessionFile(this.directory.getAbsolutePath());
        if (HintUtils.hasType(hint, SessionEnd.class) && !file.delete()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Current envelope doesn't exist.", new Object[0]);
        }
        if (HintUtils.hasType(hint, AbnormalExit.class)) {
            this.tryEndPreviousSession(hint);
        }
        if (HintUtils.hasType(hint, SessionStart.class)) {
            boolean bl;
            if (file.exists()) {
                BufferedReader bufferedReader;
                block17: {
                    this.options.getLogger().log(SentryLevel.WARNING, "Current session is not ended, we'd need to end it.", new Object[0]);
                    FileInputStream fileInputStream = new FileInputStream(file);
                    InputStreamReader inputStreamReader = new InputStreamReader((InputStream)fileInputStream, UTF_8);
                    bufferedReader = new BufferedReader((Reader)inputStreamReader);
                    Session session = this.serializer.deserialize((Reader)bufferedReader, Session.class);
                    if (session == null) break block17;
                    this.writeSessionToDisk(file2, session);
                }
                bufferedReader.close();
                catch (Throwable throwable) {
                    try {
                        bufferedReader.close();
                        throw throwable;
                    }
                    catch (Throwable throwable2) {
                        try {
                            throwable.addSuppressed(throwable2);
                            throw throwable;
                        }
                        catch (Throwable throwable3) {
                            this.options.getLogger().log(SentryLevel.ERROR, "Error processing session.", throwable3);
                        }
                    }
                }
            }
            this.updateCurrentSession(file, sentryEnvelope);
            boolean bl2 = bl = new File(this.options.getCacheDirPath(), NATIVE_CRASH_MARKER_FILE).exists();
            if (!bl) {
                file = new File(this.options.getCacheDirPath(), CRASH_MARKER_FILE);
                bl2 = bl;
                if (file.exists()) {
                    this.options.getLogger().log(SentryLevel.INFO, "Crash marker file exists, crashedLastRun will return true.", new Object[0]);
                    if (!file.delete()) {
                        this.options.getLogger().log(SentryLevel.ERROR, "Failed to delete the crash marker file. %s.", file.getAbsolutePath());
                    }
                    bl2 = true;
                }
            }
            SentryCrashLastRunState.getInstance().setCrashedLastRun(bl2);
            this.flushPreviousSession();
        }
        if ((file = this.getEnvelopeFile(sentryEnvelope)).exists()) {
            this.options.getLogger().log(SentryLevel.WARNING, "Not adding Envelope to offline storage because it already exists: %s", file.getAbsolutePath());
            return;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Adding Envelope to offline storage: %s", file.getAbsolutePath());
        this.writeEnvelopeToDisk(file, sentryEnvelope);
        if (!HintUtils.hasType(hint, UncaughtExceptionHandlerIntegration.UncaughtExceptionHint.class)) return;
        this.writeCrashMarkerFile();
    }

    public boolean waitPreviousSessionFlush() {
        try {
            boolean bl = this.previousSessionLatch.await(this.options.getSessionFlushTimeoutMillis(), TimeUnit.MILLISECONDS);
            return bl;
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            this.options.getLogger().log(SentryLevel.DEBUG, "Timed out waiting for previous session to flush.", new Object[0]);
            return false;
        }
    }
}

