/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;

public final class PersistingScopeObserver$$ExternalSyntheticLambda4
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final Runnable f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda4(PersistingScopeObserver persistingScopeObserver, Runnable runnable) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = runnable;
    }

    public final void run() {
        this.f$0.lambda$serializeToDisk$10$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

