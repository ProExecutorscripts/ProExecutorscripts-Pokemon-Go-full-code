/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;

public final class PersistingScopeObserver$$ExternalSyntheticLambda1
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final String f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda1(PersistingScopeObserver persistingScopeObserver, String string2) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = string2;
    }

    public final void run() {
        this.f$0.lambda$setTransaction$7$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

