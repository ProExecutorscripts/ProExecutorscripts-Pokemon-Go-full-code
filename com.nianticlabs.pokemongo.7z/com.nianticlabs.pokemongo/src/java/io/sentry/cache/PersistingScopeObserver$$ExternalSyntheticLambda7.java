/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.cache;

import io.sentry.SpanContext;
import io.sentry.cache.PersistingScopeObserver;

public final class PersistingScopeObserver$$ExternalSyntheticLambda7
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final SpanContext f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda7(PersistingScopeObserver persistingScopeObserver, SpanContext spanContext) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = spanContext;
    }

    public final void run() {
        this.f$0.lambda$setTrace$8$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

