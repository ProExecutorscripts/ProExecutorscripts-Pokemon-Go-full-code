/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.util.Comparator
 */
package io.sentry.cache;

import io.sentry.cache.CacheStrategy;
import java.io.File;
import java.util.Comparator;

public final class CacheStrategy$$ExternalSyntheticLambda0
implements Comparator {
    public final int compare(Object object, Object object2) {
        return CacheStrategy.lambda$sortFilesOldestToNewest$0((File)object, (File)object2);
    }
}

