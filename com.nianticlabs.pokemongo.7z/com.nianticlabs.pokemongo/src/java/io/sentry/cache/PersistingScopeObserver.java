/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Map
 */
package io.sentry.cache;

import io.sentry.Breadcrumb;
import io.sentry.ISentryExecutorService;
import io.sentry.JsonDeserializer;
import io.sentry.ScopeObserverAdapter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SpanContext;
import io.sentry.cache.CacheUtils;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda0;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda1;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda10;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda2;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda3;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda4;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda5;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda6;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda7;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda8;
import io.sentry.cache.PersistingScopeObserver$$ExternalSyntheticLambda9;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.User;
import java.util.Collection;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class PersistingScopeObserver
extends ScopeObserverAdapter {
    public static final String BREADCRUMBS_FILENAME = "breadcrumbs.json";
    public static final String CONTEXTS_FILENAME = "contexts.json";
    public static final String EXTRAS_FILENAME = "extras.json";
    public static final String FINGERPRINT_FILENAME = "fingerprint.json";
    public static final String LEVEL_FILENAME = "level.json";
    public static final String REQUEST_FILENAME = "request.json";
    public static final String SCOPE_CACHE = ".scope-cache";
    public static final String TAGS_FILENAME = "tags.json";
    public static final String TRACE_FILENAME = "trace.json";
    public static final String TRANSACTION_FILENAME = "transaction.json";
    public static final String USER_FILENAME = "user.json";
    private final SentryOptions options;

    public PersistingScopeObserver(SentryOptions sentryOptions) {
        this.options = sentryOptions;
    }

    private void delete(String string2) {
        CacheUtils.delete(this.options, SCOPE_CACHE, string2);
    }

    public static <T> T read(SentryOptions sentryOptions, String string2, Class<T> clazz) {
        return PersistingScopeObserver.read(sentryOptions, string2, clazz, null);
    }

    public static <T, R> T read(SentryOptions sentryOptions, String string2, Class<T> clazz, JsonDeserializer<R> jsonDeserializer) {
        return CacheUtils.read(sentryOptions, SCOPE_CACHE, string2, clazz, jsonDeserializer);
    }

    private void serializeToDisk(Runnable runnable) {
        try {
            ISentryExecutorService iSentryExecutorService = this.options.getExecutorService();
            PersistingScopeObserver$$ExternalSyntheticLambda4 persistingScopeObserver$$ExternalSyntheticLambda4 = new PersistingScopeObserver$$ExternalSyntheticLambda4(this, runnable);
            iSentryExecutorService.submit(persistingScopeObserver$$ExternalSyntheticLambda4);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Serialization task could not be scheduled", throwable);
        }
    }

    private <T> void store(T t2, String string2) {
        CacheUtils.store(this.options, t2, SCOPE_CACHE, string2);
    }

    /* synthetic */ void lambda$serializeToDisk$10$io-sentry-cache-PersistingScopeObserver(Runnable runnable) {
        try {
            runnable.run();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Serialization task failed", throwable);
        }
    }

    /* synthetic */ void lambda$setBreadcrumbs$1$io-sentry-cache-PersistingScopeObserver(Collection collection) {
        this.store(collection, BREADCRUMBS_FILENAME);
    }

    /* synthetic */ void lambda$setContexts$9$io-sentry-cache-PersistingScopeObserver(Contexts contexts) {
        this.store(contexts, CONTEXTS_FILENAME);
    }

    /* synthetic */ void lambda$setExtras$3$io-sentry-cache-PersistingScopeObserver(Map map2) {
        this.store(map2, EXTRAS_FILENAME);
    }

    /* synthetic */ void lambda$setFingerprint$5$io-sentry-cache-PersistingScopeObserver(Collection collection) {
        this.store(collection, FINGERPRINT_FILENAME);
    }

    /* synthetic */ void lambda$setLevel$6$io-sentry-cache-PersistingScopeObserver(SentryLevel sentryLevel) {
        if (sentryLevel == null) {
            this.delete(LEVEL_FILENAME);
        } else {
            this.store(sentryLevel, LEVEL_FILENAME);
        }
    }

    /* synthetic */ void lambda$setRequest$4$io-sentry-cache-PersistingScopeObserver(Request request) {
        if (request == null) {
            this.delete(REQUEST_FILENAME);
        } else {
            this.store(request, REQUEST_FILENAME);
        }
    }

    /* synthetic */ void lambda$setTags$2$io-sentry-cache-PersistingScopeObserver(Map map2) {
        this.store(map2, TAGS_FILENAME);
    }

    /* synthetic */ void lambda$setTrace$8$io-sentry-cache-PersistingScopeObserver(SpanContext spanContext) {
        if (spanContext == null) {
            this.delete(TRACE_FILENAME);
        } else {
            this.store(spanContext, TRACE_FILENAME);
        }
    }

    /* synthetic */ void lambda$setTransaction$7$io-sentry-cache-PersistingScopeObserver(String string2) {
        if (string2 == null) {
            this.delete(TRANSACTION_FILENAME);
        } else {
            this.store(string2, TRANSACTION_FILENAME);
        }
    }

    /* synthetic */ void lambda$setUser$0$io-sentry-cache-PersistingScopeObserver(User user) {
        if (user == null) {
            this.delete(USER_FILENAME);
        } else {
            this.store(user, USER_FILENAME);
        }
    }

    @Override
    public void setBreadcrumbs(Collection<Breadcrumb> collection) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda10(this, collection));
    }

    @Override
    public void setContexts(Contexts contexts) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda8(this, contexts));
    }

    @Override
    public void setExtras(Map<String, Object> map2) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda2(this, map2));
    }

    @Override
    public void setFingerprint(Collection<String> collection) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda5(this, collection));
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda0(this, sentryLevel));
    }

    @Override
    public void setRequest(Request request) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda6(this, request));
    }

    @Override
    public void setTags(Map<String, String> map2) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda3(this, map2));
    }

    @Override
    public void setTrace(SpanContext spanContext) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda7(this, spanContext));
    }

    @Override
    public void setTransaction(String string2) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda1(this, string2));
    }

    @Override
    public void setUser(User user) {
        this.serializeToDisk(new PersistingScopeObserver$$ExternalSyntheticLambda9(this, user));
    }
}

