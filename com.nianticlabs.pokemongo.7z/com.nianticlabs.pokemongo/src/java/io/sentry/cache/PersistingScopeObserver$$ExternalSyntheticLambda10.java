/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.Collection
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;
import java.util.Collection;

public final class PersistingScopeObserver$$ExternalSyntheticLambda10
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final Collection f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda10(PersistingScopeObserver persistingScopeObserver, Collection collection) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = collection;
    }

    public final void run() {
        this.f$0.lambda$setBreadcrumbs$1$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

