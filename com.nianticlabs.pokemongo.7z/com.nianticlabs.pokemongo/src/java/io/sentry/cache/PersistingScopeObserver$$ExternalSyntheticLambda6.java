/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.cache;

import io.sentry.cache.PersistingScopeObserver;
import io.sentry.protocol.Request;

public final class PersistingScopeObserver$$ExternalSyntheticLambda6
implements Runnable {
    public final PersistingScopeObserver f$0;
    public final Request f$1;

    public /* synthetic */ PersistingScopeObserver$$ExternalSyntheticLambda6(PersistingScopeObserver persistingScopeObserver, Request request) {
        this.f$0 = persistingScopeObserver;
        this.f$1 = request;
    }

    public final void run() {
        this.f$0.lambda$setRequest$4$io-sentry-cache-PersistingScopeObserver(this.f$1);
    }
}

