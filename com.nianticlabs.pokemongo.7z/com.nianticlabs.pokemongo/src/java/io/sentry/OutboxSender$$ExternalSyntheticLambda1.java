/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.OutboxSender;
import io.sentry.hints.Resettable;
import io.sentry.util.HintUtils;

public final class OutboxSender$$ExternalSyntheticLambda1
implements HintUtils.SentryConsumer {
    public final void accept(Object object) {
        OutboxSender.lambda$processEnvelope$1((Resettable)object);
    }
}

