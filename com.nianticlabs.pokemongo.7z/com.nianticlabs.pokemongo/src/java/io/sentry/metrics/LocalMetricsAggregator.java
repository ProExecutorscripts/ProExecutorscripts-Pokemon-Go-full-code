/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.GaugeMetric;
import io.sentry.metrics.MetricType;
import io.sentry.metrics.MetricsHelper;
import io.sentry.protocol.MetricSummary;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class LocalMetricsAggregator {
    private final Map<String, Map<String, GaugeMetric>> buckets = new HashMap();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void add(String string2, MetricType metricType, String string3, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2) {
        Map<String, Map<String, GaugeMetric>> map3;
        String string4 = MetricsHelper.getExportKey(metricType, string3, measurementUnit);
        Map<String, Map<String, GaugeMetric>> map4 = map3 = this.buckets;
        synchronized (map4) {
            Object object = (Map)this.buckets.get((Object)string4);
            metricType = object;
            if (object == null) {
                metricType = new HashMap();
                this.buckets.put((Object)string4, (Object)metricType);
            }
            if ((object = (GaugeMetric)metricType.get(string2)) == null) {
                object = new GaugeMetric(string3, d2, measurementUnit, map2);
                metricType.put(string2, object);
            } else {
                object.add(d2);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Map<String, List<MetricSummary>> getSummaries() {
        Map<String, Map<String, GaugeMetric>> map2;
        HashMap hashMap = new HashMap();
        Map<String, Map<String, GaugeMetric>> map3 = map2 = this.buckets;
        synchronized (map3) {
            Iterator iterator = this.buckets.entrySet().iterator();
            while (iterator.hasNext()) {
                Object object = (Map.Entry)iterator.next();
                String string2 = (String)Objects.requireNonNull((Object)((String)object.getKey()));
                ArrayList arrayList = new ArrayList();
                for (GaugeMetric gaugeMetric : ((Map)object.getValue()).values()) {
                    object = new MetricSummary(gaugeMetric.getMin(), gaugeMetric.getMax(), gaugeMetric.getSum(), gaugeMetric.getCount(), gaugeMetric.getTags());
                    arrayList.add(object);
                }
                hashMap.put((Object)string2, (Object)arrayList);
            }
            return hashMap;
        }
    }
}

