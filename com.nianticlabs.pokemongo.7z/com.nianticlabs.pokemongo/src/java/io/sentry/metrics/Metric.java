/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.MetricType;
import java.util.Map;

public abstract class Metric {
    private final String key;
    private final Map<String, String> tags;
    private final MetricType type;
    private final MeasurementUnit unit;

    public Metric(MetricType metricType, String string2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.type = metricType;
        this.key = string2;
        this.unit = measurementUnit;
        this.tags = map2;
    }

    public abstract void add(double var1);

    public String getKey() {
        return this.key;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public MetricType getType() {
        return this.type;
    }

    public MeasurementUnit getUnit() {
        return this.unit;
    }

    public abstract int getWeight();

    public abstract Iterable<?> serialize();
}

