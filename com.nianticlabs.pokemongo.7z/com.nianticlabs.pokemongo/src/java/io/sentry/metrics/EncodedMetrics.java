/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.charset.Charset
 *  java.util.Collection
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry.metrics;

import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricsHelper;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Map;

public final class EncodedMetrics {
    private static final Charset UTF8 = Charset.forName((String)"UTF-8");
    private final Map<Long, Map<String, Metric>> buckets;

    public EncodedMetrics(Map<Long, Map<String, Metric>> map2) {
        this.buckets = map2;
    }

    public byte[] encodeToStatsd() {
        StringBuilder stringBuilder = new StringBuilder();
        for (Map.Entry entry : this.buckets.entrySet()) {
            MetricsHelper.encodeMetrics((Long)entry.getKey(), (Collection<Metric>)((Map)entry.getValue()).values(), stringBuilder);
        }
        return stringBuilder.toString().getBytes(UTF8);
    }

    Map<Long, Map<String, Metric>> getBuckets() {
        return this.buckets;
    }
}

