/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Map
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import java.util.Arrays;
import java.util.Map;

public final class GaugeMetric
extends Metric {
    private int count;
    private double last;
    private double max;
    private double min;
    private double sum;

    public GaugeMetric(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        super(MetricType.Gauge, string2, measurementUnit, map2);
        this.last = d2;
        this.min = d2;
        this.max = d2;
        this.sum = d2;
        this.count = 1;
    }

    @Override
    public void add(double d2) {
        this.last = d2;
        this.min = Math.min((double)this.min, (double)d2);
        this.max = Math.max((double)this.max, (double)d2);
        this.sum += d2;
        ++this.count;
    }

    public int getCount() {
        return this.count;
    }

    public double getLast() {
        return this.last;
    }

    public double getMax() {
        return this.max;
    }

    public double getMin() {
        return this.min;
    }

    public double getSum() {
        return this.sum;
    }

    @Override
    public int getWeight() {
        return 5;
    }

    @Override
    public Iterable<?> serialize() {
        return Arrays.asList((Object[])new Number[]{this.last, this.min, this.max, this.sum, this.count});
    }
}

