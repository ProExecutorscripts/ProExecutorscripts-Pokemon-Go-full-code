/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.metrics;

public enum MetricType {
    Counter,
    Gauge,
    Distribution,
    Set;

}

