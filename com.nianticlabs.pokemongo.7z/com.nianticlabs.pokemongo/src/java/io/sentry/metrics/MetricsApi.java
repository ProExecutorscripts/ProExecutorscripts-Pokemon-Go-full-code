/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry.metrics;

import io.sentry.IMetricsAggregator;
import io.sentry.ISpan;
import io.sentry.MeasurementUnit;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.metrics.MetricsHelper;
import java.util.Map;

public final class MetricsApi {
    private final IMetricsInterface aggregator;

    public MetricsApi(IMetricsInterface iMetricsInterface) {
        this.aggregator = iMetricsInterface;
    }

    public void distribution(String string2, double d2) {
        this.distribution(string2, d2, null, null, null);
    }

    public void distribution(String string2, double d2, MeasurementUnit measurementUnit) {
        this.distribution(string2, d2, measurementUnit, null, null);
    }

    public void distribution(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.distribution(string2, d2, measurementUnit, map2, null);
    }

    public void distribution(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> object, Long map2) {
        long l2 = map2 != null ? map2.longValue() : System.currentTimeMillis();
        map2 = MetricsHelper.mergeTags(object, this.aggregator.getDefaultTagsForMetrics());
        object = this.aggregator.getLocalMetricsAggregator();
        this.aggregator.getMetricsAggregator().distribution(string2, d2, measurementUnit, map2, l2, (LocalMetricsAggregator)object);
    }

    public void gauge(String string2, double d2) {
        this.gauge(string2, d2, null, null, null);
    }

    public void gauge(String string2, double d2, MeasurementUnit measurementUnit) {
        this.gauge(string2, d2, measurementUnit, null, null);
    }

    public void gauge(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.gauge(string2, d2, measurementUnit, map2, null);
    }

    public void gauge(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, Long object) {
        long l2 = object != null ? object : System.currentTimeMillis();
        map2 = MetricsHelper.mergeTags(map2, this.aggregator.getDefaultTagsForMetrics());
        object = this.aggregator.getLocalMetricsAggregator();
        this.aggregator.getMetricsAggregator().gauge(string2, d2, measurementUnit, map2, l2, (LocalMetricsAggregator)object);
    }

    public void increment(String string2) {
        this.increment(string2, 1.0, null, null, null);
    }

    public void increment(String string2, double d2) {
        this.increment(string2, d2, null, null, null);
    }

    public void increment(String string2, double d2, MeasurementUnit measurementUnit) {
        this.increment(string2, d2, measurementUnit, null, null);
    }

    public void increment(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.increment(string2, d2, measurementUnit, map2, null);
    }

    public void increment(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, Long object) {
        long l2 = object != null ? object : System.currentTimeMillis();
        map2 = MetricsHelper.mergeTags(map2, this.aggregator.getDefaultTagsForMetrics());
        object = this.aggregator.getLocalMetricsAggregator();
        this.aggregator.getMetricsAggregator().increment(string2, d2, measurementUnit, map2, l2, (LocalMetricsAggregator)object);
    }

    public void set(String string2, int n2) {
        this.set(string2, n2, null, null, null);
    }

    public void set(String string2, int n2, MeasurementUnit measurementUnit) {
        this.set(string2, n2, measurementUnit, null, null);
    }

    public void set(String string2, int n2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.set(string2, n2, measurementUnit, map2, null);
    }

    public void set(String string2, int n2, MeasurementUnit measurementUnit, Map<String, String> object, Long map2) {
        long l2 = map2 != null ? map2.longValue() : System.currentTimeMillis();
        map2 = MetricsHelper.mergeTags(object, this.aggregator.getDefaultTagsForMetrics());
        object = this.aggregator.getLocalMetricsAggregator();
        this.aggregator.getMetricsAggregator().set(string2, n2, measurementUnit, map2, l2, (LocalMetricsAggregator)object);
    }

    public void set(String string2, String string3) {
        this.set(string2, string3, null, null, null);
    }

    public void set(String string2, String string3, MeasurementUnit measurementUnit) {
        this.set(string2, string3, measurementUnit, null, null);
    }

    public void set(String string2, String string3, MeasurementUnit measurementUnit, Map<String, String> map2) {
        this.set(string2, string3, measurementUnit, map2, null);
    }

    public void set(String string2, String string3, MeasurementUnit measurementUnit, Map<String, String> map2, Long object) {
        long l2 = object != null ? object : System.currentTimeMillis();
        map2 = MetricsHelper.mergeTags(map2, this.aggregator.getDefaultTagsForMetrics());
        object = this.aggregator.getLocalMetricsAggregator();
        this.aggregator.getMetricsAggregator().set(string2, string3, measurementUnit, map2, l2, (LocalMetricsAggregator)object);
    }

    public void timing(String string2, Runnable runnable) {
        this.timing(string2, runnable, null, null);
    }

    public void timing(String string2, Runnable runnable, MeasurementUnit.Duration duration) {
        this.timing(string2, runnable, duration, null);
    }

    public void timing(String string2, Runnable runnable, MeasurementUnit.Duration duration, Map<String, String> iterator) {
        if (duration == null) {
            duration = MeasurementUnit.Duration.SECOND;
        }
        Map<String, String> map2 = MetricsHelper.mergeTags(iterator, this.aggregator.getDefaultTagsForMetrics());
        LocalMetricsAggregator localMetricsAggregator = this.aggregator.getLocalMetricsAggregator();
        ISpan iSpan = this.aggregator.startSpanForMetric("metric.timing", string2);
        if (iSpan != null && iterator != null) {
            for (Map.Entry entry : iterator.entrySet()) {
                iSpan.setTag((String)entry.getKey(), (String)entry.getValue());
            }
        }
        try {
            this.aggregator.getMetricsAggregator().timing(string2, runnable, duration, map2, localMetricsAggregator);
            return;
        }
        finally {
            if (iSpan != null) {
                iSpan.finish();
            }
        }
    }

    public static interface IMetricsInterface {
        public Map<String, String> getDefaultTagsForMetrics();

        public LocalMetricsAggregator getLocalMetricsAggregator();

        public IMetricsAggregator getMetricsAggregator();

        public ISpan startSpanForMetric(String var1, String var2);
    }
}

