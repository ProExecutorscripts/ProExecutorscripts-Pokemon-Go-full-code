/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Map
 *  java.util.Set
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class SetMetric
extends Metric {
    private final Set<Integer> values = new HashSet();

    public SetMetric(String string2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        super(MetricType.Set, string2, measurementUnit, map2);
    }

    @Override
    public void add(double d2) {
        this.values.add((Object)((int)d2));
    }

    @Override
    public int getWeight() {
        return this.values.size();
    }

    @Override
    public Iterable<?> serialize() {
        return this.values;
    }
}

