/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.metrics;

import io.sentry.metrics.EncodedMetrics;
import io.sentry.protocol.SentryId;

public interface IMetricsClient {
    public SentryId captureMetrics(EncodedMetrics var1);
}

