/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Map
 */
package io.sentry.metrics;

import io.sentry.IMetricsAggregator;
import io.sentry.ISpan;
import io.sentry.MeasurementUnit;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.metrics.MetricsApi;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

public final class NoopMetricsAggregator
implements IMetricsAggregator,
MetricsApi.IMetricsInterface {
    private static final NoopMetricsAggregator instance = new NoopMetricsAggregator();

    public static NoopMetricsAggregator getInstance() {
        return instance;
    }

    public void close() throws IOException {
    }

    @Override
    public void distribution(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
    }

    @Override
    public void flush(boolean bl) {
    }

    @Override
    public void gauge(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
    }

    @Override
    public Map<String, String> getDefaultTagsForMetrics() {
        return Collections.emptyMap();
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        return null;
    }

    @Override
    public IMetricsAggregator getMetricsAggregator() {
        return this;
    }

    @Override
    public void increment(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
    }

    @Override
    public void set(String string2, int n2, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
    }

    @Override
    public void set(String string2, String string3, MeasurementUnit measurementUnit, Map<String, String> map2, long l2, LocalMetricsAggregator localMetricsAggregator) {
    }

    @Override
    public ISpan startSpanForMetric(String string2, String string3) {
        return null;
    }

    @Override
    public void timing(String string2, Runnable runnable, MeasurementUnit.Duration duration, Map<String, String> map2, LocalMetricsAggregator localMetricsAggregator) {
        runnable.run();
    }
}

