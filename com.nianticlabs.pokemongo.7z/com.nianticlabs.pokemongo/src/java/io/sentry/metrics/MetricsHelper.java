/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Random
 *  java.util.regex.Pattern
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

public final class MetricsHelper {
    public static final long FLUSHER_SLEEP_TIME_MS = 5000L;
    private static long FLUSH_SHIFT_MS = 0L;
    public static final int MAX_TOTAL_WEIGHT = 100000;
    private static final Pattern NAME_PATTERN;
    private static final int ROLLUP_IN_SECONDS = 10;
    private static final char TAGS_ESCAPE_CHAR = '\\';
    private static final char TAGS_KEY_VALUE_DELIMITER = '=';
    private static final char TAGS_PAIR_DELIMITER = ',';
    private static final Pattern TAG_KEY_PATTERN;
    private static final Pattern UNIT_PATTERN;

    static {
        UNIT_PATTERN = Pattern.compile((String)"\\W+");
        NAME_PATTERN = Pattern.compile((String)"[^\\w\\-.]+");
        TAG_KEY_PATTERN = Pattern.compile((String)"[^\\w\\-./]+");
        FLUSH_SHIFT_MS = (long)(new Random().nextFloat() * 10000.0f);
    }

    public static double convertNanosTo(MeasurementUnit.Duration duration, long l2) {
        switch (1.$SwitchMap$io$sentry$MeasurementUnit$Duration[duration.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown Duration unit: " + duration.name());
            }
            case 8: {
                return (double)l2 / 8.64E13 / 7.0;
            }
            case 7: {
                return (double)l2 / 8.64E13;
            }
            case 6: {
                return (double)l2 / 3.6E12;
            }
            case 5: {
                return (double)l2 / 6.0E10;
            }
            case 4: {
                return (double)l2 / 1.0E9;
            }
            case 3: {
                return (double)l2 / 1000000.0;
            }
            case 2: {
                return (double)l2 / 1000.0;
            }
            case 1: 
        }
        return l2;
    }

    public static void encodeMetrics(long l2, Collection<Metric> iterator, StringBuilder stringBuilder) {
        for (Metric metric : iterator) {
            stringBuilder.append(MetricsHelper.sanitizeName(metric.getKey()));
            stringBuilder.append("@");
            stringBuilder.append(MetricsHelper.sanitizeUnit(MetricsHelper.getUnitName(metric.getUnit())));
            for (Object object2 : metric.serialize()) {
                stringBuilder.append(":");
                stringBuilder.append(object2);
            }
            stringBuilder.append("|");
            stringBuilder.append(MetricsHelper.toStatsdType(metric.getType()));
            Object object = metric.getTags();
            if (object != null) {
                stringBuilder.append("|#");
                metric = object.entrySet().iterator();
                boolean bl = true;
                while (metric.hasNext()) {
                    Object object2;
                    object2 = (Map.Entry)metric.next();
                    object = MetricsHelper.sanitizeTagKey((String)object2.getKey());
                    if (bl) {
                        bl = false;
                    } else {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append(object);
                    stringBuilder.append(":");
                    stringBuilder.append(MetricsHelper.sanitizeTagValue((String)object2.getValue()));
                }
            }
            stringBuilder.append("|T");
            stringBuilder.append(l2);
            stringBuilder.append("\n");
        }
    }

    private static String escapeString(String string2) {
        StringBuilder stringBuilder = new StringBuilder(string2.length());
        for (int i2 = 0; i2 < string2.length(); ++i2) {
            char c2 = string2.charAt(i2);
            if (c2 == ',' || c2 == '=') {
                stringBuilder.append('\\');
            }
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    public static long getCutoffTimestampMs(long l2) {
        return l2 - 10000L - FLUSH_SHIFT_MS;
    }

    public static String getExportKey(MetricType metricType, String string2, MeasurementUnit object) {
        object = MetricsHelper.getUnitName((MeasurementUnit)object);
        return String.format((String)"%s:%s@%s", (Object[])new Object[]{MetricsHelper.toStatsdType(metricType), string2, object});
    }

    public static String getMetricBucketKey(MetricType object, String string2, MeasurementUnit measurementUnit, Map<String, String> object2) {
        object = MetricsHelper.toStatsdType(object);
        object2 = MetricsHelper.getTagsKey(object2);
        return String.format((String)"%s_%s_%s_%s", (Object[])new Object[]{object, string2, MetricsHelper.getUnitName(measurementUnit), object2});
    }

    private static String getTagsKey(Map<String, String> object) {
        if (object != null && !object.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();
            for (Object object2 : object.entrySet()) {
                object = MetricsHelper.escapeString((String)object2.getKey());
                object2 = MetricsHelper.escapeString((String)object2.getValue());
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(',');
                }
                stringBuilder.append(object).append('=').append((String)object2);
            }
            return stringBuilder.toString();
        }
        return "";
    }

    public static long getTimeBucketKey(long l2) {
        long l3 = l2 / 1000L / 10L * 10L;
        if (l2 >= 0L) {
            return l3;
        }
        return l3 - 1L;
    }

    private static String getUnitName(MeasurementUnit object) {
        object = object != null ? object.apiName() : "none";
        return object;
    }

    public static Map<String, String> mergeTags(Map<String, String> hashMap, Map<String, String> object) {
        if (hashMap == null) {
            return Collections.unmodifiableMap(object);
        }
        hashMap = new HashMap(hashMap);
        for (Map.Entry entry : object.entrySet()) {
            object = (String)entry.getKey();
            if (hashMap.containsKey(object)) continue;
            hashMap.put(object, (Object)((String)entry.getValue()));
        }
        return hashMap;
    }

    public static String sanitizeName(String string2) {
        return NAME_PATTERN.matcher((CharSequence)string2).replaceAll("_");
    }

    public static String sanitizeTagKey(String string2) {
        return TAG_KEY_PATTERN.matcher((CharSequence)string2).replaceAll("");
    }

    public static String sanitizeTagValue(String string2) {
        StringBuilder stringBuilder = new StringBuilder(string2.length());
        for (int i2 = 0; i2 < string2.length(); ++i2) {
            char c2 = string2.charAt(i2);
            if (c2 == '\n') {
                stringBuilder.append("\\n");
                continue;
            }
            if (c2 == '\r') {
                stringBuilder.append("\\r");
                continue;
            }
            if (c2 == '\t') {
                stringBuilder.append("\\t");
                continue;
            }
            if (c2 == '\\') {
                stringBuilder.append("\\\\");
                continue;
            }
            if (c2 == '|') {
                stringBuilder.append("\\u{7c}");
                continue;
            }
            if (c2 == ',') {
                stringBuilder.append("\\u{2c}");
                continue;
            }
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    public static String sanitizeUnit(String string2) {
        return UNIT_PATTERN.matcher((CharSequence)string2).replaceAll("");
    }

    public static void setFlushShiftMs(long l2) {
        FLUSH_SHIFT_MS = l2;
    }

    public static String toStatsdType(MetricType metricType) {
        int n2 = 1.$SwitchMap$io$sentry$metrics$MetricType[metricType.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 == 4) {
                        return "s";
                    }
                    throw new IllegalArgumentException("Invalid Metric Type: " + metricType.name());
                }
                return "d";
            }
            return "g";
        }
        return "c";
    }
}

