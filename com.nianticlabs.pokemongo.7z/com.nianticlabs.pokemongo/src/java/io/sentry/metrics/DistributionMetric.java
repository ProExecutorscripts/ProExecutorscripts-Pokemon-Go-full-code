/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class DistributionMetric
extends Metric {
    private final List<Double> values;

    public DistributionMetric(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        super(MetricType.Distribution, string2, measurementUnit, map2);
        string2 = new ArrayList();
        this.values = string2;
        string2.add((Object)d2);
    }

    @Override
    public void add(double d2) {
        this.values.add((Object)d2);
    }

    @Override
    public int getWeight() {
        return this.values.size();
    }

    @Override
    public Iterable<?> serialize() {
        return this.values;
    }
}

