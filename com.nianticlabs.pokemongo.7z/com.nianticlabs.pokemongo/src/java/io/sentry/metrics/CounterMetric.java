/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Map
 */
package io.sentry.metrics;

import io.sentry.MeasurementUnit;
import io.sentry.metrics.Metric;
import io.sentry.metrics.MetricType;
import java.util.Collections;
import java.util.Map;

public final class CounterMetric
extends Metric {
    private double value;

    public CounterMetric(String string2, double d2, MeasurementUnit measurementUnit, Map<String, String> map2) {
        super(MetricType.Counter, string2, measurementUnit, map2);
        this.value = d2;
    }

    @Override
    public void add(double d2) {
        this.value += d2;
    }

    public double getValue() {
        return this.value;
    }

    @Override
    public int getWeight() {
        return 1;
    }

    @Override
    public Iterable<?> serialize() {
        return Collections.singletonList((Object)this.value);
    }
}

