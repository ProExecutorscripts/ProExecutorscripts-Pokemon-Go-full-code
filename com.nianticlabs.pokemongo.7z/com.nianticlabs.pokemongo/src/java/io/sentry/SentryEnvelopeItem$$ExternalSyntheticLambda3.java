/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.SentryEnvelopeItem;
import io.sentry.metrics.EncodedMetrics;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem$$ExternalSyntheticLambda3
implements Callable {
    public final EncodedMetrics f$0;

    public /* synthetic */ SentryEnvelopeItem$$ExternalSyntheticLambda3(EncodedMetrics encodedMetrics) {
        this.f$0 = encodedMetrics;
    }

    public final Object call() {
        return SentryEnvelopeItem.lambda$fromMetrics$12(this.f$0);
    }
}

