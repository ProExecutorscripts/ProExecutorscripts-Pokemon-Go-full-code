/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.MemoryCollectionData;

public interface IMemoryCollector {
    public MemoryCollectionData collect();
}

