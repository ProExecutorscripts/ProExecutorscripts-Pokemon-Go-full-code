/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.reflect.InvocationTargetException
 */
package io.sentry;

import java.lang.reflect.InvocationTargetException;

public final class OptionsContainer<T> {
    private final Class<T> clazz;

    private OptionsContainer(Class<T> clazz) {
        this.clazz = clazz;
    }

    public static <T> OptionsContainer<T> create(Class<T> clazz) {
        return new OptionsContainer<T>(clazz);
    }

    public T createInstance() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        return (T)this.clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    }
}

