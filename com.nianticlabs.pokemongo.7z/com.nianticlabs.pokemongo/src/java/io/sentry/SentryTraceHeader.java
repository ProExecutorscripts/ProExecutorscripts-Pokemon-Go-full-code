/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.JsonSerializable;
import io.sentry.SpanId;
import io.sentry.exception.InvalidSentryTraceHeaderException;
import io.sentry.protocol.SentryId;

public final class SentryTraceHeader {
    public static final String SENTRY_TRACE_HEADER = "sentry-trace";
    private final Boolean sampled;
    private final SpanId spanId;
    private final SentryId traceId;

    public SentryTraceHeader(SentryId sentryId, SpanId spanId, Boolean bl) {
        this.traceId = sentryId;
        this.spanId = spanId;
        this.sampled = bl;
    }

    public SentryTraceHeader(String string2) throws InvalidSentryTraceHeaderException {
        String[] stringArray = string2.split("-", -1);
        if (stringArray.length >= 2) {
            this.sampled = stringArray.length == 3 ? Boolean.valueOf((boolean)"1".equals((Object)stringArray[2])) : null;
            try {
                JsonSerializable jsonSerializable;
                this.traceId = jsonSerializable = new SentryId(stringArray[0]);
                super(stringArray[1]);
                this.spanId = jsonSerializable;
                return;
            }
            catch (Throwable throwable) {
                throw new InvalidSentryTraceHeaderException(string2, throwable);
            }
        }
        throw new InvalidSentryTraceHeaderException(string2);
    }

    public String getName() {
        return SENTRY_TRACE_HEADER;
    }

    public SpanId getSpanId() {
        return this.spanId;
    }

    public SentryId getTraceId() {
        return this.traceId;
    }

    public String getValue() {
        Object object = this.sampled;
        if (object != null) {
            SentryId sentryId = this.traceId;
            SpanId spanId = this.spanId;
            object = object != false ? "1" : "0";
            return String.format((String)"%s-%s-%s", (Object[])new Object[]{sentryId, spanId, object});
        }
        return String.format((String)"%s-%s", (Object[])new Object[]{this.traceId, this.spanId});
    }

    public Boolean isSampled() {
        return this.sampled;
    }
}

