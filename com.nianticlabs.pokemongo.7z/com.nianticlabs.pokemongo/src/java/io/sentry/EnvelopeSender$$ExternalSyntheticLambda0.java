/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.EnvelopeSender;
import io.sentry.hints.Flushable;
import io.sentry.util.HintUtils;

public final class EnvelopeSender$$ExternalSyntheticLambda0
implements HintUtils.SentryConsumer {
    public final EnvelopeSender f$0;

    public /* synthetic */ EnvelopeSender$$ExternalSyntheticLambda0(EnvelopeSender envelopeSender) {
        this.f$0 = envelopeSender;
    }

    public final void accept(Object object) {
        this.f$0.lambda$processFile$0$io-sentry-EnvelopeSender((Flushable)object);
    }
}

