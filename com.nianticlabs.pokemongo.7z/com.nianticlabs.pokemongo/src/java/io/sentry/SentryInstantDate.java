/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.time.Instant
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.SentryDate;
import java.time.Instant;

public final class SentryInstantDate
extends SentryDate {
    private final Instant date;

    public SentryInstantDate() {
        this(Instant.now());
    }

    public SentryInstantDate(Instant instant) {
        this.date = instant;
    }

    @Override
    public long nanoTimestamp() {
        return DateUtils.secondsToNanos(this.date.getEpochSecond()) + (long)this.date.getNano();
    }
}

