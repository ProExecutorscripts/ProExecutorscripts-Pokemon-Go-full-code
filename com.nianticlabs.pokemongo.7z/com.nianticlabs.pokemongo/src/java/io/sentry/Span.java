/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.IHub;
import io.sentry.ISpan;
import io.sentry.Instrumenter;
import io.sentry.MeasurementUnit;
import io.sentry.NoOpSpan;
import io.sentry.SentryDate;
import io.sentry.SentryLevel;
import io.sentry.SentryTraceHeader;
import io.sentry.SentryTracer;
import io.sentry.Span$$ExternalSyntheticLambda0;
import io.sentry.SpanContext;
import io.sentry.SpanFinishedCallback;
import io.sentry.SpanId;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.TracesSamplingDecision;
import io.sentry.TransactionContext;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.SentryId;
import io.sentry.util.LazyEvaluator;
import io.sentry.util.Objects;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public final class Span
implements ISpan {
    private final SpanContext context;
    private final Map<String, Object> data;
    private final AtomicBoolean finished = new AtomicBoolean(false);
    private final IHub hub;
    private final Map<String, MeasurementValue> measurements;
    private final LazyEvaluator<LocalMetricsAggregator> metricsAggregator;
    private final SpanOptions options;
    private SpanFinishedCallback spanFinishedCallback;
    private SentryDate startTimestamp;
    private Throwable throwable;
    private SentryDate timestamp;
    private final SentryTracer transaction;

    public Span(TransactionContext transactionContext, SentryTracer sentryTracer, IHub iHub, SentryDate sentryDate, SpanOptions spanOptions) {
        this.data = new ConcurrentHashMap();
        this.measurements = new ConcurrentHashMap();
        this.metricsAggregator = new LazyEvaluator(new Span$$ExternalSyntheticLambda0());
        this.context = Objects.requireNonNull(transactionContext, "context is required");
        this.transaction = Objects.requireNonNull(sentryTracer, "sentryTracer is required");
        this.hub = Objects.requireNonNull(iHub, "hub is required");
        this.spanFinishedCallback = null;
        this.startTimestamp = sentryDate != null ? sentryDate : iHub.getOptions().getDateProvider().now();
        this.options = spanOptions;
    }

    Span(SentryId sentryId, SpanId spanId, SentryTracer sentryTracer, String string2, IHub iHub) {
        this(sentryId, spanId, sentryTracer, string2, iHub, null, new SpanOptions(), null);
    }

    Span(SentryId sentryId, SpanId spanId, SentryTracer sentryTracer, String string2, IHub iHub, SentryDate sentryDate, SpanOptions spanOptions, SpanFinishedCallback spanFinishedCallback) {
        this.data = new ConcurrentHashMap();
        this.measurements = new ConcurrentHashMap();
        this.metricsAggregator = new LazyEvaluator(new Span$$ExternalSyntheticLambda0());
        this.context = new SpanContext(sentryId, new SpanId(), string2, spanId, sentryTracer.getSamplingDecision());
        this.transaction = Objects.requireNonNull(sentryTracer, "transaction is required");
        this.hub = Objects.requireNonNull(iHub, "hub is required");
        this.options = spanOptions;
        this.spanFinishedCallback = spanFinishedCallback;
        this.startTimestamp = sentryDate != null ? sentryDate : iHub.getOptions().getDateProvider().now();
    }

    private List<Span> getDirectChildren() {
        ArrayList arrayList = new ArrayList();
        for (Span span : this.transaction.getSpans()) {
            if (span.getParentSpanId() == null || !span.getParentSpanId().equals(this.getSpanId())) continue;
            arrayList.add((Object)span);
        }
        return arrayList;
    }

    static /* synthetic */ LocalMetricsAggregator lambda$new$0() {
        return new LocalMetricsAggregator();
    }

    private void updateStartDate(SentryDate sentryDate) {
        this.startTimestamp = sentryDate;
    }

    @Override
    public void finish() {
        this.finish(this.context.getStatus());
    }

    @Override
    public void finish(SpanStatus spanStatus) {
        this.finish(spanStatus, this.hub.getOptions().getDateProvider().now());
    }

    @Override
    public void finish(SpanStatus object, SentryDate sentryDate) {
        block11: {
            if (!this.finished.compareAndSet(false, true)) {
                return;
            }
            this.context.setStatus((SpanStatus)object);
            object = sentryDate;
            if (sentryDate == null) {
                object = this.hub.getOptions().getDateProvider().now();
            }
            this.timestamp = object;
            if (!this.options.isTrimStart() && !this.options.isTrimEnd()) break block11;
            object = this.transaction.getRoot().getSpanId().equals(this.getSpanId()) ? this.transaction.getChildren() : this.getDirectChildren();
            Iterator iterator = object.iterator();
            sentryDate = null;
            object = null;
            while (iterator.hasNext()) {
                SentryDate sentryDate2;
                Span span;
                block13: {
                    block12: {
                        span = (Span)iterator.next();
                        if (sentryDate == null) break block12;
                        sentryDate2 = sentryDate;
                        if (!span.getStartDate().isBefore(sentryDate)) break block13;
                    }
                    sentryDate2 = span.getStartDate();
                }
                if (object != null) {
                    sentryDate = sentryDate2;
                    if (span.getFinishDate() == null) continue;
                    sentryDate = sentryDate2;
                    if (!span.getFinishDate().isAfter((SentryDate)object)) continue;
                }
                object = span.getFinishDate();
                sentryDate = sentryDate2;
            }
            if (this.options.isTrimStart() && sentryDate != null && this.startTimestamp.isBefore(sentryDate)) {
                this.updateStartDate(sentryDate);
            }
            if (this.options.isTrimEnd() && object != null && ((sentryDate = this.timestamp) == null || sentryDate.isAfter((SentryDate)object))) {
                this.updateEndDate((SentryDate)object);
            }
        }
        if ((object = this.throwable) != null) {
            this.hub.setSpanContext((Throwable)object, this, this.transaction.getName());
        }
        if ((object = this.spanFinishedCallback) != null) {
            object.execute(this);
        }
    }

    @Override
    public Object getData(String string2) {
        return this.data.get((Object)string2);
    }

    public Map<String, Object> getData() {
        return this.data;
    }

    @Override
    public String getDescription() {
        return this.context.getDescription();
    }

    @Override
    public SentryDate getFinishDate() {
        return this.timestamp;
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        return this.metricsAggregator.getValue();
    }

    public Map<String, MeasurementValue> getMeasurements() {
        return this.measurements;
    }

    @Override
    public String getOperation() {
        return this.context.getOperation();
    }

    SpanOptions getOptions() {
        return this.options;
    }

    public SpanId getParentSpanId() {
        return this.context.getParentSpanId();
    }

    public TracesSamplingDecision getSamplingDecision() {
        return this.context.getSamplingDecision();
    }

    @Override
    public SpanContext getSpanContext() {
        return this.context;
    }

    public SpanId getSpanId() {
        return this.context.getSpanId();
    }

    @Override
    public SentryDate getStartDate() {
        return this.startTimestamp;
    }

    @Override
    public SpanStatus getStatus() {
        return this.context.getStatus();
    }

    @Override
    public String getTag(String string2) {
        return (String)this.context.getTags().get((Object)string2);
    }

    public Map<String, String> getTags() {
        return this.context.getTags();
    }

    @Override
    public Throwable getThrowable() {
        return this.throwable;
    }

    public SentryId getTraceId() {
        return this.context.getTraceId();
    }

    @Override
    public boolean isFinished() {
        return this.finished.get();
    }

    @Override
    public boolean isNoOp() {
        return false;
    }

    public Boolean isProfileSampled() {
        return this.context.getProfileSampled();
    }

    public Boolean isSampled() {
        return this.context.getSampled();
    }

    @Override
    public void setData(String string2, Object object) {
        this.data.put((Object)string2, object);
    }

    @Override
    public void setDescription(String string2) {
        this.context.setDescription(string2);
    }

    @Override
    public void setMeasurement(String string2, Number number) {
        if (this.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The span is already finished. Measurement %s cannot be set", string2);
            return;
        }
        this.measurements.put((Object)string2, (Object)new MeasurementValue(number, null));
        if (this.transaction.getRoot() != this) {
            this.transaction.setMeasurementFromChild(string2, number);
        }
    }

    @Override
    public void setMeasurement(String string2, Number number, MeasurementUnit measurementUnit) {
        if (this.isFinished()) {
            this.hub.getOptions().getLogger().log(SentryLevel.DEBUG, "The span is already finished. Measurement %s cannot be set", string2);
            return;
        }
        this.measurements.put((Object)string2, (Object)new MeasurementValue(number, measurementUnit.apiName()));
        if (this.transaction.getRoot() != this) {
            this.transaction.setMeasurementFromChild(string2, number, measurementUnit);
        }
    }

    @Override
    public void setOperation(String string2) {
        this.context.setOperation(string2);
    }

    void setSpanFinishedCallback(SpanFinishedCallback spanFinishedCallback) {
        this.spanFinishedCallback = spanFinishedCallback;
    }

    @Override
    public void setStatus(SpanStatus spanStatus) {
        this.context.setStatus(spanStatus);
    }

    @Override
    public void setTag(String string2, String string3) {
        this.context.setTag(string2, string3);
    }

    @Override
    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }

    @Override
    public ISpan startChild(String string2) {
        String string3 = null;
        return this.startChild(string2, null);
    }

    @Override
    public ISpan startChild(String string2, String string3) {
        if (this.finished.get()) {
            return NoOpSpan.getInstance();
        }
        return this.transaction.startChild(this.context.getSpanId(), string2, string3);
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter) {
        return this.startChild(string2, string3, sentryDate, instrumenter, new SpanOptions());
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        if (this.finished.get()) {
            return NoOpSpan.getInstance();
        }
        return this.transaction.startChild(this.context.getSpanId(), string2, string3, sentryDate, instrumenter, spanOptions);
    }

    @Override
    public ISpan startChild(String string2, String string3, SpanOptions spanOptions) {
        if (this.finished.get()) {
            return NoOpSpan.getInstance();
        }
        return this.transaction.startChild(this.context.getSpanId(), string2, string3, spanOptions);
    }

    @Override
    public BaggageHeader toBaggageHeader(List<String> list) {
        return this.transaction.toBaggageHeader(list);
    }

    @Override
    public SentryTraceHeader toSentryTrace() {
        return new SentryTraceHeader(this.context.getTraceId(), this.context.getSpanId(), this.context.getSampled());
    }

    @Override
    public TraceContext traceContext() {
        return this.transaction.traceContext();
    }

    @Override
    public boolean updateEndDate(SentryDate sentryDate) {
        if (this.timestamp != null) {
            this.timestamp = sentryDate;
            return true;
        }
        return false;
    }
}

