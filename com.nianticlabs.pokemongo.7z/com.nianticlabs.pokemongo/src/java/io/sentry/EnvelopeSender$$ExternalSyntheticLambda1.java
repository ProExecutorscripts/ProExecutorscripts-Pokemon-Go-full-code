/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.EnvelopeSender;
import io.sentry.hints.Retryable;
import io.sentry.util.HintUtils;
import java.io.File;

public final class EnvelopeSender$$ExternalSyntheticLambda1
implements HintUtils.SentryConsumer {
    public final EnvelopeSender f$0;
    public final File f$1;

    public /* synthetic */ EnvelopeSender$$ExternalSyntheticLambda1(EnvelopeSender envelopeSender, File file) {
        this.f$0 = envelopeSender;
        this.f$1 = file;
    }

    public final void accept(Object object) {
        this.f$0.lambda$processFile$2$io-sentry-EnvelopeSender(this.f$1, (Retryable)object);
    }
}

