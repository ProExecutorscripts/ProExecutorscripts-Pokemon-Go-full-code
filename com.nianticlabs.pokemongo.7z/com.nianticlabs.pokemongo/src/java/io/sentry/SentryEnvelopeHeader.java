/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.TraceContext;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryId;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public final class SentryEnvelopeHeader
implements JsonSerializable,
JsonUnknown {
    private final SentryId eventId;
    private final SdkVersion sdkVersion;
    private Date sentAt;
    private final TraceContext traceContext;
    private Map<String, Object> unknown;

    public SentryEnvelopeHeader() {
        this(new SentryId());
    }

    public SentryEnvelopeHeader(SentryId sentryId) {
        this(sentryId, null);
    }

    public SentryEnvelopeHeader(SentryId sentryId, SdkVersion sdkVersion) {
        this(sentryId, sdkVersion, null);
    }

    public SentryEnvelopeHeader(SentryId sentryId, SdkVersion sdkVersion, TraceContext traceContext) {
        this.eventId = sentryId;
        this.sdkVersion = sdkVersion;
        this.traceContext = traceContext;
    }

    public SentryId getEventId() {
        return this.eventId;
    }

    public SdkVersion getSdkVersion() {
        return this.sdkVersion;
    }

    public Date getSentAt() {
        return this.sentAt;
    }

    public TraceContext getTraceContext() {
        return this.traceContext;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object2;
        objectWriter.beginObject();
        if (this.eventId != null) {
            objectWriter.name("event_id").value(iLogger, this.eventId);
        }
        if (this.sdkVersion != null) {
            objectWriter.name("sdk").value(iLogger, this.sdkVersion);
        }
        if (this.traceContext != null) {
            objectWriter.name("trace").value(iLogger, this.traceContext);
        }
        if (this.sentAt != null) {
            objectWriter.name("sent_at").value(iLogger, DateUtils.getTimestamp(this.sentAt));
        }
        if ((object2 = this.unknown) != null) {
            for (Object object2 : object2.keySet()) {
                Object object3 = this.unknown.get(object2);
                objectWriter.name((String)object2);
                objectWriter.value(iLogger, object3);
            }
        }
        objectWriter.endObject();
    }

    public void setSentAt(Date date) {
        this.sentAt = date;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryEnvelopeHeader> {
        @Override
        public SentryEnvelopeHeader deserialize(JsonObjectReader jsonObjectReader, ILogger object) throws Exception {
            Object object2;
            Date date;
            jsonObjectReader.beginObject();
            SentryId sentryId = null;
            SdkVersion sdkVersion = null;
            Date date2 = date = (object2 = null);
            block12: while (jsonObjectReader.peek() == JsonToken.NAME) {
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1980389946: {
                        if (!string2.equals((Object)"sent_at")) break;
                        n3 = 3;
                        break;
                    }
                    case 278118624: {
                        if (!string2.equals((Object)"event_id")) break;
                        n3 = 2;
                        break;
                    }
                    case 110620997: {
                        if (!string2.equals((Object)"trace")) break;
                        n3 = 1;
                        break;
                    }
                    case 113722: {
                        if (!string2.equals((Object)"sdk")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Date date3 = date2;
                        if (date2 == null) {
                            date3 = new HashMap();
                        }
                        jsonObjectReader.nextUnknown((ILogger)object, (Map<String, Object>)date3, string2);
                        date2 = date3;
                        continue block12;
                    }
                    case 3: {
                        date = jsonObjectReader.nextDateOrNull((ILogger)object);
                        continue block12;
                    }
                    case 2: {
                        sentryId = jsonObjectReader.nextOrNull((ILogger)object, new SentryId.Deserializer());
                        continue block12;
                    }
                    case 1: {
                        object2 = jsonObjectReader.nextOrNull((ILogger)object, new TraceContext.Deserializer());
                        continue block12;
                    }
                    case 0: 
                }
                sdkVersion = jsonObjectReader.nextOrNull((ILogger)object, new SdkVersion.Deserializer());
            }
            object = new SentryEnvelopeHeader(sentryId, sdkVersion, (TraceContext)object2);
            ((SentryEnvelopeHeader)object).setSentAt(date);
            ((SentryEnvelopeHeader)object).setUnknown((Map<String, Object>)date2);
            jsonObjectReader.endObject();
            return object;
        }
    }

    public static final class JsonKeys {
        public static final String EVENT_ID = "event_id";
        public static final String SDK = "sdk";
        public static final String SENT_AT = "sent_at";
        public static final String TRACE = "trace";
    }
}

