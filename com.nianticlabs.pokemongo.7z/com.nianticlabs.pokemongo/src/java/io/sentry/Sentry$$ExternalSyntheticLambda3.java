/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry;

import io.sentry.Sentry;
import java.io.File;

public final class Sentry$$ExternalSyntheticLambda3
implements Runnable {
    public final File f$0;

    public /* synthetic */ Sentry$$ExternalSyntheticLambda3(File file) {
        this.f$0 = file;
    }

    public final void run() {
        Sentry.lambda$initConfigurations$4(this.f$0);
    }
}

