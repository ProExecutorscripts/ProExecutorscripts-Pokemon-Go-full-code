/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.SentryDate;

public final class SentryLongDate
extends SentryDate {
    private final long nanos;

    public SentryLongDate(long l2) {
        this.nanos = l2;
    }

    @Override
    public long nanoTimestamp() {
        return this.nanos;
    }
}

