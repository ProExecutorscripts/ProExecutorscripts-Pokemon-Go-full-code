/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package io.sentry;

import io.sentry.protocol.SdkVersion;
import java.util.Map;

public interface IOptionsObserver {
    public void setDist(String var1);

    public void setEnvironment(String var1);

    public void setProguardUuid(String var1);

    public void setRelease(String var1);

    public void setSdkVersion(SdkVersion var1);

    public void setTags(Map<String, String> var1);
}

