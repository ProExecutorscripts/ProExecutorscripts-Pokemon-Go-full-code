/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package io.sentry;

import io.sentry.Hint;
import io.sentry.ISpan;
import io.sentry.SentryDate;
import io.sentry.Span;
import io.sentry.SpanStatus;
import io.sentry.TracesSamplingDecision;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.TransactionNameSource;
import java.util.List;

public interface ITransaction
extends ISpan {
    public void finish(SpanStatus var1, SentryDate var2, boolean var3, Hint var4);

    public void forceFinish(SpanStatus var1, boolean var2, Hint var3);

    public Contexts getContexts();

    public SentryId getEventId();

    public Span getLatestActiveSpan();

    public String getName();

    public TracesSamplingDecision getSamplingDecision();

    public List<Span> getSpans();

    public TransactionNameSource getTransactionNameSource();

    public Boolean isProfileSampled();

    public Boolean isSampled();

    public void scheduleFinish();

    public void setContext(String var1, Object var2);

    public void setName(String var1);

    public void setName(String var1, TransactionNameSource var2);

    public ISpan startChild(String var1, String var2, SentryDate var3);
}

