/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.instrumentation.file;

import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.SentryFileOutputStream;

public final class SentryFileOutputStream$$ExternalSyntheticLambda2
implements FileIOSpanManager.FileIOCallable {
    public final SentryFileOutputStream f$0;
    public final byte[] f$1;

    public /* synthetic */ SentryFileOutputStream$$ExternalSyntheticLambda2(SentryFileOutputStream sentryFileOutputStream, byte[] byArray) {
        this.f$0 = sentryFileOutputStream;
        this.f$1 = byArray;
    }

    public final Object call() {
        return this.f$0.lambda$write$1$io-sentry-instrumentation-file-SentryFileOutputStream(this.f$1);
    }
}

