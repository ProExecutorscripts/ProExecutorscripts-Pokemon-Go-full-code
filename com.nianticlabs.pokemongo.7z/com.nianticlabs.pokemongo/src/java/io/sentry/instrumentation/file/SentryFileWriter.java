/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileNotFoundException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.instrumentation.file;

import io.sentry.IHub;
import io.sentry.instrumentation.file.SentryFileOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public final class SentryFileWriter
extends OutputStreamWriter {
    public SentryFileWriter(File file) throws FileNotFoundException {
        super((OutputStream)new SentryFileOutputStream(file));
    }

    public SentryFileWriter(File file, boolean bl) throws FileNotFoundException {
        super((OutputStream)new SentryFileOutputStream(file, bl));
    }

    SentryFileWriter(File file, boolean bl, IHub iHub) throws FileNotFoundException {
        super((OutputStream)new SentryFileOutputStream(file, bl, iHub));
    }

    public SentryFileWriter(FileDescriptor fileDescriptor) {
        super((OutputStream)new SentryFileOutputStream(fileDescriptor));
    }

    public SentryFileWriter(String string2) throws FileNotFoundException {
        super((OutputStream)new SentryFileOutputStream(string2));
    }

    public SentryFileWriter(String string2, boolean bl) throws FileNotFoundException {
        super((OutputStream)new SentryFileOutputStream(string2, bl));
    }
}

