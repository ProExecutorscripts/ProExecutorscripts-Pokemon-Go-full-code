/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.lang.FunctionalInterface
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.instrumentation.file;

import io.sentry.IHub;
import io.sentry.ISpan;
import io.sentry.SentryIntegrationPackageStorage;
import io.sentry.SentryOptions;
import io.sentry.SentryStackTraceFactory;
import io.sentry.SpanStatus;
import io.sentry.util.Platform;
import io.sentry.util.StringUtils;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;

final class FileIOSpanManager {
    private long byteCount;
    private final ISpan currentSpan;
    private final File file;
    private final SentryOptions options;
    private SpanStatus spanStatus = SpanStatus.OK;
    private final SentryStackTraceFactory stackTraceFactory;

    FileIOSpanManager(ISpan iSpan, File file, SentryOptions sentryOptions) {
        this.currentSpan = iSpan;
        this.file = file;
        this.options = sentryOptions;
        this.stackTraceFactory = new SentryStackTraceFactory(sentryOptions);
        SentryIntegrationPackageStorage.getInstance().addIntegration("FileIO");
    }

    private void finishSpan() {
        if (this.currentSpan != null) {
            String string2 = StringUtils.byteCountToString(this.byteCount);
            if (this.file != null) {
                string2 = this.file.getName() + " (" + string2 + ")";
                this.currentSpan.setDescription(string2);
                if (Platform.isAndroid() || this.options.isSendDefaultPii()) {
                    this.currentSpan.setData("file.path", this.file.getAbsolutePath());
                }
            } else {
                this.currentSpan.setDescription(string2);
            }
            this.currentSpan.setData("file.size", this.byteCount);
            boolean bl = this.options.getMainThreadChecker().isMainThread();
            this.currentSpan.setData("blocked_main_thread", bl);
            if (bl) {
                this.currentSpan.setData("call_stack", this.stackTraceFactory.getInAppCallStack());
            }
            this.currentSpan.finish(this.spanStatus);
        }
    }

    static ISpan startSpan(IHub object, String string2) {
        object = Platform.isAndroid() ? object.getTransaction() : object.getSpan();
        object = object != null ? object.startChild(string2) : null;
        return object;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void finish(Closeable closeable) throws IOException {
        Throwable throwable2222222;
        block5: {
            closeable.close();
            {
                catch (Throwable throwable2222222) {
                    break block5;
                }
                catch (IOException iOException) {}
                {
                    this.spanStatus = SpanStatus.INTERNAL_ERROR;
                    if (this.currentSpan != null) {
                        this.currentSpan.setThrowable(iOException);
                    }
                    throw iOException;
                }
            }
            this.finishSpan();
            return;
        }
        this.finishSpan();
        throw throwable2222222;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    <T> T performIO(FileIOCallable<T> object) throws IOException {
        try {
            object = object.call();
            if (object instanceof Integer) {
                int n2 = (Integer)object;
                if (n2 == -1) return (T)object;
                this.byteCount += (long)n2;
                return (T)object;
            }
            if (!(object instanceof Long)) return (T)object;
            long l2 = (Long)object;
            if (l2 == -1L) return (T)object;
            this.byteCount += l2;
            return (T)object;
        }
        catch (IOException iOException) {
            this.spanStatus = SpanStatus.INTERNAL_ERROR;
            object = this.currentSpan;
            if (object == null) throw iOException;
            object.setThrowable(iOException);
            throw iOException;
        }
    }

    @FunctionalInterface
    static interface FileIOCallable<T> {
        public T call() throws IOException;
    }
}

