/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.atomic.AtomicInteger
 */
package io.sentry.instrumentation.file;

import io.sentry.HubAdapter;
import io.sentry.IHub;
import io.sentry.ISpan;
import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.FileInputStreamInitData;
import io.sentry.instrumentation.file.SentryFileInputStream$$ExternalSyntheticLambda0;
import io.sentry.instrumentation.file.SentryFileInputStream$$ExternalSyntheticLambda1;
import io.sentry.instrumentation.file.SentryFileInputStream$$ExternalSyntheticLambda2;
import io.sentry.instrumentation.file.SentryFileInputStream$$ExternalSyntheticLambda3;
import java.io.Closeable;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryFileInputStream
extends FileInputStream {
    private final FileInputStream delegate;
    private final FileIOSpanManager spanManager;

    private SentryFileInputStream(FileInputStreamInitData fileInputStreamInitData) throws FileNotFoundException {
        super(SentryFileInputStream.getFileDescriptor(fileInputStreamInitData.delegate));
        this.spanManager = new FileIOSpanManager(fileInputStreamInitData.span, fileInputStreamInitData.file, fileInputStreamInitData.options);
        this.delegate = fileInputStreamInitData.delegate;
    }

    private SentryFileInputStream(FileInputStreamInitData fileInputStreamInitData, FileDescriptor fileDescriptor) {
        super(fileDescriptor);
        this.spanManager = new FileIOSpanManager(fileInputStreamInitData.span, fileInputStreamInitData.file, fileInputStreamInitData.options);
        this.delegate = fileInputStreamInitData.delegate;
    }

    public SentryFileInputStream(File file) throws FileNotFoundException {
        this(file, (IHub)HubAdapter.getInstance());
    }

    SentryFileInputStream(File file, IHub iHub) throws FileNotFoundException {
        this(SentryFileInputStream.init(file, null, iHub));
    }

    public SentryFileInputStream(FileDescriptor fileDescriptor) {
        this(fileDescriptor, (IHub)HubAdapter.getInstance());
    }

    SentryFileInputStream(FileDescriptor fileDescriptor, IHub iHub) {
        this(SentryFileInputStream.init(fileDescriptor, null, iHub), fileDescriptor);
    }

    public SentryFileInputStream(String string2) throws FileNotFoundException {
        string2 = string2 != null ? new File(string2) : null;
        this((File)string2, (IHub)HubAdapter.getInstance());
    }

    private static FileDescriptor getFileDescriptor(FileInputStream fileInputStream) throws FileNotFoundException {
        try {
            fileInputStream = fileInputStream.getFD();
            return fileInputStream;
        }
        catch (IOException iOException) {
            throw new FileNotFoundException("No file descriptor");
        }
    }

    private static FileInputStreamInitData init(File file, FileInputStream fileInputStream, IHub iHub) throws FileNotFoundException {
        ISpan iSpan = FileIOSpanManager.startSpan(iHub, "file.read");
        FileInputStream fileInputStream2 = fileInputStream;
        if (fileInputStream == null) {
            fileInputStream2 = new FileInputStream(file);
        }
        return new FileInputStreamInitData(file, iSpan, fileInputStream2, iHub.getOptions());
    }

    private static FileInputStreamInitData init(FileDescriptor fileDescriptor, FileInputStream fileInputStream, IHub iHub) {
        ISpan iSpan = FileIOSpanManager.startSpan(iHub, "file.read");
        FileInputStream fileInputStream2 = fileInputStream;
        if (fileInputStream == null) {
            fileInputStream2 = new FileInputStream(fileDescriptor);
        }
        return new FileInputStreamInitData(null, iSpan, fileInputStream2, iHub.getOptions());
    }

    public void close() throws IOException {
        this.spanManager.finish((Closeable)this.delegate);
    }

    /* synthetic */ Integer lambda$read$0$io-sentry-instrumentation-file-SentryFileInputStream(AtomicInteger atomicInteger) throws IOException {
        int n2 = this.delegate.read();
        atomicInteger.set(n2);
        n2 = n2 != -1 ? 1 : 0;
        return n2;
    }

    /* synthetic */ Integer lambda$read$1$io-sentry-instrumentation-file-SentryFileInputStream(byte[] byArray) throws IOException {
        return this.delegate.read(byArray);
    }

    /* synthetic */ Integer lambda$read$2$io-sentry-instrumentation-file-SentryFileInputStream(byte[] byArray, int n2, int n3) throws IOException {
        return this.delegate.read(byArray, n2, n3);
    }

    /* synthetic */ Long lambda$skip$3$io-sentry-instrumentation-file-SentryFileInputStream(long l2) throws IOException {
        return this.delegate.skip(l2);
    }

    public int read() throws IOException {
        AtomicInteger atomicInteger = new AtomicInteger(0);
        this.spanManager.performIO(new SentryFileInputStream$$ExternalSyntheticLambda0(this, atomicInteger));
        return atomicInteger.get();
    }

    public int read(byte[] byArray) throws IOException {
        return (Integer)this.spanManager.performIO(new SentryFileInputStream$$ExternalSyntheticLambda2(this, byArray));
    }

    public int read(byte[] byArray, int n2, int n3) throws IOException {
        return (Integer)this.spanManager.performIO(new SentryFileInputStream$$ExternalSyntheticLambda1(this, byArray, n2, n3));
    }

    public long skip(long l2) throws IOException {
        return (Long)this.spanManager.performIO(new SentryFileInputStream$$ExternalSyntheticLambda3(this, l2));
    }

    public static final class Factory {
        public static FileInputStream create(FileInputStream fileInputStream, File file) throws FileNotFoundException {
            return new SentryFileInputStream(SentryFileInputStream.init(file, fileInputStream, HubAdapter.getInstance()));
        }

        static FileInputStream create(FileInputStream fileInputStream, File file, IHub iHub) throws FileNotFoundException {
            return new SentryFileInputStream(SentryFileInputStream.init(file, fileInputStream, iHub));
        }

        public static FileInputStream create(FileInputStream fileInputStream, FileDescriptor fileDescriptor) {
            return new SentryFileInputStream(SentryFileInputStream.init(fileDescriptor, fileInputStream, HubAdapter.getInstance()), fileDescriptor);
        }

        public static FileInputStream create(FileInputStream fileInputStream, String string2) throws FileNotFoundException {
            string2 = string2 != null ? new File(string2) : null;
            return new SentryFileInputStream(SentryFileInputStream.init((File)string2, fileInputStream, HubAdapter.getInstance()));
        }
    }
}

