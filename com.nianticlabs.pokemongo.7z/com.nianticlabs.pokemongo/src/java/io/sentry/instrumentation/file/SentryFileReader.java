/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileNotFoundException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.instrumentation.file;

import io.sentry.IHub;
import io.sentry.instrumentation.file.SentryFileInputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;

public final class SentryFileReader
extends InputStreamReader {
    public SentryFileReader(File file) throws FileNotFoundException {
        super((InputStream)new SentryFileInputStream(file));
    }

    SentryFileReader(File file, IHub iHub) throws FileNotFoundException {
        super((InputStream)new SentryFileInputStream(file, iHub));
    }

    public SentryFileReader(FileDescriptor fileDescriptor) {
        super((InputStream)new SentryFileInputStream(fileDescriptor));
    }

    public SentryFileReader(String string2) throws FileNotFoundException {
        super((InputStream)new SentryFileInputStream(string2));
    }
}

