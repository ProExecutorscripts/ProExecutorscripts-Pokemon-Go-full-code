/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicInteger
 */
package io.sentry.instrumentation.file;

import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.SentryFileInputStream;
import java.util.concurrent.atomic.AtomicInteger;

public final class SentryFileInputStream$$ExternalSyntheticLambda0
implements FileIOSpanManager.FileIOCallable {
    public final SentryFileInputStream f$0;
    public final AtomicInteger f$1;

    public /* synthetic */ SentryFileInputStream$$ExternalSyntheticLambda0(SentryFileInputStream sentryFileInputStream, AtomicInteger atomicInteger) {
        this.f$0 = sentryFileInputStream;
        this.f$1 = atomicInteger;
    }

    public final Object call() {
        return this.f$0.lambda$read$0$io-sentry-instrumentation-file-SentryFileInputStream(this.f$1);
    }
}

