/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.instrumentation.file;

import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.SentryFileOutputStream;

public final class SentryFileOutputStream$$ExternalSyntheticLambda0
implements FileIOSpanManager.FileIOCallable {
    public final SentryFileOutputStream f$0;
    public final byte[] f$1;
    public final int f$2;
    public final int f$3;

    public /* synthetic */ SentryFileOutputStream$$ExternalSyntheticLambda0(SentryFileOutputStream sentryFileOutputStream, byte[] byArray, int n2, int n3) {
        this.f$0 = sentryFileOutputStream;
        this.f$1 = byArray;
        this.f$2 = n2;
        this.f$3 = n3;
    }

    public final Object call() {
        return this.f$0.lambda$write$2$io-sentry-instrumentation-file-SentryFileOutputStream(this.f$1, this.f$2, this.f$3);
    }
}

