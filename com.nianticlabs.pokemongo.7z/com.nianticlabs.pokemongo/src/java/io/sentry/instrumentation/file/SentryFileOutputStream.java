/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.instrumentation.file;

import io.sentry.HubAdapter;
import io.sentry.IHub;
import io.sentry.ISpan;
import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.FileOutputStreamInitData;
import io.sentry.instrumentation.file.SentryFileOutputStream$$ExternalSyntheticLambda0;
import io.sentry.instrumentation.file.SentryFileOutputStream$$ExternalSyntheticLambda1;
import io.sentry.instrumentation.file.SentryFileOutputStream$$ExternalSyntheticLambda2;
import java.io.Closeable;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryFileOutputStream
extends FileOutputStream {
    private final FileOutputStream delegate;
    private final FileIOSpanManager spanManager;

    private SentryFileOutputStream(FileOutputStreamInitData fileOutputStreamInitData) throws FileNotFoundException {
        super(SentryFileOutputStream.getFileDescriptor(fileOutputStreamInitData.delegate));
        this.spanManager = new FileIOSpanManager(fileOutputStreamInitData.span, fileOutputStreamInitData.file, fileOutputStreamInitData.options);
        this.delegate = fileOutputStreamInitData.delegate;
    }

    private SentryFileOutputStream(FileOutputStreamInitData fileOutputStreamInitData, FileDescriptor fileDescriptor) {
        super(fileDescriptor);
        this.spanManager = new FileIOSpanManager(fileOutputStreamInitData.span, fileOutputStreamInitData.file, fileOutputStreamInitData.options);
        this.delegate = fileOutputStreamInitData.delegate;
    }

    public SentryFileOutputStream(File file) throws FileNotFoundException {
        this(file, false, HubAdapter.getInstance());
    }

    public SentryFileOutputStream(File file, boolean bl) throws FileNotFoundException {
        this(SentryFileOutputStream.init(file, bl, null, HubAdapter.getInstance()));
    }

    SentryFileOutputStream(File file, boolean bl, IHub iHub) throws FileNotFoundException {
        this(SentryFileOutputStream.init(file, bl, null, iHub));
    }

    public SentryFileOutputStream(FileDescriptor fileDescriptor) {
        this(SentryFileOutputStream.init(fileDescriptor, null, HubAdapter.getInstance()), fileDescriptor);
    }

    public SentryFileOutputStream(String string2) throws FileNotFoundException {
        string2 = string2 != null ? new File(string2) : null;
        this((File)string2, false, HubAdapter.getInstance());
    }

    public SentryFileOutputStream(String string2, boolean bl) throws FileNotFoundException {
        string2 = string2 != null ? new File(string2) : null;
        this(SentryFileOutputStream.init((File)string2, bl, null, HubAdapter.getInstance()));
    }

    private static FileDescriptor getFileDescriptor(FileOutputStream fileOutputStream) throws FileNotFoundException {
        try {
            fileOutputStream = fileOutputStream.getFD();
            return fileOutputStream;
        }
        catch (IOException iOException) {
            throw new FileNotFoundException("No file descriptor");
        }
    }

    private static FileOutputStreamInitData init(File file, boolean bl, FileOutputStream fileOutputStream, IHub iHub) throws FileNotFoundException {
        ISpan iSpan = FileIOSpanManager.startSpan(iHub, "file.write");
        FileOutputStream fileOutputStream2 = fileOutputStream;
        if (fileOutputStream == null) {
            fileOutputStream2 = new FileOutputStream(file, bl);
        }
        return new FileOutputStreamInitData(file, bl, iSpan, fileOutputStream2, iHub.getOptions());
    }

    private static FileOutputStreamInitData init(FileDescriptor fileDescriptor, FileOutputStream fileOutputStream, IHub iHub) {
        ISpan iSpan = FileIOSpanManager.startSpan(iHub, "file.write");
        FileOutputStream fileOutputStream2 = fileOutputStream;
        if (fileOutputStream == null) {
            fileOutputStream2 = new FileOutputStream(fileDescriptor);
        }
        return new FileOutputStreamInitData(null, false, iSpan, fileOutputStream2, iHub.getOptions());
    }

    public void close() throws IOException {
        this.spanManager.finish((Closeable)this.delegate);
    }

    /* synthetic */ Integer lambda$write$0$io-sentry-instrumentation-file-SentryFileOutputStream(int n2) throws IOException {
        this.delegate.write(n2);
        return 1;
    }

    /* synthetic */ Integer lambda$write$1$io-sentry-instrumentation-file-SentryFileOutputStream(byte[] byArray) throws IOException {
        this.delegate.write(byArray);
        return byArray.length;
    }

    /* synthetic */ Integer lambda$write$2$io-sentry-instrumentation-file-SentryFileOutputStream(byte[] byArray, int n2, int n3) throws IOException {
        this.delegate.write(byArray, n2, n3);
        return n3;
    }

    public void write(int n2) throws IOException {
        this.spanManager.performIO(new SentryFileOutputStream$$ExternalSyntheticLambda1(this, n2));
    }

    public void write(byte[] byArray) throws IOException {
        this.spanManager.performIO(new SentryFileOutputStream$$ExternalSyntheticLambda2(this, byArray));
    }

    public void write(byte[] byArray, int n2, int n3) throws IOException {
        this.spanManager.performIO(new SentryFileOutputStream$$ExternalSyntheticLambda0(this, byArray, n2, n3));
    }

    public static final class Factory {
        public static FileOutputStream create(FileOutputStream fileOutputStream, File file) throws FileNotFoundException {
            return new SentryFileOutputStream(SentryFileOutputStream.init(file, false, fileOutputStream, HubAdapter.getInstance()));
        }

        public static FileOutputStream create(FileOutputStream fileOutputStream, File file, boolean bl) throws FileNotFoundException {
            return new SentryFileOutputStream(SentryFileOutputStream.init(file, bl, fileOutputStream, HubAdapter.getInstance()));
        }

        public static FileOutputStream create(FileOutputStream fileOutputStream, FileDescriptor fileDescriptor) {
            return new SentryFileOutputStream(SentryFileOutputStream.init(fileDescriptor, fileOutputStream, HubAdapter.getInstance()), fileDescriptor);
        }

        public static FileOutputStream create(FileOutputStream fileOutputStream, String string2) throws FileNotFoundException {
            string2 = string2 != null ? new File(string2) : null;
            return new SentryFileOutputStream(SentryFileOutputStream.init((File)string2, false, fileOutputStream, HubAdapter.getInstance()));
        }

        public static FileOutputStream create(FileOutputStream fileOutputStream, String string2, boolean bl) throws FileNotFoundException {
            string2 = string2 != null ? new File(string2) : null;
            return new SentryFileOutputStream(SentryFileOutputStream.init((File)string2, bl, fileOutputStream, HubAdapter.getInstance()));
        }
    }
}

