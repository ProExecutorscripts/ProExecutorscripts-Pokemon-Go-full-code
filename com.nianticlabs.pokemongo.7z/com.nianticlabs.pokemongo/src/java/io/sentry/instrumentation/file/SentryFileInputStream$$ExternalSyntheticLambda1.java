/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.instrumentation.file;

import io.sentry.instrumentation.file.FileIOSpanManager;
import io.sentry.instrumentation.file.SentryFileInputStream;

public final class SentryFileInputStream$$ExternalSyntheticLambda1
implements FileIOSpanManager.FileIOCallable {
    public final SentryFileInputStream f$0;
    public final byte[] f$1;
    public final int f$2;
    public final int f$3;

    public /* synthetic */ SentryFileInputStream$$ExternalSyntheticLambda1(SentryFileInputStream sentryFileInputStream, byte[] byArray, int n2, int n3) {
        this.f$0 = sentryFileInputStream;
        this.f$1 = byArray;
        this.f$2 = n2;
        this.f$3 = n3;
    }

    public final Object call() {
        return this.f$0.lambda$read$2$io-sentry-instrumentation-file-SentryFileInputStream(this.f$1, this.f$2, this.f$3);
    }
}

