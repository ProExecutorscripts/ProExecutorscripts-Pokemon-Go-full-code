/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.HttpURLConnection
 *  java.net.URI
 *  java.util.concurrent.RejectedExecutionException
 */
package io.sentry;

import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.NoOpLogger;
import io.sentry.NoOpSentryExecutorService;
import io.sentry.SentryEnvelope;
import io.sentry.SentryExecutorService;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SpotlightIntegration$$ExternalSyntheticLambda0;
import io.sentry.util.Platform;
import java.io.Closeable;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.util.concurrent.RejectedExecutionException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SpotlightIntegration
implements Integration,
SentryOptions.BeforeEnvelopeCallback,
Closeable {
    private ISentryExecutorService executorService;
    private ILogger logger = NoOpLogger.getInstance();
    private SentryOptions options;

    public SpotlightIntegration() {
        this.executorService = NoOpSentryExecutorService.getInstance();
    }

    /*
     * Unable to fully structure code
     */
    private void closeAndDisconnect(HttpURLConnection var1_1) {
        try {
            var1_1.getInputStream().close();
        }
        catch (Throwable var2_2) {
            var1_1.disconnect();
            throw var2_2;
        }
lbl7:
        // 2 sources

        while (true) {
            var1_1.disconnect();
            return;
        }
        catch (IOException var2_3) {
            ** continue;
        }
    }

    private HttpURLConnection createConnection(String string2) throws Exception {
        string2 = (HttpURLConnection)URI.create((String)string2).toURL().openConnection();
        string2.setReadTimeout(1000);
        string2.setConnectTimeout(1000);
        string2.setRequestMethod("POST");
        string2.setDoOutput(true);
        string2.setRequestProperty("Content-Encoding", "gzip");
        string2.setRequestProperty("Content-Type", "application/x-sentry-envelope");
        string2.setRequestProperty("Accept", "application/json");
        string2.setRequestProperty("Connection", "close");
        string2.connect();
        return string2;
    }

    /*
     * Exception decompiling
     */
    private void sendEnvelope(SentryEnvelope var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [15[CATCHBLOCK], 17[CATCHBLOCK], 18[CATCHBLOCK], 16[CATCHBLOCK], 14[CATCHBLOCK], 19[CATCHBLOCK]], but top level block is 13[TRYBLOCK]
         *     at kb.j.B1(SourceFile:159)
         *     at kb.j.X0(SourceFile:49)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public void close() throws IOException {
        this.executorService.close(0L);
        SentryOptions sentryOptions = this.options;
        if (sentryOptions != null && sentryOptions.getBeforeEnvelopeCallback() == this) {
            this.options.setBeforeEnvelopeCallback(null);
        }
    }

    @Override
    public void execute(SentryEnvelope sentryEnvelope, Hint object) {
        try {
            ISentryExecutorService iSentryExecutorService = this.executorService;
            object = new SpotlightIntegration$$ExternalSyntheticLambda0(this, sentryEnvelope);
            iSentryExecutorService.submit((Runnable)object);
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            this.logger.log(SentryLevel.WARNING, "Spotlight envelope submission rejected.", rejectedExecutionException);
        }
    }

    public String getSpotlightConnectionUrl() {
        SentryOptions sentryOptions = this.options;
        if (sentryOptions != null && sentryOptions.getSpotlightConnectionUrl() != null) {
            return this.options.getSpotlightConnectionUrl();
        }
        if (Platform.isAndroid()) {
            return "http://10.0.2.2:8969/stream";
        }
        return "http://localhost:8969/stream";
    }

    /* synthetic */ void lambda$execute$0$io-sentry-SpotlightIntegration(SentryEnvelope sentryEnvelope) {
        this.sendEnvelope(sentryEnvelope);
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        this.options = sentryOptions;
        this.logger = sentryOptions.getLogger();
        if (sentryOptions.getBeforeEnvelopeCallback() == null && sentryOptions.isEnableSpotlight()) {
            this.executorService = new SentryExecutorService();
            sentryOptions.setBeforeEnvelopeCallback(this);
            this.logger.log(SentryLevel.DEBUG, "SpotlightIntegration enabled.", new Object[0]);
        } else {
            this.logger.log(SentryLevel.DEBUG, "SpotlightIntegration is not enabled. BeforeEnvelopeCallback is already set or spotlight is not enabled.", new Object[0]);
        }
    }
}

