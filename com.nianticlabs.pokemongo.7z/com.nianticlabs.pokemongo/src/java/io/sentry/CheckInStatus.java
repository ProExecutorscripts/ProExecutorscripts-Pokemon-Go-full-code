/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package io.sentry;

import java.util.Locale;

public enum CheckInStatus {
    IN_PROGRESS,
    OK,
    ERROR;


    public String apiName() {
        return this.name().toLowerCase(Locale.ROOT);
    }
}

