/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.JsonObjectDeserializer;

public final class JsonObjectDeserializer$$ExternalSyntheticLambda3
implements JsonObjectDeserializer.NextValue {
    @Override
    public final Object nextValue() {
        return JsonObjectDeserializer.lambda$parse$3();
    }
}

