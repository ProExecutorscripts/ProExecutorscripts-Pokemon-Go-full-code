/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.SentryStackTraceFactory;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.util.CollectionUtils;

public final class SentryStackTraceFactory$$ExternalSyntheticLambda0
implements CollectionUtils.Predicate {
    public final boolean test(Object object) {
        return SentryStackTraceFactory.lambda$getInAppCallStack$0((SentryStackFrame)object);
    }
}

