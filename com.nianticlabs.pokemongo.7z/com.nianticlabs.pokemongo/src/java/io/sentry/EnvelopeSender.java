/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.DirectoryProcessor;
import io.sentry.Hint;
import io.sentry.IEnvelopeSender;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISerializer;
import io.sentry.SentryLevel;
import io.sentry.hints.Flushable;
import io.sentry.hints.Retryable;
import io.sentry.util.Objects;
import java.io.File;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class EnvelopeSender
extends DirectoryProcessor
implements IEnvelopeSender {
    private final IHub hub;
    private final ILogger logger;
    private final ISerializer serializer;

    public EnvelopeSender(IHub iHub, ISerializer iSerializer, ILogger iLogger, long l2, int n2) {
        super(iHub, iLogger, l2, n2);
        this.hub = Objects.requireNonNull(iHub, "Hub is required.");
        this.serializer = Objects.requireNonNull(iSerializer, "Serializer is required.");
        this.logger = Objects.requireNonNull(iLogger, "Logger is required.");
    }

    private void safeDelete(File file, String string2) {
        try {
            if (!file.delete()) {
                this.logger.log(SentryLevel.ERROR, "Failed to delete '%s' %s", file.getAbsolutePath(), string2);
            }
        }
        catch (Throwable throwable) {
            this.logger.log(SentryLevel.ERROR, throwable, "Failed to delete '%s' %s", file.getAbsolutePath(), string2);
        }
    }

    @Override
    protected boolean isRelevantFileName(String string2) {
        return string2.endsWith(".envelope");
    }

    /* synthetic */ void lambda$processFile$0$io-sentry-EnvelopeSender(Flushable flushable) {
        if (!flushable.waitFlush()) {
            this.logger.log(SentryLevel.WARNING, "Timed out waiting for envelope submission.", new Object[0]);
        }
    }

    /* synthetic */ void lambda$processFile$1$io-sentry-EnvelopeSender(Throwable throwable, File file, Retryable retryable) {
        retryable.setRetry(false);
        this.logger.log(SentryLevel.INFO, throwable, "File '%s' won't retry.", file.getAbsolutePath());
    }

    /* synthetic */ void lambda$processFile$2$io-sentry-EnvelopeSender(File file, Retryable retryable) {
        if (!retryable.isRetry()) {
            this.safeDelete(file, "after trying to capture it");
            this.logger.log(SentryLevel.DEBUG, "Deleted file %s.", file.getAbsolutePath());
        } else {
            this.logger.log(SentryLevel.INFO, "File not deleted since retry was marked. %s.", file.getAbsolutePath());
        }
    }

    @Override
    public void processEnvelopeFile(String string2, Hint hint) {
        Objects.requireNonNull(string2, "Path is required.");
        this.processFile(new File(string2), hint);
    }

    /*
     * Exception decompiling
     */
    @Override
    protected void processFile(File var1_1, Hint var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 5 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}

