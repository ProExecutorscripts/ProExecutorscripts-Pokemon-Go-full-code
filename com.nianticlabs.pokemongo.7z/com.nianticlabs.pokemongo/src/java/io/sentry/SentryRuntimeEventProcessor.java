/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 */
package io.sentry;

import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.protocol.SentryRuntime;
import io.sentry.protocol.SentryTransaction;

final class SentryRuntimeEventProcessor
implements EventProcessor {
    private final String javaVendor;
    private final String javaVersion;

    public SentryRuntimeEventProcessor() {
        this(System.getProperty((String)"java.version"), System.getProperty((String)"java.vendor"));
    }

    public SentryRuntimeEventProcessor(String string2, String string3) {
        this.javaVersion = string2;
        this.javaVendor = string3;
    }

    private <T extends SentryBaseEvent> T process(T t2) {
        SentryRuntime sentryRuntime;
        if (t2.getContexts().getRuntime() == null) {
            t2.getContexts().setRuntime(new SentryRuntime());
        }
        if ((sentryRuntime = t2.getContexts().getRuntime()) != null && sentryRuntime.getName() == null && sentryRuntime.getVersion() == null) {
            sentryRuntime.setName(this.javaVendor);
            sentryRuntime.setVersion(this.javaVersion);
        }
        return t2;
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        return this.process(sentryEvent);
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        return this.process(sentryTransaction);
    }
}

