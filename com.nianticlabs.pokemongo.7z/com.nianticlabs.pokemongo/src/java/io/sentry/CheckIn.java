/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry;

import io.sentry.CheckInStatus;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.MonitorConfig;
import io.sentry.MonitorContexts;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.protocol.SentryId;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class CheckIn
implements JsonUnknown,
JsonSerializable {
    private final SentryId checkInId;
    private final MonitorContexts contexts = new MonitorContexts();
    private Double duration;
    private String environment;
    private MonitorConfig monitorConfig;
    private String monitorSlug;
    private String release;
    private String status;
    private Map<String, Object> unknown;

    public CheckIn(SentryId sentryId, String string2, CheckInStatus checkInStatus) {
        this(sentryId, string2, checkInStatus.apiName());
    }

    public CheckIn(SentryId sentryId, String string2, String string3) {
        SentryId sentryId2 = sentryId;
        if (sentryId == null) {
            sentryId2 = new SentryId();
        }
        this.checkInId = sentryId2;
        this.monitorSlug = string2;
        this.status = string3;
    }

    public CheckIn(String string2, CheckInStatus checkInStatus) {
        this(null, string2, checkInStatus.apiName());
    }

    public SentryId getCheckInId() {
        return this.checkInId;
    }

    public MonitorContexts getContexts() {
        return this.contexts;
    }

    public Double getDuration() {
        return this.duration;
    }

    public String getEnvironment() {
        return this.environment;
    }

    public MonitorConfig getMonitorConfig() {
        return this.monitorConfig;
    }

    public String getMonitorSlug() {
        return this.monitorSlug;
    }

    public String getRelease() {
        return this.release;
    }

    public String getStatus() {
        return this.status;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        objectWriter.name("check_in_id");
        this.checkInId.serialize(objectWriter, iLogger);
        objectWriter.name("monitor_slug").value(this.monitorSlug);
        objectWriter.name("status").value(this.status);
        if (this.duration != null) {
            objectWriter.name("duration").value((Number)this.duration);
        }
        if (this.release != null) {
            objectWriter.name("release").value(this.release);
        }
        if (this.environment != null) {
            objectWriter.name("environment").value(this.environment);
        }
        if (this.monitorConfig != null) {
            objectWriter.name("monitor_config");
            this.monitorConfig.serialize(objectWriter, iLogger);
        }
        if (this.contexts != null) {
            objectWriter.name("contexts");
            this.contexts.serialize(objectWriter, iLogger);
        }
        if ((object = this.unknown) != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setDuration(Double d2) {
        this.duration = d2;
    }

    public void setEnvironment(String string2) {
        this.environment = string2;
    }

    public void setMonitorConfig(MonitorConfig monitorConfig) {
        this.monitorConfig = monitorConfig;
    }

    public void setMonitorSlug(String string2) {
        this.monitorSlug = string2;
    }

    public void setRelease(String string2) {
        this.release = string2;
    }

    public void setStatus(CheckInStatus checkInStatus) {
        this.status = checkInStatus.apiName();
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<CheckIn> {
        @Override
        public CheckIn deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            Object object2;
            String string2;
            String string3;
            String string4;
            String string5;
            ((JsonReader)object).beginObject();
            SentryId sentryId = null;
            String string6 = null;
            String string7 = string5 = (string4 = (string3 = (string2 = null)));
            Object object3 = object2 = string7;
            block20: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string8 = ((JsonReader)object).nextName();
                string8.hashCode();
                int n2 = string8.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 1732390512: {
                        if (!string8.equals((Object)"monitor_slug")) break;
                        n3 = 7;
                        break;
                    }
                    case 1101887614: {
                        if (!string8.equals((Object)"check_in_id")) break;
                        n3 = 6;
                        break;
                    }
                    case 1090594823: {
                        if (!string8.equals((Object)"release")) break;
                        n3 = 5;
                        break;
                    }
                    case -85904877: {
                        if (!string8.equals((Object)"environment")) break;
                        n3 = 4;
                        break;
                    }
                    case -567312220: {
                        if (!string8.equals((Object)"contexts")) break;
                        n3 = 3;
                        break;
                    }
                    case -892481550: {
                        if (!string8.equals((Object)"status")) break;
                        n3 = 2;
                        break;
                    }
                    case -1992012396: {
                        if (!string8.equals((Object)"duration")) break;
                        n3 = 1;
                        break;
                    }
                    case -2075530809: {
                        if (!string8.equals((Object)"monitor_config")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        String string9 = string3;
                        if (string3 == null) {
                            string9 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)string9, string8);
                        string3 = string9;
                        continue block20;
                    }
                    case 7: {
                        string6 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block20;
                    }
                    case 6: {
                        sentryId = new SentryId.Deserializer().deserialize((JsonObjectReader)object, iLogger);
                        continue block20;
                    }
                    case 5: {
                        string5 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block20;
                    }
                    case 4: {
                        string7 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block20;
                    }
                    case 3: {
                        object3 = new MonitorContexts.Deserializer().deserialize((JsonObjectReader)object, iLogger);
                        continue block20;
                    }
                    case 2: {
                        string2 = ((JsonObjectReader)object).nextStringOrNull();
                        continue block20;
                    }
                    case 1: {
                        string4 = ((JsonObjectReader)object).nextDoubleOrNull();
                        continue block20;
                    }
                    case 0: 
                }
                object2 = new MonitorConfig.Deserializer().deserialize((JsonObjectReader)object, iLogger);
            }
            ((JsonReader)object).endObject();
            if (sentryId != null) {
                if (string6 != null) {
                    if (string2 != null) {
                        object = new CheckIn(sentryId, string6, string2);
                        ((CheckIn)object).setDuration((Double)string4);
                        ((CheckIn)object).setRelease(string5);
                        ((CheckIn)object).setEnvironment(string7);
                        ((CheckIn)object).setMonitorConfig((MonitorConfig)object2);
                        ((CheckIn)object).getContexts().putAll((Map)object3);
                        ((CheckIn)object).setUnknown((Map<String, Object>)string3);
                        return object;
                    }
                    object = new IllegalStateException("Missing required field \"status\"");
                    iLogger.log(SentryLevel.ERROR, "Missing required field \"status\"", (Throwable)object);
                    throw object;
                }
                object = new IllegalStateException("Missing required field \"monitor_slug\"");
                iLogger.log(SentryLevel.ERROR, "Missing required field \"monitor_slug\"", (Throwable)object);
                throw object;
            }
            object = new IllegalStateException("Missing required field \"check_in_id\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"check_in_id\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String CHECK_IN_ID = "check_in_id";
        public static final String CONTEXTS = "contexts";
        public static final String DURATION = "duration";
        public static final String ENVIRONMENT = "environment";
        public static final String MONITOR_CONFIG = "monitor_config";
        public static final String MONITOR_SLUG = "monitor_slug";
        public static final String RELEASE = "release";
        public static final String STATUS = "status";
    }
}

