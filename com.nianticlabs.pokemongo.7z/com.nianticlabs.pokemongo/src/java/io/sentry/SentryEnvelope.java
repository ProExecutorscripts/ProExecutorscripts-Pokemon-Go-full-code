/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.util.ArrayList
 */
package io.sentry;

import io.sentry.ISerializer;
import io.sentry.ProfilingTraceData;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEnvelopeHeader;
import io.sentry.SentryEnvelopeItem;
import io.sentry.Session;
import io.sentry.exception.SentryEnvelopeException;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryId;
import io.sentry.util.Objects;
import java.io.IOException;
import java.util.ArrayList;

public final class SentryEnvelope {
    private final SentryEnvelopeHeader header;
    private final Iterable<SentryEnvelopeItem> items;

    public SentryEnvelope(SentryEnvelopeHeader sentryEnvelopeHeader, Iterable<SentryEnvelopeItem> iterable) {
        this.header = Objects.requireNonNull(sentryEnvelopeHeader, "SentryEnvelopeHeader is required.");
        this.items = Objects.requireNonNull(iterable, "SentryEnvelope items are required.");
    }

    public SentryEnvelope(SentryId sentryId, SdkVersion sdkVersion, SentryEnvelopeItem sentryEnvelopeItem) {
        Objects.requireNonNull(sentryEnvelopeItem, "SentryEnvelopeItem is required.");
        this.header = new SentryEnvelopeHeader(sentryId, sdkVersion);
        sentryId = new ArrayList(1);
        sentryId.add(sentryEnvelopeItem);
        this.items = sentryId;
    }

    public SentryEnvelope(SentryId sentryId, SdkVersion sdkVersion, Iterable<SentryEnvelopeItem> iterable) {
        this.header = new SentryEnvelopeHeader(sentryId, sdkVersion);
        this.items = Objects.requireNonNull(iterable, "SentryEnvelope items are required.");
    }

    public static SentryEnvelope from(ISerializer iSerializer, ProfilingTraceData profilingTraceData, long l2, SdkVersion sdkVersion) throws SentryEnvelopeException {
        Objects.requireNonNull(iSerializer, "Serializer is required.");
        Objects.requireNonNull(profilingTraceData, "Profiling trace data is required.");
        return new SentryEnvelope(new SentryId(profilingTraceData.getProfileId()), sdkVersion, SentryEnvelopeItem.fromProfilingTrace(profilingTraceData, l2, iSerializer));
    }

    public static SentryEnvelope from(ISerializer iSerializer, SentryBaseEvent sentryBaseEvent, SdkVersion sdkVersion) throws IOException {
        Objects.requireNonNull(iSerializer, "Serializer is required.");
        Objects.requireNonNull(sentryBaseEvent, "item is required.");
        return new SentryEnvelope(sentryBaseEvent.getEventId(), sdkVersion, SentryEnvelopeItem.fromEvent(iSerializer, sentryBaseEvent));
    }

    public static SentryEnvelope from(ISerializer iSerializer, Session session, SdkVersion sdkVersion) throws IOException {
        Objects.requireNonNull(iSerializer, "Serializer is required.");
        Objects.requireNonNull(session, "session is required.");
        return new SentryEnvelope(null, sdkVersion, SentryEnvelopeItem.fromSession(iSerializer, session));
    }

    public SentryEnvelopeHeader getHeader() {
        return this.header;
    }

    public Iterable<SentryEnvelopeItem> getItems() {
        return this.items;
    }
}

