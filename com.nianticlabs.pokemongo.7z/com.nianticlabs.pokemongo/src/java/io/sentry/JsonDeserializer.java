/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonObjectReader;

public interface JsonDeserializer<T> {
    public T deserialize(JsonObjectReader var1, ILogger var2) throws Exception;
}

