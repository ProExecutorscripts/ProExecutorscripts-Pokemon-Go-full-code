/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

public interface IConnectionStatusProvider {
    public boolean addConnectionStatusObserver(IConnectionStatusObserver var1);

    public ConnectionStatus getConnectionStatus();

    public String getConnectionType();

    public void removeConnectionStatusObserver(IConnectionStatusObserver var1);

    public static enum ConnectionStatus {
        UNKNOWN,
        CONNECTED,
        DISCONNECTED,
        NO_PERMISSION;

    }

    public static interface IConnectionStatusObserver {
        public void onConnectionStatusChanged(ConnectionStatus var1);
    }
}

