/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.ObjectWriter;
import java.io.IOException;

public interface JsonSerializable {
    public void serialize(ObjectWriter var1, ILogger var2) throws IOException;
}

