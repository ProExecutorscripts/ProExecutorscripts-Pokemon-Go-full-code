/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collections
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Hint;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.Instrumenter;
import io.sentry.MeasurementUnit;
import io.sentry.NoOpSpan;
import io.sentry.SentryDate;
import io.sentry.SentryNanotimeDate;
import io.sentry.SentryTraceHeader;
import io.sentry.Span;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.TracesSamplingDecision;
import io.sentry.metrics.LocalMetricsAggregator;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.TransactionNameSource;
import java.util.Collections;
import java.util.List;

public final class NoOpTransaction
implements ITransaction {
    private static final NoOpTransaction instance = new NoOpTransaction();

    private NoOpTransaction() {
    }

    public static NoOpTransaction getInstance() {
        return instance;
    }

    @Override
    public void finish() {
    }

    @Override
    public void finish(SpanStatus spanStatus) {
    }

    @Override
    public void finish(SpanStatus spanStatus, SentryDate sentryDate) {
    }

    @Override
    public void finish(SpanStatus spanStatus, SentryDate sentryDate, boolean bl, Hint hint) {
    }

    @Override
    public void forceFinish(SpanStatus spanStatus, boolean bl, Hint hint) {
    }

    @Override
    public Contexts getContexts() {
        return new Contexts();
    }

    @Override
    public Object getData(String string2) {
        return null;
    }

    @Override
    public String getDescription() {
        return null;
    }

    @Override
    public SentryId getEventId() {
        return SentryId.EMPTY_ID;
    }

    @Override
    public SentryDate getFinishDate() {
        return new SentryNanotimeDate();
    }

    @Override
    public Span getLatestActiveSpan() {
        return null;
    }

    @Override
    public LocalMetricsAggregator getLocalMetricsAggregator() {
        return null;
    }

    @Override
    public String getName() {
        return "";
    }

    @Override
    public String getOperation() {
        return "";
    }

    @Override
    public TracesSamplingDecision getSamplingDecision() {
        return null;
    }

    @Override
    public SpanContext getSpanContext() {
        return new SpanContext(SentryId.EMPTY_ID, SpanId.EMPTY_ID, "op", null, null);
    }

    @Override
    public List<Span> getSpans() {
        return Collections.emptyList();
    }

    @Override
    public SentryDate getStartDate() {
        return new SentryNanotimeDate();
    }

    @Override
    public SpanStatus getStatus() {
        return null;
    }

    @Override
    public String getTag(String string2) {
        return null;
    }

    @Override
    public Throwable getThrowable() {
        return null;
    }

    @Override
    public TransactionNameSource getTransactionNameSource() {
        return TransactionNameSource.CUSTOM;
    }

    @Override
    public boolean isFinished() {
        return true;
    }

    @Override
    public boolean isNoOp() {
        return true;
    }

    @Override
    public Boolean isProfileSampled() {
        return null;
    }

    @Override
    public Boolean isSampled() {
        return null;
    }

    @Override
    public void scheduleFinish() {
    }

    @Override
    public void setContext(String string2, Object object) {
    }

    @Override
    public void setData(String string2, Object object) {
    }

    @Override
    public void setDescription(String string2) {
    }

    @Override
    public void setMeasurement(String string2, Number number) {
    }

    @Override
    public void setMeasurement(String string2, Number number, MeasurementUnit measurementUnit) {
    }

    @Override
    public void setName(String string2) {
    }

    @Override
    public void setName(String string2, TransactionNameSource transactionNameSource) {
    }

    @Override
    public void setOperation(String string2) {
    }

    @Override
    public void setStatus(SpanStatus spanStatus) {
    }

    @Override
    public void setTag(String string2, String string3) {
    }

    @Override
    public void setThrowable(Throwable throwable) {
    }

    @Override
    public ISpan startChild(String string2) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SentryDate sentryDate, Instrumenter instrumenter, SpanOptions spanOptions) {
        return NoOpSpan.getInstance();
    }

    @Override
    public ISpan startChild(String string2, String string3, SpanOptions spanOptions) {
        return NoOpSpan.getInstance();
    }

    @Override
    public BaggageHeader toBaggageHeader(List<String> list) {
        return null;
    }

    @Override
    public SentryTraceHeader toSentryTrace() {
        return new SentryTraceHeader(SentryId.EMPTY_ID, SpanId.EMPTY_ID, false);
    }

    @Override
    public TraceContext traceContext() {
        return new TraceContext(SentryId.EMPTY_ID, "");
    }

    @Override
    public boolean updateEndDate(SentryDate sentryDate) {
        return false;
    }
}

