/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Instrumenter;
import io.sentry.MeasurementUnit;
import io.sentry.SentryDate;
import io.sentry.SentryTraceHeader;
import io.sentry.SpanContext;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TraceContext;
import io.sentry.metrics.LocalMetricsAggregator;
import java.util.List;

public interface ISpan {
    public void finish();

    public void finish(SpanStatus var1);

    public void finish(SpanStatus var1, SentryDate var2);

    public Object getData(String var1);

    public String getDescription();

    public SentryDate getFinishDate();

    public LocalMetricsAggregator getLocalMetricsAggregator();

    public String getOperation();

    public SpanContext getSpanContext();

    public SentryDate getStartDate();

    public SpanStatus getStatus();

    public String getTag(String var1);

    public Throwable getThrowable();

    public boolean isFinished();

    public boolean isNoOp();

    public void setData(String var1, Object var2);

    public void setDescription(String var1);

    public void setMeasurement(String var1, Number var2);

    public void setMeasurement(String var1, Number var2, MeasurementUnit var3);

    public void setOperation(String var1);

    public void setStatus(SpanStatus var1);

    public void setTag(String var1, String var2);

    public void setThrowable(Throwable var1);

    public ISpan startChild(String var1);

    public ISpan startChild(String var1, String var2);

    public ISpan startChild(String var1, String var2, SentryDate var3, Instrumenter var4);

    public ISpan startChild(String var1, String var2, SentryDate var3, Instrumenter var4, SpanOptions var5);

    public ISpan startChild(String var1, String var2, SpanOptions var3);

    public BaggageHeader toBaggageHeader(List<String> var1);

    public SentryTraceHeader toSentryTrace();

    public TraceContext traceContext();

    public boolean updateEndDate(SentryDate var1);
}

