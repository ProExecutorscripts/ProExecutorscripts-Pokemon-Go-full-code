/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package io.sentry;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class FullyDisplayedReporter {
    private static final FullyDisplayedReporter instance = new FullyDisplayedReporter();
    private final List<FullyDisplayedReporterListener> listeners = new CopyOnWriteArrayList();

    private FullyDisplayedReporter() {
    }

    public static FullyDisplayedReporter getInstance() {
        return instance;
    }

    public void registerFullyDrawnListener(FullyDisplayedReporterListener fullyDisplayedReporterListener) {
        this.listeners.add((Object)fullyDisplayedReporterListener);
    }

    public void reportFullyDrawn() {
        Iterator iterator = this.listeners.iterator();
        this.listeners.clear();
        while (iterator.hasNext()) {
            ((FullyDisplayedReporterListener)iterator.next()).onFullyDrawn();
        }
    }

    public static interface FullyDisplayedReporterListener {
        public void onFullyDrawn();
    }
}

