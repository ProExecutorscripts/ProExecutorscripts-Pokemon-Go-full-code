/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package io.sentry;

import io.sentry.SentryOptions;
import io.sentry.SentryStackTraceFactory$$ExternalSyntheticLambda0;
import io.sentry.SentryStackTraceFactory$$ExternalSyntheticLambda1;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.util.CollectionUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class SentryStackTraceFactory {
    private static final int STACKTRACE_FRAME_LIMIT = 100;
    private final SentryOptions options;

    public SentryStackTraceFactory(SentryOptions sentryOptions) {
        this.options = sentryOptions;
    }

    static /* synthetic */ boolean lambda$getInAppCallStack$0(SentryStackFrame sentryStackFrame) {
        return Boolean.TRUE.equals((Object)sentryStackFrame.isInApp());
    }

    static /* synthetic */ boolean lambda$getInAppCallStack$1(SentryStackFrame object) {
        boolean bl;
        block2: {
            block3: {
                boolean bl2;
                object = ((SentryStackFrame)object).getModule();
                bl = bl2 = false;
                if (object == null) break block2;
                if (object.startsWith("sun.") || object.startsWith("java.") || object.startsWith("android.")) break block3;
                bl = bl2;
                if (!object.startsWith("com.android.")) break block2;
            }
            bl = true;
        }
        return bl ^ true;
    }

    public List<SentryStackFrame> getInAppCallStack() {
        return this.getInAppCallStack(new Exception());
    }

    List<SentryStackFrame> getInAppCallStack(Throwable list) {
        List<SentryStackFrame> list2 = this.getStackFrames(list.getStackTrace(), false);
        if (list2 == null) {
            return Collections.emptyList();
        }
        list = CollectionUtils.filterListEntries(list2, new SentryStackTraceFactory$$ExternalSyntheticLambda0());
        if (!list.isEmpty()) {
            return list;
        }
        return CollectionUtils.filterListEntries(list2, new SentryStackTraceFactory$$ExternalSyntheticLambda1());
    }

    public List<SentryStackFrame> getStackFrames(StackTraceElement[] arrayList, boolean bl) {
        if (arrayList != null && ((StackTraceElement[])arrayList).length > 0) {
            ArrayList arrayList2 = new ArrayList();
            for (StackTraceElement stackTraceElement : arrayList) {
                if (stackTraceElement == null) continue;
                String string2 = stackTraceElement.getClassName();
                if (!bl && string2.startsWith("io.sentry.") && !string2.startsWith("io.sentry.samples.") && !string2.startsWith("io.sentry.mobile.")) continue;
                SentryStackFrame sentryStackFrame = new SentryStackFrame();
                sentryStackFrame.setInApp(this.isInApp(string2));
                sentryStackFrame.setModule(string2);
                sentryStackFrame.setFunction(stackTraceElement.getMethodName());
                sentryStackFrame.setFilename(stackTraceElement.getFileName());
                if (stackTraceElement.getLineNumber() >= 0) {
                    sentryStackFrame.setLineno(stackTraceElement.getLineNumber());
                }
                sentryStackFrame.setNative(stackTraceElement.isNativeMethod());
                arrayList2.add((Object)sentryStackFrame);
                if (arrayList2.size() >= 100) break;
            }
            Collections.reverse((List)arrayList2);
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        return arrayList;
    }

    public Boolean isInApp(String string2) {
        Boolean bl = true;
        if (string2 != null && !string2.isEmpty()) {
            Iterator iterator = this.options.getInAppIncludes().iterator();
            while (iterator.hasNext()) {
                if (!string2.startsWith((String)iterator.next())) continue;
                return bl;
            }
            bl = this.options.getInAppExcludes().iterator();
            while (bl.hasNext()) {
                if (!string2.startsWith((String)bl.next())) continue;
                return false;
            }
            return null;
        }
        return bl;
    }
}

