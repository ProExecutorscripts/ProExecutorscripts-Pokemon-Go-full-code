/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.Sentry;
import io.sentry.SentryOptions;

public final class Sentry$$ExternalSyntheticLambda0
implements Sentry.OptionsConfiguration {
    public final void configure(SentryOptions sentryOptions) {
        Sentry.lambda$init$0(sentryOptions);
    }
}

