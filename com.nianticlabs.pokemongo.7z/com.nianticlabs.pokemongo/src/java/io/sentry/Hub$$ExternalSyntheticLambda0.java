/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry;

import io.sentry.Hub;
import io.sentry.IScope;
import io.sentry.PropagationContext;
import io.sentry.ScopeCallback;

public final class Hub$$ExternalSyntheticLambda0
implements ScopeCallback {
    public final PropagationContext f$0;

    public /* synthetic */ Hub$$ExternalSyntheticLambda0(PropagationContext propagationContext) {
        this.f$0 = propagationContext;
    }

    @Override
    public final void run(IScope iScope) {
        Hub.lambda$continueTrace$3(this.f$0, iScope);
    }
}

