/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package io.sentry;

import io.sentry.Baggage;
import java.util.List;

public final class BaggageHeader {
    public static final String BAGGAGE_HEADER = "baggage";
    private final String value;

    public BaggageHeader(String string2) {
        this.value = string2;
    }

    public static BaggageHeader fromBaggageAndOutgoingHeader(Baggage object, List<String> list) {
        if ((object = ((Baggage)object).toHeaderString(Baggage.fromHeader(list, true, ((Baggage)object).logger).getThirdPartyHeader())).isEmpty()) {
            return null;
        }
        return new BaggageHeader((String)object);
    }

    public String getName() {
        return BAGGAGE_HEADER;
    }

    public String getValue() {
        return this.value;
    }
}

