/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

import io.sentry.Hint;

public interface IEnvelopeSender {
    public void processEnvelopeFile(String var1, Hint var2);
}

