/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.CustomSamplingContext;
import io.sentry.SentryDate;
import io.sentry.SpanOptions;
import io.sentry.TransactionFinishedCallback;

public final class TransactionOptions
extends SpanOptions {
    public static final long DEFAULT_DEADLINE_TIMEOUT_AUTO_TRANSACTION = 30000L;
    private boolean bindToScope = false;
    private CustomSamplingContext customSamplingContext = null;
    private Long deadlineTimeout = null;
    private Long idleTimeout = null;
    private boolean isAppStartTransaction = false;
    private SentryDate startTimestamp = null;
    private TransactionFinishedCallback transactionFinishedCallback = null;
    private boolean waitForChildren = false;

    public CustomSamplingContext getCustomSamplingContext() {
        return this.customSamplingContext;
    }

    public Long getDeadlineTimeout() {
        return this.deadlineTimeout;
    }

    public Long getIdleTimeout() {
        return this.idleTimeout;
    }

    public SentryDate getStartTimestamp() {
        return this.startTimestamp;
    }

    public TransactionFinishedCallback getTransactionFinishedCallback() {
        return this.transactionFinishedCallback;
    }

    public boolean isAppStartTransaction() {
        return this.isAppStartTransaction;
    }

    public boolean isBindToScope() {
        return this.bindToScope;
    }

    public boolean isWaitForChildren() {
        return this.waitForChildren;
    }

    public void setAppStartTransaction(boolean bl) {
        this.isAppStartTransaction = bl;
    }

    public void setBindToScope(boolean bl) {
        this.bindToScope = bl;
    }

    public void setCustomSamplingContext(CustomSamplingContext customSamplingContext) {
        this.customSamplingContext = customSamplingContext;
    }

    public void setDeadlineTimeout(Long l2) {
        this.deadlineTimeout = l2;
    }

    public void setIdleTimeout(Long l2) {
        this.idleTimeout = l2;
    }

    public void setStartTimestamp(SentryDate sentryDate) {
        this.startTimestamp = sentryDate;
    }

    public void setTransactionFinishedCallback(TransactionFinishedCallback transactionFinishedCallback) {
        this.transactionFinishedCallback = transactionFinishedCallback;
    }

    public void setWaitForChildren(boolean bl) {
        this.waitForChildren = bl;
    }
}

