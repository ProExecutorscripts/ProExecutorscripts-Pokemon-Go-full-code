/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.CpuCollectionData;
import io.sentry.MemoryCollectionData;

public final class PerformanceCollectionData {
    private CpuCollectionData cpuData = null;
    private MemoryCollectionData memoryData = null;

    public void addCpuData(CpuCollectionData cpuCollectionData) {
        if (cpuCollectionData != null) {
            this.cpuData = cpuCollectionData;
        }
    }

    public void addMemoryData(MemoryCollectionData memoryCollectionData) {
        if (memoryCollectionData != null) {
            this.memoryData = memoryCollectionData;
        }
    }

    public CpuCollectionData getCpuData() {
        return this.cpuData;
    }

    public MemoryCollectionData getMemoryData() {
        return this.memoryData;
    }
}

