/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.List
 */
package io.sentry;

import io.sentry.Baggage;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryTraceHeader;
import io.sentry.SpanId;
import io.sentry.TraceContext;
import io.sentry.exception.InvalidSentryTraceHeaderException;
import io.sentry.protocol.SentryId;
import java.util.Arrays;
import java.util.List;

public final class PropagationContext {
    private Baggage baggage;
    private SpanId parentSpanId;
    private Boolean sampled;
    private SpanId spanId;
    private SentryId traceId;

    public PropagationContext() {
        this(new SentryId(), new SpanId(), null, null, null);
    }

    public PropagationContext(PropagationContext propagationContext) {
        this(propagationContext.getTraceId(), propagationContext.getSpanId(), propagationContext.getParentSpanId(), PropagationContext.cloneBaggage(propagationContext.getBaggage()), propagationContext.isSampled());
    }

    public PropagationContext(SentryId sentryId, SpanId spanId, SpanId spanId2, Baggage baggage, Boolean bl) {
        this.traceId = sentryId;
        this.spanId = spanId;
        this.parentSpanId = spanId2;
        this.baggage = baggage;
        this.sampled = bl;
    }

    private static Baggage cloneBaggage(Baggage baggage) {
        if (baggage != null) {
            return new Baggage(baggage);
        }
        return null;
    }

    public static PropagationContext fromHeaders(ILogger iLogger, String string2, String string3) {
        return PropagationContext.fromHeaders(iLogger, string2, (List<String>)Arrays.asList((Object[])new String[]{string3}));
    }

    public static PropagationContext fromHeaders(ILogger iLogger, String object, List<String> list) {
        if (object == null) {
            return new PropagationContext();
        }
        try {
            SentryTraceHeader sentryTraceHeader = new SentryTraceHeader((String)object);
            object = PropagationContext.fromHeaders(sentryTraceHeader, Baggage.fromHeader(list, iLogger), null);
            return object;
        }
        catch (InvalidSentryTraceHeaderException invalidSentryTraceHeaderException) {
            iLogger.log(SentryLevel.DEBUG, (Throwable)invalidSentryTraceHeaderException, "Failed to parse Sentry trace header: %s", invalidSentryTraceHeaderException.getMessage());
            return new PropagationContext();
        }
    }

    public static PropagationContext fromHeaders(SentryTraceHeader sentryTraceHeader, Baggage baggage, SpanId spanId) {
        SpanId spanId2 = spanId;
        if (spanId == null) {
            spanId2 = new SpanId();
        }
        return new PropagationContext(sentryTraceHeader.getTraceId(), spanId2, sentryTraceHeader.getSpanId(), baggage, sentryTraceHeader.isSampled());
    }

    public Baggage getBaggage() {
        return this.baggage;
    }

    public SpanId getParentSpanId() {
        return this.parentSpanId;
    }

    public SpanId getSpanId() {
        return this.spanId;
    }

    public SentryId getTraceId() {
        return this.traceId;
    }

    public Boolean isSampled() {
        return this.sampled;
    }

    public void setBaggage(Baggage baggage) {
        this.baggage = baggage;
    }

    public void setParentSpanId(SpanId spanId) {
        this.parentSpanId = spanId;
    }

    public void setSampled(Boolean bl) {
        this.sampled = bl;
    }

    public void setSpanId(SpanId spanId) {
        this.spanId = spanId;
    }

    public void setTraceId(SentryId sentryId) {
        this.traceId = sentryId;
    }

    public TraceContext traceContext() {
        Baggage baggage = this.baggage;
        if (baggage != null) {
            return baggage.toTraceContext();
        }
        return null;
    }
}

