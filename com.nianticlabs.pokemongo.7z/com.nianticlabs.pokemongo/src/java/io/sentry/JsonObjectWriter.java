/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry;

import io.sentry.ILogger;
import io.sentry.JsonObjectSerializer;
import io.sentry.ObjectWriter;
import io.sentry.vendor.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Writer;

public final class JsonObjectWriter
implements ObjectWriter {
    private final JsonObjectSerializer jsonObjectSerializer;
    private final JsonWriter jsonWriter;

    public JsonObjectWriter(Writer writer, int n2) {
        this.jsonWriter = new JsonWriter(writer);
        this.jsonObjectSerializer = new JsonObjectSerializer(n2);
    }

    @Override
    public JsonObjectWriter beginArray() throws IOException {
        this.jsonWriter.beginArray();
        return this;
    }

    @Override
    public JsonObjectWriter beginObject() throws IOException {
        this.jsonWriter.beginObject();
        return this;
    }

    @Override
    public JsonObjectWriter endArray() throws IOException {
        this.jsonWriter.endArray();
        return this;
    }

    @Override
    public JsonObjectWriter endObject() throws IOException {
        this.jsonWriter.endObject();
        return this;
    }

    @Override
    public JsonObjectWriter name(String string2) throws IOException {
        this.jsonWriter.name(string2);
        return this;
    }

    @Override
    public JsonObjectWriter nullValue() throws IOException {
        this.jsonWriter.nullValue();
        return this;
    }

    public void setIndent(String string2) {
        this.jsonWriter.setIndent(string2);
    }

    @Override
    public JsonObjectWriter value(double d2) throws IOException {
        this.jsonWriter.value(d2);
        return this;
    }

    @Override
    public JsonObjectWriter value(long l2) throws IOException {
        this.jsonWriter.value(l2);
        return this;
    }

    @Override
    public JsonObjectWriter value(ILogger iLogger, Object object) throws IOException {
        this.jsonObjectSerializer.serialize(this, iLogger, object);
        return this;
    }

    @Override
    public JsonObjectWriter value(Boolean bl) throws IOException {
        this.jsonWriter.value(bl);
        return this;
    }

    @Override
    public JsonObjectWriter value(Number number) throws IOException {
        this.jsonWriter.value(number);
        return this;
    }

    @Override
    public JsonObjectWriter value(String string2) throws IOException {
        this.jsonWriter.value(string2);
        return this;
    }

    @Override
    public JsonObjectWriter value(boolean bl) throws IOException {
        this.jsonWriter.value(bl);
        return this;
    }
}

