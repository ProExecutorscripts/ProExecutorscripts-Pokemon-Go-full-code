/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry;

import io.sentry.DefaultTransactionPerformanceCollector;
import io.sentry.ITransaction;

public final class DefaultTransactionPerformanceCollector$$ExternalSyntheticLambda0
implements Runnable {
    public final DefaultTransactionPerformanceCollector f$0;
    public final ITransaction f$1;

    public /* synthetic */ DefaultTransactionPerformanceCollector$$ExternalSyntheticLambda0(DefaultTransactionPerformanceCollector defaultTransactionPerformanceCollector, ITransaction iTransaction) {
        this.f$0 = defaultTransactionPerformanceCollector;
        this.f$1 = iTransaction;
    }

    public final void run() {
        this.f$0.lambda$start$0$io-sentry-DefaultTransactionPerformanceCollector(this.f$1);
    }
}

