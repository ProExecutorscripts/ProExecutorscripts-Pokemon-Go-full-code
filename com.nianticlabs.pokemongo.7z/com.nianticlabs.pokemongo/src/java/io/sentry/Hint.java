/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry;

import io.sentry.Attachment;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class Hint {
    private static final Map<String, Class<?>> PRIMITIVE_MAPPINGS;
    private final List<Attachment> attachments;
    private final Map<String, Object> internalStorage = new HashMap();
    private Attachment screenshot = null;
    private Attachment threadDump = null;
    private Attachment viewHierarchy = null;

    static {
        HashMap hashMap;
        PRIMITIVE_MAPPINGS = hashMap = new HashMap();
        hashMap.put((Object)"boolean", Boolean.class);
        hashMap.put((Object)"char", Character.class);
        hashMap.put((Object)"byte", Byte.class);
        hashMap.put((Object)"short", Short.class);
        hashMap.put((Object)"int", Integer.class);
        hashMap.put((Object)"long", Long.class);
        hashMap.put((Object)"float", Float.class);
        hashMap.put((Object)"double", Double.class);
    }

    public Hint() {
        this.attachments = new ArrayList();
    }

    private boolean isCastablePrimitive(Object object, Class<?> clazz) {
        Class clazz2 = (Class)PRIMITIVE_MAPPINGS.get((Object)clazz.getCanonicalName());
        boolean bl = object != null && clazz.isPrimitive() && clazz2 != null && clazz2.isInstance(object);
        return bl;
    }

    public static Hint withAttachment(Attachment attachment) {
        Hint hint = new Hint();
        hint.addAttachment(attachment);
        return hint;
    }

    public static Hint withAttachments(List<Attachment> list) {
        Hint hint = new Hint();
        hint.addAttachments(list);
        return hint;
    }

    public void addAttachment(Attachment attachment) {
        if (attachment != null) {
            this.attachments.add((Object)attachment);
        }
    }

    public void addAttachments(List<Attachment> list) {
        if (list != null) {
            this.attachments.addAll(list);
        }
    }

    public void clear() {
        Hint hint = this;
        synchronized (hint) {
            Iterator iterator = this.internalStorage.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry entry = (Map.Entry)iterator.next();
                if (entry.getKey() != null && ((String)entry.getKey()).startsWith("sentry:")) continue;
                iterator.remove();
            }
            return;
        }
    }

    public void clearAttachments() {
        this.attachments.clear();
    }

    public Object get(String object) {
        Hint hint = this;
        synchronized (hint) {
            object = this.internalStorage.get(object);
            return object;
        }
    }

    public <T> T getAs(String object, Class<T> clazz) {
        Hint hint = this;
        synchronized (hint) {
            block5: {
                boolean bl;
                block4: {
                    object = this.internalStorage.get(object);
                    bl = clazz.isInstance(object);
                    if (!bl) break block4;
                    return (T)object;
                }
                bl = this.isCastablePrimitive(object, clazz);
                if (!bl) break block5;
                return (T)object;
            }
            return null;
        }
    }

    public List<Attachment> getAttachments() {
        return new ArrayList(this.attachments);
    }

    public Attachment getScreenshot() {
        return this.screenshot;
    }

    public Attachment getThreadDump() {
        return this.threadDump;
    }

    public Attachment getViewHierarchy() {
        return this.viewHierarchy;
    }

    public void remove(String string2) {
        Hint hint = this;
        synchronized (hint) {
            this.internalStorage.remove((Object)string2);
            return;
        }
    }

    public void replaceAttachments(List<Attachment> list) {
        this.clearAttachments();
        this.addAttachments(list);
    }

    public void set(String string2, Object object) {
        Hint hint = this;
        synchronized (hint) {
            this.internalStorage.put((Object)string2, object);
            return;
        }
    }

    public void setScreenshot(Attachment attachment) {
        this.screenshot = attachment;
    }

    public void setThreadDump(Attachment attachment) {
        this.threadDump = attachment;
    }

    public void setViewHierarchy(Attachment attachment) {
        this.viewHierarchy = attachment;
    }
}

