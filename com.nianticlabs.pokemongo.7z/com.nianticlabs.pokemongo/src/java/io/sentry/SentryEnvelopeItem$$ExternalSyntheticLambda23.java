/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.ISerializer;
import io.sentry.SentryEnvelopeItem;
import io.sentry.Session;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem$$ExternalSyntheticLambda23
implements Callable {
    public final ISerializer f$0;
    public final Session f$1;

    public /* synthetic */ SentryEnvelopeItem$$ExternalSyntheticLambda23(ISerializer iSerializer, Session session) {
        this.f$0 = iSerializer;
        this.f$1 = session;
    }

    public final Object call() {
        return SentryEnvelopeItem.lambda$fromSession$0(this.f$0, this.f$1);
    }
}

