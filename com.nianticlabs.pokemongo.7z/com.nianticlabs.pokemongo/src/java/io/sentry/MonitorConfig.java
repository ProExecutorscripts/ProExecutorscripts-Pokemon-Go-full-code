/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 */
package io.sentry;

import io.sentry.HubAdapter;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.MonitorSchedule;
import io.sentry.ObjectWriter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.vendor.gson.stream.JsonReader;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class MonitorConfig
implements JsonUnknown,
JsonSerializable {
    private Long checkinMargin;
    private Long failureIssueThreshold;
    private Long maxRuntime;
    private Long recoveryThreshold;
    private MonitorSchedule schedule;
    private String timezone;
    private Map<String, Object> unknown;

    public MonitorConfig(MonitorSchedule object) {
        this.schedule = object;
        object = HubAdapter.getInstance().getOptions().getCron();
        if (object != null) {
            this.checkinMargin = ((SentryOptions.Cron)object).getDefaultCheckinMargin();
            this.maxRuntime = ((SentryOptions.Cron)object).getDefaultMaxRuntime();
            this.timezone = ((SentryOptions.Cron)object).getDefaultTimezone();
            this.failureIssueThreshold = ((SentryOptions.Cron)object).getDefaultFailureIssueThreshold();
            this.recoveryThreshold = ((SentryOptions.Cron)object).getDefaultRecoveryThreshold();
        }
    }

    public Long getCheckinMargin() {
        return this.checkinMargin;
    }

    public Long getFailureIssueThreshold() {
        return this.failureIssueThreshold;
    }

    public Long getMaxRuntime() {
        return this.maxRuntime;
    }

    public Long getRecoveryThreshold() {
        return this.recoveryThreshold;
    }

    public MonitorSchedule getSchedule() {
        return this.schedule;
    }

    public String getTimezone() {
        return this.timezone;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Iterator iterator;
        objectWriter.beginObject();
        objectWriter.name("schedule");
        this.schedule.serialize(objectWriter, iLogger);
        if (this.checkinMargin != null) {
            objectWriter.name("checkin_margin").value((Number)this.checkinMargin);
        }
        if (this.maxRuntime != null) {
            objectWriter.name("max_runtime").value((Number)this.maxRuntime);
        }
        if (this.timezone != null) {
            objectWriter.name("timezone").value(this.timezone);
        }
        if (this.failureIssueThreshold != null) {
            objectWriter.name("failure_issue_threshold").value((Number)this.failureIssueThreshold);
        }
        if (this.recoveryThreshold != null) {
            objectWriter.name("recovery_threshold").value((Number)this.recoveryThreshold);
        }
        if ((iterator = this.unknown) != null) {
            for (String string2 : iterator.keySet()) {
                Object object = this.unknown.get((Object)string2);
                objectWriter.name(string2).value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setCheckinMargin(Long l2) {
        this.checkinMargin = l2;
    }

    public void setFailureIssueThreshold(Long l2) {
        this.failureIssueThreshold = l2;
    }

    public void setMaxRuntime(Long l2) {
        this.maxRuntime = l2;
    }

    public void setRecoveryThreshold(Long l2) {
        this.recoveryThreshold = l2;
    }

    public void setSchedule(MonitorSchedule monitorSchedule) {
        this.schedule = monitorSchedule;
    }

    public void setTimezone(String string2) {
        this.timezone = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<MonitorConfig> {
        @Override
        public MonitorConfig deserialize(JsonObjectReader object, ILogger iLogger) throws Exception {
            Long l2;
            Object object2;
            Long l3;
            Long l4;
            ((JsonReader)object).beginObject();
            MonitorSchedule monitorSchedule = null;
            Long l5 = null;
            Long l6 = l4 = (l3 = (object2 = (l2 = null)));
            block16: while (((JsonReader)object).peek() == JsonToken.NAME) {
                String string2 = ((JsonReader)object).nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2138521552: {
                        if (!string2.equals((Object)"failure_issue_threshold")) break;
                        n3 = 5;
                        break;
                    }
                    case 1581873149: {
                        if (!string2.equals((Object)"max_runtime")) break;
                        n3 = 4;
                        break;
                    }
                    case -607475647: {
                        if (!string2.equals((Object)"recovery_threshold")) break;
                        n3 = 3;
                        break;
                    }
                    case -697920873: {
                        if (!string2.equals((Object)"schedule")) break;
                        n3 = 2;
                        break;
                    }
                    case -905406976: {
                        if (!string2.equals((Object)"checkin_margin")) break;
                        n3 = 1;
                        break;
                    }
                    case -2076227591: {
                        if (!string2.equals((Object)"timezone")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        Long l7 = l6;
                        if (l6 == null) {
                            l7 = new HashMap();
                        }
                        ((JsonObjectReader)object).nextUnknown(iLogger, (Map<String, Object>)l7, string2);
                        l6 = l7;
                        continue block16;
                    }
                    case 5: {
                        l3 = ((JsonObjectReader)object).nextLongOrNull();
                        continue block16;
                    }
                    case 4: {
                        l2 = ((JsonObjectReader)object).nextLongOrNull();
                        continue block16;
                    }
                    case 3: {
                        l4 = ((JsonObjectReader)object).nextLongOrNull();
                        continue block16;
                    }
                    case 2: {
                        monitorSchedule = new MonitorSchedule.Deserializer().deserialize((JsonObjectReader)object, iLogger);
                        continue block16;
                    }
                    case 1: {
                        l5 = ((JsonObjectReader)object).nextLongOrNull();
                        continue block16;
                    }
                    case 0: 
                }
                object2 = ((JsonObjectReader)object).nextStringOrNull();
            }
            ((JsonReader)object).endObject();
            if (monitorSchedule != null) {
                object = new MonitorConfig(monitorSchedule);
                ((MonitorConfig)object).setCheckinMargin(l5);
                ((MonitorConfig)object).setMaxRuntime(l2);
                ((MonitorConfig)object).setTimezone((String)object2);
                ((MonitorConfig)object).setFailureIssueThreshold(l3);
                ((MonitorConfig)object).setRecoveryThreshold(l4);
                ((MonitorConfig)object).setUnknown((Map<String, Object>)l6);
                return object;
            }
            object = new IllegalStateException("Missing required field \"schedule\"");
            iLogger.log(SentryLevel.ERROR, "Missing required field \"schedule\"", (Throwable)object);
            throw object;
        }
    }

    public static final class JsonKeys {
        public static final String CHECKIN_MARGIN = "checkin_margin";
        public static final String FAILURE_ISSUE_THRESHOLD = "failure_issue_threshold";
        public static final String MAX_RUNTIME = "max_runtime";
        public static final String RECOVERY_THRESHOLD = "recovery_threshold";
        public static final String SCHEDULE = "schedule";
        public static final String TIMEZONE = "timezone";
    }
}

