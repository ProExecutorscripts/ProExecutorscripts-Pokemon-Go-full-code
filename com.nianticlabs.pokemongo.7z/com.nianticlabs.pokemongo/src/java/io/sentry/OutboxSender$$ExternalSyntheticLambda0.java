/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 */
package io.sentry;

import io.sentry.OutboxSender;
import io.sentry.hints.Retryable;
import io.sentry.util.HintUtils;
import java.io.File;

public final class OutboxSender$$ExternalSyntheticLambda0
implements HintUtils.SentryConsumer {
    public final OutboxSender f$0;
    public final File f$1;

    public /* synthetic */ OutboxSender$$ExternalSyntheticLambda0(OutboxSender outboxSender, File file) {
        this.f$0 = outboxSender;
        this.f$1 = file;
    }

    public final void accept(Object object) {
        this.f$0.lambda$processFile$0$io-sentry-OutboxSender(this.f$1, (Retryable)object);
    }
}

