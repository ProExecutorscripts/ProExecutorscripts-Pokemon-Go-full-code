/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Comparable
 *  java.lang.Long
 *  java.lang.Object
 */
package io.sentry;

public abstract class SentryDate
implements Comparable<SentryDate> {
    public int compareTo(SentryDate sentryDate) {
        return Long.valueOf((long)this.nanoTimestamp()).compareTo(Long.valueOf((long)sentryDate.nanoTimestamp()));
    }

    public long diff(SentryDate sentryDate) {
        return this.nanoTimestamp() - sentryDate.nanoTimestamp();
    }

    public final boolean isAfter(SentryDate sentryDate) {
        boolean bl = this.diff(sentryDate) > 0L;
        return bl;
    }

    public final boolean isBefore(SentryDate sentryDate) {
        boolean bl = this.diff(sentryDate) < 0L;
        return bl;
    }

    public long laterDateNanosTimestampByDiff(SentryDate sentryDate) {
        if (sentryDate != null && this.compareTo(sentryDate) < 0) {
            return sentryDate.nanoTimestamp();
        }
        return this.nanoTimestamp();
    }

    public abstract long nanoTimestamp();
}

