/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

import io.sentry.Sentry;
import io.sentry.SentryOptions;

public final class Sentry$$ExternalSyntheticLambda1
implements Sentry.OptionsConfiguration {
    public final String f$0;

    public /* synthetic */ Sentry$$ExternalSyntheticLambda1(String string2) {
        this.f$0 = string2;
    }

    public final void configure(SentryOptions sentryOptions) {
        Sentry.lambda$init$1(this.f$0, sentryOptions);
    }
}

