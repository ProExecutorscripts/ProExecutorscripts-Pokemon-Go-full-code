/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.Reader
 *  java.io.StringReader
 *  java.lang.IllegalArgumentException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 */
package io.sentry;

import io.sentry.IEnvelopeReader;
import io.sentry.ISerializer;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEnvelopeHeader;
import io.sentry.SentryEnvelopeItem;
import io.sentry.SentryEnvelopeItemHeader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;

public final class EnvelopeReader
implements IEnvelopeReader {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private final ISerializer serializer;

    public EnvelopeReader(ISerializer iSerializer) {
        this.serializer = iSerializer;
    }

    private SentryEnvelopeHeader deserializeEnvelopeHeader(byte[] object, int n2, int n3) {
        object = new StringReader(new String(object, n2, n3, UTF_8));
        try {
            SentryEnvelopeHeader sentryEnvelopeHeader = this.serializer.deserialize((Reader)object, SentryEnvelopeHeader.class);
            return sentryEnvelopeHeader;
        }
        finally {
            object.close();
        }
    }

    private SentryEnvelopeItemHeader deserializeEnvelopeItemHeader(byte[] object, int n2, int n3) {
        StringReader stringReader = new StringReader(new String(object, n2, n3, UTF_8));
        try {
            object = this.serializer.deserialize((Reader)stringReader, SentryEnvelopeItemHeader.class);
            return object;
        }
        finally {
            stringReader.close();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public SentryEnvelope read(InputStream object) throws IOException {
        byte[] byArray = new byte[1024];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int n2 = 0;
        int n3 = -1;
        try {
            ArrayList arrayList;
            block23: {
                block24: {
                    int n4;
                    byte[] byArray2;
                    block25: {
                        block27: {
                            SentryEnvelopeHeader sentryEnvelopeHeader;
                            block26: {
                                while (true) {
                                    int n5;
                                    if ((n5 = object.read(byArray)) <= 0) {
                                        byArray2 = byteArrayOutputStream.toByteArray();
                                        if (byArray2.length != 0) {
                                            if (n3 != -1) {
                                                sentryEnvelopeHeader = this.deserializeEnvelopeHeader(byArray2, 0, n3);
                                                if (sentryEnvelopeHeader != null) break;
                                                IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Envelope header is null.");
                                                throw illegalArgumentException;
                                            }
                                            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Envelope contains no header.");
                                            throw illegalArgumentException;
                                        }
                                        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Empty stream.");
                                        throw illegalArgumentException;
                                    }
                                    int n6 = 0;
                                    while (true) {
                                        n4 = n3;
                                        if (n3 != -1) break;
                                        n4 = n3;
                                        if (n6 >= n5) break;
                                        if (byArray[n6] == 10) {
                                            n4 = n2 + n6;
                                            break;
                                        }
                                        ++n6;
                                    }
                                    byteArrayOutputStream.write(byArray, 0, n5);
                                    n2 += n5;
                                    n3 = n4;
                                }
                                n2 = n3 + 1;
                                arrayList = new ArrayList();
                                while (true) {
                                    block22: {
                                        for (n3 = n2; n3 < byArray2.length; ++n3) {
                                            if (byArray2[n3] != 10) {
                                                continue;
                                            }
                                            break block22;
                                        }
                                        n3 = -1;
                                    }
                                    if (n3 == -1) break block23;
                                    SentryEnvelopeItemHeader sentryEnvelopeItemHeader = this.deserializeEnvelopeItemHeader(byArray2, n2, n3 - n2);
                                    if (sentryEnvelopeItemHeader == null || sentryEnvelopeItemHeader.getLength() <= 0) break block24;
                                    n4 = sentryEnvelopeItemHeader.getLength() + n3 + 1;
                                    if (n4 > byArray2.length) break block25;
                                    byte[] byArray3 = Arrays.copyOfRange((byte[])byArray2, (int)(n3 + 1), (int)n4);
                                    SentryEnvelopeItem sentryEnvelopeItem = new SentryEnvelopeItem(sentryEnvelopeItemHeader, byArray3);
                                    arrayList.add((Object)sentryEnvelopeItem);
                                    if (n4 == byArray2.length) break block26;
                                    n2 = n3 = n4 + 1;
                                    if (n3 != byArray2.length) continue;
                                    break;
                                }
                                if (byArray2[n4] != 10) break block27;
                            }
                            SentryEnvelope sentryEnvelope = new SentryEnvelope(sentryEnvelopeHeader, (Iterable<SentryEnvelopeItem>)arrayList);
                            return sentryEnvelope;
                        }
                        IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Envelope has invalid data following an item.");
                        throw illegalArgumentException;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.append("Invalid length for item at index '").append(arrayList.size()).append("'. Item is '").append(n4).append("' bytes. There are '").append(byArray2.length).append("' in the buffer.").toString());
                    throw illegalArgumentException;
                }
                StringBuilder stringBuilder = new StringBuilder();
                IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.append("Item header at index '").append(arrayList.size()).append("' is null or empty.").toString());
                throw illegalArgumentException;
            }
            StringBuilder stringBuilder = new StringBuilder();
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException(stringBuilder.append("Invalid envelope. Item at index '").append(arrayList.size()).append("'. has no header delimiter.").toString());
            throw illegalArgumentException;
        }
        catch (Throwable throwable) {
            throw throwable;
        }
        finally {
            byteArrayOutputStream.close();
        }
    }
}

