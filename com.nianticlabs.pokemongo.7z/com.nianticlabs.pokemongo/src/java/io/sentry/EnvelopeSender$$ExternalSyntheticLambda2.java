/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 *  java.lang.Throwable
 */
package io.sentry;

import io.sentry.EnvelopeSender;
import io.sentry.hints.Retryable;
import io.sentry.util.HintUtils;
import java.io.File;

public final class EnvelopeSender$$ExternalSyntheticLambda2
implements HintUtils.SentryConsumer {
    public final EnvelopeSender f$0;
    public final Throwable f$1;
    public final File f$2;

    public /* synthetic */ EnvelopeSender$$ExternalSyntheticLambda2(EnvelopeSender envelopeSender, Throwable throwable, File file) {
        this.f$0 = envelopeSender;
        this.f$1 = throwable;
        this.f$2 = file;
    }

    public final void accept(Object object) {
        this.f$0.lambda$processFile$1$io-sentry-EnvelopeSender(this.f$1, this.f$2, (Retryable)object);
    }
}

