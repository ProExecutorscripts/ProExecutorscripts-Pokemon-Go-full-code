/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 */
package io.sentry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

final class SentryValues<T> {
    private final List<T> values;

    SentryValues(List<T> arrayList) {
        ArrayList arrayList2 = arrayList;
        if (arrayList == null) {
            arrayList2 = new ArrayList(0);
        }
        this.values = new ArrayList((Collection)arrayList2);
    }

    public List<T> getValues() {
        return this.values;
    }

    public static final class JsonKeys {
        public static final String VALUES = "values";
    }
}

