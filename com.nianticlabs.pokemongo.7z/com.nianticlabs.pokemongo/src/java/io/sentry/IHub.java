/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 */
package io.sentry;

import io.sentry.BaggageHeader;
import io.sentry.Breadcrumb;
import io.sentry.CheckIn;
import io.sentry.Hint;
import io.sentry.ISentryClient;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.ProfilingTraceData;
import io.sentry.ScopeCallback;
import io.sentry.SentryEnvelope;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SentryTraceHeader;
import io.sentry.TraceContext;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.UserFeedback;
import io.sentry.metrics.MetricsApi;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.transport.RateLimiter;
import java.util.List;

public interface IHub {
    public void addBreadcrumb(Breadcrumb var1);

    public void addBreadcrumb(Breadcrumb var1, Hint var2);

    default public void addBreadcrumb(String string2) {
        this.addBreadcrumb(new Breadcrumb(string2));
    }

    default public void addBreadcrumb(String object, String string2) {
        object = new Breadcrumb((String)object);
        ((Breadcrumb)object).setCategory(string2);
        this.addBreadcrumb((Breadcrumb)object);
    }

    public void bindClient(ISentryClient var1);

    public SentryId captureCheckIn(CheckIn var1);

    default public SentryId captureEnvelope(SentryEnvelope sentryEnvelope) {
        return this.captureEnvelope(sentryEnvelope, new Hint());
    }

    public SentryId captureEnvelope(SentryEnvelope var1, Hint var2);

    default public SentryId captureEvent(SentryEvent sentryEvent) {
        return this.captureEvent(sentryEvent, new Hint());
    }

    public SentryId captureEvent(SentryEvent var1, Hint var2);

    public SentryId captureEvent(SentryEvent var1, Hint var2, ScopeCallback var3);

    default public SentryId captureEvent(SentryEvent sentryEvent, ScopeCallback scopeCallback) {
        return this.captureEvent(sentryEvent, new Hint(), scopeCallback);
    }

    default public SentryId captureException(Throwable throwable) {
        return this.captureException(throwable, new Hint());
    }

    public SentryId captureException(Throwable var1, Hint var2);

    public SentryId captureException(Throwable var1, Hint var2, ScopeCallback var3);

    default public SentryId captureException(Throwable throwable, ScopeCallback scopeCallback) {
        return this.captureException(throwable, new Hint(), scopeCallback);
    }

    default public SentryId captureMessage(String string2) {
        return this.captureMessage(string2, SentryLevel.INFO);
    }

    default public SentryId captureMessage(String string2, ScopeCallback scopeCallback) {
        return this.captureMessage(string2, SentryLevel.INFO, scopeCallback);
    }

    public SentryId captureMessage(String var1, SentryLevel var2);

    public SentryId captureMessage(String var1, SentryLevel var2, ScopeCallback var3);

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, Hint hint) {
        return this.captureTransaction(sentryTransaction, null, hint);
    }

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext) {
        return this.captureTransaction(sentryTransaction, traceContext, null);
    }

    default public SentryId captureTransaction(SentryTransaction sentryTransaction, TraceContext traceContext, Hint hint) {
        return this.captureTransaction(sentryTransaction, traceContext, hint, null);
    }

    public SentryId captureTransaction(SentryTransaction var1, TraceContext var2, Hint var3, ProfilingTraceData var4);

    public void captureUserFeedback(UserFeedback var1);

    public void clearBreadcrumbs();

    public IHub clone();

    public void close();

    public void close(boolean var1);

    public void configureScope(ScopeCallback var1);

    public TransactionContext continueTrace(String var1, List<String> var2);

    public void endSession();

    public void flush(long var1);

    public BaggageHeader getBaggage();

    public SentryId getLastEventId();

    public SentryOptions getOptions();

    public RateLimiter getRateLimiter();

    public ISpan getSpan();

    public SentryTraceHeader getTraceparent();

    public ITransaction getTransaction();

    public Boolean isCrashedLastRun();

    public boolean isEnabled();

    public boolean isHealthy();

    public MetricsApi metrics();

    public void popScope();

    public void pushScope();

    public void removeExtra(String var1);

    public void removeTag(String var1);

    @Deprecated
    default public void reportFullDisplayed() {
        this.reportFullyDisplayed();
    }

    public void reportFullyDisplayed();

    public void setExtra(String var1, String var2);

    public void setFingerprint(List<String> var1);

    public void setLevel(SentryLevel var1);

    public void setSpanContext(Throwable var1, ISpan var2, String var3);

    public void setTag(String var1, String var2);

    public void setTransaction(String var1);

    public void setUser(User var1);

    public void startSession();

    default public ITransaction startTransaction(TransactionContext transactionContext) {
        return this.startTransaction(transactionContext, new TransactionOptions());
    }

    public ITransaction startTransaction(TransactionContext var1, TransactionOptions var2);

    default public ITransaction startTransaction(String string2, String string3) {
        return this.startTransaction(string2, string3, new TransactionOptions());
    }

    default public ITransaction startTransaction(String string2, String string3, TransactionOptions transactionOptions) {
        return this.startTransaction(new TransactionContext(string2, string3), transactionOptions);
    }

    @Deprecated
    public SentryTraceHeader traceHeaders();

    public void withScope(ScopeCallback var1);
}

