/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Map
 */
package io.sentry;

import io.sentry.Breadcrumb;
import io.sentry.IScopeObserver;
import io.sentry.SentryLevel;
import io.sentry.SpanContext;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.Request;
import io.sentry.protocol.User;
import java.util.Collection;
import java.util.Map;

public abstract class ScopeObserverAdapter
implements IScopeObserver {
    @Override
    public void addBreadcrumb(Breadcrumb breadcrumb) {
    }

    @Override
    public void removeExtra(String string2) {
    }

    @Override
    public void removeTag(String string2) {
    }

    @Override
    public void setBreadcrumbs(Collection<Breadcrumb> collection) {
    }

    @Override
    public void setContexts(Contexts contexts) {
    }

    @Override
    public void setExtra(String string2, String string3) {
    }

    @Override
    public void setExtras(Map<String, Object> map2) {
    }

    @Override
    public void setFingerprint(Collection<String> collection) {
    }

    @Override
    public void setLevel(SentryLevel sentryLevel) {
    }

    @Override
    public void setRequest(Request request) {
    }

    @Override
    public void setTag(String string2, String string3) {
    }

    @Override
    public void setTags(Map<String, String> map2) {
    }

    @Override
    public void setTrace(SpanContext spanContext) {
    }

    @Override
    public void setTransaction(String string2) {
    }

    @Override
    public void setUser(User user) {
    }
}

