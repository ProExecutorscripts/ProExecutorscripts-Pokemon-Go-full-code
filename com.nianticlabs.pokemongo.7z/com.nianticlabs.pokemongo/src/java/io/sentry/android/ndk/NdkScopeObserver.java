/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Locale
 */
package io.sentry.android.ndk;

import io.sentry.Breadcrumb;
import io.sentry.DateUtils;
import io.sentry.ScopeObserverAdapter;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.ndk.INativeScope;
import io.sentry.android.ndk.NativeScope;
import io.sentry.protocol.User;
import io.sentry.util.Objects;
import java.util.Locale;

public final class NdkScopeObserver
extends ScopeObserverAdapter {
    private final INativeScope nativeScope;
    private final SentryOptions options;

    public NdkScopeObserver(SentryOptions sentryOptions) {
        this(sentryOptions, new NativeScope());
    }

    NdkScopeObserver(SentryOptions sentryOptions, INativeScope iNativeScope) {
        this.options = Objects.requireNonNull(sentryOptions, "The SentryOptions object is required.");
        this.nativeScope = Objects.requireNonNull(iNativeScope, "The NativeScope object is required.");
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void addBreadcrumb(Breadcrumb var1_1) {
        block10: {
            block9: {
                var2_3 = var1_1.getLevel();
                var4_4 = null;
                if (var2_3 == null) break block9;
                var2_3 = var1_1.getLevel().name().toLowerCase(Locale.ROOT);
                break block10;
            }
            var2_3 = null;
        }
        var5_5 = DateUtils.getTimestamp(var1_1.getTimestamp());
        var6_6 = var1_1.getData();
        var3_7 = var4_4;
        try {
            if (var6_6.isEmpty()) ** GOTO lbl25
            var3_7 = this.options.getSerializer().serialize(var6_6);
        }
        catch (Throwable var3_8) {
            this.options.getLogger().log(SentryLevel.ERROR, var3_8, "Breadcrumb data is not serializable.", new Object[0]);
            var3_7 = var4_4;
        }
lbl25:
        // 4 sources

        this.nativeScope.addBreadcrumb((String)var2_3, var1_1.getMessage(), var1_1.getCategory(), var1_1.getType(), var5_5, var3_7);
        {
            catch (Throwable var1_2) {
                this.options.getLogger().log(SentryLevel.ERROR, var1_2, "Scope sync addBreadcrumb has an error.", new Object[0]);
            }
        }
    }

    @Override
    public void removeExtra(String string2) {
        try {
            this.nativeScope.removeExtra(string2);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Scope sync removeExtra(%s) has an error.", string2);
        }
    }

    @Override
    public void removeTag(String string2) {
        try {
            this.nativeScope.removeTag(string2);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Scope sync removeTag(%s) has an error.", string2);
        }
    }

    @Override
    public void setExtra(String string2, String string3) {
        try {
            this.nativeScope.setExtra(string2, string3);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Scope sync setExtra(%s) has an error.", string2);
        }
    }

    @Override
    public void setTag(String string2, String string3) {
        try {
            this.nativeScope.setTag(string2, string3);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, throwable, "Scope sync setTag(%s) has an error.", string2);
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void setUser(User var1_1) {
        block2: {
            if (var1_1 != null) ** GOTO lbl5
            try {
                this.nativeScope.removeUser();
                break block2;
lbl5:
                // 1 sources

                this.nativeScope.setUser(var1_1.getId(), var1_1.getEmail(), var1_1.getIpAddress(), var1_1.getUsername());
            }
            catch (Throwable var1_2) {
                this.options.getLogger().log(SentryLevel.ERROR, var1_2, "Scope sync setUser has an error.", new Object[0]);
            }
        }
    }
}

