/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.ndk;

interface INativeScope {
    public void addBreadcrumb(String var1, String var2, String var3, String var4, String var5, String var6);

    public void removeExtra(String var1);

    public void removeTag(String var1);

    public void removeUser();

    public void setExtra(String var1, String var2);

    public void setTag(String var1, String var2);

    public void setUser(String var1, String var2, String var3, String var4);
}

