/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package io.sentry.android.ndk;

import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.ndk.DebugImagesLoader;
import io.sentry.android.ndk.NativeModuleListLoader;
import io.sentry.android.ndk.NdkScopeObserver;
import io.sentry.android.ndk.SentryNdkUtil;

public final class SentryNdk {
    static {
        System.loadLibrary((String)"log");
        System.loadLibrary((String)"sentry");
        System.loadLibrary((String)"sentry-android");
    }

    private SentryNdk() {
    }

    public static void close() {
        SentryNdk.shutdown();
    }

    public static void init(SentryAndroidOptions sentryAndroidOptions) {
        SentryNdkUtil.addPackage(sentryAndroidOptions.getSdkVersion());
        SentryNdk.initSentryNative(sentryAndroidOptions);
        if (sentryAndroidOptions.isEnableScopeSync()) {
            sentryAndroidOptions.addScopeObserver(new NdkScopeObserver(sentryAndroidOptions));
        }
        sentryAndroidOptions.setDebugImagesLoader(new DebugImagesLoader(sentryAndroidOptions, new NativeModuleListLoader()));
    }

    private static native void initSentryNative(SentryAndroidOptions var0);

    private static native void shutdown();
}

