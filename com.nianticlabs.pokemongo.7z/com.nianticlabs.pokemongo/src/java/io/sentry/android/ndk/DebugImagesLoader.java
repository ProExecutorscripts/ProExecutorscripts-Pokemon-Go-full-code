/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.List
 */
package io.sentry.android.ndk;

import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.IDebugImagesLoader;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.ndk.NativeModuleListLoader;
import io.sentry.protocol.DebugImage;
import io.sentry.util.Objects;
import java.util.Arrays;
import java.util.List;

public final class DebugImagesLoader
implements IDebugImagesLoader {
    private static List<DebugImage> debugImages;
    private static final Object debugImagesLock;
    private final NativeModuleListLoader moduleListLoader;
    private final SentryOptions options;

    static {
        debugImagesLock = new Object();
    }

    public DebugImagesLoader(SentryAndroidOptions sentryAndroidOptions, NativeModuleListLoader nativeModuleListLoader) {
        this.options = Objects.requireNonNull(sentryAndroidOptions, "The SentryAndroidOptions is required.");
        this.moduleListLoader = Objects.requireNonNull(nativeModuleListLoader, "The NativeModuleListLoader is required.");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clearDebugImages() {
        Object object;
        Object object2 = object = debugImagesLock;
        synchronized (object2) {
            try {
                this.moduleListLoader.clearModuleList();
                this.options.getLogger().log(SentryLevel.INFO, "Debug images cleared.", new Object[0]);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, throwable, "Failed to clear debug images.", new Object[0]);
            }
            debugImages = null;
            return;
        }
    }

    List<DebugImage> getCachedDebugImages() {
        return debugImages;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public List<DebugImage> loadDebugImages() {
        Object object;
        Object object2 = object = debugImagesLock;
        synchronized (object2) {
            Object[] objectArray = debugImages;
            if (objectArray == null) {
                try {
                    objectArray = this.moduleListLoader.loadModuleList();
                    if (objectArray != null) {
                        debugImages = Arrays.asList((Object[])objectArray);
                        this.options.getLogger().log(SentryLevel.DEBUG, "Debug images loaded: %d", debugImages.size());
                    }
                }
                catch (Throwable throwable) {
                    this.options.getLogger().log(SentryLevel.ERROR, throwable, "Failed to load debug images.", new Object[0]);
                }
            }
            return debugImages;
        }
    }
}

