/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.ndk;

import io.sentry.protocol.DebugImage;

final class NativeModuleListLoader {
    NativeModuleListLoader() {
    }

    public static native void nativeClearModuleList();

    public static native DebugImage[] nativeLoadModuleList();

    public void clearModuleList() {
        NativeModuleListLoader.nativeClearModuleList();
    }

    public DebugImage[] loadModuleList() {
        return NativeModuleListLoader.nativeLoadModuleList();
    }
}

