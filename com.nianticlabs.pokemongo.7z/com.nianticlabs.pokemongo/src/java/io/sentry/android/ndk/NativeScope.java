/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.ndk;

import io.sentry.android.ndk.INativeScope;

final class NativeScope
implements INativeScope {
    NativeScope() {
    }

    public static native void nativeAddBreadcrumb(String var0, String var1, String var2, String var3, String var4, String var5);

    public static native void nativeRemoveExtra(String var0);

    public static native void nativeRemoveTag(String var0);

    public static native void nativeRemoveUser();

    public static native void nativeSetExtra(String var0, String var1);

    public static native void nativeSetTag(String var0, String var1);

    public static native void nativeSetUser(String var0, String var1, String var2, String var3);

    @Override
    public void addBreadcrumb(String string2, String string3, String string4, String string5, String string6, String string7) {
        NativeScope.nativeAddBreadcrumb(string2, string3, string4, string5, string6, string7);
    }

    @Override
    public void removeExtra(String string2) {
        NativeScope.nativeRemoveExtra(string2);
    }

    @Override
    public void removeTag(String string2) {
        NativeScope.nativeRemoveTag(string2);
    }

    @Override
    public void removeUser() {
        NativeScope.nativeRemoveUser();
    }

    @Override
    public void setExtra(String string2, String string3) {
        NativeScope.nativeSetExtra(string2, string3);
    }

    @Override
    public void setTag(String string2, String string3) {
        NativeScope.nativeSetTag(string2, string3);
    }

    @Override
    public void setUser(String string2, String string3, String string4, String string5) {
        NativeScope.nativeSetUser(string2, string3, string4, string5);
    }
}

