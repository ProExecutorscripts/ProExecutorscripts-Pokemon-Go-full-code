/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.core;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class ActivityBreadcrumbsIntegration
implements Integration,
Closeable,
Application.ActivityLifecycleCallbacks {
    private final Application application;
    private boolean enabled;
    private IHub hub;

    public ActivityBreadcrumbsIntegration(Application application) {
        this.application = Objects.requireNonNull(application, "Application is required");
    }

    private void addBreadcrumb(Activity activity2, String object) {
        if (this.hub == null) {
            return;
        }
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setType("navigation");
        breadcrumb.setData("state", object);
        breadcrumb.setData("screen", this.getActivityName(activity2));
        breadcrumb.setCategory("ui.lifecycle");
        breadcrumb.setLevel(SentryLevel.INFO);
        object = new Hint();
        ((Hint)object).set("android:activity", activity2);
        this.hub.addBreadcrumb(breadcrumb, (Hint)object);
    }

    private String getActivityName(Activity activity2) {
        return activity2.getClass().getSimpleName();
    }

    public void close() throws IOException {
        if (this.enabled) {
            this.application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
            IHub iHub = this.hub;
            if (iHub != null) {
                iHub.getOptions().getLogger().log(SentryLevel.DEBUG, "ActivityBreadcrumbsIntegration removed.", new Object[0]);
            }
        }
    }

    public void onActivityCreated(Activity activity2, Bundle bundle) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "created");
            return;
        }
    }

    public void onActivityDestroyed(Activity activity2) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "destroyed");
            return;
        }
    }

    public void onActivityPaused(Activity activity2) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "paused");
            return;
        }
    }

    public void onActivityResumed(Activity activity2) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "resumed");
            return;
        }
    }

    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "saveInstanceState");
            return;
        }
    }

    public void onActivityStarted(Activity activity2) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "started");
            return;
        }
    }

    public void onActivityStopped(Activity activity2) {
        ActivityBreadcrumbsIntegration activityBreadcrumbsIntegration = this;
        synchronized (activityBreadcrumbsIntegration) {
            this.addBreadcrumb(activity2, "stopped");
            return;
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        SentryAndroidOptions sentryAndroidOptions = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        sentryAndroidOptions = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.hub = Objects.requireNonNull(iHub, "Hub is required");
        this.enabled = sentryAndroidOptions.isEnableActivityLifecycleBreadcrumbs();
        sentryOptions.getLogger().log(SentryLevel.DEBUG, "ActivityBreadcrumbsIntegration enabled: %s", this.enabled);
        if (this.enabled) {
            this.application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "ActivityBreadcrumbIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }
}

