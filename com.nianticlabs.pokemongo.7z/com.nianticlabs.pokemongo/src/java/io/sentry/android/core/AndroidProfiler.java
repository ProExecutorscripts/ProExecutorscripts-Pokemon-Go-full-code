/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Debug
 *  android.os.Process
 *  android.os.SystemClock
 *  java.io.File
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayDeque
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.UUID
 *  java.util.concurrent.Future
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import android.os.Debug;
import android.os.Process;
import android.os.SystemClock;
import io.sentry.CpuCollectionData;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.MemoryCollectionData;
import io.sentry.PerformanceCollectionData;
import io.sentry.SentryLevel;
import io.sentry.android.core.AndroidProfiler$$ExternalSyntheticLambda0;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import io.sentry.profilemeasurements.ProfileMeasurement;
import io.sentry.profilemeasurements.ProfileMeasurementValue;
import io.sentry.util.Objects;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class AndroidProfiler {
    private static final int BUFFER_SIZE_BYTES = 3000000;
    private static final int PROFILING_TIMEOUT_MILLIS = 30000;
    private final BuildInfoProvider buildInfoProvider;
    private final ISentryExecutorService executorService;
    private final SentryFrameMetricsCollector frameMetricsCollector;
    private String frameMetricsCollectorId;
    private final ArrayDeque<ProfileMeasurementValue> frozenFrameRenderMeasurements;
    private final int intervalUs;
    private boolean isRunning = false;
    private final ILogger logger;
    private final Map<String, ProfileMeasurement> measurementsMap;
    private long profileStartNanos = 0L;
    private Future<?> scheduledFinish = null;
    private final ArrayDeque<ProfileMeasurementValue> screenFrameRateMeasurements = new ArrayDeque();
    private final ArrayDeque<ProfileMeasurementValue> slowFrameRenderMeasurements = new ArrayDeque();
    private volatile ProfileEndData timedOutProfilingData = null;
    private File traceFile = null;
    private final File traceFilesDir;

    public AndroidProfiler(String string2, int n2, SentryFrameMetricsCollector sentryFrameMetricsCollector, ISentryExecutorService iSentryExecutorService, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        this.frozenFrameRenderMeasurements = new ArrayDeque();
        this.measurementsMap = new HashMap();
        this.traceFilesDir = new File(Objects.requireNonNull(string2, "TracesFilesDirPath is required"));
        this.intervalUs = n2;
        this.logger = Objects.requireNonNull(iLogger, "Logger is required");
        this.executorService = Objects.requireNonNull(iSentryExecutorService, "ExecutorService is required.");
        this.frameMetricsCollector = Objects.requireNonNull(sentryFrameMetricsCollector, "SentryFrameMetricsCollector is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "The BuildInfoProvider is required.");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void putPerformanceCollectionDataInMeasurements(List<PerformanceCollectionData> list) {
        if (this.buildInfoProvider.getSdkInfoVersion() < 21) {
            return;
        }
        long l2 = SystemClock.elapsedRealtimeNanos() - this.profileStartNanos - TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis());
        if (list == null) return;
        ArrayDeque arrayDeque = new ArrayDeque(list.size());
        ArrayDeque arrayDeque2 = new ArrayDeque(list.size());
        ArrayDeque arrayDeque3 = new ArrayDeque(list.size());
        List<PerformanceCollectionData> list2 = list;
        // MONITORENTER : list2
        for (Object object : list) {
            Object object2 = ((PerformanceCollectionData)object).getCpuData();
            object = ((PerformanceCollectionData)object).getMemoryData();
            if (object2 != null) {
                ProfileMeasurementValue profileMeasurementValue = new ProfileMeasurementValue(TimeUnit.MILLISECONDS.toNanos(((CpuCollectionData)object2).getTimestampMillis()) + l2, (Number)Double.valueOf((double)((CpuCollectionData)object2).getCpuUsagePercentage()));
                arrayDeque3.add((Object)profileMeasurementValue);
            }
            if (object != null && ((MemoryCollectionData)object).getUsedHeapMemory() > -1L) {
                object2 = new ProfileMeasurementValue(TimeUnit.MILLISECONDS.toNanos(((MemoryCollectionData)object).getTimestampMillis()) + l2, (Number)Long.valueOf((long)((MemoryCollectionData)object).getUsedHeapMemory()));
                arrayDeque.add(object2);
            }
            if (object == null || ((MemoryCollectionData)object).getUsedNativeMemory() <= -1L) continue;
            object2 = new ProfileMeasurementValue(TimeUnit.MILLISECONDS.toNanos(((MemoryCollectionData)object).getTimestampMillis()) + l2, (Number)Long.valueOf((long)((MemoryCollectionData)object).getUsedNativeMemory()));
            arrayDeque2.add(object2);
        }
        // MONITOREXIT : list2
        if (!arrayDeque3.isEmpty()) {
            this.measurementsMap.put((Object)"cpu_usage", (Object)new ProfileMeasurement("percent", (Collection<ProfileMeasurementValue>)arrayDeque3));
        }
        if (!arrayDeque.isEmpty()) {
            this.measurementsMap.put((Object)"memory_footprint", (Object)new ProfileMeasurement("byte", (Collection<ProfileMeasurementValue>)arrayDeque));
        }
        if (arrayDeque2.isEmpty()) return;
        this.measurementsMap.put((Object)"memory_native_footprint", (Object)new ProfileMeasurement("byte", (Collection<ProfileMeasurementValue>)arrayDeque2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() {
        AndroidProfiler androidProfiler = this;
        synchronized (androidProfiler) {
            Future<?> future = this.scheduledFinish;
            if (future != null) {
                future.cancel(true);
                this.scheduledFinish = null;
            }
            if (this.isRunning) {
                this.endAndCollect(true, null);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public ProfileEndData endAndCollect(boolean bl, List<PerformanceCollectionData> object) {
        AndroidProfiler androidProfiler = this;
        synchronized (androidProfiler) {
            ProfileMeasurement profileMeasurement;
            Map<String, ProfileMeasurement> map2;
            if (this.timedOutProfilingData != null) {
                return this.timedOutProfilingData;
            }
            if (!this.isRunning) {
                this.logger.log(SentryLevel.WARNING, "Profiler not running", new Object[0]);
                return null;
            }
            int n2 = this.buildInfoProvider.getSdkInfoVersion();
            if (n2 < 21) {
                return null;
            }
            try {
                Debug.stopMethodTracing();
            }
            catch (Throwable throwable) {
                try {
                    this.logger.log(SentryLevel.ERROR, "Error while stopping profiling: ", throwable);
                }
                finally {
                    this.isRunning = false;
                }
            }
            this.frameMetricsCollector.stopCollection(this.frameMetricsCollectorId);
            long l2 = SystemClock.elapsedRealtimeNanos();
            long l3 = Process.getElapsedCpuTime();
            if (this.traceFile == null) {
                this.logger.log(SentryLevel.ERROR, "Trace file does not exists", new Object[0]);
                return null;
            }
            if (!this.slowFrameRenderMeasurements.isEmpty()) {
                map2 = this.measurementsMap;
                profileMeasurement = new ProfileMeasurement("nanosecond", (Collection<ProfileMeasurementValue>)this.slowFrameRenderMeasurements);
                map2.put((Object)"slow_frame_renders", (Object)profileMeasurement);
            }
            if (!this.frozenFrameRenderMeasurements.isEmpty()) {
                map2 = this.measurementsMap;
                profileMeasurement = new ProfileMeasurement("nanosecond", (Collection<ProfileMeasurementValue>)this.frozenFrameRenderMeasurements);
                map2.put((Object)"frozen_frame_renders", (Object)profileMeasurement);
            }
            if (!this.screenFrameRateMeasurements.isEmpty()) {
                map2 = this.measurementsMap;
                profileMeasurement = new ProfileMeasurement("hz", (Collection<ProfileMeasurementValue>)this.screenFrameRateMeasurements);
                map2.put((Object)"screen_frame_rates", (Object)profileMeasurement);
            }
            this.putPerformanceCollectionDataInMeasurements((List<PerformanceCollectionData>)object);
            object = this.scheduledFinish;
            if (object == null) return new ProfileEndData(l2, l3, bl, this.traceFile, this.measurementsMap);
            object.cancel(true);
            this.scheduledFinish = null;
            return new ProfileEndData(l2, l3, bl, this.traceFile, this.measurementsMap);
        }
    }

    /* synthetic */ void lambda$start$0$io-sentry-android-core-AndroidProfiler() {
        this.timedOutProfilingData = this.endAndCollect(true, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public ProfileStartData start() {
        AndroidProfiler androidProfiler = this;
        synchronized (androidProfiler) {
            if (this.intervalUs == 0) {
                this.logger.log(SentryLevel.WARNING, "Disabling profiling because intervaUs is set to %d", this.intervalUs);
                return null;
            }
            if (this.isRunning) {
                this.logger.log(SentryLevel.WARNING, "Profiling has already started...", new Object[0]);
                return null;
            }
            int n2 = this.buildInfoProvider.getSdkInfoVersion();
            if (n2 < 21) {
                return null;
            }
            Object object = this.traceFilesDir;
            StringBuilder stringBuilder = new StringBuilder();
            Object object2 = new File((File)object, stringBuilder.append((Object)UUID.randomUUID()).append(".trace").toString());
            this.traceFile = object2;
            this.measurementsMap.clear();
            this.screenFrameRateMeasurements.clear();
            this.slowFrameRenderMeasurements.clear();
            this.frozenFrameRenderMeasurements.clear();
            object2 = this.frameMetricsCollector;
            object = new SentryFrameMetricsCollector.FrameMetricsCollectorListener(this){
                float lastRefreshRate;
                final AndroidProfiler this$0;
                {
                    this.this$0 = androidProfiler;
                    this.lastRefreshRate = 0.0f;
                }

                @Override
                public void onFrameMetricCollected(long l2, long l3, long l4, long l5, boolean bl, boolean bl2, float f2) {
                    l2 = l3 - System.nanoTime() + SystemClock.elapsedRealtimeNanos() - this.this$0.profileStartNanos;
                    if (l2 < 0L) {
                        return;
                    }
                    if (bl2) {
                        this.this$0.frozenFrameRenderMeasurements.addLast((Object)new ProfileMeasurementValue(l2, (Number)Long.valueOf((long)l4)));
                    } else if (bl) {
                        this.this$0.slowFrameRenderMeasurements.addLast((Object)new ProfileMeasurementValue(l2, (Number)Long.valueOf((long)l4)));
                    }
                    if (f2 != this.lastRefreshRate) {
                        this.lastRefreshRate = f2;
                        this.this$0.screenFrameRateMeasurements.addLast((Object)new ProfileMeasurementValue(l2, (Number)Float.valueOf((float)f2)));
                    }
                }
            };
            this.frameMetricsCollectorId = ((SentryFrameMetricsCollector)object2).startCollection((SentryFrameMetricsCollector.FrameMetricsCollectorListener)object);
            try {
                object = this.executorService;
                object2 = new AndroidProfiler$$ExternalSyntheticLambda0(this);
                this.scheduledFinish = object.schedule((Runnable)object2, 30000L);
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                this.logger.log(SentryLevel.ERROR, "Failed to call the executor. Profiling will not be automatically finished. Did you call Sentry.close()?", rejectedExecutionException);
            }
            this.profileStartNanos = SystemClock.elapsedRealtimeNanos();
            long l2 = Process.getElapsedCpuTime();
            try {
                Debug.startMethodTracingSampling((String)this.traceFile.getPath(), (int)3000000, (int)this.intervalUs);
                this.isRunning = true;
                return new ProfileStartData(this.profileStartNanos, l2);
            }
            catch (Throwable throwable) {
                this.endAndCollect(false, null);
                this.logger.log(SentryLevel.ERROR, "Unable to start a profile: ", throwable);
                this.isRunning = false;
                return null;
            }
        }
    }

    public static class ProfileEndData {
        public final boolean didTimeout;
        public final long endCpuMillis;
        public final long endNanos;
        public final Map<String, ProfileMeasurement> measurementsMap;
        public final File traceFile;

        public ProfileEndData(long l2, long l3, boolean bl, File file, Map<String, ProfileMeasurement> map2) {
            this.endNanos = l2;
            this.traceFile = file;
            this.endCpuMillis = l3;
            this.measurementsMap = map2;
            this.didTimeout = bl;
        }
    }

    public static class ProfileStartData {
        public final long startCpuMillis;
        public final long startNanos;

        public ProfileStartData(long l2, long l3) {
            this.startNanos = l2;
            this.startCpuMillis = l3;
        }
    }
}

