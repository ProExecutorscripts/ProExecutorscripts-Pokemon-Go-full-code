/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.util.Log;
import io.sentry.Breadcrumb;
import io.sentry.Sentry;
import io.sentry.SentryLevel;

public final class SentryLogcatAdapter {
    private static void addAsBreadcrumb(String string2, SentryLevel sentryLevel, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, sentryLevel, string3, null);
    }

    private static void addAsBreadcrumb(String string2, SentryLevel sentryLevel, String string3, Throwable throwable) {
        Breadcrumb breadcrumb = new Breadcrumb();
        breadcrumb.setCategory("Logcat");
        breadcrumb.setMessage(string3);
        breadcrumb.setLevel(sentryLevel);
        if (string2 != null) {
            breadcrumb.setData("tag", string2);
        }
        if (throwable != null && throwable.getMessage() != null) {
            breadcrumb.setData("throwable", throwable.getMessage());
        }
        Sentry.addBreadcrumb(breadcrumb);
    }

    private static void addAsBreadcrumb(String string2, SentryLevel sentryLevel, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, sentryLevel, null, throwable);
    }

    public static int d(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.DEBUG, string3);
        return Log.d((String)string2, (String)string3);
    }

    public static int d(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.DEBUG, string3, throwable);
        return Log.d((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int e(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.ERROR, string3);
        return Log.e((String)string2, (String)string3);
    }

    public static int e(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.ERROR, string3, throwable);
        return Log.e((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int i(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.INFO, string3);
        return Log.i((String)string2, (String)string3);
    }

    public static int i(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.INFO, string3, throwable);
        return Log.i((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int v(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.DEBUG, string3);
        return Log.v((String)string2, (String)string3);
    }

    public static int v(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.DEBUG, string3, throwable);
        return Log.v((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int w(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.WARNING, string3);
        return Log.w((String)string2, (String)string3);
    }

    public static int w(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.WARNING, string3, throwable);
        return Log.w((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int w(String string2, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.WARNING, throwable);
        return Log.w((String)string2, (Throwable)throwable);
    }

    public static int wtf(String string2, String string3) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.ERROR, string3);
        return Log.wtf((String)string2, (String)string3);
    }

    public static int wtf(String string2, String string3, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.ERROR, string3, throwable);
        return Log.wtf((String)string2, (String)string3, (Throwable)throwable);
    }

    public static int wtf(String string2, Throwable throwable) {
        SentryLogcatAdapter.addAsBreadcrumb(string2, SentryLevel.ERROR, throwable);
        return Log.wtf((String)string2, (Throwable)throwable);
    }
}

