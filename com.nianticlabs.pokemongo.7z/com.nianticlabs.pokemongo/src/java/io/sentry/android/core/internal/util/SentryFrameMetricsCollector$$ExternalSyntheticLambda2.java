/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.FrameMetrics
 *  android.view.Window
 *  android.view.Window$OnFrameMetricsAvailableListener
 *  java.lang.Object
 */
package io.sentry.android.core.internal.util;

import android.view.FrameMetrics;
import android.view.Window;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;

public final class SentryFrameMetricsCollector$$ExternalSyntheticLambda2
implements Window.OnFrameMetricsAvailableListener {
    public final SentryFrameMetricsCollector f$0;
    public final BuildInfoProvider f$1;

    public /* synthetic */ SentryFrameMetricsCollector$$ExternalSyntheticLambda2(SentryFrameMetricsCollector sentryFrameMetricsCollector, BuildInfoProvider buildInfoProvider) {
        this.f$0 = sentryFrameMetricsCollector;
        this.f$1 = buildInfoProvider;
    }

    public final void onFrameMetricsAvailable(Window window, FrameMetrics frameMetrics, int n2) {
        this.f$0.lambda$new$2$io-sentry-android-core-internal-util-SentryFrameMetricsCollector(this.f$1, window, frameMetrics, n2);
    }
}

