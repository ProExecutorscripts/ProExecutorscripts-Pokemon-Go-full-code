/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core;

import android.content.Context;
import android.content.pm.PackageInfo;
import io.sentry.DateUtils;
import io.sentry.HubAdapter;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.IScope;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.DeviceInfoUtil;
import io.sentry.android.core.Installation;
import io.sentry.android.core.InternalSentrySdk$$ExternalSyntheticLambda0;
import io.sentry.android.core.InternalSentrySdk$$ExternalSyntheticLambda1;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.protocol.App;
import io.sentry.protocol.Device;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.User;
import io.sentry.util.MapObjectWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public final class InternalSentrySdk {
    /*
     * Exception decompiling
     */
    public static SentryId captureEnvelope(byte[] var0) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static IScope getCurrentScope() {
        AtomicReference atomicReference = new AtomicReference();
        HubAdapter.getInstance().configureScope(new InternalSentrySdk$$ExternalSyntheticLambda1(atomicReference));
        return (IScope)atomicReference.get();
    }

    static /* synthetic */ void lambda$getCurrentScope$0(AtomicReference atomicReference, IScope iScope) {
        atomicReference.set((Object)iScope.clone());
    }

    static /* synthetic */ void lambda$updateSession$1(Session.State state, boolean bl, AtomicReference atomicReference, SentryOptions sentryOptions, IScope object) {
        if ((object = object.getSession()) != null) {
            if (((Session)object).update(state, null, bl, null)) {
                if (((Session)object).getStatus() == Session.State.Crashed) {
                    ((Session)object).end();
                }
                atomicReference.set(object);
            }
        } else {
            sentryOptions.getLogger().log(SentryLevel.INFO, "Session is null on updateSession", new Object[0]);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Map<String, Object> serializeScope(Context context, SentryAndroidOptions sentryAndroidOptions, IScope iScope) {
        HashMap hashMap = new HashMap();
        if (iScope == null) {
            return hashMap;
        }
        try {
            ILogger iLogger = sentryAndroidOptions.getLogger();
            MapObjectWriter mapObjectWriter = new MapObjectWriter((Map<String, Object>)hashMap);
            Object object = DeviceInfoUtil.getInstance(context, sentryAndroidOptions);
            Object object2 = ((DeviceInfoUtil)object).collectDeviceInformation(true, true);
            iScope.getContexts().setDevice((Device)object2);
            iScope.getContexts().setOperatingSystem(((DeviceInfoUtil)object).getOperatingSystem());
            object2 = object = iScope.getUser();
            if (object == null) {
                object2 = new User();
                iScope.setUser((User)object2);
            }
            if ((object = ((User)object2).getId()) == null) {
                try {
                    ((User)object2).setId(Installation.id(context));
                }
                catch (RuntimeException runtimeException) {
                    iLogger.log(SentryLevel.ERROR, "Could not retrieve installation ID", runtimeException);
                }
            }
            object2 = object = iScope.getContexts().getApp();
            if (object == null) {
                object2 = new App();
            }
            ((App)object2).setAppName(ContextUtils.getApplicationName(context, sentryAndroidOptions.getLogger()));
            object = AppStartMetrics.getInstance().getAppStartTimeSpanWithFallback(sentryAndroidOptions);
            if (((TimeSpan)object).hasStarted()) {
                ((App)object2).setAppStartTime(DateUtils.toUtilDate(((TimeSpan)object).getStartTimestamp()));
            }
            object = new BuildInfoProvider(sentryAndroidOptions.getLogger());
            if ((context = ContextUtils.getPackageInfo(context, 4096, sentryAndroidOptions.getLogger(), (BuildInfoProvider)object)) != null) {
                ContextUtils.setAppPackageInfo((PackageInfo)context, (BuildInfoProvider)object, (App)object2);
            }
            iScope.getContexts().setApp((App)object2);
            mapObjectWriter.name("user").value(iLogger, iScope.getUser());
            mapObjectWriter.name("contexts").value(iLogger, iScope.getContexts());
            mapObjectWriter.name("tags").value(iLogger, iScope.getTags());
            mapObjectWriter.name("extras").value(iLogger, iScope.getExtras());
            mapObjectWriter.name("fingerprint").value(iLogger, iScope.getFingerprint());
            mapObjectWriter.name("level").value(iLogger, iScope.getLevel());
            mapObjectWriter.name("breadcrumbs").value(iLogger, iScope.getBreadcrumbs());
            return hashMap;
        }
        catch (Throwable throwable) {
            sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "Could not serialize scope.", throwable);
            return new HashMap();
        }
    }

    private static Session updateSession(IHub iHub, SentryOptions sentryOptions, Session.State state, boolean bl) {
        AtomicReference atomicReference = new AtomicReference();
        iHub.configureScope(new InternalSentrySdk$$ExternalSyntheticLambda0(state, bl, atomicReference, sentryOptions));
        return (Session)atomicReference.get();
    }
}

