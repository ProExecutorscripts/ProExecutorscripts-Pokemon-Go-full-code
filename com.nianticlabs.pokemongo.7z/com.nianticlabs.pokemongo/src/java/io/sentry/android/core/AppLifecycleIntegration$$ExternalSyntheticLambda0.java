/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.android.core.AppLifecycleIntegration;

public final class AppLifecycleIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final AppLifecycleIntegration f$0;

    public /* synthetic */ AppLifecycleIntegration$$ExternalSyntheticLambda0(AppLifecycleIntegration appLifecycleIntegration) {
        this.f$0 = appLifecycleIntegration;
    }

    public final void run() {
        this.f$0.lambda$close$1$io-sentry-android-core-AppLifecycleIntegration();
    }
}

