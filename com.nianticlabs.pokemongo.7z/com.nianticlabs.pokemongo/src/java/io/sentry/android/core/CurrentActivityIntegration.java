/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryOptions;
import io.sentry.android.core.CurrentActivityHolder;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class CurrentActivityIntegration
implements Integration,
Closeable,
Application.ActivityLifecycleCallbacks {
    private final Application application;

    public CurrentActivityIntegration(Application application) {
        this.application = Objects.requireNonNull(application, "Application is required");
    }

    private void cleanCurrentActivity(Activity activity2) {
        if (CurrentActivityHolder.getInstance().getActivity() == activity2) {
            CurrentActivityHolder.getInstance().clearActivity();
        }
    }

    private void setCurrentActivity(Activity activity2) {
        CurrentActivityHolder.getInstance().setActivity(activity2);
    }

    public void close() throws IOException {
        this.application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
        CurrentActivityHolder.getInstance().clearActivity();
    }

    public void onActivityCreated(Activity activity2, Bundle bundle) {
        this.setCurrentActivity(activity2);
    }

    public void onActivityDestroyed(Activity activity2) {
        this.cleanCurrentActivity(activity2);
    }

    public void onActivityPaused(Activity activity2) {
        this.cleanCurrentActivity(activity2);
    }

    public void onActivityResumed(Activity activity2) {
        this.setCurrentActivity(activity2);
    }

    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity2) {
        this.setCurrentActivity(activity2);
    }

    public void onActivityStopped(Activity activity2) {
        this.cleanCurrentActivity(activity2);
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        this.application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
    }
}

