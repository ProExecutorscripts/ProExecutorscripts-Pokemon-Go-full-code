/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.ScopeCallback;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda6
implements ScopeCallback {
    public final ActivityLifecycleIntegration f$0;
    public final ITransaction f$1;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda6(ActivityLifecycleIntegration activityLifecycleIntegration, ITransaction iTransaction) {
        this.f$0 = activityLifecycleIntegration;
        this.f$1 = iTransaction;
    }

    @Override
    public final void run(IScope iScope) {
        this.f$0.lambda$startTracing$2$io-sentry-android-core-ActivityLifecycleIntegration(this.f$1, iScope);
    }
}

