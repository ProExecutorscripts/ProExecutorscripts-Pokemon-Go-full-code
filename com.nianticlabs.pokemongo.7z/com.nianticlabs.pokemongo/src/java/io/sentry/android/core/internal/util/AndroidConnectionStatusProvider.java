/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.ConnectivityManager$NetworkCallback
 *  android.net.Network
 *  android.net.NetworkCapabilities
 *  android.net.NetworkInfo
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry.android.core.internal.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import io.sentry.IConnectionStatusProvider;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.Permissions;
import java.util.HashMap;
import java.util.Map;

public final class AndroidConnectionStatusProvider
implements IConnectionStatusProvider {
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private final ILogger logger;
    private final Map<IConnectionStatusProvider.IConnectionStatusObserver, ConnectivityManager.NetworkCallback> registeredCallbacks;

    public AndroidConnectionStatusProvider(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        this.context = context;
        this.logger = iLogger;
        this.buildInfoProvider = buildInfoProvider;
        this.registeredCallbacks = new HashMap();
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static IConnectionStatusProvider.ConnectionStatus getConnectionStatus(Context object, ConnectivityManager connectivityManager, ILogger iLogger) {
        void var2_7;
        if (!Permissions.hasPermission(object, "android.permission.ACCESS_NETWORK_STATE")) {
            var2_7.log(SentryLevel.INFO, "No permission (ACCESS_NETWORK_STATE) to check network status.", new Object[0]);
            return IConnectionStatusProvider.ConnectionStatus.NO_PERMISSION;
        }
        try {
            void var0_4;
            void var1_6;
            NetworkInfo networkInfo = var1_6.getActiveNetworkInfo();
            if (networkInfo == null) {
                var2_7.log(SentryLevel.INFO, "NetworkInfo is null, there's no active network.", new Object[0]);
                return IConnectionStatusProvider.ConnectionStatus.DISCONNECTED;
            }
            if (networkInfo.isConnected()) {
                IConnectionStatusProvider.ConnectionStatus connectionStatus = IConnectionStatusProvider.ConnectionStatus.CONNECTED;
                return var0_4;
            }
            IConnectionStatusProvider.ConnectionStatus connectionStatus = IConnectionStatusProvider.ConnectionStatus.DISCONNECTED;
            return var0_4;
        }
        catch (Throwable throwable) {
            var2_7.log(SentryLevel.WARNING, "Could not retrieve Connection Status", throwable);
            return IConnectionStatusProvider.ConnectionStatus.UNKNOWN;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String getConnectionType(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        boolean bl;
        boolean bl2;
        boolean bl3;
        block10: {
            block11: {
                block12: {
                    ConnectivityManager connectivityManager = AndroidConnectionStatusProvider.getConnectivityManager(context, iLogger);
                    if (connectivityManager == null) {
                        return null;
                    }
                    bl3 = Permissions.hasPermission(context, "android.permission.ACCESS_NETWORK_STATE");
                    bl2 = false;
                    bl = false;
                    if (!bl3) {
                        iLogger.log(SentryLevel.INFO, "No permission (ACCESS_NETWORK_STATE) to check network status.", new Object[0]);
                        return null;
                    }
                    try {
                        int n2 = buildInfoProvider.getSdkInfoVersion();
                        bl3 = true;
                        if (n2 >= 23) {
                            context = connectivityManager.getActiveNetwork();
                            if (context == null) {
                                iLogger.log(SentryLevel.INFO, "Network is null and cannot check network status", new Object[0]);
                                return null;
                            }
                            if ((context = connectivityManager.getNetworkCapabilities((Network)context)) == null) {
                                iLogger.log(SentryLevel.INFO, "NetworkCapabilities is null and cannot check network type", new Object[0]);
                                return null;
                            }
                            bl2 = context.hasTransport(3);
                            bl = context.hasTransport(1);
                            bl3 = context.hasTransport(0);
                            break block10;
                        }
                        context = connectivityManager.getActiveNetworkInfo();
                        if (context == null) {
                            iLogger.log(SentryLevel.INFO, "NetworkInfo is null, there's no active network.", new Object[0]);
                            return null;
                        }
                        n2 = context.getType();
                        if (n2 == 0) break block11;
                        if (n2 == 1) break block12;
                        if (n2 == 9) return "ethernet";
                        bl2 = bl;
                    }
                    catch (Throwable throwable) {
                        iLogger.log(SentryLevel.ERROR, "Failed to retrieve network info", throwable);
                        return null;
                    }
                    bl = false;
                    bl3 = false;
                    break block10;
                }
                bl = true;
                bl3 = false;
                break block10;
            }
            bl = false;
        }
        if (bl2) {
            return "ethernet";
        }
        if (bl) {
            return "wifi";
        }
        if (!bl3) return null;
        return "cellular";
    }

    public static String getConnectionType(NetworkCapabilities networkCapabilities, BuildInfoProvider buildInfoProvider) {
        if (buildInfoProvider.getSdkInfoVersion() < 21) {
            return null;
        }
        if (networkCapabilities.hasTransport(3)) {
            return "ethernet";
        }
        if (networkCapabilities.hasTransport(1)) {
            return "wifi";
        }
        if (networkCapabilities.hasTransport(0)) {
            return "cellular";
        }
        return null;
    }

    private static ConnectivityManager getConnectivityManager(Context context, ILogger iLogger) {
        if ((context = (ConnectivityManager)context.getSystemService("connectivity")) == null) {
            iLogger.log(SentryLevel.INFO, "ConnectivityManager is null and cannot check network status", new Object[0]);
        }
        return context;
    }

    public static boolean registerNetworkCallback(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider, ConnectivityManager.NetworkCallback networkCallback) {
        if (buildInfoProvider.getSdkInfoVersion() < 24) {
            iLogger.log(SentryLevel.DEBUG, "NetworkCallbacks need Android N+.", new Object[0]);
            return false;
        }
        buildInfoProvider = AndroidConnectionStatusProvider.getConnectivityManager(context, iLogger);
        if (buildInfoProvider == null) {
            return false;
        }
        if (!Permissions.hasPermission(context, "android.permission.ACCESS_NETWORK_STATE")) {
            iLogger.log(SentryLevel.INFO, "No permission (ACCESS_NETWORK_STATE) to check network status.", new Object[0]);
            return false;
        }
        try {
            buildInfoProvider.registerDefaultNetworkCallback(networkCallback);
            return true;
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.WARNING, "registerDefaultNetworkCallback failed", throwable);
            return false;
        }
    }

    public static void unregisterNetworkCallback(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider, ConnectivityManager.NetworkCallback networkCallback) {
        if (buildInfoProvider.getSdkInfoVersion() < 21) {
            return;
        }
        if ((context = AndroidConnectionStatusProvider.getConnectivityManager(context, iLogger)) == null) {
            return;
        }
        try {
            context.unregisterNetworkCallback(networkCallback);
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.WARNING, "unregisterNetworkCallback failed", throwable);
        }
    }

    @Override
    public boolean addConnectionStatusObserver(IConnectionStatusProvider.IConnectionStatusObserver iConnectionStatusObserver) {
        if (this.buildInfoProvider.getSdkInfoVersion() < 21) {
            this.logger.log(SentryLevel.DEBUG, "addConnectionStatusObserver requires Android 5+.", new Object[0]);
            return false;
        }
        ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback(this, iConnectionStatusObserver){
            final AndroidConnectionStatusProvider this$0;
            final IConnectionStatusProvider.IConnectionStatusObserver val$observer;
            {
                this.this$0 = androidConnectionStatusProvider;
                this.val$observer = iConnectionStatusObserver;
            }

            public void onAvailable(Network network) {
                this.val$observer.onConnectionStatusChanged(this.this$0.getConnectionStatus());
            }

            public void onLosing(Network network, int n2) {
                this.val$observer.onConnectionStatusChanged(this.this$0.getConnectionStatus());
            }

            public void onLost(Network network) {
                this.val$observer.onConnectionStatusChanged(this.this$0.getConnectionStatus());
            }

            public void onUnavailable() {
                this.val$observer.onConnectionStatusChanged(this.this$0.getConnectionStatus());
            }
        };
        this.registeredCallbacks.put((Object)iConnectionStatusObserver, (Object)networkCallback);
        return AndroidConnectionStatusProvider.registerNetworkCallback(this.context, this.logger, this.buildInfoProvider, networkCallback);
    }

    @Override
    public IConnectionStatusProvider.ConnectionStatus getConnectionStatus() {
        ConnectivityManager connectivityManager = AndroidConnectionStatusProvider.getConnectivityManager(this.context, this.logger);
        if (connectivityManager == null) {
            return IConnectionStatusProvider.ConnectionStatus.UNKNOWN;
        }
        return AndroidConnectionStatusProvider.getConnectionStatus(this.context, connectivityManager, this.logger);
    }

    @Override
    public String getConnectionType() {
        return AndroidConnectionStatusProvider.getConnectionType(this.context, this.logger, this.buildInfoProvider);
    }

    public Map<IConnectionStatusProvider.IConnectionStatusObserver, ConnectivityManager.NetworkCallback> getRegisteredCallbacks() {
        return this.registeredCallbacks;
    }

    @Override
    public void removeConnectionStatusObserver(IConnectionStatusProvider.IConnectionStatusObserver iConnectionStatusObserver) {
        if ((iConnectionStatusObserver = (ConnectivityManager.NetworkCallback)this.registeredCallbacks.remove((Object)iConnectionStatusObserver)) != null) {
            AndroidConnectionStatusProvider.unregisterNetworkCallback(this.context, this.logger, this.buildInfoProvider, (ConnectivityManager.NetworkCallback)iConnectionStatusObserver);
        }
    }
}

