/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 *  java.lang.Comparable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package io.sentry.android.core.performance;

import android.os.SystemClock;
import io.sentry.DateUtils;
import io.sentry.SentryDate;
import io.sentry.SentryLongDate;

public class TimeSpan
implements Comparable<TimeSpan> {
    private String description;
    private long startUnixTimeMs;
    private long startUptimeMs;
    private long stopUptimeMs;

    public int compareTo(TimeSpan timeSpan) {
        return Long.compare((long)this.startUnixTimeMs, (long)timeSpan.startUnixTimeMs);
    }

    public String getDescription() {
        return this.description;
    }

    public long getDurationMs() {
        if (this.hasStopped()) {
            return this.stopUptimeMs - this.startUptimeMs;
        }
        return 0L;
    }

    public SentryDate getProjectedStopTimestamp() {
        if (this.hasStopped()) {
            return new SentryLongDate(DateUtils.millisToNanos(this.getProjectedStopTimestampMs()));
        }
        return null;
    }

    public long getProjectedStopTimestampMs() {
        if (this.hasStarted()) {
            return this.startUnixTimeMs + this.getDurationMs();
        }
        return 0L;
    }

    public double getProjectedStopTimestampSecs() {
        return DateUtils.millisToSeconds(this.getProjectedStopTimestampMs());
    }

    public SentryDate getStartTimestamp() {
        if (this.hasStarted()) {
            return new SentryLongDate(DateUtils.millisToNanos(this.getStartTimestampMs()));
        }
        return null;
    }

    public long getStartTimestampMs() {
        return this.startUnixTimeMs;
    }

    public double getStartTimestampSecs() {
        return DateUtils.millisToSeconds(this.startUnixTimeMs);
    }

    public long getStartUptimeMs() {
        return this.startUptimeMs;
    }

    public boolean hasNotStarted() {
        boolean bl = this.startUptimeMs == 0L;
        return bl;
    }

    public boolean hasNotStopped() {
        boolean bl = this.stopUptimeMs == 0L;
        return bl;
    }

    public boolean hasStarted() {
        boolean bl = this.startUptimeMs != 0L;
        return bl;
    }

    public boolean hasStopped() {
        boolean bl = this.stopUptimeMs != 0L;
        return bl;
    }

    public void reset() {
        this.description = null;
        this.startUptimeMs = 0L;
        this.stopUptimeMs = 0L;
        this.startUnixTimeMs = 0L;
    }

    public void setDescription(String string2) {
        this.description = string2;
    }

    public void setStartUnixTimeMs(long l2) {
        this.startUnixTimeMs = l2;
    }

    public void setStartedAt(long l2) {
        this.startUptimeMs = l2;
        long l3 = SystemClock.uptimeMillis();
        l2 = this.startUptimeMs;
        this.startUnixTimeMs = System.currentTimeMillis() - (l3 - l2);
    }

    public void setStoppedAt(long l2) {
        this.stopUptimeMs = l2;
    }

    public void start() {
        this.startUptimeMs = SystemClock.uptimeMillis();
        this.startUnixTimeMs = System.currentTimeMillis();
    }

    public void stop() {
        this.stopUptimeMs = SystemClock.uptimeMillis();
    }
}

