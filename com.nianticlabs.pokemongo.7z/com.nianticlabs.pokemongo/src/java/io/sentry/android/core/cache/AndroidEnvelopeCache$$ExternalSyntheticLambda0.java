/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.core.cache;

import io.sentry.android.core.AnrV2Integration;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.cache.AndroidEnvelopeCache;
import io.sentry.util.HintUtils;

public final class AndroidEnvelopeCache$$ExternalSyntheticLambda0
implements HintUtils.SentryConsumer {
    public final AndroidEnvelopeCache f$0;
    public final SentryAndroidOptions f$1;

    public /* synthetic */ AndroidEnvelopeCache$$ExternalSyntheticLambda0(AndroidEnvelopeCache androidEnvelopeCache, SentryAndroidOptions sentryAndroidOptions) {
        this.f$0 = androidEnvelopeCache;
        this.f$1 = sentryAndroidOptions;
    }

    public final void accept(Object object) {
        this.f$0.lambda$store$0$io-sentry-android-core-cache-AndroidEnvelopeCache(this.f$1, (AnrV2Integration.AnrV2Hint)object);
    }
}

