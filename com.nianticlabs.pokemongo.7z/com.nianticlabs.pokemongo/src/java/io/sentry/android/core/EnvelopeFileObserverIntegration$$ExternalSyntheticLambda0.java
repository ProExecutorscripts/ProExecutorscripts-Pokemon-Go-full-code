/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.SentryOptions;
import io.sentry.android.core.EnvelopeFileObserverIntegration;

public final class EnvelopeFileObserverIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final EnvelopeFileObserverIntegration f$0;
    public final IHub f$1;
    public final SentryOptions f$2;
    public final String f$3;

    public /* synthetic */ EnvelopeFileObserverIntegration$$ExternalSyntheticLambda0(EnvelopeFileObserverIntegration envelopeFileObserverIntegration, IHub iHub, SentryOptions sentryOptions, String string2) {
        this.f$0 = envelopeFileObserverIntegration;
        this.f$1 = iHub;
        this.f$2 = sentryOptions;
        this.f$3 = string2;
    }

    public final void run() {
        this.f$0.lambda$register$0$io-sentry-android-core-EnvelopeFileObserverIntegration(this.f$1, this.f$2, this.f$3);
    }
}

