/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.MotionEvent
 *  android.view.View
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.Collections
 *  java.util.Map
 */
package io.sentry.android.core.internal.gestures;

import android.app.Activity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.SentryLevel;
import io.sentry.SpanOptions;
import io.sentry.SpanStatus;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.gestures.SentryGestureListener$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.gestures.SentryGestureListener$$ExternalSyntheticLambda1;
import io.sentry.android.core.internal.gestures.SentryGestureListener$$ExternalSyntheticLambda2;
import io.sentry.android.core.internal.gestures.SentryGestureListener$$ExternalSyntheticLambda3;
import io.sentry.android.core.internal.gestures.ViewUtils;
import io.sentry.internal.gestures.UiElement;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.util.TracingUtils;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryGestureListener
implements GestureDetector.OnGestureListener {
    private static final String TRACE_ORIGIN = "auto.ui.gesture_listener";
    static final String UI_ACTION = "ui.action";
    private GestureType activeEventType = GestureType.Unknown;
    private ITransaction activeTransaction = null;
    private UiElement activeUiElement = null;
    private final WeakReference<Activity> activityRef;
    private final IHub hub;
    private final SentryAndroidOptions options;
    private final ScrollState scrollState = new ScrollState();

    public SentryGestureListener(Activity activity2, IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        this.activityRef = new WeakReference((Object)activity2);
        this.hub = iHub;
        this.options = sentryAndroidOptions;
    }

    private void addBreadcrumb(UiElement uiElement, GestureType object, Map<String, Object> map2, MotionEvent motionEvent) {
        if (!this.options.isEnableUserInteractionBreadcrumbs()) {
            return;
        }
        object = SentryGestureListener.getGestureType(object);
        Hint hint = new Hint();
        hint.set("android:motionEvent", motionEvent);
        hint.set("android:view", uiElement.getView());
        this.hub.addBreadcrumb(Breadcrumb.userInteraction((String)object, uiElement.getResourceName(), uiElement.getClassName(), uiElement.getTag(), map2), hint);
    }

    private View ensureWindowDecorView(String string2) {
        Activity activity2 = (Activity)this.activityRef.get();
        if (activity2 == null) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Activity is null in " + string2 + ". No breadcrumb captured.", new Object[0]);
            return null;
        }
        if ((activity2 = activity2.getWindow()) == null) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Window is null in " + string2 + ". No breadcrumb captured.", new Object[0]);
            return null;
        }
        if ((activity2 = activity2.getDecorView()) == null) {
            this.options.getLogger().log(SentryLevel.DEBUG, "DecorView is null in " + string2 + ". No breadcrumb captured.", new Object[0]);
            return null;
        }
        return activity2;
    }

    private String getActivityName(Activity activity2) {
        return activity2.getClass().getSimpleName();
    }

    private static String getGestureType(GestureType object) {
        int n2 = 1.$SwitchMap$io$sentry$android$core$internal$gestures$SentryGestureListener$GestureType[object.ordinal()];
        object = n2 != 1 ? (n2 != 2 ? (n2 != 3 ? "unknown" : "swipe") : "scroll") : "click";
        return object;
    }

    private void startTracing(UiElement uiElement, GestureType gestureType) {
        boolean bl = gestureType == this.activeEventType && uiElement.equals(this.activeUiElement);
        boolean bl2 = gestureType == GestureType.Click;
        bl = bl2 || !bl;
        if (this.options.isTracingEnabled() && this.options.isEnableUserInteractionTracing()) {
            Object object = (Activity)this.activityRef.get();
            if (object == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Activity is null, no transaction captured.", new Object[0]);
                return;
            }
            Object object2 = uiElement.getIdentifier();
            Object object3 = this.activeTransaction;
            if (object3 != null) {
                if (!bl && !object3.isFinished()) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "The view with id: " + (String)object2 + " already has an ongoing transaction assigned. Rescheduling finish", new Object[0]);
                    if (this.options.getIdleTimeout() != null) {
                        this.activeTransaction.scheduleFinish();
                    }
                    return;
                }
                this.stopTracing(SpanStatus.OK);
            }
            object2 = this.getActivityName((Activity)object) + "." + (String)object2;
            object = "ui.action." + SentryGestureListener.getGestureType(gestureType);
            object3 = new TransactionOptions();
            ((TransactionOptions)object3).setWaitForChildren(true);
            ((TransactionOptions)object3).setDeadlineTimeout(30000L);
            ((TransactionOptions)object3).setIdleTimeout(this.options.getIdleTimeout());
            ((SpanOptions)object3).setTrimEnd(true);
            object2 = this.hub.startTransaction(new TransactionContext((String)object2, TransactionNameSource.COMPONENT, (String)object), (TransactionOptions)object3);
            object2.getSpanContext().setOrigin("auto.ui.gesture_listener." + uiElement.getOrigin());
            this.hub.configureScope(new SentryGestureListener$$ExternalSyntheticLambda2(this, (ITransaction)object2));
            this.activeTransaction = object2;
            this.activeUiElement = uiElement;
            this.activeEventType = gestureType;
            return;
        }
        if (bl) {
            TracingUtils.startNewTrace(this.hub);
            this.activeUiElement = uiElement;
            this.activeEventType = gestureType;
        }
    }

    void applyScope(IScope iScope, ITransaction iTransaction) {
        iScope.withTransaction(new SentryGestureListener$$ExternalSyntheticLambda0(this, iScope, iTransaction));
    }

    void clearScope(IScope iScope) {
        iScope.withTransaction(new SentryGestureListener$$ExternalSyntheticLambda3(this, iScope));
    }

    /* synthetic */ void lambda$applyScope$3$io-sentry-android-core-internal-gestures-SentryGestureListener(IScope iScope, ITransaction iTransaction, ITransaction iTransaction2) {
        if (iTransaction2 == null) {
            iScope.setTransaction(iTransaction);
        } else {
            this.options.getLogger().log(SentryLevel.DEBUG, "Transaction '%s' won't be bound to the Scope since there's one already in there.", iTransaction.getName());
        }
    }

    /* synthetic */ void lambda$clearScope$2$io-sentry-android-core-internal-gestures-SentryGestureListener(IScope iScope, ITransaction iTransaction) {
        if (iTransaction == this.activeTransaction) {
            iScope.clearTransaction();
        }
    }

    /* synthetic */ void lambda$startTracing$0$io-sentry-android-core-internal-gestures-SentryGestureListener(ITransaction iTransaction, IScope iScope) {
        this.applyScope(iScope, iTransaction);
    }

    /* synthetic */ void lambda$stopTracing$1$io-sentry-android-core-internal-gestures-SentryGestureListener(IScope iScope) {
        this.clearScope(iScope);
    }

    public boolean onDown(MotionEvent motionEvent) {
        if (motionEvent == null) {
            return false;
        }
        this.scrollState.reset();
        ScrollState.access$502(this.scrollState, motionEvent.getX());
        ScrollState.access$602(this.scrollState, motionEvent.getY());
        return false;
    }

    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
        ScrollState.access$202(this.scrollState, GestureType.Swipe);
        return false;
    }

    public void onLongPress(MotionEvent motionEvent) {
    }

    public boolean onScroll(MotionEvent object, MotionEvent motionEvent, float f2, float f3) {
        motionEvent = this.ensureWindowDecorView("onScroll");
        if (motionEvent != null && object != null && this.scrollState.type == GestureType.Unknown) {
            if ((object = ViewUtils.findTarget(this.options, (View)motionEvent, object.getX(), object.getY(), UiElement.Type.SCROLLABLE)) == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Unable to find scroll target. No breadcrumb captured.", new Object[0]);
                return false;
            }
            this.options.getLogger().log(SentryLevel.DEBUG, "Scroll target found: " + ((UiElement)object).getIdentifier(), new Object[0]);
            this.scrollState.setTarget((UiElement)object);
            ScrollState.access$202(this.scrollState, GestureType.Scroll);
        }
        return false;
    }

    public void onShowPress(MotionEvent motionEvent) {
    }

    public boolean onSingleTapUp(MotionEvent motionEvent) {
        Object object = this.ensureWindowDecorView("onSingleTapUp");
        if (object != null && motionEvent != null) {
            if ((object = ViewUtils.findTarget(this.options, object, motionEvent.getX(), motionEvent.getY(), UiElement.Type.CLICKABLE)) == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Unable to find click target. No breadcrumb captured.", new Object[0]);
                return false;
            }
            this.addBreadcrumb((UiElement)object, GestureType.Click, (Map<String, Object>)Collections.emptyMap(), motionEvent);
            this.startTracing((UiElement)object, GestureType.Click);
        }
        return false;
    }

    public void onUp(MotionEvent motionEvent) {
        Object object = this.ensureWindowDecorView("onUp");
        UiElement uiElement = this.scrollState.target;
        if (object != null && uiElement != null) {
            if (this.scrollState.type == GestureType.Unknown) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Unable to define scroll type. No breadcrumb captured.", new Object[0]);
                return;
            }
            object = this.scrollState.calculateDirection(motionEvent);
            this.addBreadcrumb(uiElement, this.scrollState.type, (Map<String, Object>)Collections.singletonMap((Object)"direction", (Object)object), motionEvent);
            this.startTracing(uiElement, this.scrollState.type);
            this.scrollState.reset();
        }
    }

    void stopTracing(SpanStatus spanStatus) {
        ITransaction iTransaction = this.activeTransaction;
        if (iTransaction != null) {
            if (iTransaction.getStatus() == null) {
                this.activeTransaction.finish(spanStatus);
            } else {
                this.activeTransaction.finish();
            }
        }
        this.hub.configureScope(new SentryGestureListener$$ExternalSyntheticLambda1(this));
        this.activeTransaction = null;
        if (this.activeUiElement != null) {
            this.activeUiElement = null;
        }
        this.activeEventType = GestureType.Unknown;
    }

    private static enum GestureType {
        Click,
        Scroll,
        Swipe,
        Unknown;

    }

    private static final class ScrollState {
        private float startX = 0.0f;
        private float startY = 0.0f;
        private UiElement target;
        private GestureType type = GestureType.Unknown;

        private ScrollState() {
        }

        static /* synthetic */ GestureType access$202(ScrollState scrollState, GestureType gestureType) {
            scrollState.type = gestureType;
            return gestureType;
        }

        static /* synthetic */ float access$502(ScrollState scrollState, float f2) {
            scrollState.startX = f2;
            return f2;
        }

        static /* synthetic */ float access$602(ScrollState scrollState, float f2) {
            scrollState.startY = f2;
            return f2;
        }

        private String calculateDirection(MotionEvent object) {
            float f2 = object.getX() - this.startX;
            float f3 = object.getY() - this.startY;
            object = Math.abs((float)f2) > Math.abs((float)f3) ? (f2 > 0.0f ? "right" : "left") : (f3 > 0.0f ? "down" : "up");
            return object;
        }

        private void reset() {
            this.target = null;
            this.type = GestureType.Unknown;
            this.startX = 0.0f;
            this.startY = 0.0f;
        }

        private void setTarget(UiElement uiElement) {
            this.target = uiElement;
        }
    }
}

