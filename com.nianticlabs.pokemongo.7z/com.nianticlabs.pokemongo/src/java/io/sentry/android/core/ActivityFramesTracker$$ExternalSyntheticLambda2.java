/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.android.core.ActivityFramesTracker;

public final class ActivityFramesTracker$$ExternalSyntheticLambda2
implements Runnable {
    public final ActivityFramesTracker f$0;

    public /* synthetic */ ActivityFramesTracker$$ExternalSyntheticLambda2(ActivityFramesTracker activityFramesTracker) {
        this.f$0 = activityFramesTracker;
    }

    public final void run() {
        this.f$0.lambda$stop$2$io-sentry-android-core-ActivityFramesTracker();
    }
}

