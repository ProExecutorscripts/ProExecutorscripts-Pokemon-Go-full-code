/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.android.core.ANRWatchDog;
import io.sentry.transport.ICurrentDateProvider;

public final class ANRWatchDog$$ExternalSyntheticLambda1
implements ICurrentDateProvider {
    @Override
    public final long getCurrentTimeMillis() {
        return ANRWatchDog.lambda$new$0();
    }
}

