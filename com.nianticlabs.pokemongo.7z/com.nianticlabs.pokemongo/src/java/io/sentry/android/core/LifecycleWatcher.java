/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.DefaultLifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Timer
 *  java.util.TimerTask
 *  java.util.concurrent.atomic.AtomicLong
 */
package io.sentry.android.core;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import io.sentry.Breadcrumb;
import io.sentry.IHub;
import io.sentry.IScope;
import io.sentry.SentryLevel;
import io.sentry.Session;
import io.sentry.android.core.AppState;
import io.sentry.android.core.LifecycleWatcher$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.BreadcrumbFactory;
import io.sentry.transport.CurrentDateProvider;
import io.sentry.transport.ICurrentDateProvider;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicLong;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class LifecycleWatcher
implements DefaultLifecycleObserver {
    private final ICurrentDateProvider currentDateProvider;
    private final boolean enableAppLifecycleBreadcrumbs;
    private final boolean enableSessionTracking;
    private final IHub hub;
    private final AtomicLong lastUpdatedSession = new AtomicLong(0L);
    private final long sessionIntervalMillis;
    private final Timer timer;
    private final Object timerLock = new Object();
    private TimerTask timerTask;

    LifecycleWatcher(IHub iHub, long l2, boolean bl, boolean bl2) {
        this(iHub, l2, bl, bl2, CurrentDateProvider.getInstance());
    }

    LifecycleWatcher(IHub iHub, long l2, boolean bl, boolean bl2, ICurrentDateProvider iCurrentDateProvider) {
        this.sessionIntervalMillis = l2;
        this.enableSessionTracking = bl;
        this.enableAppLifecycleBreadcrumbs = bl2;
        this.hub = iHub;
        this.currentDateProvider = iCurrentDateProvider;
        this.timer = bl ? new Timer(true) : null;
    }

    private void addAppBreadcrumb(String string2) {
        if (this.enableAppLifecycleBreadcrumbs) {
            Breadcrumb breadcrumb = new Breadcrumb();
            breadcrumb.setType("navigation");
            breadcrumb.setData("state", string2);
            breadcrumb.setCategory("app.lifecycle");
            breadcrumb.setLevel(SentryLevel.INFO);
            this.hub.addBreadcrumb(breadcrumb);
        }
    }

    private void addSessionBreadcrumb(String object) {
        object = BreadcrumbFactory.forSession((String)object);
        this.hub.addBreadcrumb((Breadcrumb)object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void cancelTask() {
        Object object;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            TimerTask timerTask = this.timerTask;
            if (timerTask != null) {
                timerTask.cancel();
                this.timerTask = null;
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void scheduleEndSession() {
        Object object;
        Object object2 = object = this.timerLock;
        synchronized (object2) {
            this.cancelTask();
            if (this.timer != null) {
                TimerTask timerTask;
                this.timerTask = timerTask = new TimerTask(this){
                    final LifecycleWatcher this$0;
                    {
                        this.this$0 = lifecycleWatcher;
                    }

                    public void run() {
                        this.this$0.addSessionBreadcrumb("end");
                        this.this$0.hub.endSession();
                    }
                };
                this.timer.schedule(timerTask, this.sessionIntervalMillis);
            }
            return;
        }
    }

    private void startSession() {
        if (this.enableSessionTracking) {
            this.cancelTask();
            long l2 = this.currentDateProvider.getCurrentTimeMillis();
            this.hub.configureScope(new LifecycleWatcher$$ExternalSyntheticLambda0(this));
            long l3 = this.lastUpdatedSession.get();
            if (l3 == 0L || l3 + this.sessionIntervalMillis <= l2) {
                this.addSessionBreadcrumb("start");
                this.hub.startSession();
            }
            this.lastUpdatedSession.set(l2);
        }
    }

    Timer getTimer() {
        return this.timer;
    }

    TimerTask getTimerTask() {
        return this.timerTask;
    }

    /* synthetic */ void lambda$startSession$0$io-sentry-android-core-LifecycleWatcher(IScope object) {
        if (this.lastUpdatedSession.get() == 0L && (object = object.getSession()) != null && ((Session)object).getStarted() != null) {
            this.lastUpdatedSession.set(((Session)object).getStarted().getTime());
        }
    }

    public void onStart(LifecycleOwner lifecycleOwner) {
        this.startSession();
        this.addAppBreadcrumb("foreground");
        AppState.getInstance().setInBackground(false);
    }

    public void onStop(LifecycleOwner lifecycleOwner) {
        if (this.enableSessionTracking) {
            long l2 = this.currentDateProvider.getCurrentTimeMillis();
            this.lastUpdatedSession.set(l2);
            this.scheduleEndSession();
        }
        AppState.getInstance().setInBackground(true);
        this.addAppBreadcrumb("background");
    }
}

