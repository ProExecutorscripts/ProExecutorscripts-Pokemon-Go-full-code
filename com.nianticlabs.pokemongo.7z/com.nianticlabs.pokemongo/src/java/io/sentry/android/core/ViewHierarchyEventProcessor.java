/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.Window
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import io.sentry.Attachment;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.ILogger;
import io.sentry.ISerializer;
import io.sentry.JsonSerializable;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.android.core.CurrentActivityHolder;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.ViewHierarchyEventProcessor$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.gestures.ViewUtils;
import io.sentry.android.core.internal.util.AndroidCurrentDateProvider;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.android.core.internal.util.ClassUtil;
import io.sentry.android.core.internal.util.Debouncer;
import io.sentry.internal.viewhierarchy.ViewHierarchyExporter;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.ViewHierarchy;
import io.sentry.protocol.ViewHierarchyNode;
import io.sentry.util.HintUtils;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.JsonSerializationUtils;
import io.sentry.util.Objects;
import io.sentry.util.thread.IMainThreadChecker;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public final class ViewHierarchyEventProcessor
implements EventProcessor {
    private static final long CAPTURE_TIMEOUT_MS = 1000L;
    private static final int DEBOUNCE_MAX_EXECUTIONS = 3;
    private static final long DEBOUNCE_WAIT_TIME_MS = 2000L;
    private final Debouncer debouncer;
    private final SentryAndroidOptions options;

    public ViewHierarchyEventProcessor(SentryAndroidOptions sentryAndroidOptions) {
        this.options = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.debouncer = new Debouncer(AndroidCurrentDateProvider.getInstance(), 2000L, 3);
        if (sentryAndroidOptions.isAttachViewHierarchy()) {
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }

    private static void addChildren(View view2, ViewHierarchyNode viewHierarchyNode, List<ViewHierarchyExporter> list) {
        if (!(view2 instanceof ViewGroup)) {
            return;
        }
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            if (!((ViewHierarchyExporter)iterator.next()).export(viewHierarchyNode, view2)) continue;
            return;
        }
        int n2 = (view2 = (ViewGroup)view2).getChildCount();
        if (n2 == 0) {
            return;
        }
        ArrayList arrayList = new ArrayList(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            iterator = view2.getChildAt(i2);
            if (iterator == null) continue;
            ViewHierarchyNode viewHierarchyNode2 = ViewHierarchyEventProcessor.viewToNode((View)iterator);
            arrayList.add((Object)viewHierarchyNode2);
            ViewHierarchyEventProcessor.addChildren((View)iterator, viewHierarchyNode2, list);
        }
        viewHierarchyNode.setChildren((List<ViewHierarchyNode>)arrayList);
    }

    static /* synthetic */ void lambda$snapshotViewHierarchy$0(AtomicReference atomicReference, View view2, List list, CountDownLatch countDownLatch, ILogger iLogger) {
        try {
            atomicReference.set((Object)ViewHierarchyEventProcessor.snapshotViewHierarchy(view2, (List<ViewHierarchyExporter>)list));
            countDownLatch.countDown();
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Failed to process view hierarchy.", throwable);
        }
    }

    public static ViewHierarchy snapshotViewHierarchy(Activity activity2, ILogger iLogger) {
        return ViewHierarchyEventProcessor.snapshotViewHierarchy(activity2, (List<ViewHierarchyExporter>)new ArrayList(0), AndroidMainThreadChecker.getInstance(), iLogger);
    }

    public static ViewHierarchy snapshotViewHierarchy(Activity object, List<ViewHierarchyExporter> list, IMainThreadChecker object2, ILogger iLogger) {
        if (object == null) {
            iLogger.log(SentryLevel.INFO, "Missing activity for view hierarchy snapshot.", new Object[0]);
            return null;
        }
        Window window = object.getWindow();
        if (window == null) {
            iLogger.log(SentryLevel.INFO, "Missing window for view hierarchy snapshot.", new Object[0]);
            return null;
        }
        if ((window = window.peekDecorView()) == null) {
            iLogger.log(SentryLevel.INFO, "Missing decor view for view hierarchy snapshot.", new Object[0]);
            return null;
        }
        try {
            if (object2.isMainThread()) {
                return ViewHierarchyEventProcessor.snapshotViewHierarchy((View)window, list);
            }
            CountDownLatch countDownLatch = new CountDownLatch(1);
            AtomicReference atomicReference = new AtomicReference(null);
            object2 = new ViewHierarchyEventProcessor$$ExternalSyntheticLambda0(atomicReference, (View)window, list, countDownLatch, iLogger);
            object.runOnUiThread((Runnable)object2);
            if (countDownLatch.await(1000L, TimeUnit.MILLISECONDS)) {
                object = (ViewHierarchy)atomicReference.get();
                return object;
            }
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Failed to process view hierarchy.", throwable);
        }
        return null;
    }

    public static ViewHierarchy snapshotViewHierarchy(View view2) {
        return ViewHierarchyEventProcessor.snapshotViewHierarchy(view2, (List<ViewHierarchyExporter>)new ArrayList(0));
    }

    public static ViewHierarchy snapshotViewHierarchy(View view2, List<ViewHierarchyExporter> list) {
        ArrayList arrayList = new ArrayList(1);
        ViewHierarchy viewHierarchy = new ViewHierarchy("android_view_system", (List<ViewHierarchyNode>)arrayList);
        ViewHierarchyNode viewHierarchyNode = ViewHierarchyEventProcessor.viewToNode(view2);
        arrayList.add((Object)viewHierarchyNode);
        ViewHierarchyEventProcessor.addChildren(view2, viewHierarchyNode, list);
        return viewHierarchy;
    }

    public static byte[] snapshotViewHierarchyAsData(Activity object, IMainThreadChecker iMainThreadChecker, ISerializer iSerializer, ILogger iLogger) {
        if ((object = ViewHierarchyEventProcessor.snapshotViewHierarchy(object, (List<ViewHierarchyExporter>)new ArrayList(0), iMainThreadChecker, iLogger)) == null) {
            iLogger.log(SentryLevel.ERROR, "Could not get ViewHierarchy.", new Object[0]);
            return null;
        }
        if ((object = (Object)JsonSerializationUtils.bytesFrom(iSerializer, iLogger, (JsonSerializable)object)) == null) {
            iLogger.log(SentryLevel.ERROR, "Could not serialize ViewHierarchy.", new Object[0]);
            return null;
        }
        if (((Activity)object).length < 1) {
            iLogger.log(SentryLevel.ERROR, "Got empty bytes array after serializing ViewHierarchy.", new Object[0]);
            return null;
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static ViewHierarchyNode viewToNode(View view2) {
        ViewHierarchyNode viewHierarchyNode = new ViewHierarchyNode();
        viewHierarchyNode.setType(ClassUtil.getClassName(view2));
        try {
            viewHierarchyNode.setIdentifier(ViewUtils.getResourceId(view2));
        }
        catch (Throwable throwable) {}
        viewHierarchyNode.setX((double)view2.getX());
        viewHierarchyNode.setY((double)view2.getY());
        viewHierarchyNode.setWidth((double)view2.getWidth());
        viewHierarchyNode.setHeight((double)view2.getHeight());
        viewHierarchyNode.setAlpha((double)view2.getAlpha());
        int n2 = view2.getVisibility();
        if (n2 == 0) {
            viewHierarchyNode.setVisibility("visible");
            return viewHierarchyNode;
        }
        if (n2 == 4) {
            viewHierarchyNode.setVisibility("invisible");
            return viewHierarchyNode;
        }
        if (n2 != 8) {
            return viewHierarchyNode;
        }
        viewHierarchyNode.setVisibility("gone");
        return viewHierarchyNode;
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        if (!sentryEvent.isErrored()) {
            return sentryEvent;
        }
        if (!this.options.isAttachViewHierarchy()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "attachViewHierarchy is disabled.", new Object[0]);
            return sentryEvent;
        }
        if (HintUtils.isFromHybridSdk(hint)) {
            return sentryEvent;
        }
        boolean bl = this.debouncer.checkForDebounce();
        Object object = this.options.getBeforeViewHierarchyCaptureCallback();
        if (object != null ? !object.execute(sentryEvent, hint, bl) : bl) {
            return sentryEvent;
        }
        object = ViewHierarchyEventProcessor.snapshotViewHierarchy(CurrentActivityHolder.getInstance().getActivity(), this.options.getViewHierarchyExporters(), this.options.getMainThreadChecker(), this.options.getLogger());
        if (object != null) {
            hint.setViewHierarchy(Attachment.fromViewHierarchy((ViewHierarchy)object));
        }
        return sentryEvent;
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        return sentryTransaction;
    }
}

