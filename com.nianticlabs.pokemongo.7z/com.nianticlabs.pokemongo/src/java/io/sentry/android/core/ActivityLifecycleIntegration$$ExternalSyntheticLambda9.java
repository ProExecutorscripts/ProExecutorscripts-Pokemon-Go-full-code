/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.Scope;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda9
implements Scope.IWithTransaction {
    public final ActivityLifecycleIntegration f$0;
    public final IScope f$1;
    public final ITransaction f$2;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda9(ActivityLifecycleIntegration activityLifecycleIntegration, IScope iScope, ITransaction iTransaction) {
        this.f$0 = activityLifecycleIntegration;
        this.f$1 = iScope;
        this.f$2 = iTransaction;
    }

    @Override
    public final void accept(ITransaction iTransaction) {
        this.f$0.lambda$applyScope$3$io-sentry-android-core-ActivityLifecycleIntegration(this.f$1, this.f$2, iTransaction);
    }
}

