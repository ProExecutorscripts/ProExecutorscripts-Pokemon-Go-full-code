/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core.cache;

import io.sentry.Hint;
import io.sentry.SentryEnvelope;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.UncaughtExceptionHandlerIntegration;
import io.sentry.android.core.AnrV2Integration;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.cache.AndroidEnvelopeCache$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.AndroidCurrentDateProvider;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.cache.EnvelopeCache;
import io.sentry.transport.ICurrentDateProvider;
import io.sentry.util.FileUtils;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import java.io.File;
import java.io.FileOutputStream;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class AndroidEnvelopeCache
extends EnvelopeCache {
    public static final String LAST_ANR_REPORT = "last_anr_report";
    private final ICurrentDateProvider currentDateProvider;

    public AndroidEnvelopeCache(SentryAndroidOptions sentryAndroidOptions) {
        this(sentryAndroidOptions, AndroidCurrentDateProvider.getInstance());
    }

    AndroidEnvelopeCache(SentryAndroidOptions sentryAndroidOptions, ICurrentDateProvider iCurrentDateProvider) {
        super(sentryAndroidOptions, Objects.requireNonNull(sentryAndroidOptions.getCacheDirPath(), "cacheDirPath must not be null"), sentryAndroidOptions.getMaxCacheItems());
        this.currentDateProvider = iCurrentDateProvider;
    }

    public static boolean hasStartupCrashMarker(SentryOptions sentryOptions) {
        boolean bl;
        block4: {
            String string2 = sentryOptions.getOutboxPath();
            if (string2 == null) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "Outbox path is null, the startup crash marker file does not exist", new Object[0]);
                return false;
            }
            string2 = new File(string2, "startup_crash");
            try {
                bl = string2.exists();
                if (!bl) break block4;
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.ERROR, "Error reading/deleting the startup crash marker file on the disk", throwable);
                return false;
            }
            if (string2.delete()) break block4;
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to delete the startup crash marker file. %s.", string2.getAbsolutePath());
        }
        return bl;
    }

    public static Long lastReportedAnr(SentryOptions sentryOptions) {
        Object object;
        block4: {
            block6: {
                Long l2;
                block5: {
                    object = new File(Objects.requireNonNull(sentryOptions.getCacheDirPath(), "Cache dir path should be set for getting ANRs reported"), LAST_ANR_REPORT);
                    l2 = null;
                    if (!object.exists() || !object.canRead()) break block4;
                    if (!(object = FileUtils.readText(object)).equals((Object)"null")) break block5;
                    sentryOptions = l2;
                    break block6;
                }
                l2 = Long.parseLong((String)object.trim());
                sentryOptions = l2;
            }
            return sentryOptions;
        }
        try {
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "Last ANR marker does not exist. %s.", object.getAbsolutePath());
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Error reading last ANR marker", throwable);
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void writeLastReportedAnrMarker(Long l2) {
        String string2 = this.options.getCacheDirPath();
        if (string2 == null) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Cache dir path is null, the ANR marker will not be written", new Object[0]);
            return;
        }
        File file = new File(string2, LAST_ANR_REPORT);
        string2 = new FileOutputStream(file);
        string2.write(String.valueOf((Object)l2).getBytes(UTF_8));
        string2.flush();
        string2.close();
        return;
        catch (Throwable throwable) {
            try {
                string2.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Error writing the ANR marker to the disk", throwable3);
                }
            }
        }
    }

    private void writeStartupCrashMarkerFile() {
        String string2 = this.options.getOutboxPath();
        if (string2 == null) {
            this.options.getLogger().log(SentryLevel.DEBUG, "Outbox path is null, the startup crash marker file will not be written", new Object[0]);
            return;
        }
        string2 = new File(string2, "startup_crash");
        try {
            string2.createNewFile();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error writing the startup crash marker file to the disk", throwable);
        }
    }

    public File getDirectory() {
        return this.directory;
    }

    /* synthetic */ void lambda$store$0$io-sentry-android-core-cache-AndroidEnvelopeCache(SentryAndroidOptions sentryAndroidOptions, AnrV2Integration.AnrV2Hint anrV2Hint) {
        anrV2Hint = anrV2Hint.timestamp();
        sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "Writing last reported ANR marker with timestamp %d", anrV2Hint);
        this.writeLastReportedAnrMarker((Long)anrV2Hint);
    }

    @Override
    public void store(SentryEnvelope object, Hint hint) {
        long l2;
        super.store((SentryEnvelope)object, hint);
        object = (SentryAndroidOptions)this.options;
        TimeSpan timeSpan = AppStartMetrics.getInstance().getSdkInitTimeSpan();
        if (HintUtils.hasType(hint, UncaughtExceptionHandlerIntegration.UncaughtExceptionHint.class) && timeSpan.hasStarted() && (l2 = this.currentDateProvider.getCurrentTimeMillis() - timeSpan.getStartTimestampMs()) <= ((SentryAndroidOptions)object).getStartupCrashDurationThresholdMillis()) {
            ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "Startup Crash detected %d milliseconds after SDK init. Writing a startup crash marker file to disk.", l2);
            this.writeStartupCrashMarkerFile();
        }
        HintUtils.runIfHasType(hint, AnrV2Integration.AnrV2Hint.class, new AndroidEnvelopeCache$$ExternalSyntheticLambda0(this, (SentryAndroidOptions)object));
    }
}

