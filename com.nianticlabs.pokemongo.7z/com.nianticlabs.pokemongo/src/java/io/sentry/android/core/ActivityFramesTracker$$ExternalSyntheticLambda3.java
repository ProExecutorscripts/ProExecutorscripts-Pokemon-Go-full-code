/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package io.sentry.android.core;

import io.sentry.android.core.ActivityFramesTracker;

public final class ActivityFramesTracker$$ExternalSyntheticLambda3
implements Runnable {
    public final ActivityFramesTracker f$0;
    public final Runnable f$1;
    public final String f$2;

    public /* synthetic */ ActivityFramesTracker$$ExternalSyntheticLambda3(ActivityFramesTracker activityFramesTracker, Runnable runnable, String string2) {
        this.f$0 = activityFramesTracker;
        this.f$1 = runnable;
        this.f$2 = string2;
    }

    public final void run() {
        this.f$0.lambda$runSafelyOnUiThread$3$io-sentry-android-core-ActivityFramesTracker(this.f$1, this.f$2);
    }
}

