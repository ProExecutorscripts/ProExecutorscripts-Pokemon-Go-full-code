/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$MemoryInfo
 *  android.content.Context
 *  android.os.Build
 *  android.os.Process
 *  android.os.SystemClock
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import io.sentry.HubAdapter;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.ITransaction;
import io.sentry.ITransactionProfiler;
import io.sentry.PerformanceCollectionData;
import io.sentry.ProfilingTraceData;
import io.sentry.ProfilingTransactionData;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.AndroidProfiler;
import io.sentry.android.core.AndroidTransactionProfiler$$ExternalSyntheticLambda0;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.CpuInfoUtils;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import io.sentry.util.Objects;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

final class AndroidTransactionProfiler
implements ITransactionProfiler {
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private ProfilingTransactionData currentProfilingTransactionData;
    private final ISentryExecutorService executorService;
    private final SentryFrameMetricsCollector frameMetricsCollector;
    private boolean isInitialized = false;
    private final boolean isProfilingEnabled;
    private final ILogger logger;
    private long profileStartCpuMillis;
    private long profileStartNanos;
    private AndroidProfiler profiler = null;
    private final String profilingTracesDirPath;
    private final int profilingTracesHz;
    private int transactionsCounter = 0;

    public AndroidTransactionProfiler(Context context, BuildInfoProvider buildInfoProvider, SentryFrameMetricsCollector sentryFrameMetricsCollector, ILogger iLogger, String string2, boolean bl, int n2, ISentryExecutorService iSentryExecutorService) {
        this.context = Objects.requireNonNull(context, "The application context is required");
        this.logger = Objects.requireNonNull(iLogger, "ILogger is required");
        this.frameMetricsCollector = Objects.requireNonNull(sentryFrameMetricsCollector, "SentryFrameMetricsCollector is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "The BuildInfoProvider is required.");
        this.profilingTracesDirPath = string2;
        this.isProfilingEnabled = bl;
        this.profilingTracesHz = n2;
        this.executorService = Objects.requireNonNull(iSentryExecutorService, "The ISentryExecutorService is required.");
    }

    public AndroidTransactionProfiler(Context context, SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider buildInfoProvider, SentryFrameMetricsCollector sentryFrameMetricsCollector) {
        this(context, buildInfoProvider, sentryFrameMetricsCollector, sentryAndroidOptions.getLogger(), sentryAndroidOptions.getProfilingTracesDirPath(), sentryAndroidOptions.isProfilingEnabled(), sentryAndroidOptions.getProfilingTracesHz(), sentryAndroidOptions.getExecutorService());
    }

    @Deprecated
    public AndroidTransactionProfiler(Context context, SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider buildInfoProvider, SentryFrameMetricsCollector sentryFrameMetricsCollector, IHub iHub) {
        this(context, sentryAndroidOptions, buildInfoProvider, sentryFrameMetricsCollector);
    }

    private ActivityManager.MemoryInfo getMemInfo() {
        block4: {
            ActivityManager.MemoryInfo memoryInfo;
            ActivityManager activityManager;
            try {
                activityManager = (ActivityManager)this.context.getSystemService("activity");
                memoryInfo = new ActivityManager.MemoryInfo();
                if (activityManager == null) break block4;
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.ERROR, "Error getting MemoryInfo.", throwable);
                return null;
            }
            activityManager.getMemoryInfo(memoryInfo);
            return memoryInfo;
        }
        this.logger.log(SentryLevel.INFO, "Error getting MemoryInfo.", new Object[0]);
        return null;
    }

    private void init() {
        if (this.isInitialized) {
            return;
        }
        this.isInitialized = true;
        if (!this.isProfilingEnabled) {
            this.logger.log(SentryLevel.INFO, "Profiling is disabled in options.", new Object[0]);
            return;
        }
        if (this.profilingTracesDirPath == null) {
            this.logger.log(SentryLevel.WARNING, "Disabling profiling because no profiling traces dir path is defined in options.", new Object[0]);
            return;
        }
        if (this.profilingTracesHz <= 0) {
            this.logger.log(SentryLevel.WARNING, "Disabling profiling because trace rate is set to %d", this.profilingTracesHz);
            return;
        }
        this.profiler = new AndroidProfiler(this.profilingTracesDirPath, (int)TimeUnit.SECONDS.toMicros(1L) / this.profilingTracesHz, this.frameMetricsCollector, this.executorService, this.logger, this.buildInfoProvider);
    }

    static /* synthetic */ List lambda$onTransactionFinish$0() throws Exception {
        return CpuInfoUtils.getInstance().readMaxFrequencies();
    }

    private boolean onFirstStart() {
        Object object = this.profiler;
        if (object == null) {
            return false;
        }
        if ((object = ((AndroidProfiler)object).start()) == null) {
            return false;
        }
        this.profileStartNanos = ((AndroidProfiler.ProfileStartData)object).startNanos;
        this.profileStartCpuMillis = ((AndroidProfiler.ProfileStartData)object).startCpuMillis;
        return true;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private ProfilingTraceData onTransactionFinish(String object, String string2, String string3, boolean bl, List<PerformanceCollectionData> object2, SentryOptions object3) {
        AndroidTransactionProfiler androidTransactionProfiler = this;
        synchronized (androidTransactionProfiler) {
            void var3_3;
            void var2_2;
            AndroidProfiler androidProfiler = this.profiler;
            if (androidProfiler == null) {
                return null;
            }
            int n2 = this.buildInfoProvider.getSdkInfoVersion();
            if (n2 < 21) {
                return null;
            }
            ProfilingTransactionData profilingTransactionData = this.currentProfilingTransactionData;
            if (profilingTransactionData != null && profilingTransactionData.getId().equals((Object)var2_2)) {
                void var5_9;
                void var12_18;
                void var4_4;
                String string4;
                void var5_5;
                n2 = this.transactionsCounter;
                if (n2 > 0) {
                    this.transactionsCounter = n2 - 1;
                }
                this.logger.log(SentryLevel.DEBUG, "Transaction %s (%s) finished.", object, var3_3);
                if (this.transactionsCounter != 0) {
                    object = this.currentProfilingTransactionData;
                    if (object == null) return null;
                    ((ProfilingTransactionData)object).notifyFinish(SystemClock.elapsedRealtimeNanos(), this.profileStartNanos, Process.getElapsedCpuTime(), this.profileStartCpuMillis);
                    return null;
                }
                AndroidProfiler.ProfileEndData profileEndData = this.profiler.endAndCollect(false, (List<PerformanceCollectionData>)var5_5);
                if (profileEndData == null) {
                    return null;
                }
                long l2 = profileEndData.endNanos;
                long l3 = this.profileStartNanos;
                ArrayList arrayList = new ArrayList(1);
                object2 = this.currentProfilingTransactionData;
                if (object2 != null) {
                    arrayList.add(object2);
                }
                this.currentProfilingTransactionData = null;
                this.transactionsCounter = 0;
                String string5 = "0";
                ActivityManager.MemoryInfo memoryInfo = this.getMemInfo();
                if (memoryInfo != null) {
                    String string6 = Long.toString((long)memoryInfo.totalMem);
                }
                String[] stringArray = Build.SUPPORTED_ABIS;
                Iterator iterator = arrayList.iterator();
                while (iterator.hasNext()) {
                    ((ProfilingTransactionData)iterator.next()).notifyFinish(profileEndData.endNanos, this.profileStartNanos, profileEndData.endCpuMillis, this.profileStartCpuMillis);
                }
                File file = profileEndData.traceFile;
                String string7 = Long.toString((long)(l2 - l3));
                n2 = this.buildInfoProvider.getSdkInfoVersion();
                if (stringArray != null && stringArray.length > 0) {
                    String string8 = stringArray[0];
                } else {
                    String string9 = "";
                }
                AndroidTransactionProfiler$$ExternalSyntheticLambda0 androidTransactionProfiler$$ExternalSyntheticLambda0 = new AndroidTransactionProfiler$$ExternalSyntheticLambda0();
                String string10 = this.buildInfoProvider.getManufacturer();
                String string11 = this.buildInfoProvider.getModel();
                String string12 = this.buildInfoProvider.getVersionRelease();
                Boolean bl2 = this.buildInfoProvider.isEmulator();
                String string13 = ((SentryOptions)((Object)string4)).getProguardUuid();
                String string14 = ((SentryOptions)((Object)string4)).getRelease();
                String string15 = ((SentryOptions)((Object)string4)).getEnvironment();
                string4 = !profileEndData.didTimeout && var4_4 == false ? "normal" : "timeout";
                return new ProfilingTraceData(file, (List<ProfilingTransactionData>)arrayList, (String)object, (String)var2_2, (String)var3_3, string7, n2, (String)var12_18, androidTransactionProfiler$$ExternalSyntheticLambda0, string10, string11, string12, bl2, (String)var5_9, string13, string14, string15, string4, profileEndData.measurementsMap);
            }
            this.logger.log(SentryLevel.INFO, "Transaction %s (%s) finished, but was not currently being profiled. Skipping", object, var3_3);
            return null;
        }
    }

    @Override
    public void bindTransaction(ITransaction iTransaction) {
        AndroidTransactionProfiler androidTransactionProfiler = this;
        synchronized (androidTransactionProfiler) {
            if (this.transactionsCounter > 0 && this.currentProfilingTransactionData == null) {
                ProfilingTransactionData profilingTransactionData;
                this.currentProfilingTransactionData = profilingTransactionData = new ProfilingTransactionData(iTransaction, this.profileStartNanos, this.profileStartCpuMillis);
            }
            return;
        }
    }

    @Override
    public void close() {
        Object object = this.currentProfilingTransactionData;
        if (object != null) {
            this.onTransactionFinish(((ProfilingTransactionData)object).getName(), this.currentProfilingTransactionData.getId(), this.currentProfilingTransactionData.getTraceId(), true, null, HubAdapter.getInstance().getOptions());
        } else {
            int n2 = this.transactionsCounter;
            if (n2 != 0) {
                this.transactionsCounter = n2 - 1;
            }
        }
        object = this.profiler;
        if (object != null) {
            ((AndroidProfiler)object).close();
        }
    }

    int getTransactionsCounter() {
        return this.transactionsCounter;
    }

    @Override
    public boolean isRunning() {
        boolean bl = this.transactionsCounter != 0;
        return bl;
    }

    @Override
    public ProfilingTraceData onTransactionFinish(ITransaction object, List<PerformanceCollectionData> list, SentryOptions sentryOptions) {
        AndroidTransactionProfiler androidTransactionProfiler = this;
        synchronized (androidTransactionProfiler) {
            object = this.onTransactionFinish(object.getName(), object.getEventId().toString(), object.getSpanContext().getTraceId().toString(), false, list, sentryOptions);
            return object;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void start() {
        AndroidTransactionProfiler androidTransactionProfiler = this;
        synchronized (androidTransactionProfiler) {
            int n2 = this.buildInfoProvider.getSdkInfoVersion();
            if (n2 < 21) {
                return;
            }
            this.init();
            this.transactionsCounter = n2 = this.transactionsCounter + 1;
            if (n2 == 1 && this.onFirstStart()) {
                this.logger.log(SentryLevel.DEBUG, "Profiler started.", new Object[0]);
            } else {
                --this.transactionsCounter;
                this.logger.log(SentryLevel.WARNING, "A profile is already running. This profile will be ignored.", new Object[0]);
            }
            return;
        }
    }
}

