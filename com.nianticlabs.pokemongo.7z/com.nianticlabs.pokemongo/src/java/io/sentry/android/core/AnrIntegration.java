/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.content.Context;
import io.sentry.IHub;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.ANRWatchDog;
import io.sentry.android.core.AnrIntegration$$ExternalSyntheticLambda0;
import io.sentry.android.core.AnrIntegration$$ExternalSyntheticLambda1;
import io.sentry.android.core.AppState;
import io.sentry.android.core.ApplicationNotResponding;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.exception.ExceptionMechanismException;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.TransactionEnd;
import io.sentry.protocol.Mechanism;
import io.sentry.util.HintUtils;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class AnrIntegration
implements Integration,
Closeable {
    private static ANRWatchDog anrWatchDog;
    private static final Object watchDogLock;
    private final Context context;
    private boolean isClosed = false;
    private SentryOptions options;
    private final Object startLock = new Object();

    static {
        watchDogLock = new Object();
    }

    public AnrIntegration(Context context) {
        this.context = context;
    }

    private Throwable buildAnrThrowable(boolean bl, SentryAndroidOptions object, ApplicationNotResponding object2) {
        String string2 = "ANR for at least " + ((SentryAndroidOptions)object).getAnrTimeoutIntervalMillis() + " ms.";
        object = string2;
        if (bl) {
            object = "Background " + string2;
        }
        object = new ApplicationNotResponding((String)object, ((ApplicationNotResponding)((Object)object2)).getThread());
        object2 = new Mechanism();
        ((Mechanism)object2).setType("ANR");
        return new ExceptionMechanismException((Mechanism)object2, (Throwable)object, ((ApplicationNotResponding)((Object)object)).getThread(), true);
    }

    private void register(IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "AnrIntegration enabled: %s", sentryAndroidOptions.isAnrEnabled());
        if (sentryAndroidOptions.isAnrEnabled()) {
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
            try {
                ISentryExecutorService iSentryExecutorService = sentryAndroidOptions.getExecutorService();
                AnrIntegration$$ExternalSyntheticLambda1 anrIntegration$$ExternalSyntheticLambda1 = new AnrIntegration$$ExternalSyntheticLambda1(this, iHub, sentryAndroidOptions);
                iSentryExecutorService.submit(anrIntegration$$ExternalSyntheticLambda1);
            }
            catch (Throwable throwable) {
                sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "Failed to start AnrIntegration on executor thread.", throwable);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void startAnrWatchdog(IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        Object object;
        Object object2 = object = watchDogLock;
        synchronized (object2) {
            if (anrWatchDog == null) {
                ANRWatchDog aNRWatchDog;
                sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "ANR timeout in milliseconds: %d", sentryAndroidOptions.getAnrTimeoutIntervalMillis());
                long l2 = sentryAndroidOptions.getAnrTimeoutIntervalMillis();
                boolean bl = sentryAndroidOptions.isAnrReportInDebug();
                AnrIntegration$$ExternalSyntheticLambda0 anrIntegration$$ExternalSyntheticLambda0 = new AnrIntegration$$ExternalSyntheticLambda0(this, iHub, sentryAndroidOptions);
                anrWatchDog = aNRWatchDog = new ANRWatchDog(l2, bl, anrIntegration$$ExternalSyntheticLambda0, sentryAndroidOptions.getLogger(), this.context);
                aNRWatchDog.start();
                sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "AnrIntegration installed.", new Object[0]);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        Object object;
        Object object2;
        Object object3 = object2 = this.startLock;
        synchronized (object3) {
            this.isClosed = true;
        }
        Object object4 = object = watchDogLock;
        synchronized (object4) {
            object2 = anrWatchDog;
            if (object2 != null) {
                object2.interrupt();
                anrWatchDog = null;
                object2 = this.options;
                if (object2 != null) {
                    ((SentryOptions)object2).getLogger().log(SentryLevel.DEBUG, "AnrIntegration removed.", new Object[0]);
                }
            }
            return;
        }
    }

    ANRWatchDog getANRWatchDog() {
        return anrWatchDog;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$register$0$io-sentry-android-core-AnrIntegration(IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            if (!this.isClosed) {
                this.startAnrWatchdog(iHub, sentryAndroidOptions);
            }
            return;
        }
    }

    /* synthetic */ void lambda$startAnrWatchdog$1$io-sentry-android-core-AnrIntegration(IHub iHub, SentryAndroidOptions sentryAndroidOptions, ApplicationNotResponding applicationNotResponding) {
        this.reportANR(iHub, sentryAndroidOptions, applicationNotResponding);
    }

    @Override
    public final void register(IHub iHub, SentryOptions sentryOptions) {
        this.options = Objects.requireNonNull(sentryOptions, "SentryOptions is required");
        this.register(iHub, (SentryAndroidOptions)sentryOptions);
    }

    void reportANR(IHub iHub, SentryAndroidOptions object, ApplicationNotResponding applicationNotResponding) {
        ((SentryOptions)object).getLogger().log(SentryLevel.INFO, "ANR triggered with message: %s", applicationNotResponding.getMessage());
        boolean bl = Boolean.TRUE.equals((Object)AppState.getInstance().isInBackground());
        object = new SentryEvent(this.buildAnrThrowable(bl, (SentryAndroidOptions)object, applicationNotResponding));
        ((SentryEvent)object).setLevel(SentryLevel.ERROR);
        iHub.captureEvent((SentryEvent)object, HintUtils.createWithTypeCheckHint(new AnrHint(bl)));
    }

    static final class AnrHint
    implements AbnormalExit,
    TransactionEnd {
        private final boolean isBackgroundAnr;

        AnrHint(boolean bl) {
            this.isBackgroundAnr = bl;
        }

        @Override
        public boolean ignoreCurrentThread() {
            return true;
        }

        @Override
        public String mechanism() {
            String string2 = this.isBackgroundAnr ? "anr_background" : "anr_foreground";
            return string2;
        }

        @Override
        public Long timestamp() {
            return null;
        }
    }
}

