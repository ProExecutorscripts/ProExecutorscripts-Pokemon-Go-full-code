/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.util.SparseIntArray
 *  androidx.core.app.FrameMetricsAggregator
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.WeakHashMap
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.android.core;

import android.app.Activity;
import android.util.SparseIntArray;
import androidx.core.app.FrameMetricsAggregator;
import io.sentry.SentryLevel;
import io.sentry.android.core.ActivityFramesTracker$$ExternalSyntheticLambda0;
import io.sentry.android.core.ActivityFramesTracker$$ExternalSyntheticLambda1;
import io.sentry.android.core.ActivityFramesTracker$$ExternalSyntheticLambda2;
import io.sentry.android.core.ActivityFramesTracker$$ExternalSyntheticLambda3;
import io.sentry.android.core.LoadClass;
import io.sentry.android.core.MainLooperHandler;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.SentryId;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ActivityFramesTracker {
    private final Map<SentryId, Map<String, MeasurementValue>> activityMeasurements = new ConcurrentHashMap();
    private final Map<Activity, FrameCounts> frameCountAtStartSnapshots = new WeakHashMap();
    private FrameMetricsAggregator frameMetricsAggregator = null;
    private final MainLooperHandler handler;
    private final SentryAndroidOptions options;

    public ActivityFramesTracker(LoadClass loadClass, SentryAndroidOptions sentryAndroidOptions) {
        this(loadClass, sentryAndroidOptions, new MainLooperHandler());
    }

    public ActivityFramesTracker(LoadClass loadClass, SentryAndroidOptions sentryAndroidOptions, MainLooperHandler mainLooperHandler) {
        if (loadClass.isClassAvailable("androidx.core.app.FrameMetricsAggregator", sentryAndroidOptions.getLogger())) {
            this.frameMetricsAggregator = new FrameMetricsAggregator();
        }
        this.options = sentryAndroidOptions;
        this.handler = mainLooperHandler;
    }

    ActivityFramesTracker(LoadClass loadClass, SentryAndroidOptions sentryAndroidOptions, MainLooperHandler mainLooperHandler, FrameMetricsAggregator frameMetricsAggregator) {
        this(loadClass, sentryAndroidOptions, mainLooperHandler);
        this.frameMetricsAggregator = frameMetricsAggregator;
    }

    private FrameCounts calculateCurrentFrameCounts() {
        int n2;
        int n3;
        if (!this.isFrameMetricsAggregatorAvailable()) {
            return null;
        }
        SparseIntArray sparseIntArray = this.frameMetricsAggregator;
        if (sparseIntArray == null) {
            return null;
        }
        sparseIntArray = sparseIntArray.getMetrics();
        int n4 = 0;
        if (sparseIntArray != null && ((SparseIntArray[])sparseIntArray).length > 0 && (sparseIntArray = sparseIntArray[0]) != null) {
            n4 = 0;
            n2 = n3 = 0;
            for (int i2 = 0; i2 < sparseIntArray.size(); ++i2) {
                int n5;
                int n6;
                int n7 = sparseIntArray.keyAt(i2);
                int n8 = sparseIntArray.valueAt(i2);
                n4 += n8;
                if (n7 > 700) {
                    n6 = n2 + n8;
                    n5 = n3;
                } else {
                    n5 = n3;
                    n6 = n2;
                    if (n7 > 16) {
                        n5 = n3 + n8;
                        n6 = n2;
                    }
                }
                n3 = n5;
                n2 = n6;
            }
        } else {
            n3 = 0;
            n2 = 0;
        }
        return new FrameCounts(n4, n3, n2);
    }

    private FrameCounts diffFrameCountsAtEnd(Activity object) {
        FrameCounts frameCounts = (FrameCounts)this.frameCountAtStartSnapshots.remove(object);
        if (frameCounts == null) {
            return null;
        }
        object = this.calculateCurrentFrameCounts();
        if (object == null) {
            return null;
        }
        return new FrameCounts(((FrameCounts)object).totalFrames - frameCounts.totalFrames, ((FrameCounts)object).slowFrames - frameCounts.slowFrames, ((FrameCounts)object).frozenFrames - frameCounts.frozenFrames);
    }

    private void runSafelyOnUiThread(Runnable runnable, String string2) {
        block4: {
            try {
                if (AndroidMainThreadChecker.getInstance().isMainThread()) {
                    runnable.run();
                } else {
                    MainLooperHandler mainLooperHandler = this.handler;
                    ActivityFramesTracker$$ExternalSyntheticLambda3 activityFramesTracker$$ExternalSyntheticLambda3 = new ActivityFramesTracker$$ExternalSyntheticLambda3(this, runnable, string2);
                    mainLooperHandler.post(activityFramesTracker$$ExternalSyntheticLambda3);
                }
            }
            catch (Throwable throwable) {
                if (string2 == null) break block4;
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to execute " + string2, new Object[0]);
            }
        }
    }

    private void snapshotFrameCountsAtStart(Activity activity2) {
        FrameCounts frameCounts = this.calculateCurrentFrameCounts();
        if (frameCounts != null) {
            this.frameCountAtStartSnapshots.put((Object)activity2, (Object)frameCounts);
        }
    }

    public void addActivity(Activity activity2) {
        ActivityFramesTracker activityFramesTracker = this;
        synchronized (activityFramesTracker) {
            block4: {
                boolean bl = this.isFrameMetricsAggregatorAvailable();
                if (bl) break block4;
                return;
            }
            ActivityFramesTracker$$ExternalSyntheticLambda0 activityFramesTracker$$ExternalSyntheticLambda0 = new ActivityFramesTracker$$ExternalSyntheticLambda0(this, activity2);
            this.runSafelyOnUiThread(activityFramesTracker$$ExternalSyntheticLambda0, "FrameMetricsAggregator.add");
            this.snapshotFrameCountsAtStart(activity2);
            return;
        }
    }

    public boolean isFrameMetricsAggregatorAvailable() {
        boolean bl = this.frameMetricsAggregator != null && this.options.isEnableFramesTracking() && !this.options.isEnablePerformanceV2();
        return bl;
    }

    /* synthetic */ void lambda$addActivity$0$io-sentry-android-core-ActivityFramesTracker(Activity activity2) {
        this.frameMetricsAggregator.add(activity2);
    }

    /* synthetic */ void lambda$runSafelyOnUiThread$3$io-sentry-android-core-ActivityFramesTracker(Runnable runnable, String string2) {
        block2: {
            try {
                runnable.run();
            }
            catch (Throwable throwable) {
                if (string2 == null) break block2;
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to execute " + string2, new Object[0]);
            }
        }
    }

    /* synthetic */ void lambda$setMetrics$1$io-sentry-android-core-ActivityFramesTracker(Activity activity2) {
        this.frameMetricsAggregator.remove(activity2);
    }

    /* synthetic */ void lambda$stop$2$io-sentry-android-core-ActivityFramesTracker() {
        this.frameMetricsAggregator.stop();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setMetrics(Activity object, SentryId sentryId) {
        ActivityFramesTracker activityFramesTracker = this;
        synchronized (activityFramesTracker) {
            boolean bl = this.isFrameMetricsAggregatorAvailable();
            if (!bl) {
                return;
            }
            Object object2 = new ActivityFramesTracker$$ExternalSyntheticLambda1(this, (Activity)object);
            this.runSafelyOnUiThread((Runnable)object2, null);
            FrameCounts frameCounts = this.diffFrameCountsAtEnd((Activity)object);
            if (frameCounts != null && (frameCounts.totalFrames != 0 || frameCounts.slowFrames != 0 || frameCounts.frozenFrames != 0)) {
                MeasurementValue measurementValue = new MeasurementValue((Number)Integer.valueOf((int)frameCounts.totalFrames), "none");
                object2 = new MeasurementValue((Number)Integer.valueOf((int)frameCounts.slowFrames), "none");
                MeasurementValue measurementValue2 = new MeasurementValue((Number)Integer.valueOf((int)frameCounts.frozenFrames), "none");
                frameCounts = new HashMap();
                frameCounts.put("frames_total", measurementValue);
                frameCounts.put("frames_slow", object2);
                frameCounts.put("frames_frozen", measurementValue2);
                this.activityMeasurements.put((Object)sentryId, (Object)frameCounts);
                return;
            }
            return;
        }
    }

    public void stop() {
        ActivityFramesTracker activityFramesTracker = this;
        synchronized (activityFramesTracker) {
            if (this.isFrameMetricsAggregatorAvailable()) {
                ActivityFramesTracker$$ExternalSyntheticLambda2 activityFramesTracker$$ExternalSyntheticLambda2 = new ActivityFramesTracker$$ExternalSyntheticLambda2(this);
                this.runSafelyOnUiThread(activityFramesTracker$$ExternalSyntheticLambda2, "FrameMetricsAggregator.stop");
                this.frameMetricsAggregator.reset();
            }
            this.activityMeasurements.clear();
            return;
        }
    }

    public Map<String, MeasurementValue> takeMetrics(SentryId sentryId) {
        ActivityFramesTracker activityFramesTracker = this;
        synchronized (activityFramesTracker) {
            block4: {
                boolean bl = this.isFrameMetricsAggregatorAvailable();
                if (bl) break block4;
                return null;
            }
            Map map2 = (Map)this.activityMeasurements.get((Object)sentryId);
            this.activityMeasurements.remove((Object)sentryId);
            return map2;
        }
    }

    private static final class FrameCounts {
        private final int frozenFrames;
        private final int slowFrames;
        private final int totalFrames;

        private FrameCounts(int n2, int n3, int n4) {
            this.totalFrames = n2;
            this.slowFrames = n3;
            this.frozenFrames = n4;
        }
    }
}

