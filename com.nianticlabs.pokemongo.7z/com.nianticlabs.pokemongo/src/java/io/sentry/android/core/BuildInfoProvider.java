/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.os.Build;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.util.Objects;

public final class BuildInfoProvider {
    final ILogger logger;

    public BuildInfoProvider(ILogger iLogger) {
        this.logger = Objects.requireNonNull(iLogger, "The ILogger object is required.");
    }

    public String getBuildTags() {
        return Build.TAGS;
    }

    public String getManufacturer() {
        return Build.MANUFACTURER;
    }

    public String getModel() {
        return Build.MODEL;
    }

    public int getSdkInfoVersion() {
        return Build.VERSION.SDK_INT;
    }

    public String getVersionRelease() {
        return Build.VERSION.RELEASE;
    }

    public Boolean isEmulator() {
        boolean bl;
        block3: {
            try {
                if (!(Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic") || Build.FINGERPRINT.startsWith("generic") || Build.FINGERPRINT.startsWith("unknown") || Build.HARDWARE.contains((CharSequence)"goldfish") || Build.HARDWARE.contains((CharSequence)"ranchu") || Build.MODEL.contains((CharSequence)"google_sdk") || Build.MODEL.contains((CharSequence)"Emulator") || Build.MODEL.contains((CharSequence)"Android SDK built for x86") || Build.MANUFACTURER.contains((CharSequence)"Genymotion") || Build.PRODUCT.contains((CharSequence)"sdk_google") || Build.PRODUCT.contains((CharSequence)"google_sdk") || Build.PRODUCT.contains((CharSequence)"sdk") || Build.PRODUCT.contains((CharSequence)"sdk_x86") || Build.PRODUCT.contains((CharSequence)"vbox86p") || Build.PRODUCT.contains((CharSequence)"emulator") || Build.PRODUCT.contains((CharSequence)"simulator"))) {
                    bl = false;
                    break block3;
                }
                bl = true;
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.ERROR, "Error checking whether application is running in an emulator.", throwable);
                return null;
            }
        }
        return bl;
    }
}

