/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.graphics.Canvas
 *  android.view.View
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core.internal.util;

import android.app.Activity;
import android.graphics.Canvas;
import android.view.View;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.util.thread.IMainThreadChecker;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenshotUtils {
    private static final long CAPTURE_TIMEOUT_MS = 1000L;

    private static boolean isActivityValid(Activity activity2) {
        boolean bl = !activity2.isFinishing() && !activity2.isDestroyed();
        return bl;
    }

    static /* synthetic */ void lambda$takeScreenshot$0(AtomicBoolean atomicBoolean, CountDownLatch countDownLatch, int n2) {
        boolean bl = n2 == 0;
        atomicBoolean.set(bl);
        countDownLatch.countDown();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static /* synthetic */ void lambda$takeScreenshot$1(View view2, Canvas canvas, ILogger iLogger, CountDownLatch countDownLatch) {
        try {
            view2.draw(canvas);
            return;
        }
        catch (Throwable throwable) {
            try {
                iLogger.log(SentryLevel.ERROR, "Taking screenshot failed (view.draw).", throwable);
                return;
            }
            finally {
                countDownLatch.countDown();
            }
        }
    }

    public static byte[] takeScreenshot(Activity activity2, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        return ScreenshotUtils.takeScreenshot(activity2, AndroidMainThreadChecker.getInstance(), iLogger, buildInfoProvider);
    }

    /*
     * Exception decompiling
     */
    public static byte[] takeScreenshot(Activity var0, IMainThreadChecker var1_3, ILogger var2_7, BuildInfoProvider var3_8) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}

