/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.android.core.ANRWatchDog;
import io.sentry.transport.ICurrentDateProvider;

public final class ANRWatchDog$$ExternalSyntheticLambda0
implements Runnable {
    public final ANRWatchDog f$0;
    public final ICurrentDateProvider f$1;

    public /* synthetic */ ANRWatchDog$$ExternalSyntheticLambda0(ANRWatchDog aNRWatchDog, ICurrentDateProvider iCurrentDateProvider) {
        this.f$0 = aNRWatchDog;
        this.f$1 = iCurrentDateProvider;
    }

    public final void run() {
        this.f$0.lambda$new$1$io-sentry-android-core-ANRWatchDog(this.f$1);
    }
}

