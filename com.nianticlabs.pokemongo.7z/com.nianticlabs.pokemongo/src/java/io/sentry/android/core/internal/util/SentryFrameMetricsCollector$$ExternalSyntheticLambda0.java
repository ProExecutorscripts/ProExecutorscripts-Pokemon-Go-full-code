/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 */
package io.sentry.android.core.internal.util;

import io.sentry.ILogger;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;

public final class SentryFrameMetricsCollector$$ExternalSyntheticLambda0
implements Thread.UncaughtExceptionHandler {
    public final ILogger f$0;

    public /* synthetic */ SentryFrameMetricsCollector$$ExternalSyntheticLambda0(ILogger iLogger) {
        this.f$0 = iLogger;
    }

    public final void uncaughtException(Thread thread, Throwable throwable) {
        SentryFrameMetricsCollector.lambda$new$0(this.f$0, thread, throwable);
    }
}

