/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Map
 *  java.util.TreeMap
 */
package io.sentry.android.core.internal.modules;

import android.content.Context;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.internal.modules.ModulesLoader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.TreeMap;

public final class AssetsModulesLoader
extends ModulesLoader {
    private final Context context;

    public AssetsModulesLoader(Context context, ILogger iLogger) {
        super(iLogger);
        this.context = context;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected Map<String, String> loadModules() {
        TreeMap treeMap = new TreeMap();
        InputStream inputStream = this.context.getAssets().open("sentry-external-modules.txt");
        Map<String, String> map2 = this.parseStream(inputStream);
        if (inputStream == null) return map2;
        inputStream.close();
        return map2;
        catch (Throwable throwable) {
            if (inputStream == null) throw throwable;
            try {
                inputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (IOException iOException) {
                    this.logger.log(SentryLevel.ERROR, "Error extracting modules.", iOException);
                    return treeMap;
                }
                catch (FileNotFoundException fileNotFoundException) {
                    this.logger.log(SentryLevel.INFO, "%s file was not found.", "sentry-external-modules.txt");
                }
            }
        }
        return treeMap;
    }
}

