/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.core;

import io.sentry.android.core.AndroidOptionsInitializer;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.util.LazyEvaluator;

public final class AndroidOptionsInitializer$$ExternalSyntheticLambda0
implements LazyEvaluator.Evaluator {
    public final SentryAndroidOptions f$0;

    public /* synthetic */ AndroidOptionsInitializer$$ExternalSyntheticLambda0(SentryAndroidOptions sentryAndroidOptions) {
        this.f$0 = sentryAndroidOptions;
    }

    public final Object evaluate() {
        return AndroidOptionsInitializer.lambda$installDefaultIntegrations$0(this.f$0);
    }
}

