/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.TimeUnit
 *  java.util.concurrent.TimeoutException
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core;

import io.sentry.DataCategory;
import io.sentry.IConnectionStatusProvider;
import io.sentry.IHub;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.SendCachedEnvelopeFireAndForgetIntegration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SendCachedEnvelopeIntegration$$ExternalSyntheticLambda0;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.transport.RateLimiter;
import io.sentry.util.LazyEvaluator;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class SendCachedEnvelopeIntegration
implements Integration,
IConnectionStatusProvider.IConnectionStatusObserver,
Closeable {
    private IConnectionStatusProvider connectionStatusProvider;
    private final SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForgetFactory factory;
    private IHub hub;
    private final AtomicBoolean isClosed;
    private final AtomicBoolean isInitialized;
    private SentryAndroidOptions options;
    private SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForget sender;
    private final AtomicBoolean startupCrashHandled = new AtomicBoolean(false);
    private final LazyEvaluator<Boolean> startupCrashMarkerEvaluator;

    public SendCachedEnvelopeIntegration(SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForgetFactory sendFireAndForgetFactory, LazyEvaluator<Boolean> lazyEvaluator) {
        this.isInitialized = new AtomicBoolean(false);
        this.isClosed = new AtomicBoolean(false);
        this.factory = Objects.requireNonNull(sendFireAndForgetFactory, "SendFireAndForgetFactory is required");
        this.startupCrashMarkerEvaluator = lazyEvaluator;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void sendCachedEnvelopes(IHub future, SentryAndroidOptions sentryAndroidOptions) {
        SendCachedEnvelopeIntegration sendCachedEnvelopeIntegration = this;
        synchronized (sendCachedEnvelopeIntegration) {
            void var2_5;
            try {
                ISentryExecutorService iSentryExecutorService = var2_5.getExecutorService();
                SendCachedEnvelopeIntegration$$ExternalSyntheticLambda0 sendCachedEnvelopeIntegration$$ExternalSyntheticLambda0 = new SendCachedEnvelopeIntegration$$ExternalSyntheticLambda0(this, (SentryAndroidOptions)var2_5, (IHub)future);
                future = iSentryExecutorService.submit(sendCachedEnvelopeIntegration$$ExternalSyntheticLambda0);
                if (this.startupCrashMarkerEvaluator.getValue().booleanValue() && this.startupCrashHandled.compareAndSet(false, true)) {
                    var2_5.getLogger().log(SentryLevel.DEBUG, "Startup Crash marker exists, blocking flush.", new Object[0]);
                    try {
                        future.get(var2_5.getStartupCrashFlushTimeoutMillis(), TimeUnit.MILLISECONDS);
                    }
                    catch (TimeoutException timeoutException) {
                        var2_5.getLogger().log(SentryLevel.DEBUG, "Synchronous send timed out, continuing in the background.", new Object[0]);
                    }
                }
                var2_5.getLogger().log(SentryLevel.DEBUG, "SendCachedEnvelopeIntegration installed.", new Object[0]);
            }
            catch (Throwable throwable) {
                var2_5.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Cached events will not be sent", throwable);
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                var2_5.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Cached events will not be sent. Did you call Sentry.close()?", rejectedExecutionException);
            }
            return;
        }
    }

    public void close() throws IOException {
        this.isClosed.set(true);
        IConnectionStatusProvider iConnectionStatusProvider = this.connectionStatusProvider;
        if (iConnectionStatusProvider != null) {
            iConnectionStatusProvider.removeConnectionStatusObserver(this);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$sendCachedEnvelopes$0$io-sentry-android-core-SendCachedEnvelopeIntegration(SentryAndroidOptions sentryAndroidOptions, IHub object) {
        try {
            IConnectionStatusProvider iConnectionStatusProvider;
            if (this.isClosed.get()) {
                sentryAndroidOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeIntegration, not trying to send after closing.", new Object[0]);
                return;
            }
            if (!this.isInitialized.getAndSet(true)) {
                this.connectionStatusProvider = iConnectionStatusProvider = sentryAndroidOptions.getConnectionStatusProvider();
                iConnectionStatusProvider.addConnectionStatusObserver(this);
                this.sender = this.factory.create((IHub)object, sentryAndroidOptions);
            }
            if ((iConnectionStatusProvider = this.connectionStatusProvider) != null && iConnectionStatusProvider.getConnectionStatus() == IConnectionStatusProvider.ConnectionStatus.DISCONNECTED) {
                sentryAndroidOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeIntegration, no connection.", new Object[0]);
                return;
            }
            if ((object = object.getRateLimiter()) != null && ((RateLimiter)object).isActiveForCategory(DataCategory.All)) {
                sentryAndroidOptions.getLogger().log(SentryLevel.INFO, "SendCachedEnvelopeIntegration, rate limiting active.", new Object[0]);
                return;
            }
            object = this.sender;
            if (object == null) {
                sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "SendCachedEnvelopeIntegration factory is null.", new Object[0]);
                return;
            }
            object.send();
            return;
        }
        catch (Throwable throwable) {
            sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "Failed trying to send cached events.", throwable);
        }
    }

    @Override
    public void onConnectionStatusChanged(IConnectionStatusProvider.ConnectionStatus object) {
        IHub iHub = this.hub;
        if (iHub != null && (object = this.options) != null) {
            this.sendCachedEnvelopes(iHub, (SentryAndroidOptions)object);
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        this.hub = Objects.requireNonNull(iHub, "Hub is required");
        Object object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = Objects.requireNonNull(object, "SentryAndroidOptions is required");
        object = sentryOptions.getCacheDirPath();
        if (!this.factory.hasValidPath((String)object, sentryOptions.getLogger())) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "No cache dir path is defined in options.", new Object[0]);
            return;
        }
        this.sendCachedEnvelopes(iHub, this.options);
    }
}

