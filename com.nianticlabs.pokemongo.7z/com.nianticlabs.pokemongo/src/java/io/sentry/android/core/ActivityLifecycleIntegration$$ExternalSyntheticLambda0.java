/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.Scope;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda0
implements Scope.IWithTransaction {
    public final ITransaction f$0;
    public final IScope f$1;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda0(ITransaction iTransaction, IScope iScope) {
        this.f$0 = iTransaction;
        this.f$1 = iScope;
    }

    @Override
    public final void accept(ITransaction iTransaction) {
        ActivityLifecycleIntegration.lambda$clearScope$4(this.f$0, this.f$1, iTransaction);
    }
}

