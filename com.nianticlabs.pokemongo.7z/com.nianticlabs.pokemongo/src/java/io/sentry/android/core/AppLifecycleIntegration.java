/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.ProcessLifecycleOwner
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.ProcessLifecycleOwner;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.AppLifecycleIntegration$$ExternalSyntheticLambda0;
import io.sentry.android.core.AppLifecycleIntegration$$ExternalSyntheticLambda1;
import io.sentry.android.core.LifecycleWatcher;
import io.sentry.android.core.MainLooperHandler;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class AppLifecycleIntegration
implements Integration,
Closeable {
    private final MainLooperHandler handler;
    private SentryAndroidOptions options;
    volatile LifecycleWatcher watcher;

    public AppLifecycleIntegration() {
        this(new MainLooperHandler());
    }

    AppLifecycleIntegration(MainLooperHandler mainLooperHandler) {
        this.handler = mainLooperHandler;
    }

    private void addObserver(IHub iHub) {
        if (this.options == null) {
            return;
        }
        this.watcher = new LifecycleWatcher(iHub, this.options.getSessionTrackingIntervalMillis(), this.options.isEnableAutoSessionTracking(), this.options.isEnableAppLifecycleBreadcrumbs());
        try {
            ProcessLifecycleOwner.get().getLifecycle().addObserver((LifecycleObserver)this.watcher);
            this.options.getLogger().log(SentryLevel.DEBUG, "AppLifecycleIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
        catch (Throwable throwable) {
            this.watcher = null;
            this.options.getLogger().log(SentryLevel.ERROR, "AppLifecycleIntegration failed to get Lifecycle and could not be installed.", throwable);
        }
    }

    private void removeObserver() {
        Object object = this.watcher;
        if (object != null) {
            ProcessLifecycleOwner.get().getLifecycle().removeObserver((LifecycleObserver)object);
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "AppLifecycleIntegration removed.", new Object[0]);
            }
        }
        this.watcher = null;
    }

    public void close() throws IOException {
        if (this.watcher == null) {
            return;
        }
        if (AndroidMainThreadChecker.getInstance().isMainThread()) {
            this.removeObserver();
        } else {
            this.handler.post(new AppLifecycleIntegration$$ExternalSyntheticLambda0(this));
        }
    }

    /* synthetic */ void lambda$close$1$io-sentry-android-core-AppLifecycleIntegration() {
        this.removeObserver();
    }

    /* synthetic */ void lambda$register$0$io-sentry-android-core-AppLifecycleIntegration(IHub iHub) {
        this.addObserver(iHub);
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        Objects.requireNonNull(iHub, "Hub is required");
        Object object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        object = Objects.requireNonNull(object, "SentryAndroidOptions is required");
        this.options = object;
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "enableSessionTracking enabled: %s", this.options.isEnableAutoSessionTracking());
        this.options.getLogger().log(SentryLevel.DEBUG, "enableAppLifecycleBreadcrumbs enabled: %s", this.options.isEnableAppLifecycleBreadcrumbs());
        if (this.options.isEnableAutoSessionTracking() || this.options.isEnableAppLifecycleBreadcrumbs()) {
            try {
                Class.forName((String)"androidx.lifecycle.DefaultLifecycleObserver");
                Class.forName((String)"androidx.lifecycle.ProcessLifecycleOwner");
                if (AndroidMainThreadChecker.getInstance().isMainThread()) {
                    this.addObserver(iHub);
                } else {
                    object = this.handler;
                    AppLifecycleIntegration$$ExternalSyntheticLambda1 appLifecycleIntegration$$ExternalSyntheticLambda1 = new AppLifecycleIntegration$$ExternalSyntheticLambda1(this, iHub);
                    ((MainLooperHandler)object).post(appLifecycleIntegration$$ExternalSyntheticLambda1);
                }
            }
            catch (IllegalStateException illegalStateException) {
                sentryOptions.getLogger().log(SentryLevel.ERROR, "AppLifecycleIntegration could not be installed", illegalStateException);
            }
            catch (ClassNotFoundException classNotFoundException) {
                sentryOptions.getLogger().log(SentryLevel.INFO, "androidx.lifecycle is not available, AppLifecycleIntegration won't be installed", classNotFoundException);
            }
        }
    }
}

