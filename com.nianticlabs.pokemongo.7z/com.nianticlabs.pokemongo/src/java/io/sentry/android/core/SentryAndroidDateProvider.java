/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.SentryDate;
import io.sentry.SentryDateProvider;
import io.sentry.SentryNanotimeDateProvider;

public final class SentryAndroidDateProvider
implements SentryDateProvider {
    private SentryDateProvider dateProvider = new SentryNanotimeDateProvider();

    @Override
    public SentryDate now() {
        return this.dateProvider.now();
    }
}

