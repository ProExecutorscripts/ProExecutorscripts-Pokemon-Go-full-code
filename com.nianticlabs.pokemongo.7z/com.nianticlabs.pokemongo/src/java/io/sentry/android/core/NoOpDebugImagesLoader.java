/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.List
 */
package io.sentry.android.core;

import io.sentry.android.core.IDebugImagesLoader;
import io.sentry.protocol.DebugImage;
import java.util.List;

final class NoOpDebugImagesLoader
implements IDebugImagesLoader {
    private static final NoOpDebugImagesLoader instance = new NoOpDebugImagesLoader();

    private NoOpDebugImagesLoader() {
    }

    public static NoOpDebugImagesLoader getInstance() {
        return instance;
    }

    @Override
    public void clearDebugImages() {
    }

    @Override
    public List<DebugImage> loadDebugImages() {
        return null;
    }
}

