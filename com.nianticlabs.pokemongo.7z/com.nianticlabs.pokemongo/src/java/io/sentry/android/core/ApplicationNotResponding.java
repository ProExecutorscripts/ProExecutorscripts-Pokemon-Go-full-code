/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Thread
 */
package io.sentry.android.core;

import io.sentry.util.Objects;

final class ApplicationNotResponding
extends RuntimeException {
    private static final long serialVersionUID = 252541144579117016L;
    private final Thread thread;

    ApplicationNotResponding(String string2, Thread thread) {
        super(string2);
        string2 = Objects.requireNonNull(thread, "Thread must be provided.");
        this.thread = string2;
        this.setStackTrace(string2.getStackTrace());
    }

    public Thread getThread() {
        return this.thread;
    }
}

