/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.view.Choreographer
 *  android.view.FrameMetrics
 *  android.view.Window
 *  android.view.Window$OnFrameMetricsAvailableListener
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.lang.reflect.Field
 *  java.util.Map
 *  java.util.Set
 *  java.util.UUID
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.CopyOnWriteArraySet
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core.internal.util;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Choreographer;
import android.view.FrameMetrics;
import android.view.Window;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector$$ExternalSyntheticLambda1;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector$$ExternalSyntheticLambda2;
import io.sentry.util.Objects;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.TimeUnit;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SentryFrameMetricsCollector
implements Application.ActivityLifecycleCallbacks {
    private static final long frozenFrameThresholdNanos;
    private static final long oneSecondInNanos;
    private final BuildInfoProvider buildInfoProvider;
    private Choreographer choreographer;
    private Field choreographerLastFrameTimeField;
    private WeakReference<Window> currentWindow;
    private Window.OnFrameMetricsAvailableListener frameMetricsAvailableListener;
    private Handler handler;
    private boolean isAvailable = false;
    private long lastFrameEndNanos = 0L;
    private long lastFrameStartNanos = 0L;
    private final Map<String, FrameMetricsCollectorListener> listenerMap;
    private final ILogger logger;
    private final Set<Window> trackedWindows = new CopyOnWriteArraySet();
    private final WindowFrameMetricsManager windowFrameMetricsManager;

    static {
        oneSecondInNanos = TimeUnit.SECONDS.toNanos(1L);
        frozenFrameThresholdNanos = TimeUnit.MILLISECONDS.toNanos(700L);
    }

    public SentryFrameMetricsCollector(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        this(context, iLogger, buildInfoProvider, new WindowFrameMetricsManager(){});
    }

    public SentryFrameMetricsCollector(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider, WindowFrameMetricsManager windowFrameMetricsManager) {
        this.listenerMap = new ConcurrentHashMap();
        Objects.requireNonNull(context, "The context is required");
        this.logger = Objects.requireNonNull(iLogger, "Logger is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
        this.windowFrameMetricsManager = Objects.requireNonNull(windowFrameMetricsManager, "WindowFrameMetricsManager is required");
        if (!(context instanceof Application)) {
            return;
        }
        if (buildInfoProvider.getSdkInfoVersion() < 24) {
            return;
        }
        this.isAvailable = true;
        windowFrameMetricsManager = new HandlerThread("io.sentry.android.core.internal.util.SentryFrameMetricsCollector");
        windowFrameMetricsManager.setUncaughtExceptionHandler(new SentryFrameMetricsCollector$$ExternalSyntheticLambda0(iLogger));
        windowFrameMetricsManager.start();
        this.handler = new Handler(windowFrameMetricsManager.getLooper());
        ((Application)context).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
        new Handler(Looper.getMainLooper()).post((Runnable)new SentryFrameMetricsCollector$$ExternalSyntheticLambda1(this, iLogger));
        try {
            context = Choreographer.class.getDeclaredField("mLastFrameTimeNanos");
            this.choreographerLastFrameTimeField = context;
            context.setAccessible(true);
        }
        catch (NoSuchFieldException noSuchFieldException) {
            iLogger.log(SentryLevel.ERROR, "Unable to get the frame timestamp from the choreographer: ", noSuchFieldException);
        }
        this.frameMetricsAvailableListener = new SentryFrameMetricsCollector$$ExternalSyntheticLambda2(this, buildInfoProvider);
    }

    public SentryFrameMetricsCollector(Context context, SentryOptions sentryOptions, BuildInfoProvider buildInfoProvider) {
        this(context, sentryOptions, buildInfoProvider, new WindowFrameMetricsManager(){});
    }

    public SentryFrameMetricsCollector(Context context, SentryOptions sentryOptions, BuildInfoProvider buildInfoProvider, WindowFrameMetricsManager windowFrameMetricsManager) {
        this(context, sentryOptions.getLogger(), buildInfoProvider, windowFrameMetricsManager);
    }

    private long getFrameCpuDuration(FrameMetrics frameMetrics) {
        return frameMetrics.getMetric(0) + frameMetrics.getMetric(1) + frameMetrics.getMetric(2) + frameMetrics.getMetric(3) + frameMetrics.getMetric(4) + frameMetrics.getMetric(5);
    }

    private long getFrameStartTimestamp(FrameMetrics frameMetrics) {
        if (this.buildInfoProvider.getSdkInfoVersion() >= 26) {
            return frameMetrics.getMetric(10);
        }
        return this.getLastKnownFrameStartTimeNanos();
    }

    public static boolean isFrozen(long l2) {
        boolean bl = l2 > frozenFrameThresholdNanos;
        return bl;
    }

    public static boolean isSlow(long l2, long l3) {
        boolean bl = l2 > l3;
        return bl;
    }

    static /* synthetic */ void lambda$new$0(ILogger iLogger, Thread thread, Throwable throwable) {
        iLogger.log(SentryLevel.ERROR, "Error during frames measurements.", throwable);
    }

    private void setCurrentWindow(Window window) {
        WeakReference<Window> weakReference = this.currentWindow;
        if (weakReference != null && weakReference.get() == window) {
            return;
        }
        this.currentWindow = new WeakReference((Object)window);
        this.trackCurrentWindow();
    }

    private void stopTrackingWindow(Window window) {
        if (this.trackedWindows.contains((Object)window)) {
            if (this.buildInfoProvider.getSdkInfoVersion() >= 24) {
                try {
                    this.windowFrameMetricsManager.removeOnFrameMetricsAvailableListener(window, this.frameMetricsAvailableListener);
                }
                catch (Exception exception) {
                    this.logger.log(SentryLevel.ERROR, "Failed to remove frameMetricsAvailableListener", exception);
                }
            }
            this.trackedWindows.remove((Object)window);
        }
    }

    private void trackCurrentWindow() {
        Object object = this.currentWindow;
        object = object != null ? (Window)object.get() : null;
        if (object != null && this.isAvailable && !this.trackedWindows.contains(object) && !this.listenerMap.isEmpty() && this.buildInfoProvider.getSdkInfoVersion() >= 24 && this.handler != null) {
            this.trackedWindows.add(object);
            this.windowFrameMetricsManager.addOnFrameMetricsAvailableListener((Window)object, this.frameMetricsAvailableListener, this.handler);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public long getLastKnownFrameStartTimeNanos() {
        Choreographer choreographer = this.choreographer;
        if (choreographer == null) return -1L;
        Field field = this.choreographerLastFrameTimeField;
        if (field == null) return -1L;
        try {
            field = (Long)field.get((Object)choreographer);
            if (field == null) return -1L;
        }
        catch (IllegalAccessException illegalAccessException) {
            return -1L;
        }
        return field.longValue();
    }

    /* synthetic */ void lambda$new$1$io-sentry-android-core-internal-util-SentryFrameMetricsCollector(ILogger iLogger) {
        try {
            this.choreographer = Choreographer.getInstance();
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Error retrieving Choreographer instance. Slow and frozen frames will not be reported.", throwable);
        }
    }

    /* synthetic */ void lambda$new$2$io-sentry-android-core-internal-util-SentryFrameMetricsCollector(BuildInfoProvider buildInfoProvider, Window window, FrameMetrics frameMetrics, int n2) {
        long l2;
        long l3 = System.nanoTime();
        float f2 = buildInfoProvider.getSdkInfoVersion() >= 30 ? window.getContext().getDisplay().getRefreshRate() : window.getWindowManager().getDefaultDisplay().getRefreshRate();
        long l4 = oneSecondInNanos;
        long l5 = (long)((float)l4 / f2);
        long l6 = this.getFrameCpuDuration(frameMetrics);
        long l7 = Math.max((long)0L, (long)(l6 - l5));
        l5 = l2 = this.getFrameStartTimestamp(frameMetrics);
        if (l2 < 0L) {
            l5 = l3 - l6;
        }
        if ((l2 = Math.max((long)l5, (long)this.lastFrameEndNanos)) == this.lastFrameStartNanos) {
            return;
        }
        this.lastFrameStartNanos = l2;
        this.lastFrameEndNanos = l2 + l6;
        boolean bl = SentryFrameMetricsCollector.isSlow(l6, (long)((float)l4 / (f2 - 1.0f)));
        boolean bl2 = bl && SentryFrameMetricsCollector.isFrozen(l6);
        buildInfoProvider = this.listenerMap.values().iterator();
        l5 = l6;
        while (buildInfoProvider.hasNext()) {
            ((FrameMetricsCollectorListener)buildInfoProvider.next()).onFrameMetricCollected(l2, this.lastFrameEndNanos, l5, l7, bl, bl2, f2);
        }
    }

    public void onActivityCreated(Activity activity2, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity2) {
    }

    public void onActivityPaused(Activity activity2) {
    }

    public void onActivityResumed(Activity activity2) {
    }

    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity2) {
        this.setCurrentWindow(activity2.getWindow());
    }

    public void onActivityStopped(Activity activity2) {
        this.stopTrackingWindow(activity2.getWindow());
        WeakReference<Window> weakReference = this.currentWindow;
        if (weakReference != null && weakReference.get() == activity2.getWindow()) {
            this.currentWindow = null;
        }
    }

    public String startCollection(FrameMetricsCollectorListener frameMetricsCollectorListener) {
        if (!this.isAvailable) {
            return null;
        }
        String string2 = UUID.randomUUID().toString();
        this.listenerMap.put((Object)string2, (Object)frameMetricsCollectorListener);
        this.trackCurrentWindow();
        return string2;
    }

    public void stopCollection(String object) {
        if (!this.isAvailable) {
            return;
        }
        if (object != null) {
            this.listenerMap.remove(object);
        }
        if ((object = (object = this.currentWindow) != null ? (Window)object.get() : null) != null && this.listenerMap.isEmpty()) {
            this.stopTrackingWindow((Window)object);
        }
    }

    public static interface FrameMetricsCollectorListener {
        public void onFrameMetricCollected(long var1, long var3, long var5, long var7, boolean var9, boolean var10, float var11);
    }

    public static interface WindowFrameMetricsManager {
        default public void addOnFrameMetricsAvailableListener(Window window, Window.OnFrameMetricsAvailableListener onFrameMetricsAvailableListener, Handler handler) {
            window.addOnFrameMetricsAvailableListener(onFrameMetricsAvailableListener, handler);
        }

        default public void removeOnFrameMetricsAvailableListener(Window window, Window.OnFrameMetricsAvailableListener onFrameMetricsAvailableListener) {
            window.removeOnFrameMetricsAvailableListener(onFrameMetricsAvailableListener);
        }
    }
}

