/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.ISpan;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda2
implements Runnable {
    public final ActivityLifecycleIntegration f$0;
    public final ISpan f$1;
    public final ISpan f$2;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda2(ActivityLifecycleIntegration activityLifecycleIntegration, ISpan iSpan, ISpan iSpan2) {
        this.f$0 = activityLifecycleIntegration;
        this.f$1 = iSpan;
        this.f$2 = iSpan2;
    }

    public final void run() {
        this.f$0.lambda$onActivityResumed$9$io-sentry-android-core-ActivityLifecycleIntegration(this.f$1, this.f$2);
    }
}

