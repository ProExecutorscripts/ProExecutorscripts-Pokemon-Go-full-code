/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.android.core.InternalSentrySdk;
import java.util.concurrent.atomic.AtomicReference;

public final class InternalSentrySdk$$ExternalSyntheticLambda1
implements ScopeCallback {
    public final AtomicReference f$0;

    public /* synthetic */ InternalSentrySdk$$ExternalSyntheticLambda1(AtomicReference atomicReference) {
        this.f$0 = atomicReference;
    }

    @Override
    public final void run(IScope iScope) {
        InternalSentrySdk.lambda$getCurrentScope$0(this.f$0, iScope);
    }
}

