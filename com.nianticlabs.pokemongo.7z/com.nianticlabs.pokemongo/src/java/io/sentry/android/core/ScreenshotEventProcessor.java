/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import android.app.Activity;
import io.sentry.Attachment;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.CurrentActivityHolder;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.AndroidCurrentDateProvider;
import io.sentry.android.core.internal.util.Debouncer;
import io.sentry.android.core.internal.util.ScreenshotUtils;
import io.sentry.protocol.SentryTransaction;
import io.sentry.util.HintUtils;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;

public final class ScreenshotEventProcessor
implements EventProcessor {
    private static final int DEBOUNCE_MAX_EXECUTIONS = 3;
    private static final long DEBOUNCE_WAIT_TIME_MS = 2000L;
    private final BuildInfoProvider buildInfoProvider;
    private final Debouncer debouncer;
    private final SentryAndroidOptions options;

    public ScreenshotEventProcessor(SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider buildInfoProvider) {
        this.options = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
        this.debouncer = new Debouncer(AndroidCurrentDateProvider.getInstance(), 2000L, 3);
        if (sentryAndroidOptions.isAttachScreenshot()) {
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        if (!sentryEvent.isErrored()) {
            return sentryEvent;
        }
        if (!this.options.isAttachScreenshot()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "attachScreenshot is disabled.", new Object[0]);
            return sentryEvent;
        }
        Activity activity2 = CurrentActivityHolder.getInstance().getActivity();
        if (activity2 != null && !HintUtils.isFromHybridSdk(hint)) {
            boolean bl = this.debouncer.checkForDebounce();
            Object object = this.options.getBeforeScreenshotCaptureCallback();
            if (object != null ? !object.execute(sentryEvent, hint, bl) : bl) {
                return sentryEvent;
            }
            object = ScreenshotUtils.takeScreenshot(activity2, this.options.getMainThreadChecker(), this.options.getLogger(), this.buildInfoProvider);
            if (object == null) {
                return sentryEvent;
            }
            hint.setScreenshot(Attachment.fromScreenshot((byte[])object));
            hint.set("android:activity", activity2);
        }
        return sentryEvent;
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        return sentryTransaction;
    }
}

