/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core;

import io.sentry.android.core.SentryPerformanceProvider;
import java.util.concurrent.atomic.AtomicBoolean;

public final class SentryPerformanceProvider$1$$ExternalSyntheticLambda0
implements Runnable {
    public final SentryPerformanceProvider.1 f$0;
    public final AtomicBoolean f$1;

    public /* synthetic */ SentryPerformanceProvider$1$$ExternalSyntheticLambda0(SentryPerformanceProvider.1 var1_1, AtomicBoolean atomicBoolean) {
        this.f$0 = var1_1;
        this.f$1 = atomicBoolean;
    }

    public final void run() {
        this.f$0.lambda$onActivityStarted$0$io-sentry-android-core-SentryPerformanceProvider$1(this.f$1);
    }
}

