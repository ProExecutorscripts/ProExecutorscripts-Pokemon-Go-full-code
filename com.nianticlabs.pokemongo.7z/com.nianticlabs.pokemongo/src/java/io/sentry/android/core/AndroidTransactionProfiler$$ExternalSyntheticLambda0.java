/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry.android.core;

import io.sentry.android.core.AndroidTransactionProfiler;
import java.util.concurrent.Callable;

public final class AndroidTransactionProfiler$$ExternalSyntheticLambda0
implements Callable {
    public final Object call() {
        return AndroidTransactionProfiler.lambda$onTransactionFinish$0();
    }
}

