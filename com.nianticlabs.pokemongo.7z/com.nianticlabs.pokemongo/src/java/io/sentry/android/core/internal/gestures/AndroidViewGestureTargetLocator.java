/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources$NotFoundException
 *  android.view.View
 *  android.widget.AbsListView
 *  android.widget.ScrollView
 *  androidx.core.view.ScrollingView
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.core.internal.gestures;

import android.content.res.Resources;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ScrollView;
import androidx.core.view.ScrollingView;
import io.sentry.android.core.internal.gestures.ViewUtils;
import io.sentry.android.core.internal.util.ClassUtil;
import io.sentry.internal.gestures.GestureTargetLocator;
import io.sentry.internal.gestures.UiElement;

public final class AndroidViewGestureTargetLocator
implements GestureTargetLocator {
    private static final String ORIGIN = "old_view_system";
    private final int[] coordinates = new int[2];
    private final boolean isAndroidXAvailable;

    public AndroidViewGestureTargetLocator(boolean bl) {
        this.isAndroidXAvailable = bl;
    }

    private UiElement createUiElement(View object) {
        try {
            String string2 = ViewUtils.getResourceId(object);
            object = new UiElement(object, ClassUtil.getClassName(object), string2, null, ORIGIN);
            return object;
        }
        catch (Resources.NotFoundException notFoundException) {
            return null;
        }
    }

    private static boolean isJetpackScrollingView(View view2, boolean bl) {
        if (!bl) {
            return false;
        }
        return ScrollingView.class.isAssignableFrom(view2.getClass());
    }

    private static boolean isViewScrollable(View view2, boolean bl) {
        bl = (AndroidViewGestureTargetLocator.isJetpackScrollingView(view2, bl) || AbsListView.class.isAssignableFrom(view2.getClass()) || ScrollView.class.isAssignableFrom(view2.getClass())) && view2.getVisibility() == 0;
        return bl;
    }

    private static boolean isViewTappable(View view2) {
        boolean bl = view2.isClickable() && view2.getVisibility() == 0;
        return bl;
    }

    private boolean touchWithinBounds(View view2, float f2, float f3) {
        view2.getLocationOnScreen(this.coordinates);
        int[] nArray = this.coordinates;
        boolean bl = false;
        int n2 = nArray[0];
        int n3 = nArray[1];
        int n4 = view2.getWidth();
        int n5 = view2.getHeight();
        boolean bl2 = bl;
        if (!(f2 < (float)n2)) {
            bl2 = bl;
            if (!(f2 > (float)(n2 + n4))) {
                bl2 = bl;
                if (!(f3 < (float)n3)) {
                    bl2 = bl;
                    if (!(f3 > (float)(n3 + n5))) {
                        bl2 = true;
                    }
                }
            }
        }
        return bl2;
    }

    @Override
    public UiElement locate(Object object, float f2, float f3, UiElement.Type type) {
        if (!(object instanceof View)) {
            return null;
        }
        if (this.touchWithinBounds((View)(object = (View)object), f2, f3)) {
            if (type == UiElement.Type.CLICKABLE && AndroidViewGestureTargetLocator.isViewTappable((View)object)) {
                return this.createUiElement((View)object);
            }
            if (type == UiElement.Type.SCROLLABLE && AndroidViewGestureTargetLocator.isViewScrollable((View)object, this.isAndroidXAvailable)) {
                return this.createUiElement((View)object);
            }
        }
        return null;
    }
}

