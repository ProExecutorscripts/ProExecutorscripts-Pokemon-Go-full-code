/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Process
 *  android.os.SystemClock
 *  io.sentry.android.fragment.FragmentLifecycleIntegration
 *  io.sentry.android.timber.SentryTimberIntegration
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.InstantiationException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.util.ArrayList
 */
package io.sentry.android.core;

import android.content.Context;
import android.os.Process;
import android.os.SystemClock;
import io.sentry.ILogger;
import io.sentry.Integration;
import io.sentry.OptionsContainer;
import io.sentry.Sentry;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.ActivityFramesTracker;
import io.sentry.android.core.AndroidLogger;
import io.sentry.android.core.AndroidOptionsInitializer;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.LoadClass;
import io.sentry.android.core.SentryAndroid$$ExternalSyntheticLambda0;
import io.sentry.android.core.SentryAndroid$$ExternalSyntheticLambda1;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.BreadcrumbFactory;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.android.fragment.FragmentLifecycleIntegration;
import io.sentry.android.timber.SentryTimberIntegration;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

public final class SentryAndroid {
    private static final String FRAGMENT_CLASS_NAME = "androidx.fragment.app.FragmentManager$FragmentLifecycleCallbacks";
    static final String SENTRY_FRAGMENT_INTEGRATION_CLASS_NAME = "io.sentry.android.fragment.FragmentLifecycleIntegration";
    static final String SENTRY_TIMBER_INTEGRATION_CLASS_NAME = "io.sentry.android.timber.SentryTimberIntegration";
    private static final String TIMBER_CLASS_NAME = "timber.log.Timber";
    private static final long sdkInitMillis = SystemClock.uptimeMillis();

    private SentryAndroid() {
    }

    private static void deduplicateIntegrations(SentryOptions sentryOptions, boolean bl, boolean bl2) {
        ArrayList arrayList = new ArrayList();
        Object object = new ArrayList();
        for (Integration integration : sentryOptions.getIntegrations()) {
            if (bl && integration instanceof FragmentLifecycleIntegration) {
                object.add((Object)integration);
            }
            if (!bl2 || !(integration instanceof SentryTimberIntegration)) continue;
            arrayList.add((Object)integration);
        }
        int n2 = object.size();
        int n3 = 0;
        if (n2 > 1) {
            for (n2 = 0; n2 < object.size() - 1; ++n2) {
                Integration integration;
                integration = (Integration)object.get(n2);
                sentryOptions.getIntegrations().remove((Object)integration);
            }
        }
        if (arrayList.size() > 1) {
            for (n2 = n3; n2 < arrayList.size() - 1; ++n2) {
                object = (Integration)arrayList.get(n2);
                sentryOptions.getIntegrations().remove(object);
            }
        }
    }

    public static void init(Context context) {
        SentryAndroid.init(context, new AndroidLogger());
    }

    public static void init(Context context, ILogger iLogger) {
        SentryAndroid.init(context, iLogger, new SentryAndroid$$ExternalSyntheticLambda1());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void init(Context object, ILogger object2, Sentry.OptionsConfiguration<SentryAndroidOptions> optionsConfiguration) {
        Class<SentryAndroid> clazz = SentryAndroid.class;
        synchronized (SentryAndroid.class) {
            try {
                try {
                    OptionsContainer<SentryAndroidOptions> optionsContainer = OptionsContainer.create(SentryAndroidOptions.class);
                    SentryAndroid$$ExternalSyntheticLambda0 sentryAndroid$$ExternalSyntheticLambda0 = new SentryAndroid$$ExternalSyntheticLambda0((ILogger)object2, (Context)object, optionsConfiguration);
                    Sentry.init(optionsContainer, sentryAndroid$$ExternalSyntheticLambda0, true);
                    object = Sentry.getCurrentHub();
                    if (object.getOptions().isEnableAutoSessionTracking() && ContextUtils.isForegroundImportance()) {
                        object.addBreadcrumb(BreadcrumbFactory.forSession("session.start"));
                        object.startSession();
                    }
                    // ** MonitorExit[var5_8] (shouldn't be in output)
                    return;
                }
                catch (InvocationTargetException invocationTargetException) {
                    object2.log(SentryLevel.FATAL, "Fatal error during SentryAndroid.init(...)", invocationTargetException);
                    object2 = new RuntimeException("Failed to initialize Sentry's SDK", (Throwable)invocationTargetException);
                    throw object2;
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    object2.log(SentryLevel.FATAL, "Fatal error during SentryAndroid.init(...)", noSuchMethodException);
                    object2 = new RuntimeException("Failed to initialize Sentry's SDK", (Throwable)noSuchMethodException);
                    throw object2;
                }
                catch (InstantiationException instantiationException) {
                    object2.log(SentryLevel.FATAL, "Fatal error during SentryAndroid.init(...)", instantiationException);
                    object2 = new RuntimeException("Failed to initialize Sentry's SDK", (Throwable)instantiationException);
                    throw object2;
                }
                catch (IllegalAccessException illegalAccessException) {
                    object2.log(SentryLevel.FATAL, "Fatal error during SentryAndroid.init(...)", illegalAccessException);
                    object2 = new RuntimeException("Failed to initialize Sentry's SDK", (Throwable)illegalAccessException);
                    throw object2;
                }
            }
            catch (Throwable throwable) {}
            throw throwable;
        }
    }

    public static void init(Context context, Sentry.OptionsConfiguration<SentryAndroidOptions> optionsConfiguration) {
        SentryAndroid.init(context, new AndroidLogger(), optionsConfiguration);
    }

    static /* synthetic */ void lambda$init$0(SentryAndroidOptions sentryAndroidOptions) {
    }

    static /* synthetic */ void lambda$init$1(ILogger object, Context context, Sentry.OptionsConfiguration object2, SentryAndroidOptions sentryAndroidOptions) {
        Object object3 = new LoadClass();
        boolean bl = ((LoadClass)object3).isClassAvailable(TIMBER_CLASS_NAME, sentryAndroidOptions);
        boolean bl2 = ((LoadClass)object3).isClassAvailable(FRAGMENT_CLASS_NAME, sentryAndroidOptions);
        boolean bl3 = true;
        bl2 = bl2 && ((LoadClass)object3).isClassAvailable(SENTRY_FRAGMENT_INTEGRATION_CLASS_NAME, sentryAndroidOptions);
        if (!bl || !((LoadClass)object3).isClassAvailable(SENTRY_TIMBER_INTEGRATION_CLASS_NAME, sentryAndroidOptions)) {
            bl3 = false;
        }
        object3 = new BuildInfoProvider((ILogger)object);
        LoadClass loadClass = new LoadClass();
        ActivityFramesTracker activityFramesTracker = new ActivityFramesTracker(loadClass, sentryAndroidOptions);
        AndroidOptionsInitializer.loadDefaultAndMetadataOptions(sentryAndroidOptions, context, (ILogger)object, (BuildInfoProvider)object3);
        AndroidOptionsInitializer.installDefaultIntegrations(context, sentryAndroidOptions, (BuildInfoProvider)object3, loadClass, activityFramesTracker, bl2, bl3);
        object2.configure(sentryAndroidOptions);
        object = AppStartMetrics.getInstance();
        if (sentryAndroidOptions.isEnablePerformanceV2() && ((BuildInfoProvider)object3).getSdkInfoVersion() >= 24 && ((TimeSpan)(object2 = ((AppStartMetrics)object).getAppStartTimeSpan())).hasNotStarted()) {
            ((TimeSpan)object2).setStartedAt(Process.getStartUptimeMillis());
        }
        if (((TimeSpan)(object = ((AppStartMetrics)object).getSdkInitTimeSpan())).hasNotStarted()) {
            ((TimeSpan)object).setStartedAt(sdkInitMillis);
        }
        AndroidOptionsInitializer.initializeIntegrationsAndProcessors(sentryAndroidOptions, context, (BuildInfoProvider)object3, loadClass, activityFramesTracker);
        SentryAndroid.deduplicateIntegrations(sentryAndroidOptions, bl2, bl3);
    }
}

