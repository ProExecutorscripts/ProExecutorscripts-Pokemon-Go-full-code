/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.content.pm.ProviderInfo
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Process
 *  android.os.SystemClock
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.WeakHashMap
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.os.SystemClock;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.ITransactionProfiler;
import io.sentry.JsonSerializer;
import io.sentry.NoOpLogger;
import io.sentry.SentryAppStartProfilingOptions;
import io.sentry.SentryExecutorService;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.TracesSamplingDecision;
import io.sentry.android.core.AndroidLogger;
import io.sentry.android.core.AndroidOptionsInitializer;
import io.sentry.android.core.AndroidTransactionProfiler;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.EmptySecureContentProvider;
import io.sentry.android.core.SentryPerformanceProvider$1$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.FirstDrawDoneListener;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import io.sentry.android.core.performance.ActivityLifecycleCallbacksAdapter;
import io.sentry.android.core.performance.ActivityLifecycleTimeSpan;
import io.sentry.android.core.performance.AppStartMetrics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public final class SentryPerformanceProvider
extends EmptySecureContentProvider {
    private static final long sdkInitMillis = SystemClock.uptimeMillis();
    private Application.ActivityLifecycleCallbacks activityCallback;
    private Application app;
    private final BuildInfoProvider buildInfoProvider;
    private final ILogger logger;

    public SentryPerformanceProvider() {
        AndroidLogger androidLogger = new AndroidLogger();
        this.logger = androidLogger;
        this.buildInfoProvider = new BuildInfoProvider(androidLogger);
    }

    SentryPerformanceProvider(ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        this.logger = iLogger;
        this.buildInfoProvider = buildInfoProvider;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void launchAppStartProfiler(AppStartMetrics appStartMetrics) {
        BufferedReader bufferedReader;
        block20: {
            Object object;
            Object object2;
            Context context;
            block19: {
                block18: {
                    context = this.getContext();
                    if (context == null) {
                        this.logger.log(SentryLevel.FATAL, "App. Context from ContentProvider is null", new Object[0]);
                        return;
                    }
                    if (this.buildInfoProvider.getSdkInfoVersion() < 21) {
                        return;
                    }
                    File file = new File(AndroidOptionsInitializer.getCacheDir(context), "app_start_profiling_config");
                    if (!file.exists() || !file.canRead()) return;
                    object2 = new FileInputStream(file);
                    object = new InputStreamReader((InputStream)object2);
                    bufferedReader = new BufferedReader((Reader)object);
                    object2 = new JsonSerializer(SentryOptions.empty());
                    object = ((JsonSerializer)object2).deserialize((Reader)bufferedReader, SentryAppStartProfilingOptions.class);
                    if (object != null) break block18;
                    this.logger.log(SentryLevel.WARNING, "Unable to deserialize the SentryAppStartProfilingOptions. App start profiling will not start.", new Object[0]);
                    bufferedReader.close();
                    return;
                }
                if (((SentryAppStartProfilingOptions)object).isProfilingEnabled()) break block19;
                this.logger.log(SentryLevel.INFO, "Profiling is not enabled. App start profiling will not start.", new Object[0]);
                bufferedReader.close();
                return;
            }
            object2 = new TracesSamplingDecision(((SentryAppStartProfilingOptions)object).isTraceSampled(), ((SentryAppStartProfilingOptions)object).getTraceSampleRate(), ((SentryAppStartProfilingOptions)object).isProfileSampled(), ((SentryAppStartProfilingOptions)object).getProfileSampleRate());
            appStartMetrics.setAppStartSamplingDecision((TracesSamplingDecision)object2);
            if (!((TracesSamplingDecision)object2).getProfileSampled().booleanValue() || !((TracesSamplingDecision)object2).getSampled().booleanValue()) break block20;
            this.logger.log(SentryLevel.DEBUG, "App start profiling started.", new Object[0]);
            Context context2 = context.getApplicationContext();
            BuildInfoProvider buildInfoProvider = this.buildInfoProvider;
            SentryFrameMetricsCollector sentryFrameMetricsCollector = new SentryFrameMetricsCollector(context.getApplicationContext(), this.logger, this.buildInfoProvider);
            ILogger iLogger = this.logger;
            String string2 = ((SentryAppStartProfilingOptions)object).getProfilingTracesDirPath();
            boolean bl = ((SentryAppStartProfilingOptions)object).isProfilingEnabled();
            int n2 = ((SentryAppStartProfilingOptions)object).getProfilingTracesHz();
            object = new SentryExecutorService();
            object2 = new AndroidTransactionProfiler(context2, buildInfoProvider, sentryFrameMetricsCollector, iLogger, string2, bl, n2, (ISentryExecutorService)object);
            appStartMetrics.setAppStartProfiler((ITransactionProfiler)object2);
            object2.start();
            bufferedReader.close();
            return;
        }
        this.logger.log(SentryLevel.DEBUG, "App start profiling was not sampled. It will not start.", new Object[0]);
        bufferedReader.close();
        return;
        catch (Throwable throwable) {
            try {
                bufferedReader.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (Throwable throwable3) {
                    this.logger.log(SentryLevel.ERROR, "Error reading app start profiling config file. ", throwable3);
                    return;
                }
                catch (FileNotFoundException fileNotFoundException) {
                    this.logger.log(SentryLevel.ERROR, "App start profiling config file not found. ", fileNotFoundException);
                }
            }
        }
    }

    private void onAppLaunched(Context object, AppStartMetrics appStartMetrics) {
        appStartMetrics.getSdkInitTimeSpan().setStartedAt(sdkInitMillis);
        if (this.buildInfoProvider.getSdkInfoVersion() < 24) {
            return;
        }
        if (object instanceof Application) {
            this.app = (Application)object;
        }
        if (this.app == null) {
            return;
        }
        appStartMetrics.getAppStartTimeSpan().setStartedAt(Process.getStartUptimeMillis());
        object = new ActivityLifecycleCallbacksAdapter(this, appStartMetrics, new AtomicBoolean(false)){
            final WeakHashMap<Activity, ActivityLifecycleTimeSpan> activityLifecycleMap;
            final SentryPerformanceProvider this$0;
            final AppStartMetrics val$appStartMetrics;
            final AtomicBoolean val$firstDrawDone;
            {
                this.this$0 = sentryPerformanceProvider;
                this.val$appStartMetrics = appStartMetrics;
                this.val$firstDrawDone = atomicBoolean;
                this.activityLifecycleMap = new WeakHashMap();
            }

            /* synthetic */ void lambda$onActivityStarted$0$io-sentry-android-core-SentryPerformanceProvider$1(AtomicBoolean atomicBoolean) {
                if (atomicBoolean.compareAndSet(false, true)) {
                    this.this$0.onAppStartDone();
                }
            }

            @Override
            public void onActivityCreated(Activity object, Bundle bundle) {
                if (this.val$appStartMetrics.getAppStartType() == AppStartMetrics.AppStartType.UNKNOWN) {
                    AppStartMetrics appStartMetrics = this.val$appStartMetrics;
                    object = bundle == null ? AppStartMetrics.AppStartType.COLD : AppStartMetrics.AppStartType.WARM;
                    appStartMetrics.setAppStartType((AppStartMetrics.AppStartType)((Object)object));
                }
            }

            @Override
            public void onActivityDestroyed(Activity activity2) {
                this.activityLifecycleMap.remove((Object)activity2);
            }

            public void onActivityPostCreated(Activity activity2, Bundle object) {
                if (this.val$appStartMetrics.getAppStartTimeSpan().hasStopped()) {
                    return;
                }
                object = (ActivityLifecycleTimeSpan)this.activityLifecycleMap.get((Object)activity2);
                if (object != null) {
                    ((ActivityLifecycleTimeSpan)object).getOnCreate().stop();
                    ((ActivityLifecycleTimeSpan)object).getOnCreate().setDescription(activity2.getClass().getName() + ".onCreate");
                }
            }

            public void onActivityPostStarted(Activity activity2) {
                ActivityLifecycleTimeSpan activityLifecycleTimeSpan = (ActivityLifecycleTimeSpan)this.activityLifecycleMap.remove((Object)activity2);
                if (this.val$appStartMetrics.getAppStartTimeSpan().hasStopped()) {
                    return;
                }
                if (activityLifecycleTimeSpan != null) {
                    activityLifecycleTimeSpan.getOnStart().stop();
                    activityLifecycleTimeSpan.getOnStart().setDescription(activity2.getClass().getName() + ".onStart");
                    this.val$appStartMetrics.addActivityLifecycleTimeSpans(activityLifecycleTimeSpan);
                }
            }

            public void onActivityPreCreated(Activity activity2, Bundle object) {
                long l2 = SystemClock.uptimeMillis();
                if (this.val$appStartMetrics.getAppStartTimeSpan().hasStopped()) {
                    return;
                }
                object = new ActivityLifecycleTimeSpan();
                ((ActivityLifecycleTimeSpan)object).getOnCreate().setStartedAt(l2);
                this.activityLifecycleMap.put((Object)activity2, object);
            }

            public void onActivityPreStarted(Activity object) {
                long l2 = SystemClock.uptimeMillis();
                if (this.val$appStartMetrics.getAppStartTimeSpan().hasStopped()) {
                    return;
                }
                if ((object = (ActivityLifecycleTimeSpan)this.activityLifecycleMap.get(object)) != null) {
                    ((ActivityLifecycleTimeSpan)object).getOnStart().setStartedAt(l2);
                }
            }

            @Override
            public void onActivityStarted(Activity activity2) {
                if (this.val$firstDrawDone.get()) {
                    return;
                }
                FirstDrawDoneListener.registerForNextDraw(activity2, (Runnable)new SentryPerformanceProvider$1$$ExternalSyntheticLambda0(this, this.val$firstDrawDone), new BuildInfoProvider(NoOpLogger.getInstance()));
            }
        };
        this.activityCallback = object;
        this.app.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)object);
    }

    public void attachInfo(Context context, ProviderInfo providerInfo) {
        if (!SentryPerformanceProvider.class.getName().equals((Object)providerInfo.authority)) {
            super.attachInfo(context, providerInfo);
            return;
        }
        throw new IllegalStateException("An applicationId is required to fulfill the manifest placeholder.");
    }

    Application.ActivityLifecycleCallbacks getActivityCallback() {
        return this.activityCallback;
    }

    public String getType(Uri uri) {
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void onAppStartDone() {
        SentryPerformanceProvider sentryPerformanceProvider = this;
        synchronized (sentryPerformanceProvider) {
            Application.ActivityLifecycleCallbacks activityLifecycleCallbacks;
            AppStartMetrics appStartMetrics = AppStartMetrics.getInstance();
            appStartMetrics.getSdkInitTimeSpan().stop();
            appStartMetrics.getAppStartTimeSpan().stop();
            appStartMetrics = this.app;
            if (appStartMetrics != null && (activityLifecycleCallbacks = this.activityCallback) != null) {
                appStartMetrics.unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks);
            }
            return;
        }
    }

    public boolean onCreate() {
        AppStartMetrics appStartMetrics = AppStartMetrics.getInstance();
        this.onAppLaunched(this.getContext(), appStartMetrics);
        this.launchAppStartProfiler(appStartMetrics);
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void shutdown() {
        AppStartMetrics appStartMetrics;
        AppStartMetrics appStartMetrics2 = appStartMetrics = AppStartMetrics.getInstance();
        synchronized (appStartMetrics2) {
            ITransactionProfiler iTransactionProfiler = AppStartMetrics.getInstance().getAppStartProfiler();
            if (iTransactionProfiler != null) {
                iTransactionProfiler.close();
            }
            return;
        }
    }
}

