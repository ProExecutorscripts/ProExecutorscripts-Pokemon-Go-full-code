/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package io.sentry.android.core;

import android.content.Context;
import io.sentry.Integration;
import io.sentry.android.core.AnrIntegration;
import io.sentry.android.core.AnrV2Integration;
import io.sentry.android.core.BuildInfoProvider;

public final class AnrIntegrationFactory {
    public static Integration create(Context context, BuildInfoProvider buildInfoProvider) {
        if (buildInfoProvider.getSdkInfoVersion() >= 30) {
            return new AnrV2Integration(context);
        }
        return new AnrIntegration(context);
    }
}

