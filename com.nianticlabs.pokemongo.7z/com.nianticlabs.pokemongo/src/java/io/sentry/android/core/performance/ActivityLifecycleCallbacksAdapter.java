/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  java.lang.Object
 */
package io.sentry.android.core.performance;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public class ActivityLifecycleCallbacksAdapter
implements Application.ActivityLifecycleCallbacks {
    public void onActivityCreated(Activity activity2, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity2) {
    }

    public void onActivityPaused(Activity activity2) {
    }

    public void onActivityResumed(Activity activity2) {
    }

    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity2) {
    }

    public void onActivityStopped(Activity activity2) {
    }
}

