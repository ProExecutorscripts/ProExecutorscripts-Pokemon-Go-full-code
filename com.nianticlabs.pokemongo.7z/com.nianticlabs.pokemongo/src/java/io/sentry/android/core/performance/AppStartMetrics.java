/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.ContentProvider
 *  android.os.SystemClock
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package io.sentry.android.core.performance;

import android.app.Application;
import android.content.ContentProvider;
import android.os.SystemClock;
import io.sentry.ITransactionProfiler;
import io.sentry.TracesSamplingDecision;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.performance.ActivityLifecycleTimeSpan;
import io.sentry.android.core.performance.TimeSpan;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppStartMetrics {
    private static long CLASS_LOADED_UPTIME_MS = SystemClock.uptimeMillis();
    private static volatile AppStartMetrics instance;
    private final List<ActivityLifecycleTimeSpan> activityLifecycles;
    private boolean appLaunchedInForeground = false;
    private ITransactionProfiler appStartProfiler = null;
    private TracesSamplingDecision appStartSamplingDecision = null;
    private final TimeSpan appStartSpan;
    private AppStartType appStartType = AppStartType.UNKNOWN;
    private final TimeSpan applicationOnCreate;
    private final Map<ContentProvider, TimeSpan> contentProviderOnCreates;
    private final TimeSpan sdkInitTimeSpan;

    public AppStartMetrics() {
        this.appStartSpan = new TimeSpan();
        this.sdkInitTimeSpan = new TimeSpan();
        this.applicationOnCreate = new TimeSpan();
        this.contentProviderOnCreates = new HashMap();
        this.activityLifecycles = new ArrayList();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static AppStartMetrics getInstance() {
        if (instance != null) return instance;
        Class<AppStartMetrics> clazz = AppStartMetrics.class;
        synchronized (AppStartMetrics.class) {
            AppStartMetrics appStartMetrics;
            if (instance != null) return instance;
            instance = appStartMetrics = new AppStartMetrics();
            // ** MonitorExit[var1] (shouldn't be in output)
            return instance;
        }
    }

    public static void onApplicationCreate(Application object) {
        long l2 = SystemClock.uptimeMillis();
        object = AppStartMetrics.getInstance();
        if (object.applicationOnCreate.hasNotStarted()) {
            object.applicationOnCreate.setStartedAt(l2);
            object.appLaunchedInForeground = ContextUtils.isForegroundImportance();
        }
    }

    public static void onApplicationPostCreate(Application application) {
        long l2 = SystemClock.uptimeMillis();
        AppStartMetrics appStartMetrics = AppStartMetrics.getInstance();
        if (appStartMetrics.applicationOnCreate.hasNotStopped()) {
            appStartMetrics.applicationOnCreate.setDescription(application.getClass().getName() + ".onCreate");
            appStartMetrics.applicationOnCreate.setStoppedAt(l2);
        }
    }

    public static void onContentProviderCreate(ContentProvider contentProvider) {
        long l2 = SystemClock.uptimeMillis();
        TimeSpan timeSpan = new TimeSpan();
        timeSpan.setStartedAt(l2);
        AppStartMetrics.getInstance().contentProviderOnCreates.put((Object)contentProvider, (Object)timeSpan);
    }

    public static void onContentProviderPostCreate(ContentProvider contentProvider) {
        long l2 = SystemClock.uptimeMillis();
        TimeSpan timeSpan = (TimeSpan)AppStartMetrics.getInstance().contentProviderOnCreates.get((Object)contentProvider);
        if (timeSpan != null && timeSpan.hasNotStopped()) {
            timeSpan.setDescription(contentProvider.getClass().getName() + ".onCreate");
            timeSpan.setStoppedAt(l2);
        }
    }

    public void addActivityLifecycleTimeSpans(ActivityLifecycleTimeSpan activityLifecycleTimeSpan) {
        this.activityLifecycles.add((Object)activityLifecycleTimeSpan);
    }

    public void clear() {
        this.appStartType = AppStartType.UNKNOWN;
        this.appStartSpan.reset();
        this.sdkInitTimeSpan.reset();
        this.applicationOnCreate.reset();
        this.contentProviderOnCreates.clear();
        this.activityLifecycles.clear();
        ITransactionProfiler iTransactionProfiler = this.appStartProfiler;
        if (iTransactionProfiler != null) {
            iTransactionProfiler.close();
        }
        this.appStartProfiler = null;
        this.appStartSamplingDecision = null;
    }

    public List<ActivityLifecycleTimeSpan> getActivityLifecycleTimeSpans() {
        ArrayList arrayList = new ArrayList(this.activityLifecycles);
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public ITransactionProfiler getAppStartProfiler() {
        return this.appStartProfiler;
    }

    public TracesSamplingDecision getAppStartSamplingDecision() {
        return this.appStartSamplingDecision;
    }

    public TimeSpan getAppStartTimeSpan() {
        return this.appStartSpan;
    }

    public TimeSpan getAppStartTimeSpanWithFallback(SentryAndroidOptions object) {
        if (((SentryAndroidOptions)object).isEnablePerformanceV2() && ((TimeSpan)(object = this.getAppStartTimeSpan())).hasStarted()) {
            return object;
        }
        return this.getSdkInitTimeSpan();
    }

    public AppStartType getAppStartType() {
        return this.appStartType;
    }

    public TimeSpan getApplicationOnCreateTimeSpan() {
        return this.applicationOnCreate;
    }

    public long getClassLoadedUptimeMs() {
        return CLASS_LOADED_UPTIME_MS;
    }

    public List<TimeSpan> getContentProviderOnCreateTimeSpans() {
        ArrayList arrayList = new ArrayList(this.contentProviderOnCreates.values());
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public TimeSpan getSdkInitTimeSpan() {
        return this.sdkInitTimeSpan;
    }

    public boolean isAppLaunchedInForeground() {
        return this.appLaunchedInForeground;
    }

    public void setAppStartProfiler(ITransactionProfiler iTransactionProfiler) {
        this.appStartProfiler = iTransactionProfiler;
    }

    public void setAppStartSamplingDecision(TracesSamplingDecision tracesSamplingDecision) {
        this.appStartSamplingDecision = tracesSamplingDecision;
    }

    public void setAppStartType(AppStartType appStartType) {
        this.appStartType = appStartType;
    }

    public void setClassLoadedUptimeMs(long l2) {
        CLASS_LOADED_UPTIME_MS = l2;
    }

    public static enum AppStartType {
        UNKNOWN,
        COLD,
        WARM;

    }
}

