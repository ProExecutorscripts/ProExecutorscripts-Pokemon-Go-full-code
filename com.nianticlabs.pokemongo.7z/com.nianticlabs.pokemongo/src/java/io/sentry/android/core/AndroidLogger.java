/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.util.Log;
import io.sentry.ILogger;
import io.sentry.SentryLevel;

public final class AndroidLogger
implements ILogger {
    private final String tag;

    public AndroidLogger() {
        this("Sentry");
    }

    public AndroidLogger(String string2) {
        this.tag = string2;
    }

    private int toLogcatLevel(SentryLevel sentryLevel) {
        int n2 = 1.$SwitchMap$io$sentry$SentryLevel[sentryLevel.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 4) {
                    return 3;
                }
                return 7;
            }
            return 5;
        }
        return 4;
    }

    @Override
    public boolean isEnabled(SentryLevel sentryLevel) {
        return true;
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Throwable throwable) {
        int n2 = 1.$SwitchMap$io$sentry$SentryLevel[sentryLevel.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        Log.d((String)this.tag, (String)string2, (Throwable)throwable);
                    } else {
                        Log.wtf((String)this.tag, (String)string2, (Throwable)throwable);
                    }
                } else {
                    Log.e((String)this.tag, (String)string2, (Throwable)throwable);
                }
            } else {
                Log.w((String)this.tag, (String)string2, (Throwable)throwable);
            }
        } else {
            Log.i((String)this.tag, (String)string2, (Throwable)throwable);
        }
    }

    @Override
    public void log(SentryLevel sentryLevel, String string2, Object ... objectArray) {
        Log.println((int)this.toLogcatLevel(sentryLevel), (String)this.tag, (String)String.format((String)string2, (Object[])objectArray));
    }

    @Override
    public void log(SentryLevel sentryLevel, Throwable throwable, String string2, Object ... objectArray) {
        this.log(sentryLevel, String.format((String)string2, (Object[])objectArray), throwable);
    }
}

