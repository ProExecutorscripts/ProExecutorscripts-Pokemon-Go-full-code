/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$ProcessErrorStateInfo
 *  android.content.Context
 *  android.os.Debug
 *  android.os.SystemClock
 *  java.lang.IllegalArgumentException
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;
import android.os.SystemClock;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.android.core.ANRWatchDog$$ExternalSyntheticLambda0;
import io.sentry.android.core.ANRWatchDog$$ExternalSyntheticLambda1;
import io.sentry.android.core.ApplicationNotResponding;
import io.sentry.android.core.MainLooperHandler;
import io.sentry.transport.ICurrentDateProvider;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
final class ANRWatchDog
extends Thread {
    private final ANRListener anrListener;
    private final Context context;
    private volatile long lastKnownActiveUiTimestampMs = 0L;
    private final ILogger logger;
    private long pollingIntervalMs;
    private final boolean reportInDebug;
    private final AtomicBoolean reported = new AtomicBoolean(false);
    private final Runnable ticker;
    private final ICurrentDateProvider timeProvider;
    private final long timeoutIntervalMillis;
    private final MainLooperHandler uiHandler;

    ANRWatchDog(long l2, boolean bl, ANRListener aNRListener, ILogger iLogger, Context context) {
        this(new ANRWatchDog$$ExternalSyntheticLambda1(), l2, 500L, bl, aNRListener, iLogger, new MainLooperHandler(), context);
    }

    ANRWatchDog(ICurrentDateProvider iCurrentDateProvider, long l2, long l3, boolean bl, ANRListener aNRListener, ILogger iLogger, MainLooperHandler mainLooperHandler, Context context) {
        super("|ANR-WatchDog|");
        this.timeProvider = iCurrentDateProvider;
        this.timeoutIntervalMillis = l2;
        this.pollingIntervalMs = l3;
        this.reportInDebug = bl;
        this.anrListener = aNRListener;
        this.logger = iLogger;
        this.uiHandler = mainLooperHandler;
        this.context = context;
        this.ticker = new ANRWatchDog$$ExternalSyntheticLambda0(this, iCurrentDateProvider);
        if (l2 >= this.pollingIntervalMs * 2L) {
            return;
        }
        throw new IllegalArgumentException(String.format((String)"ANRWatchDog: timeoutIntervalMillis has to be at least %d ms", (Object[])new Object[]{this.pollingIntervalMs * 2L}));
    }

    private boolean isProcessNotResponding() {
        ActivityManager activityManager = (ActivityManager)this.context.getSystemService("activity");
        if (activityManager != null) {
            try {
                activityManager = activityManager.getProcessesInErrorState();
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.ERROR, "Error getting ActivityManager#getProcessesInErrorState.", throwable);
                activityManager = null;
            }
            if (activityManager != null) {
                activityManager = activityManager.iterator();
                while (activityManager.hasNext()) {
                    if (((ActivityManager.ProcessErrorStateInfo)activityManager.next()).condition != 2) continue;
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    static /* synthetic */ long lambda$new$0() {
        return SystemClock.uptimeMillis();
    }

    /* synthetic */ void lambda$new$1$io-sentry-android-core-ANRWatchDog(ICurrentDateProvider iCurrentDateProvider) {
        this.lastKnownActiveUiTimestampMs = iCurrentDateProvider.getCurrentTimeMillis();
        this.reported.set(false);
    }

    public void run() {
        this.ticker.run();
        while (!this.isInterrupted()) {
            this.uiHandler.post(this.ticker);
            try {
                Thread.sleep((long)this.pollingIntervalMs);
            }
            catch (InterruptedException interruptedException) {
                try {
                    Thread.currentThread().interrupt();
                }
                catch (SecurityException securityException) {
                    this.logger.log(SentryLevel.WARNING, "Failed to interrupt due to SecurityException: %s", interruptedException.getMessage());
                    break;
                }
                this.logger.log(SentryLevel.WARNING, "Interrupted: %s", interruptedException.getMessage());
                return;
            }
            if (this.timeProvider.getCurrentTimeMillis() - this.lastKnownActiveUiTimestampMs <= this.timeoutIntervalMillis) continue;
            if (!this.reportInDebug && (Debug.isDebuggerConnected() || Debug.waitingForDebugger())) {
                this.logger.log(SentryLevel.DEBUG, "An ANR was detected but ignored because the debugger is connected.", new Object[0]);
                this.reported.set(true);
                continue;
            }
            if (!this.isProcessNotResponding() || !this.reported.compareAndSet(false, true)) continue;
            ApplicationNotResponding applicationNotResponding = new ApplicationNotResponding("Application Not Responding for at least " + this.timeoutIntervalMillis + " ms.", this.uiHandler.getThread());
            this.anrListener.onAppNotResponding(applicationNotResponding);
        }
    }

    public static interface ANRListener {
        public void onAppNotResponding(ApplicationNotResponding var1);
    }
}

