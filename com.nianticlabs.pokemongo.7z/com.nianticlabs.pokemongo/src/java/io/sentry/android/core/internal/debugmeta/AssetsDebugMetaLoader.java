/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  java.io.BufferedInputStream
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.RuntimeException
 *  java.lang.Throwable
 *  java.util.Collections
 *  java.util.List
 *  java.util.Properties
 */
package io.sentry.android.core.internal.debugmeta;

import android.content.Context;
import android.content.res.AssetManager;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.internal.debugmeta.IDebugMetaLoader;
import io.sentry.util.DebugMetaPropertiesApplier;
import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public final class AssetsDebugMetaLoader
implements IDebugMetaLoader {
    private final Context context;
    private final ILogger logger;

    public AssetsDebugMetaLoader(Context context, ILogger iLogger) {
        this.context = context;
        this.logger = iLogger;
    }

    /*
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public List<Properties> loadDebugMeta() {
        AssetManager assetManager = this.context.getAssets();
        BufferedInputStream bufferedInputStream = new BufferedInputStream(assetManager.open(DebugMetaPropertiesApplier.DEBUG_META_PROPERTIES_FILENAME));
        assetManager = new Properties();
        assetManager.load((InputStream)bufferedInputStream);
        assetManager = Collections.singletonList((Object)assetManager);
        bufferedInputStream.close();
        return assetManager;
        catch (Throwable throwable) {
            try {
                bufferedInputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    throwable.addSuppressed(throwable2);
                    throw throwable;
                }
                catch (RuntimeException runtimeException) {
                    this.logger.log(SentryLevel.ERROR, runtimeException, "%s file is malformed.", DebugMetaPropertiesApplier.DEBUG_META_PROPERTIES_FILENAME);
                    return null;
                }
                catch (IOException iOException) {
                    this.logger.log(SentryLevel.ERROR, "Error getting Proguard UUIDs.", iOException);
                    return null;
                }
                catch (FileNotFoundException fileNotFoundException) {
                    this.logger.log(SentryLevel.INFO, fileNotFoundException, "%s file was not found.", DebugMetaPropertiesApplier.DEBUG_META_PROPERTIES_FILENAME);
                }
            }
        }
        return null;
    }
}

