/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core.internal.util;

import io.sentry.ILogger;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;

public final class SentryFrameMetricsCollector$$ExternalSyntheticLambda1
implements Runnable {
    public final SentryFrameMetricsCollector f$0;
    public final ILogger f$1;

    public /* synthetic */ SentryFrameMetricsCollector$$ExternalSyntheticLambda1(SentryFrameMetricsCollector sentryFrameMetricsCollector, ILogger iLogger) {
        this.f$0 = sentryFrameMetricsCollector;
        this.f$1 = iLogger;
    }

    public final void run() {
        this.f$0.lambda$new$1$io-sentry-android-core-internal-util-SentryFrameMetricsCollector(this.f$1);
    }
}

