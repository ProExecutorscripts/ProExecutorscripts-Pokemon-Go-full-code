/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import android.app.Activity;
import io.sentry.android.core.ActivityFramesTracker;

public final class ActivityFramesTracker$$ExternalSyntheticLambda0
implements Runnable {
    public final ActivityFramesTracker f$0;
    public final Activity f$1;

    public /* synthetic */ ActivityFramesTracker$$ExternalSyntheticLambda0(ActivityFramesTracker activityFramesTracker, Activity activity2) {
        this.f$0 = activityFramesTracker;
        this.f$1 = activity2;
    }

    public final void run() {
        this.f$0.lambda$addActivity$0$io-sentry-android-core-ActivityFramesTracker(this.f$1);
    }
}

