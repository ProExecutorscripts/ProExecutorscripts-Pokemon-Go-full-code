/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Thread
 */
package io.sentry.android.core.internal.util;

import android.os.Looper;
import io.sentry.protocol.SentryThread;
import io.sentry.util.thread.IMainThreadChecker;

public final class AndroidMainThreadChecker
implements IMainThreadChecker {
    private static final AndroidMainThreadChecker instance = new AndroidMainThreadChecker();

    private AndroidMainThreadChecker() {
    }

    public static AndroidMainThreadChecker getInstance() {
        return instance;
    }

    @Override
    public boolean isMainThread() {
        return this.isMainThread(Thread.currentThread());
    }

    @Override
    public boolean isMainThread(long l2) {
        boolean bl = Looper.getMainLooper().getThread().getId() == l2;
        return bl;
    }

    @Override
    public boolean isMainThread(SentryThread sentryThread) {
        boolean bl = (sentryThread = sentryThread.getId()) != null && this.isMainThread(sentryThread.longValue());
        return bl;
    }

    @Override
    public boolean isMainThread(Thread thread) {
        return this.isMainThread(thread.getId());
    }
}

