/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.UUID
 */
package io.sentry.android.core;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.UUID;

final class Installation {
    static final String INSTALLATION = "INSTALLATION";
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    static String deviceId;

    private Installation() {
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String id(Context object) throws RuntimeException {
        Class<Installation> clazz = Installation.class;
        synchronized (Installation.class) {
            Object object2;
            block7: {
                if (deviceId != null) return deviceId;
                object2 = new File(object.getFilesDir(), INSTALLATION);
                try {
                    if (object2.exists()) break block7;
                    object = Installation.writeInstallationFile(object2);
                    deviceId = object;
                    // ** MonitorExit[var2_3] (shouldn't be in output)
                    return object;
                }
                catch (Throwable throwable) {
                    object2 = new RuntimeException(throwable);
                    throw object2;
                }
            }
            deviceId = Installation.readInstallationFile(object2);
            return deviceId;
        }
    }

    static String readInstallationFile(File file) throws IOException {
        file = new RandomAccessFile(file, "r");
        try {
            Object object = new byte[(int)file.length()];
            file.readFully(object);
            object = new String(object, UTF_8);
            return object;
        }
        finally {
            file.close();
        }
    }

    static String writeInstallationFile(File file) throws IOException {
        file = new FileOutputStream(file);
        try {
            String string2 = UUID.randomUUID().toString();
            file.write(string2.getBytes(UTF_8));
            file.flush();
            return string2;
        }
        finally {
            file.close();
        }
    }
}

