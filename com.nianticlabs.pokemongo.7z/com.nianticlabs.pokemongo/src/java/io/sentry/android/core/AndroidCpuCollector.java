/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.SystemClock
 *  android.system.Os
 *  android.system.OsConstants
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.regex.Pattern
 */
package io.sentry.android.core;

import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import io.sentry.CpuCollectionData;
import io.sentry.ILogger;
import io.sentry.IPerformanceSnapshotCollector;
import io.sentry.PerformanceCollectionData;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.util.FileUtils;
import io.sentry.util.Objects;
import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;

public final class AndroidCpuCollector
implements IPerformanceSnapshotCollector {
    private final long NANOSECOND_PER_SECOND;
    private final BuildInfoProvider buildInfoProvider;
    private long clockSpeedHz = 1L;
    private boolean isEnabled = false;
    private long lastCpuNanos = 0L;
    private long lastRealtimeNanos = 0L;
    private final ILogger logger;
    private double nanosecondsPerClockTick = 1.0E9 / (double)1L;
    private final Pattern newLinePattern;
    private long numCores = 1L;
    private final File selfStat = new File("/proc/self/stat");

    public AndroidCpuCollector(ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        this.NANOSECOND_PER_SECOND = 1000000000L;
        this.newLinePattern = Pattern.compile((String)"[\n\t\r ]");
        this.logger = Objects.requireNonNull(iLogger, "Logger is required.");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required.");
    }

    private long readTotalCpuNanos() {
        String[] stringArray;
        try {
            stringArray = FileUtils.readText(this.selfStat);
        }
        catch (IOException iOException) {
            this.isEnabled = false;
            this.logger.log(SentryLevel.WARNING, "Unable to read /proc/self/stat file. Disabling cpu collection.", iOException);
            stringArray = null;
        }
        if (stringArray != null) {
            double d2;
            double d3;
            stringArray = stringArray.trim();
            stringArray = this.newLinePattern.split((CharSequence)stringArray);
            try {
                d3 = Long.parseLong((String)stringArray[13]) + Long.parseLong((String)stringArray[14]) + Long.parseLong((String)stringArray[15]) + Long.parseLong((String)stringArray[16]);
                d2 = this.nanosecondsPerClockTick;
            }
            catch (NumberFormatException numberFormatException) {
                this.logger.log(SentryLevel.ERROR, "Error parsing /proc/self/stat file.", numberFormatException);
            }
            return (long)(d3 * d2);
        }
        return 0L;
    }

    @Override
    public void collect(PerformanceCollectionData performanceCollectionData) {
        if (this.buildInfoProvider.getSdkInfoVersion() >= 21 && this.isEnabled) {
            long l2 = SystemClock.elapsedRealtimeNanos();
            long l3 = this.lastRealtimeNanos;
            this.lastRealtimeNanos = l2;
            long l4 = this.readTotalCpuNanos();
            long l5 = this.lastCpuNanos;
            this.lastCpuNanos = l4;
            double d2 = (double)(l4 - l5) / (double)(l2 - l3);
            performanceCollectionData.addCpuData(new CpuCollectionData(System.currentTimeMillis(), d2 / (double)this.numCores * 100.0));
        }
    }

    @Override
    public void setup() {
        if (this.buildInfoProvider.getSdkInfoVersion() < 21) {
            this.isEnabled = false;
            return;
        }
        this.isEnabled = true;
        this.clockSpeedHz = Os.sysconf((int)OsConstants._SC_CLK_TCK);
        this.numCores = Os.sysconf((int)OsConstants._SC_NPROCESSORS_CONF);
        this.nanosecondsPerClockTick = 1.0E9 / (double)this.clockSpeedHz;
        this.lastCpuNanos = this.readTotalCpuNanos();
    }
}

