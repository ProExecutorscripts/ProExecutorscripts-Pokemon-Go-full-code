/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.PackageManager$PackageInfoFlags
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 */
package io.sentry.android.core.internal.util;

import android.content.Context;
import android.content.pm.PackageManager;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.util.Objects;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;

public final class RootChecker {
    private static final Charset UTF_8 = Charset.forName((String)"UTF-8");
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private final ILogger logger;
    private final String[] rootFiles;
    private final String[] rootPackages;
    private final Runtime runtime;

    public RootChecker(Context context, BuildInfoProvider buildInfoProvider, ILogger iLogger) {
        Runtime runtime = Runtime.getRuntime();
        this(context, buildInfoProvider, iLogger, new String[]{"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su", "/su/bin", "/system/xbin/daemonsu"}, new String[]{"com.devadvance.rootcloak", "com.devadvance.rootcloakplus", "com.koushikdutta.superuser", "com.thirdparty.superuser", "eu.chainfire.supersu", "com.noshufou.android.su"}, runtime);
    }

    RootChecker(Context context, BuildInfoProvider buildInfoProvider, ILogger iLogger, String[] stringArray, String[] stringArray2, Runtime runtime) {
        this.context = Objects.requireNonNull(context, "The application context is required.");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "The BuildInfoProvider is required.");
        this.logger = Objects.requireNonNull(iLogger, "The Logger is required.");
        this.rootFiles = Objects.requireNonNull(stringArray, "The root Files are required.");
        this.rootPackages = Objects.requireNonNull(stringArray2, "The root packages are required.");
        this.runtime = Objects.requireNonNull(runtime, "The Runtime is required.");
    }

    private boolean checkRootFiles() {
        for (String string2 : this.rootFiles) {
            try {
                File file = new File(string2);
                boolean bl = file.exists();
                if (!bl) continue;
                return true;
            }
            catch (RuntimeException runtimeException) {
                this.logger.log(SentryLevel.ERROR, runtimeException, "Error when trying to check if root file %s exists.", string2);
            }
        }
        return false;
    }

    private boolean checkRootPackages(ILogger object) {
        object = new BuildInfoProvider((ILogger)object);
        PackageManager packageManager = this.context.getPackageManager();
        if (packageManager != null) {
            for (String string2 : this.rootPackages) {
                try {
                    if (((BuildInfoProvider)object).getSdkInfoVersion() >= 33) {
                        packageManager.getPackageInfo(string2, PackageManager.PackageInfoFlags.of((long)0L));
                    } else {
                        packageManager.getPackageInfo(string2, 0);
                    }
                    return true;
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                }
            }
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean checkSUExist() {
        var3_1 = null;
        var2_3 /* !! */  = null;
        var2_3 /* !! */  = var4_6 = this.runtime.exec(new String[]{"/system/xbin/which", "su"});
        var3_1 = var4_6;
        var2_3 /* !! */  = var4_6;
        var3_1 = var4_6;
        var2_3 /* !! */  = var4_6;
        var3_1 = var4_6;
        var6_9 = new InputStreamReader(var4_6.getInputStream(), RootChecker.UTF_8);
        var2_3 /* !! */  = var4_6;
        var3_1 = var4_6;
        var5_7 = new BufferedReader((Reader)var6_9);
        try {
            var2_3 /* !! */  = var5_7.readLine();
            var1_11 = var2_3 /* !! */  != null;
            var2_3 /* !! */  = var4_6;
            var3_1 = var4_6;
        }
        catch (Throwable var6_10) {
            try {
                var5_7.close();
            }
            catch (Throwable var5_8) {
                var2_3 /* !! */  = var4_6;
                var3_1 = var4_6;
                var6_10.addSuppressed(var5_8);
            }
            var2_3 /* !! */  = var4_6;
            var3_1 = var4_6;
            throw var6_10;
            {
                catch (Throwable var3_2) {
                    var4_6 = var2_3 /* !! */ ;
                    this.logger.log(SentryLevel.DEBUG, "Error when trying to check if SU exists.", var3_2);
                    if (var2_3 /* !! */  == null) return false;
lbl39:
                    // 2 sources

                    while (true) {
                        var2_3 /* !! */ .destroy();
                        return false;
                    }
                }
                catch (IOException var2_4) {
                    var4_6 = var3_1;
                    this.logger.log(SentryLevel.DEBUG, "SU isn't found on this Device.", new Object[0]);
                    if (var3_1 == null) return false;
                    var2_3 /* !! */  = var3_1;
                    ** continue;
                    {
                        catch (Throwable var2_5) {
                            if (var4_6 == null) throw var2_5;
                            var4_6.destroy();
                            throw var2_5;
                        }
                    }
                }
            }
        }
        var5_7.close();
        if (var4_6 == null) return var1_11;
        var4_6.destroy();
        return var1_11;
    }

    private boolean checkTestKeys() {
        String string2 = this.buildInfoProvider.getBuildTags();
        boolean bl = string2 != null && string2.contains((CharSequence)"test-keys");
        return bl;
    }

    public boolean isDeviceRooted() {
        boolean bl = this.checkTestKeys() || this.checkRootFiles() || this.checkSUExist() || this.checkRootPackages(this.logger);
        return bl;
    }
}

