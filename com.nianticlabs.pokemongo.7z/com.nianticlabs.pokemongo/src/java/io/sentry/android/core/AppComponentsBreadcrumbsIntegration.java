/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ComponentCallbacks
 *  android.content.ComponentCallbacks2
 *  android.content.Context
 *  android.content.res.Configuration
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Throwable
 *  java.util.Locale
 */
package io.sentry.android.core;

import android.content.ComponentCallbacks;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.DeviceOrientations;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;
import java.util.Locale;

public final class AppComponentsBreadcrumbsIntegration
implements Integration,
Closeable,
ComponentCallbacks2 {
    private final Context context;
    private IHub hub;
    private SentryAndroidOptions options;

    public AppComponentsBreadcrumbsIntegration(Context context) {
        this.context = Objects.requireNonNull(context, "Context is required");
    }

    private void createLowMemoryBreadcrumb(Integer n2) {
        if (this.hub != null) {
            Breadcrumb breadcrumb = new Breadcrumb();
            if (n2 != null) {
                if (n2 < 40) {
                    return;
                }
                breadcrumb.setData("level", n2);
            }
            breadcrumb.setType("system");
            breadcrumb.setCategory("device.event");
            breadcrumb.setMessage("Low memory");
            breadcrumb.setData("action", "LOW_MEMORY");
            breadcrumb.setLevel(SentryLevel.WARNING);
            this.hub.addBreadcrumb(breadcrumb);
        }
    }

    public void close() throws IOException {
        SentryAndroidOptions sentryAndroidOptions;
        block3: {
            try {
                this.context.unregisterComponentCallbacks((ComponentCallbacks)this);
            }
            catch (Throwable throwable) {
                sentryAndroidOptions = this.options;
                if (sentryAndroidOptions == null) break block3;
                sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, throwable, "It was not possible to unregisterComponentCallbacks", new Object[0]);
            }
        }
        sentryAndroidOptions = this.options;
        if (sentryAndroidOptions != null) {
            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "AppComponentsBreadcrumbsIntegration removed.", new Object[0]);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        if (this.hub != null) {
            Object object = DeviceOrientations.getOrientation(this.context.getResources().getConfiguration().orientation);
            object = object != null ? object.name().toLowerCase(Locale.ROOT) : "undefined";
            Breadcrumb breadcrumb = new Breadcrumb();
            breadcrumb.setType("navigation");
            breadcrumb.setCategory("device.orientation");
            breadcrumb.setData("position", object);
            breadcrumb.setLevel(SentryLevel.INFO);
            object = new Hint();
            ((Hint)object).set("android:configuration", configuration);
            this.hub.addBreadcrumb(breadcrumb, (Hint)object);
        }
    }

    public void onLowMemory() {
        this.createLowMemoryBreadcrumb(null);
    }

    public void onTrimMemory(int n2) {
        this.createLowMemoryBreadcrumb(n2);
    }

    @Override
    public void register(IHub object, SentryOptions sentryOptions) {
        this.hub = Objects.requireNonNull(object, "Hub is required");
        object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = object = (SentryAndroidOptions)Objects.requireNonNull(object, "SentryAndroidOptions is required");
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "AppComponentsBreadcrumbsIntegration enabled: %s", this.options.isEnableAppComponentBreadcrumbs());
        if (this.options.isEnableAppComponentBreadcrumbs()) {
            try {
                this.context.registerComponentCallbacks((ComponentCallbacks)this);
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "AppComponentsBreadcrumbsIntegration installed.", new Object[0]);
                IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
            }
            catch (Throwable throwable) {
                this.options.setEnableAppComponentBreadcrumbs(false);
                sentryOptions.getLogger().log(SentryLevel.INFO, throwable, "ComponentCallbacks2 is not available.", new Object[0]);
            }
        }
    }
}

