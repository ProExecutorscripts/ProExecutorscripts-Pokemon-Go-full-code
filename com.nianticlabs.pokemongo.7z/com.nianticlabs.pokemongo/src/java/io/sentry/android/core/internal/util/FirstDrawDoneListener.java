/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Handler
 *  android.os.Looper
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.view.ViewTreeObserver$OnDrawListener
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.view.Window
 *  android.view.Window$Callback
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core.internal.util;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.gestures.NoOpWindowCallback;
import io.sentry.android.core.internal.util.FirstDrawDoneListener$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.FirstDrawDoneListener$$ExternalSyntheticLambda1;
import io.sentry.android.core.performance.WindowContentChangedCallback;
import java.util.concurrent.atomic.AtomicReference;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class FirstDrawDoneListener
implements ViewTreeObserver.OnDrawListener {
    private final Runnable callback;
    private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());
    private final AtomicReference<View> viewReference;

    private FirstDrawDoneListener(View view2, Runnable runnable) {
        this.viewReference = new AtomicReference((Object)view2);
        this.callback = runnable;
    }

    private static boolean isAliveAndAttached(View view2) {
        boolean bl = view2.getViewTreeObserver().isAlive() && view2.isAttachedToWindow();
        return bl;
    }

    static /* synthetic */ void lambda$registerForNextDraw$0(Window window, Window.Callback callback, Runnable runnable, BuildInfoProvider buildInfoProvider) {
        View view2 = window.peekDecorView();
        if (view2 != null) {
            window.setCallback(callback);
            FirstDrawDoneListener.registerForNextDraw(view2, runnable, buildInfoProvider);
        }
    }

    public static void registerForNextDraw(Activity object, Runnable runnable, BuildInfoProvider buildInfoProvider) {
        Window window = object.getWindow();
        if (window != null) {
            object = window.peekDecorView();
            if (object != null) {
                FirstDrawDoneListener.registerForNextDraw((View)object, runnable, buildInfoProvider);
            } else {
                Window.Callback callback = window.getCallback();
                object = callback != null ? callback : new NoOpWindowCallback();
                window.setCallback((Window.Callback)new WindowContentChangedCallback((Window.Callback)object, new FirstDrawDoneListener$$ExternalSyntheticLambda1(window, callback, runnable, buildInfoProvider)));
            }
        }
    }

    public static void registerForNextDraw(View view2, Runnable object, BuildInfoProvider buildInfoProvider) {
        object = new FirstDrawDoneListener(view2, (Runnable)object);
        if (buildInfoProvider.getSdkInfoVersion() < 26 && !FirstDrawDoneListener.isAliveAndAttached(view2)) {
            view2.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener((FirstDrawDoneListener)object){
                final FirstDrawDoneListener val$listener;
                {
                    this.val$listener = firstDrawDoneListener;
                }

                public void onViewAttachedToWindow(View view2) {
                    view2.getViewTreeObserver().addOnDrawListener((ViewTreeObserver.OnDrawListener)this.val$listener);
                    view2.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
                }

                public void onViewDetachedFromWindow(View view2) {
                    view2.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
                }
            });
        } else {
            view2.getViewTreeObserver().addOnDrawListener((ViewTreeObserver.OnDrawListener)object);
        }
    }

    /* synthetic */ void lambda$onDraw$1$io-sentry-android-core-internal-util-FirstDrawDoneListener(View view2) {
        view2.getViewTreeObserver().removeOnDrawListener((ViewTreeObserver.OnDrawListener)this);
    }

    public void onDraw() {
        View view2 = (View)this.viewReference.getAndSet(null);
        if (view2 == null) {
            return;
        }
        view2.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)new FirstDrawDoneListener$$ExternalSyntheticLambda0(this, view2));
        this.mainThreadHandler.postAtFrontOfQueue(this.callback);
    }
}

