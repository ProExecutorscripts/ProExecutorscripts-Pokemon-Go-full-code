/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  io.sentry.android.fragment.FragmentLifecycleIntegration
 *  io.sentry.android.timber.SentryTimberIntegration
 *  io.sentry.compose.gestures.ComposeGestureTargetLocator
 *  io.sentry.compose.viewhierarchy.ComposeViewHierarchyExporter
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package io.sentry.android.core;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import io.sentry.DeduplicateMultithreadedEventProcessor;
import io.sentry.DefaultTransactionPerformanceCollector;
import io.sentry.ILogger;
import io.sentry.ITransactionProfiler;
import io.sentry.Integration;
import io.sentry.NoOpConnectionStatusProvider;
import io.sentry.SendFireAndForgetEnvelopeSender;
import io.sentry.SendFireAndForgetOutboxSender;
import io.sentry.SentryLevel;
import io.sentry.android.core.ActivityBreadcrumbsIntegration;
import io.sentry.android.core.ActivityFramesTracker;
import io.sentry.android.core.ActivityLifecycleIntegration;
import io.sentry.android.core.AndroidCpuCollector;
import io.sentry.android.core.AndroidLogger;
import io.sentry.android.core.AndroidMemoryCollector;
import io.sentry.android.core.AndroidOptionsInitializer$$ExternalSyntheticLambda0;
import io.sentry.android.core.AndroidOptionsInitializer$$ExternalSyntheticLambda1;
import io.sentry.android.core.AndroidOptionsInitializer$$ExternalSyntheticLambda2;
import io.sentry.android.core.AndroidTransactionProfiler;
import io.sentry.android.core.AndroidTransportGate;
import io.sentry.android.core.AnrIntegrationFactory;
import io.sentry.android.core.AnrV2EventProcessor;
import io.sentry.android.core.AppComponentsBreadcrumbsIntegration;
import io.sentry.android.core.AppLifecycleIntegration;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.CurrentActivityIntegration;
import io.sentry.android.core.DefaultAndroidEventProcessor;
import io.sentry.android.core.EnvelopeFileObserverIntegration;
import io.sentry.android.core.Installation;
import io.sentry.android.core.LoadClass;
import io.sentry.android.core.ManifestMetadataReader;
import io.sentry.android.core.NdkIntegration;
import io.sentry.android.core.NetworkBreadcrumbsIntegration;
import io.sentry.android.core.PerformanceAndroidEventProcessor;
import io.sentry.android.core.PhoneStateBreadcrumbsIntegration;
import io.sentry.android.core.ScreenshotEventProcessor;
import io.sentry.android.core.SendCachedEnvelopeIntegration;
import io.sentry.android.core.SentryAndroidDateProvider;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.SpanFrameMetricsCollector;
import io.sentry.android.core.SystemEventsBreadcrumbsIntegration;
import io.sentry.android.core.TempSensorBreadcrumbsIntegration;
import io.sentry.android.core.UserInteractionIntegration;
import io.sentry.android.core.ViewHierarchyEventProcessor;
import io.sentry.android.core.cache.AndroidEnvelopeCache;
import io.sentry.android.core.internal.debugmeta.AssetsDebugMetaLoader;
import io.sentry.android.core.internal.gestures.AndroidViewGestureTargetLocator;
import io.sentry.android.core.internal.modules.AssetsModulesLoader;
import io.sentry.android.core.internal.util.AndroidConnectionStatusProvider;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.fragment.FragmentLifecycleIntegration;
import io.sentry.android.timber.SentryTimberIntegration;
import io.sentry.cache.PersistingOptionsObserver;
import io.sentry.cache.PersistingScopeObserver;
import io.sentry.compose.gestures.ComposeGestureTargetLocator;
import io.sentry.compose.viewhierarchy.ComposeViewHierarchyExporter;
import io.sentry.internal.gestures.GestureTargetLocator;
import io.sentry.internal.viewhierarchy.ViewHierarchyExporter;
import io.sentry.transport.NoOpEnvelopeCache;
import io.sentry.util.LazyEvaluator;
import io.sentry.util.Objects;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class AndroidOptionsInitializer {
    static final String COMPOSE_CLASS_NAME = "androidx.compose.ui.node.Owner";
    static final long DEFAULT_FLUSH_TIMEOUT_MS = 4000L;
    static final String SENTRY_COMPOSE_GESTURE_INTEGRATION_CLASS_NAME = "io.sentry.compose.gestures.ComposeGestureTargetLocator";
    static final String SENTRY_COMPOSE_VIEW_HIERARCHY_INTEGRATION_CLASS_NAME = "io.sentry.compose.viewhierarchy.ComposeViewHierarchyExporter";

    private AndroidOptionsInitializer() {
    }

    static File getCacheDir(Context context) {
        return new File(context.getCacheDir(), "sentry");
    }

    private static String getSentryReleaseVersion(PackageInfo packageInfo, String string2) {
        return packageInfo.packageName + "@" + packageInfo.versionName + "+" + string2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void initializeIntegrationsAndProcessors(SentryAndroidOptions sentryAndroidOptions, Context context, BuildInfoProvider buildInfoProvider, LoadClass loadClass, ActivityFramesTracker object) {
        if (sentryAndroidOptions.getCacheDirPath() != null && sentryAndroidOptions.getEnvelopeDiskCache() instanceof NoOpEnvelopeCache) {
            sentryAndroidOptions.setEnvelopeDiskCache(new AndroidEnvelopeCache(sentryAndroidOptions));
        }
        if (sentryAndroidOptions.getConnectionStatusProvider() instanceof NoOpConnectionStatusProvider) {
            sentryAndroidOptions.setConnectionStatusProvider(new AndroidConnectionStatusProvider(context, sentryAndroidOptions.getLogger(), buildInfoProvider));
        }
        sentryAndroidOptions.addEventProcessor(new DeduplicateMultithreadedEventProcessor(sentryAndroidOptions));
        sentryAndroidOptions.addEventProcessor(new DefaultAndroidEventProcessor(context, buildInfoProvider, sentryAndroidOptions));
        sentryAndroidOptions.addEventProcessor(new PerformanceAndroidEventProcessor(sentryAndroidOptions, (ActivityFramesTracker)object));
        sentryAndroidOptions.addEventProcessor(new ScreenshotEventProcessor(sentryAndroidOptions, buildInfoProvider));
        sentryAndroidOptions.addEventProcessor(new ViewHierarchyEventProcessor(sentryAndroidOptions));
        sentryAndroidOptions.addEventProcessor(new AnrV2EventProcessor(context, sentryAndroidOptions, buildInfoProvider));
        sentryAndroidOptions.setTransportGate(new AndroidTransportGate(sentryAndroidOptions));
        Object object2 = object = AppStartMetrics.getInstance();
        synchronized (object2) {
            ITransactionProfiler iTransactionProfiler = AppStartMetrics.getInstance().getAppStartProfiler();
            if (iTransactionProfiler != null) {
                sentryAndroidOptions.setTransactionProfiler(iTransactionProfiler);
                AppStartMetrics.getInstance().setAppStartProfiler(null);
            } else {
                iTransactionProfiler = new AndroidTransactionProfiler(context, sentryAndroidOptions, buildInfoProvider, Objects.requireNonNull(sentryAndroidOptions.getFrameMetricsCollector(), "options.getFrameMetricsCollector is required"));
                sentryAndroidOptions.setTransactionProfiler(iTransactionProfiler);
            }
        }
        sentryAndroidOptions.setModulesLoader(new AssetsModulesLoader(context, sentryAndroidOptions.getLogger()));
        sentryAndroidOptions.setDebugMetaLoader(new AssetsDebugMetaLoader(context, sentryAndroidOptions.getLogger()));
        boolean bl = loadClass.isClassAvailable("androidx.core.view.ScrollingView", sentryAndroidOptions);
        boolean bl2 = loadClass.isClassAvailable(COMPOSE_CLASS_NAME, sentryAndroidOptions);
        if (sentryAndroidOptions.getGestureTargetLocators().isEmpty()) {
            context = new ArrayList(2);
            context.add((Object)new AndroidViewGestureTargetLocator(bl));
            boolean bl3 = bl2 && loadClass.isClassAvailable(SENTRY_COMPOSE_GESTURE_INTEGRATION_CLASS_NAME, sentryAndroidOptions);
            if (bl3) {
                context.add((Object)new ComposeGestureTargetLocator(sentryAndroidOptions.getLogger()));
            }
            sentryAndroidOptions.setGestureTargetLocators((List<GestureTargetLocator>)context);
        }
        if (sentryAndroidOptions.getViewHierarchyExporters().isEmpty() && bl2 && loadClass.isClassAvailable(SENTRY_COMPOSE_VIEW_HIERARCHY_INTEGRATION_CLASS_NAME, sentryAndroidOptions)) {
            context = new ArrayList(1);
            context.add((Object)new ComposeViewHierarchyExporter(sentryAndroidOptions.getLogger()));
            sentryAndroidOptions.setViewHierarchyExporters((List<ViewHierarchyExporter>)context);
        }
        sentryAndroidOptions.setMainThreadChecker(AndroidMainThreadChecker.getInstance());
        if (sentryAndroidOptions.getPerformanceCollectors().isEmpty()) {
            sentryAndroidOptions.addPerformanceCollector(new AndroidMemoryCollector());
            sentryAndroidOptions.addPerformanceCollector(new AndroidCpuCollector(sentryAndroidOptions.getLogger(), buildInfoProvider));
            if (sentryAndroidOptions.isEnablePerformanceV2()) {
                sentryAndroidOptions.addPerformanceCollector(new SpanFrameMetricsCollector(sentryAndroidOptions, Objects.requireNonNull(sentryAndroidOptions.getFrameMetricsCollector(), "options.getFrameMetricsCollector is required")));
            }
        }
        sentryAndroidOptions.setTransactionPerformanceCollector(new DefaultTransactionPerformanceCollector(sentryAndroidOptions));
        if (sentryAndroidOptions.getCacheDirPath() != null) {
            if (sentryAndroidOptions.isEnableScopePersistence()) {
                sentryAndroidOptions.addScopeObserver(new PersistingScopeObserver(sentryAndroidOptions));
            }
            sentryAndroidOptions.addOptionsObserver(new PersistingOptionsObserver(sentryAndroidOptions));
        }
    }

    static void initializeIntegrationsAndProcessors(SentryAndroidOptions sentryAndroidOptions, Context context, LoadClass loadClass, ActivityFramesTracker activityFramesTracker) {
        AndroidOptionsInitializer.initializeIntegrationsAndProcessors(sentryAndroidOptions, context, new BuildInfoProvider(new AndroidLogger()), loadClass, activityFramesTracker);
    }

    static void installDefaultIntegrations(Context context, SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider buildInfoProvider, LoadClass loadClass, ActivityFramesTracker activityFramesTracker, boolean bl, boolean bl2) {
        Application application = new LazyEvaluator(new AndroidOptionsInitializer$$ExternalSyntheticLambda0(sentryAndroidOptions));
        sentryAndroidOptions.addIntegration(new SendCachedEnvelopeIntegration(new SendFireAndForgetEnvelopeSender(new AndroidOptionsInitializer$$ExternalSyntheticLambda1(sentryAndroidOptions)), (LazyEvaluator<Boolean>)application));
        sentryAndroidOptions.addIntegration(new NdkIntegration(loadClass.loadClass("io.sentry.android.ndk.SentryNdk", sentryAndroidOptions.getLogger())));
        sentryAndroidOptions.addIntegration(EnvelopeFileObserverIntegration.getOutboxFileObserver());
        sentryAndroidOptions.addIntegration(new SendCachedEnvelopeIntegration(new SendFireAndForgetOutboxSender(new AndroidOptionsInitializer$$ExternalSyntheticLambda2(sentryAndroidOptions)), (LazyEvaluator<Boolean>)application));
        sentryAndroidOptions.addIntegration(new AppLifecycleIntegration());
        sentryAndroidOptions.addIntegration(AnrIntegrationFactory.create(context, buildInfoProvider));
        if (context instanceof Application) {
            application = (Application)context;
            sentryAndroidOptions.addIntegration(new ActivityLifecycleIntegration(application, buildInfoProvider, activityFramesTracker));
            sentryAndroidOptions.addIntegration(new ActivityBreadcrumbsIntegration(application));
            sentryAndroidOptions.addIntegration(new CurrentActivityIntegration(application));
            sentryAndroidOptions.addIntegration(new UserInteractionIntegration(application, loadClass));
            if (bl) {
                sentryAndroidOptions.addIntegration((Integration)new FragmentLifecycleIntegration(application, true, true));
            }
        } else {
            sentryAndroidOptions.getLogger().log(SentryLevel.WARNING, "ActivityLifecycle, FragmentLifecycle and UserInteraction Integrations need an Application class to be installed.", new Object[0]);
        }
        if (bl2) {
            sentryAndroidOptions.addIntegration((Integration)new SentryTimberIntegration());
        }
        sentryAndroidOptions.addIntegration(new AppComponentsBreadcrumbsIntegration(context));
        sentryAndroidOptions.addIntegration(new SystemEventsBreadcrumbsIntegration(context));
        sentryAndroidOptions.addIntegration(new NetworkBreadcrumbsIntegration(context, buildInfoProvider, sentryAndroidOptions.getLogger()));
        sentryAndroidOptions.addIntegration(new TempSensorBreadcrumbsIntegration(context));
        sentryAndroidOptions.addIntegration(new PhoneStateBreadcrumbsIntegration(context));
    }

    static /* synthetic */ Boolean lambda$installDefaultIntegrations$0(SentryAndroidOptions sentryAndroidOptions) {
        return AndroidEnvelopeCache.hasStartupCrashMarker(sentryAndroidOptions);
    }

    static /* synthetic */ String lambda$installDefaultIntegrations$1(SentryAndroidOptions sentryAndroidOptions) {
        return sentryAndroidOptions.getCacheDirPath();
    }

    static /* synthetic */ String lambda$installDefaultIntegrations$2(SentryAndroidOptions sentryAndroidOptions) {
        return sentryAndroidOptions.getOutboxPath();
    }

    static void loadDefaultAndMetadataOptions(SentryAndroidOptions sentryAndroidOptions, Context context) {
        AndroidLogger androidLogger = new AndroidLogger();
        AndroidOptionsInitializer.loadDefaultAndMetadataOptions(sentryAndroidOptions, context, androidLogger, new BuildInfoProvider(androidLogger));
    }

    static void loadDefaultAndMetadataOptions(SentryAndroidOptions sentryAndroidOptions, Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        Objects.requireNonNull(context, "The context is required.");
        Context context2 = context;
        if (context.getApplicationContext() != null) {
            context2 = context.getApplicationContext();
        }
        Objects.requireNonNull(sentryAndroidOptions, "The options object is required.");
        Objects.requireNonNull(iLogger, "The ILogger object is required.");
        sentryAndroidOptions.setLogger(iLogger);
        sentryAndroidOptions.setDateProvider(new SentryAndroidDateProvider());
        sentryAndroidOptions.setFlushTimeoutMillis(4000L);
        sentryAndroidOptions.setFrameMetricsCollector(new SentryFrameMetricsCollector(context2, iLogger, buildInfoProvider));
        ManifestMetadataReader.applyMetadata(context2, sentryAndroidOptions, buildInfoProvider);
        sentryAndroidOptions.setCacheDirPath(AndroidOptionsInitializer.getCacheDir(context2).getAbsolutePath());
        AndroidOptionsInitializer.readDefaultOptionValues(sentryAndroidOptions, context2, buildInfoProvider);
    }

    private static void readDefaultOptionValues(SentryAndroidOptions sentryAndroidOptions, Context context, BuildInfoProvider object) {
        PackageInfo packageInfo = ContextUtils.getPackageInfo(context, sentryAndroidOptions.getLogger(), (BuildInfoProvider)object);
        if (packageInfo != null) {
            if (sentryAndroidOptions.getRelease() == null) {
                sentryAndroidOptions.setRelease(AndroidOptionsInitializer.getSentryReleaseVersion(packageInfo, ContextUtils.getVersionCode(packageInfo, (BuildInfoProvider)object)));
            }
            if ((object = packageInfo.packageName) != null && !object.startsWith("android.")) {
                sentryAndroidOptions.addInAppInclude((String)object);
            }
        }
        if (sentryAndroidOptions.getDistinctId() == null) {
            try {
                sentryAndroidOptions.setDistinctId(Installation.id(context));
            }
            catch (RuntimeException runtimeException) {
                sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "Could not generate distinct Id.", runtimeException);
            }
        }
    }
}

