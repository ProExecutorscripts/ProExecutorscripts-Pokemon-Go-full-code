/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Bundle
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 */
package io.sentry.android.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.SystemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import io.sentry.util.StringUtils;
import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class SystemEventsBreadcrumbsIntegration
implements Integration,
Closeable {
    private final List<String> actions;
    private final Context context;
    private boolean isClosed = false;
    private SentryAndroidOptions options;
    SystemEventsBroadcastReceiver receiver;
    private final Object startLock = new Object();

    public SystemEventsBreadcrumbsIntegration(Context context) {
        this(context, SystemEventsBreadcrumbsIntegration.getDefaultActions());
    }

    public SystemEventsBreadcrumbsIntegration(Context context, List<String> list) {
        this.context = Objects.requireNonNull(context, "Context is required");
        this.actions = Objects.requireNonNull(list, "Actions list is required");
    }

    private static List<String> getDefaultActions() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_DELETED");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_DISABLED");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_ENABLED");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_HOST_RESTORED");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_RESTORED");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_UPDATE");
        arrayList.add((Object)"android.appwidget.action.APPWIDGET_UPDATE_OPTIONS");
        arrayList.add((Object)"android.intent.action.ACTION_POWER_CONNECTED");
        arrayList.add((Object)"android.intent.action.ACTION_POWER_DISCONNECTED");
        arrayList.add((Object)"android.intent.action.ACTION_SHUTDOWN");
        arrayList.add((Object)"android.intent.action.AIRPLANE_MODE");
        arrayList.add((Object)"android.intent.action.BATTERY_LOW");
        arrayList.add((Object)"android.intent.action.BATTERY_OKAY");
        arrayList.add((Object)"android.intent.action.BOOT_COMPLETED");
        arrayList.add((Object)"android.intent.action.CAMERA_BUTTON");
        arrayList.add((Object)"android.intent.action.CONFIGURATION_CHANGED");
        arrayList.add((Object)"android.intent.action.CONTENT_CHANGED");
        arrayList.add((Object)"android.intent.action.DATE_CHANGED");
        arrayList.add((Object)"android.intent.action.DEVICE_STORAGE_LOW");
        arrayList.add((Object)"android.intent.action.DEVICE_STORAGE_OK");
        arrayList.add((Object)"android.intent.action.DOCK_EVENT");
        arrayList.add((Object)"android.intent.action.DREAMING_STARTED");
        arrayList.add((Object)"android.intent.action.DREAMING_STOPPED");
        arrayList.add((Object)"android.intent.action.INPUT_METHOD_CHANGED");
        arrayList.add((Object)"android.intent.action.LOCALE_CHANGED");
        arrayList.add((Object)"android.intent.action.REBOOT");
        arrayList.add((Object)"android.intent.action.SCREEN_OFF");
        arrayList.add((Object)"android.intent.action.SCREEN_ON");
        arrayList.add((Object)"android.intent.action.TIMEZONE_CHANGED");
        arrayList.add((Object)"android.intent.action.TIME_SET");
        arrayList.add((Object)"android.os.action.DEVICE_IDLE_MODE_CHANGED");
        arrayList.add((Object)"android.os.action.POWER_SAVE_MODE_CHANGED");
        arrayList.add((Object)"android.intent.action.APP_ERROR");
        arrayList.add((Object)"android.intent.action.BUG_REPORT");
        arrayList.add((Object)"android.intent.action.MEDIA_BAD_REMOVAL");
        arrayList.add((Object)"android.intent.action.MEDIA_MOUNTED");
        arrayList.add((Object)"android.intent.action.MEDIA_UNMOUNTABLE");
        arrayList.add((Object)"android.intent.action.MEDIA_UNMOUNTED");
        return arrayList;
    }

    private void startSystemEventsReceiver(IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        this.receiver = new SystemEventsBroadcastReceiver(iHub, sentryAndroidOptions.getLogger());
        IntentFilter intentFilter = new IntentFilter();
        iHub = this.actions.iterator();
        while (iHub.hasNext()) {
            intentFilter.addAction((String)iHub.next());
        }
        try {
            ContextUtils.registerReceiver(this.context, sentryAndroidOptions, (BroadcastReceiver)this.receiver, intentFilter);
            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "SystemEventsBreadcrumbsIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
        catch (Throwable throwable) {
            sentryAndroidOptions.setEnableSystemEventBreadcrumbs(false);
            sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "Failed to initialize SystemEventsBreadcrumbsIntegration.", throwable);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            this.isClosed = true;
        }
        object = this.receiver;
        if (object != null) {
            this.context.unregisterReceiver((BroadcastReceiver)object);
            this.receiver = null;
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "SystemEventsBreadcrumbsIntegration remove.", new Object[0]);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$register$0$io-sentry-android-core-SystemEventsBreadcrumbsIntegration(IHub iHub, SentryOptions sentryOptions) {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            if (!this.isClosed) {
                this.startSystemEventsReceiver(iHub, (SentryAndroidOptions)sentryOptions);
            }
            return;
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        Objects.requireNonNull(iHub, "Hub is required");
        Object object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        object = Objects.requireNonNull(object, "SentryAndroidOptions is required");
        this.options = object;
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "SystemEventsBreadcrumbsIntegration enabled: %s", this.options.isEnableSystemEventBreadcrumbs());
        if (this.options.isEnableSystemEventBreadcrumbs()) {
            try {
                object = sentryOptions.getExecutorService();
                SystemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0 systemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0 = new SystemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0(this, iHub, sentryOptions);
                object.submit(systemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0);
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to start SystemEventsBreadcrumbsIntegration on executor thread.", throwable);
            }
        }
    }

    static final class SystemEventsBroadcastReceiver
    extends BroadcastReceiver {
        private final IHub hub;
        private final ILogger logger;

        SystemEventsBroadcastReceiver(IHub iHub, ILogger iLogger) {
            this.hub = iHub;
            this.logger = iLogger;
        }

        public void onReceive(Context object, Intent intent) {
            object = new Breadcrumb();
            ((Breadcrumb)object).setType("system");
            ((Breadcrumb)object).setCategory("device.event");
            Object object2 = intent.getAction();
            String string2 = StringUtils.getStringAfterDot((String)object2);
            if (string2 != null) {
                ((Breadcrumb)object).setData("action", string2);
            }
            Bundle bundle = intent.getExtras();
            HashMap hashMap = new HashMap();
            if (bundle != null && !bundle.isEmpty()) {
                for (String string3 : bundle.keySet()) {
                    Object object3 = bundle.get(string3);
                    if (object3 == null) continue;
                    try {
                        hashMap.put((Object)string3, (Object)object3.toString());
                    }
                    catch (Throwable throwable) {
                        this.logger.log(SentryLevel.ERROR, throwable, "%s key of the %s action threw an error.", string3, object2);
                    }
                }
                ((Breadcrumb)object).setData("extras", hashMap);
            }
            ((Breadcrumb)object).setLevel(SentryLevel.INFO);
            object2 = new Hint();
            ((Hint)object2).set("android:intent", intent);
            this.hub.addBreadcrumb((Breadcrumb)object, (Hint)object2);
        }
    }
}

