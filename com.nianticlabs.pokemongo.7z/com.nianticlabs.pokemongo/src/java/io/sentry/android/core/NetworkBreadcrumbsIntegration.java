/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager$NetworkCallback
 *  android.net.Network
 *  android.net.NetworkCapabilities
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.core;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import io.sentry.Breadcrumb;
import io.sentry.DateUtils;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.Integration;
import io.sentry.SentryDateProvider;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.AndroidConnectionStatusProvider;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class NetworkBreadcrumbsIntegration
implements Integration,
Closeable {
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private final ILogger logger;
    NetworkBreadcrumbsNetworkCallback networkCallback;

    public NetworkBreadcrumbsIntegration(Context context, BuildInfoProvider buildInfoProvider, ILogger iLogger) {
        this.context = Objects.requireNonNull(context, "Context is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
        this.logger = Objects.requireNonNull(iLogger, "ILogger is required");
    }

    public void close() throws IOException {
        NetworkBreadcrumbsNetworkCallback networkBreadcrumbsNetworkCallback = this.networkCallback;
        if (networkBreadcrumbsNetworkCallback != null) {
            AndroidConnectionStatusProvider.unregisterNetworkCallback(this.context, this.logger, this.buildInfoProvider, networkBreadcrumbsNetworkCallback);
            this.logger.log(SentryLevel.DEBUG, "NetworkBreadcrumbsIntegration remove.", new Object[0]);
        }
        this.networkCallback = null;
    }

    @Override
    public void register(IHub object, SentryOptions sentryOptions) {
        Objects.requireNonNull(object, "Hub is required");
        SentryAndroidOptions sentryAndroidOptions = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        sentryAndroidOptions = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.logger.log(SentryLevel.DEBUG, "NetworkBreadcrumbsIntegration enabled: %s", sentryAndroidOptions.isEnableNetworkEventBreadcrumbs());
        if (sentryAndroidOptions.isEnableNetworkEventBreadcrumbs()) {
            if (this.buildInfoProvider.getSdkInfoVersion() < 21) {
                this.networkCallback = null;
                this.logger.log(SentryLevel.DEBUG, "NetworkBreadcrumbsIntegration requires Android 5+", new Object[0]);
                return;
            }
            object = new NetworkBreadcrumbsNetworkCallback((IHub)object, this.buildInfoProvider, sentryOptions.getDateProvider());
            this.networkCallback = object;
            if (!AndroidConnectionStatusProvider.registerNetworkCallback(this.context, this.logger, this.buildInfoProvider, (ConnectivityManager.NetworkCallback)object)) {
                this.networkCallback = null;
                this.logger.log(SentryLevel.DEBUG, "NetworkBreadcrumbsIntegration not installed.", new Object[0]);
                return;
            }
            this.logger.log(SentryLevel.DEBUG, "NetworkBreadcrumbsIntegration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }

    static class NetworkBreadcrumbConnectionDetail {
        final int downBandwidth;
        final boolean isVpn;
        final int signalStrength;
        private long timestampNanos;
        final String type;
        final int upBandwidth;

        NetworkBreadcrumbConnectionDetail(NetworkCapabilities object, BuildInfoProvider buildInfoProvider, long l2) {
            Objects.requireNonNull(object, "NetworkCapabilities is required");
            Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
            this.downBandwidth = object.getLinkDownstreamBandwidthKbps();
            this.upBandwidth = object.getLinkUpstreamBandwidthKbps();
            int n2 = buildInfoProvider.getSdkInfoVersion();
            int n3 = 0;
            n2 = n2 >= 29 ? object.getSignalStrength() : 0;
            if (n2 > -100) {
                n3 = n2;
            }
            this.signalStrength = n3;
            this.isVpn = object.hasTransport(4);
            if ((object = AndroidConnectionStatusProvider.getConnectionType(object, buildInfoProvider)) == null) {
                object = "";
            }
            this.type = object;
            this.timestampNanos = l2;
        }

        boolean isSimilar(NetworkBreadcrumbConnectionDetail networkBreadcrumbConnectionDetail) {
            int n2 = Math.abs((int)(this.signalStrength - networkBreadcrumbConnectionDetail.signalStrength));
            int n3 = Math.abs((int)(this.downBandwidth - networkBreadcrumbConnectionDetail.downBandwidth));
            int n4 = Math.abs((int)(this.upBandwidth - networkBreadcrumbConnectionDetail.upBandwidth));
            double d2 = DateUtils.nanosToMillis(Math.abs((long)(this.timestampNanos - networkBreadcrumbConnectionDetail.timestampNanos)));
            boolean bl = true;
            boolean bl2 = d2 < 5000.0;
            n2 = !bl2 && n2 > 5 ? 0 : 1;
            n3 = !bl2 && !((double)n3 <= Math.max((double)1000.0, (double)((double)Math.abs((int)this.downBandwidth) * 0.1))) ? 0 : 1;
            bl2 = bl2 || (double)n4 <= Math.max((double)1000.0, (double)((double)Math.abs((int)this.upBandwidth) * 0.1));
            if (this.isVpn != networkBreadcrumbConnectionDetail.isVpn || !this.type.equals((Object)networkBreadcrumbConnectionDetail.type) || n2 == 0 || n3 == 0 || !bl2) {
                bl = false;
            }
            return bl;
        }
    }

    static final class NetworkBreadcrumbsNetworkCallback
    extends ConnectivityManager.NetworkCallback {
        final BuildInfoProvider buildInfoProvider;
        Network currentNetwork = null;
        final SentryDateProvider dateProvider;
        final IHub hub;
        NetworkCapabilities lastCapabilities = null;
        long lastCapabilityNanos = 0L;

        NetworkBreadcrumbsNetworkCallback(IHub iHub, BuildInfoProvider buildInfoProvider, SentryDateProvider sentryDateProvider) {
            this.hub = Objects.requireNonNull(iHub, "Hub is required");
            this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
            this.dateProvider = Objects.requireNonNull(sentryDateProvider, "SentryDateProvider is required");
        }

        private Breadcrumb createBreadcrumb(String string2) {
            Breadcrumb breadcrumb = new Breadcrumb();
            breadcrumb.setType("system");
            breadcrumb.setCategory("network.event");
            breadcrumb.setData("action", string2);
            breadcrumb.setLevel(SentryLevel.INFO);
            return breadcrumb;
        }

        private NetworkBreadcrumbConnectionDetail getNewConnectionDetails(NetworkCapabilities networkCapabilities, NetworkCapabilities object, long l2, long l3) {
            if (networkCapabilities == null) {
                return new NetworkBreadcrumbConnectionDetail((NetworkCapabilities)object, this.buildInfoProvider, l3);
            }
            NetworkBreadcrumbConnectionDetail networkBreadcrumbConnectionDetail = new NetworkBreadcrumbConnectionDetail(networkCapabilities, this.buildInfoProvider, l2);
            networkCapabilities = object = new NetworkBreadcrumbConnectionDetail((NetworkCapabilities)object, this.buildInfoProvider, l3);
            if (networkBreadcrumbConnectionDetail.isSimilar((NetworkBreadcrumbConnectionDetail)object)) {
                networkCapabilities = null;
            }
            return networkCapabilities;
        }

        public void onAvailable(Network network) {
            if (network.equals((Object)this.currentNetwork)) {
                return;
            }
            Breadcrumb breadcrumb = this.createBreadcrumb("NETWORK_AVAILABLE");
            this.hub.addBreadcrumb(breadcrumb);
            this.currentNetwork = network;
            this.lastCapabilities = null;
        }

        public void onCapabilitiesChanged(Network object, NetworkCapabilities object2) {
            if (!object.equals((Object)this.currentNetwork)) {
                return;
            }
            long l2 = this.dateProvider.now().nanoTimestamp();
            object = this.getNewConnectionDetails(this.lastCapabilities, (NetworkCapabilities)object2, this.lastCapabilityNanos, l2);
            if (object == null) {
                return;
            }
            this.lastCapabilities = object2;
            this.lastCapabilityNanos = l2;
            Breadcrumb breadcrumb = this.createBreadcrumb("NETWORK_CAPABILITIES_CHANGED");
            breadcrumb.setData("download_bandwidth", object.downBandwidth);
            breadcrumb.setData("upload_bandwidth", object.upBandwidth);
            breadcrumb.setData("vpn_active", object.isVpn);
            breadcrumb.setData("network_type", object.type);
            if (object.signalStrength != 0) {
                breadcrumb.setData("signal_strength", object.signalStrength);
            }
            object2 = new Hint();
            ((Hint)object2).set("android:networkCapabilities", object);
            this.hub.addBreadcrumb(breadcrumb, (Hint)object2);
        }

        public void onLost(Network object) {
            if (!object.equals((Object)this.currentNetwork)) {
                return;
            }
            object = this.createBreadcrumb("NETWORK_LOST");
            this.hub.addBreadcrumb((Breadcrumb)object);
            this.currentNetwork = null;
            this.lastCapabilities = null;
        }
    }
}

