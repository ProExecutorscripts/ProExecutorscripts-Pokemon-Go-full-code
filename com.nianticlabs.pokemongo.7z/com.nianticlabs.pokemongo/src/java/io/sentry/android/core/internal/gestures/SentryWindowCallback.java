/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.MotionEvent
 *  android.view.Window$Callback
 *  androidx.core.view.GestureDetectorCompat
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Throwable
 */
package io.sentry.android.core.internal.gestures;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.Window;
import androidx.core.view.GestureDetectorCompat;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SpanStatus;
import io.sentry.android.core.internal.gestures.SentryGestureListener;
import io.sentry.android.core.internal.gestures.WindowCallbackAdapter;

public final class SentryWindowCallback
extends WindowCallbackAdapter {
    private final Window.Callback delegate;
    private final GestureDetectorCompat gestureDetector;
    private final SentryGestureListener gestureListener;
    private final MotionEventObtainer motionEventObtainer;
    private final SentryOptions options;

    public SentryWindowCallback(Window.Callback callback, Context context, SentryGestureListener sentryGestureListener, SentryOptions sentryOptions) {
        this(callback, new GestureDetectorCompat(context, (GestureDetector.OnGestureListener)sentryGestureListener), sentryGestureListener, sentryOptions, new MotionEventObtainer(){});
    }

    SentryWindowCallback(Window.Callback callback, GestureDetectorCompat gestureDetectorCompat, SentryGestureListener sentryGestureListener, SentryOptions sentryOptions, MotionEventObtainer motionEventObtainer) {
        super(callback);
        this.delegate = callback;
        this.gestureListener = sentryGestureListener;
        this.options = sentryOptions;
        this.gestureDetector = gestureDetectorCompat;
        this.motionEventObtainer = motionEventObtainer;
    }

    private void handleTouchEvent(MotionEvent motionEvent) {
        this.gestureDetector.onTouchEvent(motionEvent);
        if (motionEvent.getActionMasked() == 1) {
            this.gestureListener.onUp(motionEvent);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent != null) {
            MotionEvent motionEvent2 = this.motionEventObtainer.obtain(motionEvent);
            try {
                this.handleTouchEvent(motionEvent2);
            }
            catch (Throwable throwable) {
                try {
                    if (this.options != null) {
                        this.options.getLogger().log(SentryLevel.ERROR, "Error dispatching touch event", throwable);
                    }
                }
                finally {
                    motionEvent2.recycle();
                }
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public Window.Callback getDelegate() {
        return this.delegate;
    }

    public void stopTracking() {
        this.gestureListener.stopTracing(SpanStatus.CANCELLED);
    }

    static interface MotionEventObtainer {
        default public MotionEvent obtain(MotionEvent motionEvent) {
            return MotionEvent.obtain((MotionEvent)motionEvent);
        }
    }
}

