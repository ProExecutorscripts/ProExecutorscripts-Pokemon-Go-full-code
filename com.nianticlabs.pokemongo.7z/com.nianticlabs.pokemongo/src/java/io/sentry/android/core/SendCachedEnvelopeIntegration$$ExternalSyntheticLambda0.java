/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.android.core.SendCachedEnvelopeIntegration;
import io.sentry.android.core.SentryAndroidOptions;

public final class SendCachedEnvelopeIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final SendCachedEnvelopeIntegration f$0;
    public final SentryAndroidOptions f$1;
    public final IHub f$2;

    public /* synthetic */ SendCachedEnvelopeIntegration$$ExternalSyntheticLambda0(SendCachedEnvelopeIntegration sendCachedEnvelopeIntegration, SentryAndroidOptions sentryAndroidOptions, IHub iHub) {
        this.f$0 = sendCachedEnvelopeIntegration;
        this.f$1 = sentryAndroidOptions;
        this.f$2 = iHub;
    }

    public final void run() {
        this.f$0.lambda$sendCachedEnvelopes$0$io-sentry-android-core-SendCachedEnvelopeIntegration(this.f$1, this.f$2);
    }
}

