/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core.internal.util;

public class ClassUtil {
    public static String getClassName(Object object) {
        if (object == null) {
            return null;
        }
        String string2 = object.getClass().getCanonicalName();
        if (string2 != null) {
            return string2;
        }
        return object.getClass().getSimpleName();
    }
}

