/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.telephony.PhoneStateListener
 *  android.telephony.TelephonyManager
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import io.sentry.Breadcrumb;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.PhoneStateBreadcrumbsIntegration$$ExternalSyntheticLambda0;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.Permissions;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class PhoneStateBreadcrumbsIntegration
implements Integration,
Closeable {
    private final Context context;
    private boolean isClosed = false;
    PhoneStateChangeListener listener;
    private SentryAndroidOptions options;
    private final Object startLock = new Object();
    private TelephonyManager telephonyManager;

    public PhoneStateBreadcrumbsIntegration(Context context) {
        this.context = Objects.requireNonNull(context, "Context is required");
    }

    private void startTelephonyListener(IHub iHub, SentryOptions sentryOptions) {
        Object object;
        this.telephonyManager = object = (TelephonyManager)this.context.getSystemService("phone");
        if (object != null) {
            try {
                object = new PhoneStateChangeListener(iHub);
                this.listener = object;
                this.telephonyManager.listen((PhoneStateListener)object, 32);
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "PhoneStateBreadcrumbsIntegration installed.", new Object[0]);
                IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.INFO, throwable, "TelephonyManager is not available or ready to use.", new Object[0]);
            }
        } else {
            sentryOptions.getLogger().log(SentryLevel.INFO, "TelephonyManager is not available", new Object[0]);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            this.isClosed = true;
        }
        Object object3 = this.telephonyManager;
        if (object3 != null && (object = this.listener) != null) {
            object3.listen((PhoneStateListener)object, 0);
            this.listener = null;
            object3 = this.options;
            if (object3 != null) {
                ((SentryOptions)object3).getLogger().log(SentryLevel.DEBUG, "PhoneStateBreadcrumbsIntegration removed.", new Object[0]);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$register$0$io-sentry-android-core-PhoneStateBreadcrumbsIntegration(IHub iHub, SentryOptions sentryOptions) {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            if (!this.isClosed) {
                this.startTelephonyListener(iHub, sentryOptions);
            }
            return;
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        Objects.requireNonNull(iHub, "Hub is required");
        Object object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        object = Objects.requireNonNull(object, "SentryAndroidOptions is required");
        this.options = object;
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "enableSystemEventBreadcrumbs enabled: %s", this.options.isEnableSystemEventBreadcrumbs());
        if (this.options.isEnableSystemEventBreadcrumbs() && Permissions.hasPermission(this.context, "android.permission.READ_PHONE_STATE")) {
            try {
                object = sentryOptions.getExecutorService();
                PhoneStateBreadcrumbsIntegration$$ExternalSyntheticLambda0 phoneStateBreadcrumbsIntegration$$ExternalSyntheticLambda0 = new PhoneStateBreadcrumbsIntegration$$ExternalSyntheticLambda0(this, iHub, sentryOptions);
                object.submit(phoneStateBreadcrumbsIntegration$$ExternalSyntheticLambda0);
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to start PhoneStateBreadcrumbsIntegration on executor thread.", throwable);
            }
        }
    }

    static final class PhoneStateChangeListener
    extends PhoneStateListener {
        private final IHub hub;

        PhoneStateChangeListener(IHub iHub) {
            this.hub = iHub;
        }

        public void onCallStateChanged(int n2, String object) {
            if (n2 == 1) {
                object = new Breadcrumb();
                ((Breadcrumb)object).setType("system");
                ((Breadcrumb)object).setCategory("device.event");
                ((Breadcrumb)object).setData("action", "CALL_STATE_RINGING");
                ((Breadcrumb)object).setMessage("Device ringing");
                ((Breadcrumb)object).setLevel(SentryLevel.INFO);
                this.hub.addBreadcrumb((Breadcrumb)object);
            }
        }
    }
}

