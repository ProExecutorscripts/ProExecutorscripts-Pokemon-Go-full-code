/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core.internal.threaddump;

public final class Line {
    public int lineno;
    public String text;

    public Line(int n2, String string2) {
        this.lineno = n2;
        this.text = string2;
    }
}

