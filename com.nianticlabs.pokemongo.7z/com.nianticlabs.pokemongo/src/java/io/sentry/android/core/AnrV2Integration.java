/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ApplicationExitInfo
 *  android.content.Context
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import io.sentry.Attachment;
import io.sentry.DateUtils;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.Integration;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.cache.AndroidEnvelopeCache;
import io.sentry.cache.EnvelopeCache;
import io.sentry.cache.IEnvelopeCache;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.Backfillable;
import io.sentry.hints.BlockingFlushHint;
import io.sentry.protocol.Message;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryThread;
import io.sentry.transport.CurrentDateProvider;
import io.sentry.transport.ICurrentDateProvider;
import io.sentry.util.HintUtils;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AnrV2Integration
implements Integration,
Closeable {
    static final long NINETY_DAYS_THRESHOLD = TimeUnit.DAYS.toMillis(91L);
    private final Context context;
    private final ICurrentDateProvider dateProvider;
    private SentryAndroidOptions options;

    public AnrV2Integration(Context context) {
        this(context, CurrentDateProvider.getInstance());
    }

    AnrV2Integration(Context context, ICurrentDateProvider iCurrentDateProvider) {
        this.context = context;
        this.dateProvider = iCurrentDateProvider;
    }

    public void close() throws IOException {
        SentryAndroidOptions sentryAndroidOptions = this.options;
        if (sentryAndroidOptions != null) {
            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "AnrV2Integration removed.", new Object[0]);
        }
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        Object object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        object = Objects.requireNonNull(object, "SentryAndroidOptions is required");
        this.options = object;
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "AnrIntegration enabled: %s", this.options.isAnrEnabled());
        if (this.options.getCacheDirPath() == null) {
            this.options.getLogger().log(SentryLevel.INFO, "Cache dir is not set, unable to process ANRs", new Object[0]);
            return;
        }
        if (this.options.isAnrEnabled()) {
            try {
                object = sentryOptions.getExecutorService();
                AnrProcessor anrProcessor = new AnrProcessor(this.context, iHub, this.options, this.dateProvider);
                object.submit(anrProcessor);
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to start AnrProcessor.", throwable);
            }
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "AnrV2Integration installed.", new Object[0]);
            IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
        }
    }

    static class AnrProcessor
    implements Runnable {
        private final Context context;
        private final IHub hub;
        private final SentryAndroidOptions options;
        private final long threshold;

        AnrProcessor(Context context, IHub iHub, SentryAndroidOptions sentryAndroidOptions, ICurrentDateProvider iCurrentDateProvider) {
            this.context = context;
            this.hub = iHub;
            this.options = sentryAndroidOptions;
            this.threshold = iCurrentDateProvider.getCurrentTimeMillis() - NINETY_DAYS_THRESHOLD;
        }

        private byte[] getDumpBytes(InputStream object) throws IOException {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                int n2;
                byte[] byArray = new byte[1024];
                while ((n2 = object.read(byArray, 0, 1024)) != -1) {
                    byteArrayOutputStream.write(byArray, 0, n2);
                }
                object = byteArrayOutputStream.toByteArray();
                return object;
            }
            finally {
                try {
                    byteArrayOutputStream.close();
                }
                catch (Throwable throwable) {
                    Throwable throwable2;
                    throwable2.addSuppressed(throwable);
                }
            }
        }

        /*
         * Exception decompiling
         */
        private ParseResult parseThreadDump(ApplicationExitInfo var1_1, boolean var2_4) {
            /*
             * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
             * 
             * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
             *     at kb.j.j1(SourceFile:66)
             *     at kb.j.X0(SourceFile:54)
             *     at kb.i.Z0(SourceFile:40)
             *     at ib.f.d(SourceFile:217)
             *     at ib.f.e(SourceFile:7)
             *     at ib.f.c(SourceFile:95)
             *     at rc.f.n(SourceFile:11)
             *     at pc.i.m(SourceFile:5)
             *     at pc.d.K(SourceFile:92)
             *     at pc.d.A(SourceFile:32)
             *     at pc.d.K(SourceFile:27)
             *     at pc.d.g0(SourceFile:1)
             *     at fb.b.d(SourceFile:191)
             *     at fb.b.c(SourceFile:145)
             *     at fb.a.a(SourceFile:108)
             *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
             *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
             *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
             *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
             *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
             *     at e7.a.run(SourceFile:1)
             *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
             *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
             *     at java.lang.Thread.run(Thread.java:929)
             */
            throw new IllegalStateException("Decompilation failed");
        }

        private void reportAsSentryEvent(ApplicationExitInfo object, boolean bl) {
            long l2 = object.getTimestamp();
            boolean bl2 = object.getImportance() != 100;
            ParseResult parseResult = this.parseThreadDump((ApplicationExitInfo)object, bl2);
            if (parseResult.type == ParseResult.Type.NO_DUMP) {
                this.options.getLogger().log(SentryLevel.WARNING, "Not reporting ANR event as there was no thread dump for the ANR %s", object.toString());
                return;
            }
            AnrV2Hint anrV2Hint = new AnrV2Hint(this.options.getFlushTimeoutMillis(), this.options.getLogger(), l2, bl, bl2);
            object = HintUtils.createWithTypeCheckHint(anrV2Hint);
            SentryEvent sentryEvent = new SentryEvent();
            if (parseResult.type == ParseResult.Type.ERROR) {
                Message message = new Message();
                message.setFormatted("Sentry Android SDK failed to parse system thread dump for this ANR. We recommend enabling [SentryOptions.isAttachAnrThreadDump] option to attach the thread dump as plain text and report this issue on GitHub.");
                sentryEvent.setMessage(message);
            } else if (parseResult.type == ParseResult.Type.DUMP) {
                sentryEvent.setThreads(parseResult.threads);
            }
            sentryEvent.setLevel(SentryLevel.FATAL);
            sentryEvent.setTimestamp(DateUtils.getDateTime(l2));
            if (this.options.isAttachAnrThreadDump() && parseResult.dump != null) {
                ((Hint)object).setThreadDump(Attachment.fromThreadDump(parseResult.dump));
            }
            if (!this.hub.captureEvent(sentryEvent, (Hint)object).equals(SentryId.EMPTY_ID) && !anrV2Hint.waitFlush()) {
                this.options.getLogger().log(SentryLevel.WARNING, "Timed out waiting to flush ANR event to disk. Event: %s", sentryEvent.getEventId());
            }
        }

        private void reportNonEnrichedHistoricalAnrs(List<ApplicationExitInfo> iterator, Long l2) {
            Collections.reverse(iterator);
            for (ApplicationExitInfo applicationExitInfo : iterator) {
                if (applicationExitInfo.getReason() != 6) continue;
                if (applicationExitInfo.getTimestamp() < this.threshold) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "ANR happened too long ago %s.", applicationExitInfo);
                    continue;
                }
                if (l2 != null && applicationExitInfo.getTimestamp() <= l2) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "ANR has already been reported %s.", applicationExitInfo);
                    continue;
                }
                this.reportAsSentryEvent(applicationExitInfo, false);
            }
        }

        public void run() {
            ArrayList arrayList;
            IEnvelopeCache iEnvelopeCache;
            ActivityManager activityManager;
            block7: {
                activityManager = (ActivityManager)this.context.getSystemService("activity");
                Object var2_2 = null;
                if ((activityManager = activityManager.getHistoricalProcessExitReasons(null, 0, 0)).size() == 0) {
                    this.options.getLogger().log(SentryLevel.DEBUG, "No records in historical exit reasons.", new Object[0]);
                    return;
                }
                iEnvelopeCache = this.options.getEnvelopeDiskCache();
                if (iEnvelopeCache instanceof EnvelopeCache && this.options.isEnableAutoSessionTracking() && !((EnvelopeCache)(iEnvelopeCache = (EnvelopeCache)iEnvelopeCache)).waitPreviousSessionFlush()) {
                    this.options.getLogger().log(SentryLevel.WARNING, "Timed out waiting to flush previous session to its own file.", new Object[0]);
                    ((EnvelopeCache)iEnvelopeCache).flushPreviousSession();
                }
                arrayList = new ArrayList((Collection)activityManager);
                iEnvelopeCache = AndroidEnvelopeCache.lastReportedAnr(this.options);
                Iterator iterator = arrayList.iterator();
                do {
                    activityManager = var2_2;
                    if (!iterator.hasNext()) break block7;
                } while ((activityManager = (ApplicationExitInfo)iterator.next()).getReason() != 6);
                arrayList.remove((Object)activityManager);
            }
            if (activityManager == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "No ANRs have been found in the historical exit reasons list.", new Object[0]);
                return;
            }
            if (activityManager.getTimestamp() < this.threshold) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Latest ANR happened too long ago, returning early.", new Object[0]);
                return;
            }
            if (iEnvelopeCache != null && activityManager.getTimestamp() <= iEnvelopeCache.longValue()) {
                this.options.getLogger().log(SentryLevel.DEBUG, "Latest ANR has already been reported, returning early.", new Object[0]);
                return;
            }
            if (this.options.isReportHistoricalAnrs()) {
                this.reportNonEnrichedHistoricalAnrs((List<ApplicationExitInfo>)arrayList, (Long)iEnvelopeCache);
            }
            this.reportAsSentryEvent((ApplicationExitInfo)activityManager, true);
        }
    }

    public static final class AnrV2Hint
    extends BlockingFlushHint
    implements Backfillable,
    AbnormalExit {
        private final boolean isBackgroundAnr;
        private final boolean shouldEnrich;
        private final long timestamp;

        public AnrV2Hint(long l2, ILogger iLogger, long l3, boolean bl, boolean bl2) {
            super(l2, iLogger);
            this.timestamp = l3;
            this.shouldEnrich = bl;
            this.isBackgroundAnr = bl2;
        }

        @Override
        public boolean ignoreCurrentThread() {
            return false;
        }

        @Override
        public boolean isFlushable(SentryId sentryId) {
            return true;
        }

        @Override
        public String mechanism() {
            String string2 = this.isBackgroundAnr ? "anr_background" : "anr_foreground";
            return string2;
        }

        @Override
        public void setFlushable(SentryId sentryId) {
        }

        @Override
        public boolean shouldEnrich() {
            return this.shouldEnrich;
        }

        @Override
        public Long timestamp() {
            return this.timestamp;
        }
    }

    static final class ParseResult {
        final byte[] dump;
        final List<SentryThread> threads;
        final Type type;

        ParseResult(Type type) {
            this.type = type;
            this.dump = null;
            this.threads = null;
        }

        ParseResult(Type type, byte[] byArray) {
            this.type = type;
            this.dump = byArray;
            this.threads = null;
        }

        ParseResult(Type type, byte[] byArray, List<SentryThread> list) {
            this.type = type;
            this.dump = byArray;
            this.threads = list;
        }

        static enum Type {
            DUMP,
            NO_DUMP,
            ERROR;

        }
    }
}

