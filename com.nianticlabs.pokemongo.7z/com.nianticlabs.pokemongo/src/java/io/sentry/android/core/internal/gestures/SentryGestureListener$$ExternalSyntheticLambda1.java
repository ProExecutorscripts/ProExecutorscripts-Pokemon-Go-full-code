/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core.internal.gestures;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.android.core.internal.gestures.SentryGestureListener;

public final class SentryGestureListener$$ExternalSyntheticLambda1
implements ScopeCallback {
    public final SentryGestureListener f$0;

    public /* synthetic */ SentryGestureListener$$ExternalSyntheticLambda1(SentryGestureListener sentryGestureListener) {
        this.f$0 = sentryGestureListener;
    }

    @Override
    public final void run(IScope iScope) {
        this.f$0.lambda$stopTracing$1$io-sentry-android-core-internal-gestures-SentryGestureListener(iScope);
    }
}

