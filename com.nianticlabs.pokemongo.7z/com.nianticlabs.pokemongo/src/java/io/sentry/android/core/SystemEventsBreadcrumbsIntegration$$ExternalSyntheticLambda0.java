/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.SentryOptions;
import io.sentry.android.core.SystemEventsBreadcrumbsIntegration;

public final class SystemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final SystemEventsBreadcrumbsIntegration f$0;
    public final IHub f$1;
    public final SentryOptions f$2;

    public /* synthetic */ SystemEventsBreadcrumbsIntegration$$ExternalSyntheticLambda0(SystemEventsBreadcrumbsIntegration systemEventsBreadcrumbsIntegration, IHub iHub, SentryOptions sentryOptions) {
        this.f$0 = systemEventsBreadcrumbsIntegration;
        this.f$1 = iHub;
        this.f$2 = sentryOptions;
    }

    public final void run() {
        this.f$0.lambda$register$0$io-sentry-android-core-SystemEventsBreadcrumbsIntegration(this.f$1, this.f$2);
    }
}

