/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.core.internal.util;

import io.sentry.protocol.Device;

public final class DeviceOrientations {
    private DeviceOrientations() {
    }

    public static Device.DeviceOrientation getOrientation(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                return null;
            }
            return Device.DeviceOrientation.LANDSCAPE;
        }
        return Device.DeviceOrientation.PORTRAIT;
    }
}

