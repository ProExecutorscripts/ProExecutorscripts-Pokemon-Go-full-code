/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources$NotFoundException
 *  android.view.View
 *  android.view.ViewGroup
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.LinkedList
 */
package io.sentry.android.core.internal.gestures;

import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.internal.gestures.GestureTargetLocator;
import io.sentry.internal.gestures.UiElement;
import io.sentry.util.Objects;
import java.util.Iterator;
import java.util.LinkedList;

public final class ViewUtils {
    static UiElement findTarget(SentryAndroidOptions sentryAndroidOptions, View view2, float f2, float f3, UiElement.Type type) {
        LinkedList linkedList = new LinkedList();
        linkedList.add((Object)view2);
        Object object = null;
        block0: while (linkedList.size() > 0) {
            View view3 = Objects.requireNonNull((View)linkedList.poll(), "view is required");
            if (view3 instanceof ViewGroup) {
                view2 = (ViewGroup)view3;
                for (int i2 = 0; i2 < view2.getChildCount(); ++i2) {
                    linkedList.add((Object)view2.getChildAt(i2));
                }
            }
            Iterator iterator = sentryAndroidOptions.getGestureTargetLocators().iterator();
            view2 = object;
            while (true) {
                object = view2;
                if (!iterator.hasNext()) continue block0;
                object = ((GestureTargetLocator)iterator.next()).locate(view3, f2, f3, type);
                if (object == null) continue;
                if (type != UiElement.Type.CLICKABLE) break;
                view2 = object;
            }
            return object;
        }
        return object;
    }

    public static String getResourceId(View view2) throws Resources.NotFoundException {
        int n2 = view2.getId();
        if (n2 != -1 && !ViewUtils.isViewIdGenerated(n2)) {
            if ((view2 = view2.getContext().getResources()) != null) {
                return view2.getResourceEntryName(n2);
            }
            return "";
        }
        throw new Resources.NotFoundException();
    }

    static String getResourceIdWithFallback(View object) {
        int n2 = object.getId();
        try {
            object = ViewUtils.getResourceId(object);
            return object;
        }
        catch (Resources.NotFoundException notFoundException) {
            return "0x" + Integer.toString((int)n2, (int)16);
        }
    }

    private static boolean isViewIdGenerated(int n2) {
        boolean bl = (0xFF000000 & n2) == 0 && (n2 & 0xFFFFFF) != 0;
        return bl;
    }
}

