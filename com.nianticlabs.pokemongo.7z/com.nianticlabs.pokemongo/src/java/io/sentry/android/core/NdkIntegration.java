/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class NdkIntegration
implements Integration,
Closeable {
    public static final String SENTRY_NDK_CLASS_NAME = "io.sentry.android.ndk.SentryNdk";
    private SentryAndroidOptions options;
    private final Class<?> sentryNdkClass;

    public NdkIntegration(Class<?> clazz) {
        this.sentryNdkClass = clazz;
    }

    private void disableNdkIntegration(SentryAndroidOptions sentryAndroidOptions) {
        sentryAndroidOptions.setEnableNdk(false);
        sentryAndroidOptions.setEnableScopeSync(false);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        Class<?> clazz = this.options;
        if (clazz == null) return;
        if (!clazz.isEnableNdk()) return;
        clazz = this.sentryNdkClass;
        if (clazz == null) return;
        try {
            clazz.getMethod("close", new Class[0]).invoke(null, new Object[0]);
            this.options.getLogger().log(SentryLevel.DEBUG, "NdkIntegration removed.", new Object[0]);
            return;
        }
        catch (Throwable throwable) {
            try {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to close SentryNdk.", throwable);
                return;
                catch (NoSuchMethodException noSuchMethodException) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Failed to invoke the SentryNdk.close method.", noSuchMethodException);
                    return;
                }
            }
            finally {
                this.disableNdkIntegration(this.options);
            }
        }
    }

    Class<?> getSentryNdkClass() {
        return this.sentryNdkClass;
    }

    @Override
    public final void register(IHub object, SentryOptions sentryOptions) {
        Objects.requireNonNull(object, "Hub is required");
        object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = object = (SentryAndroidOptions)Objects.requireNonNull(object, "SentryAndroidOptions is required");
        boolean bl = ((SentryAndroidOptions)object).isEnableNdk();
        this.options.getLogger().log(SentryLevel.DEBUG, "NdkIntegration enabled: %s", bl);
        if (bl && this.sentryNdkClass != null) {
            if (this.options.getCacheDirPath() == null) {
                this.options.getLogger().log(SentryLevel.ERROR, "No cache dir path is defined in options.", new Object[0]);
                this.disableNdkIntegration(this.options);
                return;
            }
            try {
                this.sentryNdkClass.getMethod("init", new Class[]{SentryAndroidOptions.class}).invoke(null, new Object[]{this.options});
                this.options.getLogger().log(SentryLevel.DEBUG, "NdkIntegration installed.", new Object[0]);
                IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
            }
            catch (Throwable throwable) {
                this.disableNdkIntegration(this.options);
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to initialize SentryNdk.", throwable);
            }
            catch (NoSuchMethodException noSuchMethodException) {
                this.disableNdkIntegration(this.options);
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to invoke the SentryNdk.init method.", noSuchMethodException);
            }
        } else {
            this.disableNdkIntegration(this.options);
        }
    }
}

