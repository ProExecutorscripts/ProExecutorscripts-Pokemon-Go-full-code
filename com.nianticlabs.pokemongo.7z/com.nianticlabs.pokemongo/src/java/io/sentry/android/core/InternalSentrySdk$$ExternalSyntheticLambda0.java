/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.SentryOptions;
import io.sentry.Session;
import io.sentry.android.core.InternalSentrySdk;
import java.util.concurrent.atomic.AtomicReference;

public final class InternalSentrySdk$$ExternalSyntheticLambda0
implements ScopeCallback {
    public final Session.State f$0;
    public final boolean f$1;
    public final AtomicReference f$2;
    public final SentryOptions f$3;

    public /* synthetic */ InternalSentrySdk$$ExternalSyntheticLambda0(Session.State state, boolean bl, AtomicReference atomicReference, SentryOptions sentryOptions) {
        this.f$0 = state;
        this.f$1 = bl;
        this.f$2 = atomicReference;
        this.f$3 = sentryOptions;
    }

    @Override
    public final void run(IScope iScope) {
        InternalSentrySdk.lambda$updateSession$1(this.f$0, this.f$1, this.f$2, this.f$3, iScope);
    }
}

