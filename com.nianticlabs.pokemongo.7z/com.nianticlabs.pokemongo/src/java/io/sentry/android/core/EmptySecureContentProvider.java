/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentValues
 *  android.database.Cursor
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import io.sentry.android.core.internal.util.ContentProviderSecurityChecker;

abstract class EmptySecureContentProvider
extends ContentProvider {
    private final ContentProviderSecurityChecker securityChecker = new ContentProviderSecurityChecker();

    EmptySecureContentProvider() {
    }

    public final int delete(Uri uri, String string2, String[] stringArray) {
        this.securityChecker.checkPrivilegeEscalation(this);
        return 0;
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        this.securityChecker.checkPrivilegeEscalation(this);
        return null;
    }

    public final Cursor query(Uri uri, String[] stringArray, String string2, String[] stringArray2, String string3) {
        this.securityChecker.checkPrivilegeEscalation(this);
        return null;
    }

    public final int update(Uri uri, ContentValues contentValues, String string2, String[] stringArray) {
        this.securityChecker.checkPrivilegeEscalation(this);
        return 0;
    }
}

