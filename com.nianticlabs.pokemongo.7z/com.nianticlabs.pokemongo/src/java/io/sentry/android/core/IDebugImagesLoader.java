/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package io.sentry.android.core;

import io.sentry.protocol.DebugImage;
import java.util.List;

public interface IDebugImagesLoader {
    public void clearDebugImages();

    public List<DebugImage> loadDebugImages();
}

