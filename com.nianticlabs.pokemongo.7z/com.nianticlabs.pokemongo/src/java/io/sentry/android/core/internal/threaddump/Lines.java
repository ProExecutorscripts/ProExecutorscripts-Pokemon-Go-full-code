/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.FileReader
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package io.sentry.android.core.internal.threaddump;

import io.sentry.android.core.internal.threaddump.Line;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

public final class Lines {
    private final ArrayList<? extends Line> mList;
    private final int mMax;
    private final int mMin;
    public int pos;

    public Lines(ArrayList<? extends Line> arrayList) {
        this.mList = arrayList;
        this.mMin = 0;
        this.mMax = arrayList.size();
    }

    public static Lines readLines(BufferedReader bufferedReader) throws IOException {
        String string2;
        ArrayList arrayList = new ArrayList();
        int n2 = 0;
        while ((string2 = bufferedReader.readLine()) != null) {
            arrayList.add((Object)new Line(++n2, string2));
        }
        return new Lines((ArrayList<? extends Line>)arrayList);
    }

    public static Lines readLines(File object) throws IOException {
        BufferedReader bufferedReader = new BufferedReader((Reader)new FileReader(object));
        try {
            object = Lines.readLines(bufferedReader);
            return object;
        }
        finally {
            bufferedReader.close();
        }
    }

    public boolean hasNext() {
        boolean bl = this.pos < this.mMax;
        return bl;
    }

    public Line next() {
        int n2 = this.pos;
        if (n2 >= this.mMin && n2 < this.mMax) {
            ArrayList<? extends Line> arrayList = this.mList;
            this.pos = n2 + 1;
            return (Line)arrayList.get(n2);
        }
        return null;
    }

    public void rewind() {
        --this.pos;
    }
}

