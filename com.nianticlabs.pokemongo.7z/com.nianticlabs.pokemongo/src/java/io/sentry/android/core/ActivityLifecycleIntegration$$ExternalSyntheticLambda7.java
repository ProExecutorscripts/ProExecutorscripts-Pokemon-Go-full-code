/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda7
implements ScopeCallback {
    public final String f$0;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda7(String string2) {
        this.f$0 = string2;
    }

    @Override
    public final void run(IScope iScope) {
        ActivityLifecycleIntegration.lambda$onActivityCreated$6(this.f$0, iScope);
    }
}

