/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager$MemoryInfo
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 */
package io.sentry.android.core;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import io.sentry.BackfillingEventProcessor;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.JsonSerializable;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.SentryExceptionFactory;
import io.sentry.SentryLevel;
import io.sentry.SentryStackTraceFactory;
import io.sentry.SpanContext;
import io.sentry.android.core.ApplicationNotResponding;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.Installation;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.CpuInfoUtils;
import io.sentry.cache.PersistingOptionsObserver;
import io.sentry.cache.PersistingScopeObserver;
import io.sentry.hints.AbnormalExit;
import io.sentry.hints.Backfillable;
import io.sentry.protocol.App;
import io.sentry.protocol.Contexts;
import io.sentry.protocol.DebugImage;
import io.sentry.protocol.DebugMeta;
import io.sentry.protocol.Device;
import io.sentry.protocol.Mechanism;
import io.sentry.protocol.OperatingSystem;
import io.sentry.protocol.Request;
import io.sentry.protocol.SdkVersion;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.util.HintUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class AnrV2EventProcessor
implements BackfillingEventProcessor {
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private final SentryAndroidOptions options;
    private final SentryExceptionFactory sentryExceptionFactory;

    public AnrV2EventProcessor(Context context, SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider buildInfoProvider) {
        this.context = context;
        this.options = sentryAndroidOptions;
        this.buildInfoProvider = buildInfoProvider;
        this.sentryExceptionFactory = new SentryExceptionFactory(new SentryStackTraceFactory(sentryAndroidOptions));
    }

    private void backfillOptions(SentryEvent sentryEvent, Object object) {
        this.setRelease(sentryEvent);
        this.setEnvironment(sentryEvent);
        this.setDist(sentryEvent);
        this.setDebugMeta(sentryEvent);
        this.setSdk(sentryEvent);
        this.setApp(sentryEvent, object);
        this.setOptionsTags(sentryEvent);
    }

    private void backfillScope(SentryEvent sentryEvent, Object object) {
        this.setRequest(sentryEvent);
        this.setUser(sentryEvent);
        this.setScopeTags(sentryEvent);
        this.setBreadcrumbs(sentryEvent);
        this.setExtras(sentryEvent);
        this.setContexts(sentryEvent);
        this.setTransaction(sentryEvent);
        this.setFingerprints(sentryEvent, object);
        this.setLevel(sentryEvent);
        this.setTrace(sentryEvent);
    }

    private SentryThread findMainThread(List<SentryThread> object) {
        if (object != null) {
            Iterator iterator = object.iterator();
            while (iterator.hasNext()) {
                object = (SentryThread)iterator.next();
                String string2 = ((SentryThread)object).getName();
                if (string2 == null || !string2.equals((Object)"main")) continue;
                return object;
            }
        }
        return null;
    }

    private Device getDevice() {
        Device device = new Device();
        if (this.options.isSendDefaultPii()) {
            device.setName(ContextUtils.getDeviceName(this.context));
        }
        device.setManufacturer(Build.MANUFACTURER);
        device.setBrand(Build.BRAND);
        device.setFamily(ContextUtils.getFamily(this.options.getLogger()));
        device.setModel(Build.MODEL);
        device.setModelId(Build.ID);
        device.setArchs(ContextUtils.getArchitectures(this.buildInfoProvider));
        List<Integer> list = ContextUtils.getMemInfo(this.context, this.options.getLogger());
        if (list != null) {
            device.setMemorySize(this.getMemorySize((ActivityManager.MemoryInfo)list));
        }
        device.setSimulator(this.buildInfoProvider.isEmulator());
        list = ContextUtils.getDisplayMetrics(this.context, this.options.getLogger());
        if (list != null) {
            device.setScreenWidthPixels(list.widthPixels);
            device.setScreenHeightPixels(list.heightPixels);
            device.setScreenDensity(Float.valueOf((float)list.density));
            device.setScreenDpi(list.densityDpi);
        }
        if (device.getId() == null) {
            device.setId(this.getDeviceId());
        }
        if (!(list = CpuInfoUtils.getInstance().readMaxFrequencies()).isEmpty()) {
            device.setProcessorFrequency(((Integer)Collections.max(list)).doubleValue());
            device.setProcessorCount(list.size());
        }
        return device;
    }

    private String getDeviceId() {
        try {
            String string2 = Installation.id(this.context);
            return string2;
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting installationId.", throwable);
            return null;
        }
    }

    private Long getMemorySize(ActivityManager.MemoryInfo memoryInfo) {
        return memoryInfo.totalMem;
    }

    private OperatingSystem getOperatingSystem() {
        OperatingSystem operatingSystem = new OperatingSystem();
        operatingSystem.setName("Android");
        operatingSystem.setVersion(Build.VERSION.RELEASE);
        operatingSystem.setBuild(Build.DISPLAY);
        try {
            operatingSystem.setKernelVersion(ContextUtils.getKernelVersion(this.options.getLogger()));
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting OperatingSystem.", throwable);
        }
        return operatingSystem;
    }

    private boolean isBackgroundAnr(Object object) {
        if (object instanceof AbnormalExit) {
            return "anr_background".equals((Object)((AbnormalExit)object).mechanism());
        }
        return false;
    }

    private void mergeOS(SentryBaseEvent sentryBaseEvent) {
        OperatingSystem operatingSystem = sentryBaseEvent.getContexts().getOperatingSystem();
        Object object = this.getOperatingSystem();
        sentryBaseEvent.getContexts().setOperatingSystem((OperatingSystem)object);
        if (operatingSystem != null) {
            object = operatingSystem.getName();
            object = object != null && !object.isEmpty() ? "os_" + object.trim().toLowerCase(Locale.ROOT) : "os_1";
            sentryBaseEvent.getContexts().put(object, operatingSystem);
        }
    }

    private void mergeUser(SentryBaseEvent sentryBaseEvent) {
        User user;
        User user2 = user = sentryBaseEvent.getUser();
        if (user == null) {
            user2 = new User();
            sentryBaseEvent.setUser(user2);
        }
        if (user2.getId() == null) {
            user2.setId(this.getDeviceId());
        }
        if (user2.getIpAddress() == null) {
            user2.setIpAddress("{{auto}}");
        }
    }

    private void setApp(SentryBaseEvent sentryBaseEvent, Object object) {
        Object object2 = sentryBaseEvent.getContexts().getApp();
        App app = object2;
        if (object2 == null) {
            app = new App();
        }
        app.setAppName(ContextUtils.getApplicationName(this.context, this.options.getLogger()));
        app.setInForeground(this.isBackgroundAnr(object) ^ true);
        object = ContextUtils.getPackageInfo(this.context, this.options.getLogger(), this.buildInfoProvider);
        if (object != null) {
            app.setAppIdentifier(((PackageInfo)object).packageName);
        }
        if ((object = sentryBaseEvent.getRelease() != null ? sentryBaseEvent.getRelease() : PersistingOptionsObserver.read(this.options, "release.json", String.class)) != null) {
            try {
                String string2 = object.substring(object.indexOf(64) + 1, object.indexOf(43));
                object2 = object.substring(object.indexOf(43) + 1);
                app.setAppVersion(string2);
                app.setAppBuild((String)object2);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to parse release from scope cache: %s", object);
            }
        }
        sentryBaseEvent.getContexts().setApp(app);
    }

    private void setBreadcrumbs(SentryBaseEvent sentryBaseEvent) {
        List list = PersistingScopeObserver.read(this.options, "breadcrumbs.json", List.class, new Breadcrumb.Deserializer());
        if (list == null) {
            return;
        }
        if (sentryBaseEvent.getBreadcrumbs() == null) {
            sentryBaseEvent.setBreadcrumbs((List<Breadcrumb>)new ArrayList((Collection)list));
        } else {
            sentryBaseEvent.getBreadcrumbs().addAll((Collection)list);
        }
    }

    private void setContexts(SentryBaseEvent object) {
        Contexts contexts2 = PersistingScopeObserver.read(this.options, "contexts.json", Contexts.class);
        if (contexts2 == null) {
            return;
        }
        object = ((SentryBaseEvent)object).getContexts();
        for (Contexts contexts2 : new Contexts(contexts2).entrySet()) {
            Object object2 = contexts2.getValue();
            if ("trace".equals(contexts2.getKey()) && object2 instanceof SpanContext || object.containsKey(contexts2.getKey())) continue;
            object.put((Object)((String)contexts2.getKey()), object2);
        }
    }

    private void setDebugMeta(SentryBaseEvent sentryBaseEvent) {
        List<DebugImage> list;
        JsonSerializable jsonSerializable = sentryBaseEvent.getDebugMeta();
        DebugMeta debugMeta = jsonSerializable;
        if (jsonSerializable == null) {
            debugMeta = new DebugMeta();
        }
        if (debugMeta.getImages() == null) {
            debugMeta.setImages((List<DebugImage>)new ArrayList());
        }
        if ((list = debugMeta.getImages()) != null) {
            String string2 = PersistingOptionsObserver.read(this.options, "proguard-uuid.json", String.class);
            if (string2 != null) {
                jsonSerializable = new DebugImage();
                ((DebugImage)jsonSerializable).setType("proguard");
                ((DebugImage)jsonSerializable).setUuid(string2);
                list.add((Object)jsonSerializable);
            }
            sentryBaseEvent.setDebugMeta(debugMeta);
        }
    }

    private void setDevice(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getContexts().getDevice() == null) {
            sentryBaseEvent.getContexts().setDevice(this.getDevice());
        }
    }

    private void setDist(SentryBaseEvent sentryBaseEvent) {
        String string2;
        if (sentryBaseEvent.getDist() == null) {
            sentryBaseEvent.setDist(PersistingOptionsObserver.read(this.options, "dist.json", String.class));
        }
        if (sentryBaseEvent.getDist() == null && (string2 = PersistingOptionsObserver.read(this.options, "release.json", String.class)) != null) {
            try {
                sentryBaseEvent.setDist(string2.substring(string2.indexOf(43) + 1));
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.WARNING, "Failed to parse release from scope cache: %s", string2);
            }
        }
    }

    private void setEnvironment(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getEnvironment() == null) {
            String string2 = PersistingOptionsObserver.read(this.options, "environment.json", String.class);
            if (string2 == null) {
                string2 = this.options.getEnvironment();
            }
            sentryBaseEvent.setEnvironment(string2);
        }
    }

    private void setExceptions(SentryEvent sentryEvent, Object object) {
        Mechanism mechanism = new Mechanism();
        if (!((Backfillable)object).shouldEnrich()) {
            mechanism.setType("HistoricalAppExitInfo");
        } else {
            mechanism.setType("AppExitInfo");
        }
        object = this.isBackgroundAnr(object) ? "Background ANR" : "ANR";
        ApplicationNotResponding applicationNotResponding = new ApplicationNotResponding((String)object, Thread.currentThread());
        SentryThread sentryThread = this.findMainThread(sentryEvent.getThreads());
        object = sentryThread;
        if (sentryThread == null) {
            object = new SentryThread();
            ((SentryThread)object).setStacktrace(new SentryStackTrace());
        }
        sentryEvent.setExceptions(this.sentryExceptionFactory.getSentryExceptionsFromThread((SentryThread)object, mechanism, (Throwable)applicationNotResponding));
    }

    private void setExtras(SentryBaseEvent sentryBaseEvent) {
        Map map22 = PersistingScopeObserver.read(this.options, "extras.json", Map.class);
        if (map22 == null) {
            return;
        }
        if (sentryBaseEvent.getExtras() == null) {
            sentryBaseEvent.setExtras((Map<String, Object>)new HashMap(map22));
        } else {
            for (Map map22 : map22.entrySet()) {
                if (sentryBaseEvent.getExtras().containsKey(map22.getKey())) continue;
                sentryBaseEvent.getExtras().put((Object)((String)map22.getKey()), map22.getValue());
            }
        }
    }

    private void setFingerprints(SentryEvent sentryEvent, Object object) {
        List list = PersistingScopeObserver.read(this.options, "fingerprint.json", List.class);
        if (sentryEvent.getFingerprints() == null) {
            sentryEvent.setFingerprints((List<String>)list);
        }
        boolean bl = this.isBackgroundAnr(object);
        if (sentryEvent.getFingerprints() == null) {
            object = bl ? "background-anr" : "foreground-anr";
            sentryEvent.setFingerprints((List<String>)Arrays.asList((Object[])new String[]{"{{ default }}", object}));
        }
    }

    private void setLevel(SentryEvent sentryEvent) {
        SentryLevel sentryLevel = PersistingScopeObserver.read(this.options, "level.json", SentryLevel.class);
        if (sentryEvent.getLevel() == null) {
            sentryEvent.setLevel(sentryLevel);
        }
    }

    private void setOptionsTags(SentryBaseEvent sentryBaseEvent) {
        Map map2 = PersistingOptionsObserver.read(this.options, "tags.json", Map.class);
        if (map2 == null) {
            return;
        }
        if (sentryBaseEvent.getTags() == null) {
            sentryBaseEvent.setTags((Map<String, String>)new HashMap(map2));
        } else {
            for (Map.Entry entry : map2.entrySet()) {
                if (sentryBaseEvent.getTags().containsKey(entry.getKey())) continue;
                sentryBaseEvent.setTag((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }

    private void setPlatform(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getPlatform() == null) {
            sentryBaseEvent.setPlatform("java");
        }
    }

    private void setRelease(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getRelease() == null) {
            sentryBaseEvent.setRelease(PersistingOptionsObserver.read(this.options, "release.json", String.class));
        }
    }

    private void setRequest(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getRequest() == null) {
            sentryBaseEvent.setRequest(PersistingScopeObserver.read(this.options, "request.json", Request.class));
        }
    }

    private void setScopeTags(SentryBaseEvent sentryBaseEvent) {
        Map map2 = PersistingScopeObserver.read(this.options, "tags.json", Map.class);
        if (map2 == null) {
            return;
        }
        if (sentryBaseEvent.getTags() == null) {
            sentryBaseEvent.setTags((Map<String, String>)new HashMap(map2));
        } else {
            for (Map.Entry entry : map2.entrySet()) {
                if (sentryBaseEvent.getTags().containsKey(entry.getKey())) continue;
                sentryBaseEvent.setTag((String)entry.getKey(), (String)entry.getValue());
            }
        }
    }

    private void setSdk(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getSdk() == null) {
            sentryBaseEvent.setSdk(PersistingOptionsObserver.read(this.options, "sdk-version.json", SdkVersion.class));
        }
    }

    private void setSideLoadedInfo(SentryBaseEvent sentryBaseEvent) {
        block4: {
            ContextUtils.SideLoadedInfo sideLoadedInfo = ContextUtils.retrieveSideLoadedInfo(this.context, this.options.getLogger(), this.buildInfoProvider);
            if (sideLoadedInfo == null) break block4;
            try {
                for (Map.Entry entry : sideLoadedInfo.asTags().entrySet()) {
                    sentryBaseEvent.setTag((String)entry.getKey(), (String)entry.getValue());
                }
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error getting side loaded info.", throwable);
            }
        }
    }

    private void setStaticValues(SentryEvent sentryEvent) {
        this.mergeUser(sentryEvent);
        this.setSideLoadedInfo(sentryEvent);
    }

    private void setTrace(SentryEvent sentryEvent) {
        SpanContext spanContext = PersistingScopeObserver.read(this.options, "trace.json", SpanContext.class);
        if (sentryEvent.getContexts().getTrace() == null && spanContext != null && spanContext.getSpanId() != null && spanContext.getTraceId() != null) {
            sentryEvent.getContexts().setTrace(spanContext);
        }
    }

    private void setTransaction(SentryEvent sentryEvent) {
        String string2 = PersistingScopeObserver.read(this.options, "transaction.json", String.class);
        if (sentryEvent.getTransaction() == null) {
            sentryEvent.setTransaction(string2);
        }
    }

    private void setUser(SentryBaseEvent sentryBaseEvent) {
        if (sentryBaseEvent.getUser() == null) {
            sentryBaseEvent.setUser(PersistingScopeObserver.read(this.options, "user.json", User.class));
        }
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint object) {
        if (!((object = HintUtils.getSentrySdkHint((Hint)object)) instanceof Backfillable)) {
            this.options.getLogger().log(SentryLevel.WARNING, "The event is not Backfillable, but has been passed to BackfillingEventProcessor, skipping.", new Object[0]);
            return sentryEvent;
        }
        this.setExceptions(sentryEvent, object);
        this.setPlatform(sentryEvent);
        this.mergeOS(sentryEvent);
        this.setDevice(sentryEvent);
        if (!((Backfillable)object).shouldEnrich()) {
            this.options.getLogger().log(SentryLevel.DEBUG, "The event is Backfillable, but should not be enriched, skipping.", new Object[0]);
            return sentryEvent;
        }
        this.backfillScope(sentryEvent, object);
        this.backfillOptions(sentryEvent, object);
        this.setStaticValues(sentryEvent);
        return sentryEvent;
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        return sentryTransaction;
    }
}

