/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 */
package io.sentry.android.core.internal.util;

import android.content.ContentProvider;
import io.sentry.NoOpLogger;
import io.sentry.android.core.BuildInfoProvider;

public final class ContentProviderSecurityChecker {
    private final BuildInfoProvider buildInfoProvider;

    public ContentProviderSecurityChecker() {
        this(new BuildInfoProvider(NoOpLogger.getInstance()));
    }

    public ContentProviderSecurityChecker(BuildInfoProvider buildInfoProvider) {
        this.buildInfoProvider = buildInfoProvider;
    }

    public void checkPrivilegeEscalation(ContentProvider object) {
        int n2 = this.buildInfoProvider.getSdkInfoVersion();
        if (n2 >= 26 && n2 <= 28) {
            String string2 = object.getCallingPackage();
            object = object.getContext().getPackageName();
            if (string2 != null && string2.equals(object)) {
                return;
            }
            throw new SecurityException("Provider does not allow for granting of Uri permissions");
        }
    }
}

