/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry.android.core;

import android.content.Context;
import io.sentry.android.core.DefaultAndroidEventProcessor;
import io.sentry.android.core.SentryAndroidOptions;
import java.util.concurrent.Callable;

public final class DefaultAndroidEventProcessor$$ExternalSyntheticLambda0
implements Callable {
    public final Context f$0;
    public final SentryAndroidOptions f$1;

    public /* synthetic */ DefaultAndroidEventProcessor$$ExternalSyntheticLambda0(Context context, SentryAndroidOptions sentryAndroidOptions) {
        this.f$0 = context;
        this.f$1 = sentryAndroidOptions;
    }

    public final Object call() {
        return DefaultAndroidEventProcessor.lambda$new$0(this.f$0, this.f$1);
    }
}

