/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Process
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core.internal.util;

import android.content.Context;
import android.os.Process;
import io.sentry.util.Objects;

public final class Permissions {
    private Permissions() {
    }

    public static boolean hasPermission(Context context, String string2) {
        Objects.requireNonNull(context, "The application context is required.");
        boolean bl = context.checkPermission(string2, Process.myPid(), Process.myUid()) == 0;
        return bl;
    }
}

