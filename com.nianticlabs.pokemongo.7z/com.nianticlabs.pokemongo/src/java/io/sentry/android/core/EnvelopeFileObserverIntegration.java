/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.ILogger;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.OutboxSender;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.EnvelopeFileObserver;
import io.sentry.android.core.EnvelopeFileObserverIntegration$$ExternalSyntheticLambda0;
import io.sentry.util.Objects;
import java.io.Closeable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class EnvelopeFileObserverIntegration
implements Integration,
Closeable {
    private boolean isClosed = false;
    private ILogger logger;
    private EnvelopeFileObserver observer;
    private final Object startLock = new Object();

    public static EnvelopeFileObserverIntegration getOutboxFileObserver() {
        return new OutboxEnvelopeFileObserverIntegration();
    }

    private void startOutboxSender(IHub object, SentryOptions sentryOptions, String string2) {
        object = new EnvelopeFileObserver(string2, new OutboxSender((IHub)object, sentryOptions.getEnvelopeReader(), sentryOptions.getSerializer(), sentryOptions.getLogger(), sentryOptions.getFlushTimeoutMillis(), sentryOptions.getMaxQueueSize()), sentryOptions.getLogger(), sentryOptions.getFlushTimeoutMillis());
        this.observer = object;
        try {
            object.startWatching();
            sentryOptions.getLogger().log(SentryLevel.DEBUG, "EnvelopeFileObserverIntegration installed.", new Object[0]);
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, "Failed to initialize EnvelopeFileObserverIntegration.", throwable);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            this.isClosed = true;
        }
        object = this.observer;
        if (object != null) {
            object.stopWatching();
            object = this.logger;
            if (object != null) {
                object.log(SentryLevel.DEBUG, "EnvelopeFileObserverIntegration removed.", new Object[0]);
            }
        }
    }

    abstract String getPath(SentryOptions var1);

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$register$0$io-sentry-android-core-EnvelopeFileObserverIntegration(IHub iHub, SentryOptions sentryOptions, String string2) {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            if (!this.isClosed) {
                this.startOutboxSender(iHub, sentryOptions, string2);
            }
            return;
        }
    }

    @Override
    public final void register(IHub iHub, SentryOptions sentryOptions) {
        Objects.requireNonNull(iHub, "Hub is required");
        Objects.requireNonNull(sentryOptions, "SentryOptions is required");
        this.logger = sentryOptions.getLogger();
        String string2 = this.getPath(sentryOptions);
        if (string2 == null) {
            this.logger.log(SentryLevel.WARNING, "Null given as a path to EnvelopeFileObserverIntegration. Nothing will be registered.", new Object[0]);
        } else {
            this.logger.log(SentryLevel.DEBUG, "Registering EnvelopeFileObserverIntegration for path: %s", string2);
            try {
                ISentryExecutorService iSentryExecutorService = sentryOptions.getExecutorService();
                EnvelopeFileObserverIntegration$$ExternalSyntheticLambda0 envelopeFileObserverIntegration$$ExternalSyntheticLambda0 = new EnvelopeFileObserverIntegration$$ExternalSyntheticLambda0(this, iHub, sentryOptions, string2);
                iSentryExecutorService.submit(envelopeFileObserverIntegration$$ExternalSyntheticLambda0);
            }
            catch (Throwable throwable) {
                this.logger.log(SentryLevel.DEBUG, "Failed to start EnvelopeFileObserverIntegration on executor thread.", throwable);
            }
        }
    }

    private static final class OutboxEnvelopeFileObserverIntegration
    extends EnvelopeFileObserverIntegration {
        private OutboxEnvelopeFileObserverIntegration() {
        }

        @Override
        protected String getPath(SentryOptions sentryOptions) {
            return sentryOptions.getOutboxPath();
        }
    }
}

