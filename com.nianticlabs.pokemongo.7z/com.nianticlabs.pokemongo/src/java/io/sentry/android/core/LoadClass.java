/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsatisfiedLinkError
 */
package io.sentry.android.core;

import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;

public final class LoadClass {
    public boolean isClassAvailable(String string2, ILogger iLogger) {
        boolean bl = this.loadClass(string2, iLogger) != null;
        return bl;
    }

    public boolean isClassAvailable(String string2, SentryOptions object) {
        object = object != null ? ((SentryOptions)object).getLogger() : null;
        return this.isClassAvailable(string2, (ILogger)object);
    }

    public Class<?> loadClass(String string2, ILogger iLogger) {
        block6: {
            try {
                Class clazz = Class.forName((String)string2);
                return clazz;
            }
            catch (Throwable throwable) {
                if (iLogger != null) {
                    iLogger.log(SentryLevel.ERROR, "Failed to initialize " + string2, throwable);
                }
            }
            catch (UnsatisfiedLinkError unsatisfiedLinkError) {
                if (iLogger != null) {
                    iLogger.log(SentryLevel.ERROR, "Failed to load (UnsatisfiedLinkError) " + string2, unsatisfiedLinkError);
                }
            }
            catch (ClassNotFoundException classNotFoundException) {
                if (iLogger == null) break block6;
                iLogger.log(SentryLevel.DEBUG, "Class not available:" + string2, classNotFoundException);
            }
        }
        return null;
    }
}

