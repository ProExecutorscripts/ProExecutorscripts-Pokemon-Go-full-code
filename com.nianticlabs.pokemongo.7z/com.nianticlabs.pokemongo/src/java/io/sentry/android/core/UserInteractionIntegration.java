/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.Window
 *  android.view.Window$Callback
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.view.Window;
import io.sentry.IHub;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.LoadClass;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.gestures.NoOpWindowCallback;
import io.sentry.android.core.internal.gestures.SentryGestureListener;
import io.sentry.android.core.internal.gestures.SentryWindowCallback;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

public final class UserInteractionIntegration
implements Integration,
Closeable,
Application.ActivityLifecycleCallbacks {
    private final Application application;
    private IHub hub;
    private final boolean isAndroidXAvailable;
    private SentryAndroidOptions options;

    public UserInteractionIntegration(Application application, LoadClass loadClass) {
        this.application = Objects.requireNonNull(application, "Application is required");
        this.isAndroidXAvailable = loadClass.isClassAvailable("androidx.core.view.GestureDetectorCompat", this.options);
    }

    private void startTracking(Activity object) {
        Window window = object.getWindow();
        if (window == null) {
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.INFO, "Window was null in startTracking", new Object[0]);
            }
            return;
        }
        if (this.hub != null && this.options != null) {
            Window.Callback callback;
            Window.Callback callback2 = callback = window.getCallback();
            if (callback == null) {
                callback2 = new NoOpWindowCallback();
            }
            window.setCallback((Window.Callback)new SentryWindowCallback(callback2, (Context)object, new SentryGestureListener((Activity)object, this.hub, this.options), this.options));
        }
    }

    private void stopTracking(Activity object) {
        if ((object = object.getWindow()) == null) {
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.INFO, "Window was null in stopTracking", new Object[0]);
            }
            return;
        }
        Window.Callback callback = object.getCallback();
        if (callback instanceof SentryWindowCallback) {
            callback = (SentryWindowCallback)callback;
            callback.stopTracking();
            if (callback.getDelegate() instanceof NoOpWindowCallback) {
                object.setCallback(null);
            } else {
                object.setCallback(callback.getDelegate());
            }
        }
    }

    public void close() throws IOException {
        this.application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
        SentryAndroidOptions sentryAndroidOptions = this.options;
        if (sentryAndroidOptions != null) {
            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "UserInteractionIntegration removed.", new Object[0]);
        }
    }

    public void onActivityCreated(Activity activity2, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity2) {
    }

    public void onActivityPaused(Activity activity2) {
        this.stopTracking(activity2);
    }

    public void onActivityResumed(Activity activity2) {
        this.startTracking(activity2);
    }

    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity2) {
    }

    public void onActivityStopped(Activity activity2) {
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        SentryAndroidOptions sentryAndroidOptions = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.hub = Objects.requireNonNull(iHub, "Hub is required");
        boolean bl = this.options.isEnableUserInteractionBreadcrumbs() || this.options.isEnableUserInteractionTracing();
        this.options.getLogger().log(SentryLevel.DEBUG, "UserInteractionIntegration enabled: %s", bl);
        if (bl) {
            if (this.isAndroidXAvailable) {
                this.application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
                this.options.getLogger().log(SentryLevel.DEBUG, "UserInteractionIntegration installed.", new Object[0]);
                IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
            } else {
                sentryOptions.getLogger().log(SentryLevel.INFO, "androidx.core is not available, UserInteractionIntegration won't be installed", new Object[0]);
            }
        }
    }
}

