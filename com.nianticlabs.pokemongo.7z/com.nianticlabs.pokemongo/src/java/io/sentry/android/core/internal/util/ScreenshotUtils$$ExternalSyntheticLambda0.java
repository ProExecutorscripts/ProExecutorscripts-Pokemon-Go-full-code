/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.PixelCopy$OnPixelCopyFinishedListener
 *  java.lang.Object
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.sentry.android.core.internal.util;

import android.view.PixelCopy;
import io.sentry.android.core.internal.util.ScreenshotUtils;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ScreenshotUtils$$ExternalSyntheticLambda0
implements PixelCopy.OnPixelCopyFinishedListener {
    public final AtomicBoolean f$0;
    public final CountDownLatch f$1;

    public /* synthetic */ ScreenshotUtils$$ExternalSyntheticLambda0(AtomicBoolean atomicBoolean, CountDownLatch countDownLatch) {
        this.f$0 = atomicBoolean;
        this.f$1 = countDownLatch;
    }

    public final void onPixelCopyFinished(int n2) {
        ScreenshotUtils.lambda$takeScreenshot$0(this.f$0, this.f$1, n2);
    }
}

