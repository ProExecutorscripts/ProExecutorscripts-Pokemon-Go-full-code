/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$MemoryInfo
 *  android.app.ActivityManager$RunningAppProcessInfo
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$ApplicationInfoFlags
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.PackageManager$PackageInfoFlags
 *  android.os.Build
 *  android.provider.Settings$Global
 *  android.util.DisplayMetrics
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.Map
 */
package io.sentry.android.core;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.util.DisplayMetrics;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.protocol.App;
import java.util.HashMap;
import java.util.Map;

public final class ContextUtils {
    private ContextUtils() {
    }

    static ApplicationInfo getApplicationInfo(Context context, long l2, BuildInfoProvider buildInfoProvider) throws PackageManager.NameNotFoundException {
        if (buildInfoProvider.getSdkInfoVersion() >= 33) {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.ApplicationInfoFlags.of((long)l2));
        }
        return context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static String getApplicationName(Context object, ILogger iLogger) {
        ApplicationInfo applicationInfo;
        try {
            applicationInfo = object.getApplicationInfo();
            int n2 = applicationInfo.labelRes;
            if (n2 != 0) return object.getString(n2);
        }
        catch (Throwable throwable) {
            void var1_3;
            var1_3.log(SentryLevel.ERROR, "Error getting application name.", throwable);
            return null;
        }
        if (applicationInfo.nonLocalizedLabel == null) return object.getPackageManager().getApplicationLabel(applicationInfo).toString();
        return applicationInfo.nonLocalizedLabel.toString();
    }

    static String[] getArchitectures(BuildInfoProvider stringArray) {
        stringArray = stringArray.getSdkInfoVersion() >= 21 ? Build.SUPPORTED_ABIS : new String[]{Build.CPU_ABI, Build.CPU_ABI2};
        return stringArray;
    }

    static String getDeviceName(Context context) {
        return Settings.Global.getString((ContentResolver)context.getContentResolver(), (String)"device_name");
    }

    static DisplayMetrics getDisplayMetrics(Context context, ILogger iLogger) {
        try {
            context = context.getResources().getDisplayMetrics();
            return context;
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Error getting DisplayMetrics.", throwable);
            return null;
        }
    }

    static String getFamily(ILogger iLogger) {
        try {
            String string2 = Build.MODEL.split(" ", -1)[0];
            return string2;
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Error getting device family.", throwable);
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    static String getKernelVersion(ILogger var0) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
         *     at java.lang.Thread.run(Thread.java:929)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    static ActivityManager.MemoryInfo getMemInfo(Context context, ILogger iLogger) {
        block4: {
            ActivityManager activityManager;
            try {
                activityManager = (ActivityManager)context.getSystemService("activity");
                context = new ActivityManager.MemoryInfo();
                if (activityManager == null) break block4;
            }
            catch (Throwable throwable) {
                iLogger.log(SentryLevel.ERROR, "Error getting MemoryInfo.", throwable);
                return null;
            }
            activityManager.getMemoryInfo((ActivityManager.MemoryInfo)context);
            return context;
        }
        iLogger.log(SentryLevel.INFO, "Error getting MemoryInfo.", new Object[0]);
        return null;
    }

    static PackageInfo getPackageInfo(Context context, int n2, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        try {
            if (buildInfoProvider.getSdkInfoVersion() >= 33) {
                return context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.PackageInfoFlags.of((long)n2));
            }
            context = context.getPackageManager().getPackageInfo(context.getPackageName(), n2);
            return context;
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Error getting package info.", throwable);
            return null;
        }
    }

    static PackageInfo getPackageInfo(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) {
        return ContextUtils.getPackageInfo(context, 0, iLogger, buildInfoProvider);
    }

    static String getVersionCode(PackageInfo packageInfo, BuildInfoProvider buildInfoProvider) {
        if (buildInfoProvider.getSdkInfoVersion() >= 28) {
            return Long.toString((long)packageInfo.getLongVersionCode());
        }
        return ContextUtils.getVersionCodeDep(packageInfo);
    }

    private static String getVersionCodeDep(PackageInfo packageInfo) {
        return Integer.toString((int)packageInfo.versionCode);
    }

    static String getVersionName(PackageInfo packageInfo) {
        return packageInfo.versionName;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean isForegroundImportance() {
        boolean bl = false;
        try {
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState((ActivityManager.RunningAppProcessInfo)runningAppProcessInfo);
            int n2 = runningAppProcessInfo.importance;
            if (n2 != 100) return bl;
            return true;
        }
        catch (Throwable throwable) {
            return bl;
        }
    }

    static Intent registerReceiver(Context context, SentryOptions sentryOptions, BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        return ContextUtils.registerReceiver(context, new BuildInfoProvider(sentryOptions.getLogger()), broadcastReceiver, intentFilter);
    }

    static Intent registerReceiver(Context context, BuildInfoProvider buildInfoProvider, BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        if (buildInfoProvider.getSdkInfoVersion() >= 33) {
            return context.registerReceiver(broadcastReceiver, intentFilter, 2);
        }
        return context.registerReceiver(broadcastReceiver, intentFilter);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static SideLoadedInfo retrieveSideLoadedInfo(Context object, ILogger iLogger, BuildInfoProvider object2) {
        object2 = ContextUtils.getPackageInfo(object, iLogger, (BuildInfoProvider)object2);
        PackageManager packageManager = object.getPackageManager();
        if (object2 == null) return null;
        if (packageManager == null) return null;
        object = ((PackageInfo)object2).packageName;
        object2 = packageManager.getInstallerPackageName((String)object);
        boolean bl = object2 == null;
        return new SideLoadedInfo(bl, (String)object2);
        {
            catch (IllegalArgumentException illegalArgumentException) {}
        }
        catch (IllegalArgumentException illegalArgumentException) {
            object = null;
            iLogger.log(SentryLevel.DEBUG, "%s package isn't installed.", object);
        }
        return null;
    }

    static void setAppPackageInfo(PackageInfo object, BuildInfoProvider stringArray, App app) {
        app.setAppIdentifier(object.packageName);
        app.setAppVersion(object.versionName);
        app.setAppBuild(ContextUtils.getVersionCode(object, (BuildInfoProvider)stringArray));
        HashMap hashMap = new HashMap();
        stringArray = object.requestedPermissions;
        int[] nArray = object.requestedPermissionsFlags;
        if (stringArray != null && stringArray.length > 0 && nArray != null && nArray.length > 0) {
            for (int i2 = 0; i2 < stringArray.length; ++i2) {
                object = stringArray[i2];
                int n2 = object.lastIndexOf(46);
                boolean bl = true;
                String string2 = object.substring(n2 + 1);
                if ((nArray[i2] & 2) != 2) {
                    bl = false;
                }
                object = bl ? "granted" : "not_granted";
                hashMap.put((Object)string2, object);
            }
        }
        app.setPermissions((Map<String, String>)hashMap);
    }

    static class SideLoadedInfo {
        private final String installerStore;
        private final boolean isSideLoaded;

        public SideLoadedInfo(boolean bl, String string2) {
            this.isSideLoaded = bl;
            this.installerStore = string2;
        }

        public Map<String, String> asTags() {
            HashMap hashMap = new HashMap();
            hashMap.put((Object)"isSideLoaded", (Object)String.valueOf((boolean)this.isSideLoaded));
            String string2 = this.installerStore;
            if (string2 != null) {
                hashMap.put((Object)"installerStore", (Object)string2);
            }
            return hashMap;
        }

        public String getInstallerStore() {
            return this.installerStore;
        }

        public boolean isSideLoaded() {
            return this.isSideLoaded;
        }
    }
}

