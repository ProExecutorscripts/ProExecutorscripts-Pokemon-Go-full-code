/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package io.sentry.android.core.internal.threaddump;

import io.sentry.SentryLevel;
import io.sentry.SentryLockReason;
import io.sentry.SentryOptions;
import io.sentry.SentryStackTraceFactory;
import io.sentry.android.core.internal.threaddump.Line;
import io.sentry.android.core.internal.threaddump.Lines;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThreadDumpParser {
    private static final Pattern BEGIN_MANAGED_THREAD_RE = Pattern.compile((String)"\"(.*)\" (.*) ?prio=(\\d+)\\s+tid=(\\d+)\\s*(.*)");
    private static final Pattern BEGIN_UNMANAGED_NATIVE_THREAD_RE = Pattern.compile((String)"\"(.*)\" (.*) ?sysTid=(\\d+)");
    private static final Pattern BLANK_RE;
    private static final Pattern JAVA_RE;
    private static final Pattern JNI_RE;
    private static final Pattern LOCKED_RE;
    private static final Pattern NATIVE_NO_LOC_RE;
    private static final Pattern NATIVE_RE;
    private static final Pattern SLEEPING_ON_RE;
    private static final Pattern WAITING_ON_RE;
    private static final Pattern WAITING_TO_LOCK_HELD_RE;
    private static final Pattern WAITING_TO_LOCK_RE;
    private static final Pattern WAITING_TO_LOCK_UNKNOWN_RE;
    private final boolean isBackground;
    private final SentryOptions options;
    private final SentryStackTraceFactory stackTraceFactory;

    static {
        NATIVE_RE = Pattern.compile((String)" *(?:native: )?#\\d+ \\S+ [0-9a-fA-F]+\\s+(.*?)\\s+\\((.*)\\+(\\d+)\\)(?: \\(.*\\))?");
        NATIVE_NO_LOC_RE = Pattern.compile((String)" *(?:native: )?#\\d+ \\S+ [0-9a-fA-F]+\\s+(.*)\\s*\\(?(.*)\\)?(?: \\(.*\\))?");
        JAVA_RE = Pattern.compile((String)" *at (?:(.+)\\.)?([^.]+)\\.([^.]+)\\((.*):([\\d-]+)\\)");
        JNI_RE = Pattern.compile((String)" *at (?:(.+)\\.)?([^.]+)\\.([^.]+)\\(Native method\\)");
        LOCKED_RE = Pattern.compile((String)" *- locked \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)");
        SLEEPING_ON_RE = Pattern.compile((String)" *- sleeping on \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)");
        WAITING_ON_RE = Pattern.compile((String)" *- waiting on \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)");
        WAITING_TO_LOCK_RE = Pattern.compile((String)" *- waiting to lock \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)");
        WAITING_TO_LOCK_HELD_RE = Pattern.compile((String)" *- waiting to lock \\<([0x0-9a-fA-F]{1,16})\\> \\(a (?:(.+)\\.)?([^.]+)\\)(?: held by thread (\\d+))");
        WAITING_TO_LOCK_UNKNOWN_RE = Pattern.compile((String)" *- waiting to lock an unknown object");
        BLANK_RE = Pattern.compile((String)"\\s+");
    }

    public ThreadDumpParser(SentryOptions sentryOptions, boolean bl) {
        this.options = sentryOptions;
        this.isBackground = bl;
        this.stackTraceFactory = new SentryStackTraceFactory(sentryOptions);
    }

    private void combineThreadLocks(SentryThread sentryThread, SentryLockReason sentryLockReason) {
        Object object = sentryThread.getHeldLocks();
        HashMap hashMap = object;
        if (object == null) {
            hashMap = new HashMap();
        }
        if ((object = (SentryLockReason)hashMap.get((Object)sentryLockReason.getAddress())) != null) {
            ((SentryLockReason)object).setType(Math.max((int)((SentryLockReason)object).getType(), (int)sentryLockReason.getType()));
        } else {
            hashMap.put((Object)sentryLockReason.getAddress(), (Object)new SentryLockReason(sentryLockReason));
        }
        sentryThread.setHeldLocks((Map<String, SentryLockReason>)hashMap);
    }

    private Integer getInteger(Matcher object, int n2, Integer n3) {
        if ((object = object.group(n2)) != null && object.length() != 0) {
            return Integer.parseInt((String)object);
        }
        return n3;
    }

    private Long getLong(Matcher object, int n2, Long l2) {
        if ((object = object.group(n2)) != null && object.length() != 0) {
            return Long.parseLong((String)object);
        }
        return l2;
    }

    private Integer getUInteger(Matcher object, int n2, Integer n3) {
        String string2 = object.group(n2);
        object = n3;
        if (string2 != null) {
            if (string2.length() == 0) {
                object = n3;
            } else {
                string2 = Integer.valueOf((int)Integer.parseInt((String)string2));
                object = n3;
                if (string2.intValue() >= 0) {
                    object = string2;
                }
            }
        }
        return object;
    }

    private boolean matches(Matcher matcher, String string2) {
        matcher.reset((CharSequence)string2);
        return matcher.matches();
    }

    /*
     * Unable to fully structure code
     */
    private SentryStackTrace parseStacktrace(Lines var1_1, SentryThread var2_2) {
        var10_3 = new ArrayList();
        var6_4 = ThreadDumpParser.NATIVE_RE.matcher((CharSequence)"");
        var8_5 = ThreadDumpParser.NATIVE_NO_LOC_RE.matcher((CharSequence)"");
        var9_6 = ThreadDumpParser.JAVA_RE.matcher((CharSequence)"");
        var11_7 = ThreadDumpParser.JNI_RE.matcher((CharSequence)"");
        var15_8 = ThreadDumpParser.LOCKED_RE.matcher((CharSequence)"");
        var12_9 = ThreadDumpParser.WAITING_ON_RE.matcher((CharSequence)"");
        var13_10 = ThreadDumpParser.SLEEPING_ON_RE.matcher((CharSequence)"");
        var7_11 = ThreadDumpParser.WAITING_TO_LOCK_HELD_RE.matcher((CharSequence)"");
        var16_12 = ThreadDumpParser.WAITING_TO_LOCK_RE.matcher((CharSequence)"");
        var14_13 = ThreadDumpParser.WAITING_TO_LOCK_UNKNOWN_RE.matcher((CharSequence)"");
        var5_14 = ThreadDumpParser.BLANK_RE.matcher((CharSequence)"");
        var4_15 = null;
        while (var1_1.hasNext()) {
            block12: {
                block21: {
                    block20: {
                        block19: {
                            block18: {
                                block17: {
                                    block16: {
                                        block15: {
                                            block14: {
                                                block13: {
                                                    var3_16 = var1_1.next();
                                                    if (var3_16 == null) {
                                                        this.options.getLogger().log(SentryLevel.WARNING, "Internal error while parsing thread dump.", new Object[0]);
                                                        break;
                                                    }
                                                    var17_17 = var3_16.text;
                                                    if (this.matches(var6_4, var17_17)) {
                                                        var3_16 = new SentryStackFrame();
                                                        var3_16.setPackage(var6_4.group(1));
                                                        var3_16.setFunction(var6_4.group(2));
                                                        var3_16.setLineno(this.getInteger(var6_4, 3, null));
                                                        var10_3.add(var3_16);
lbl27:
                                                        // 2 sources

                                                        while (true) {
                                                            var3_16 = null;
                                                            break block12;
                                                            break;
                                                        }
                                                    }
                                                    if (this.matches(var8_5, var17_17)) {
                                                        var3_16 = new SentryStackFrame();
                                                        var3_16.setPackage(var8_5.group(1));
                                                        var3_16.setFunction(var8_5.group(2));
                                                        var10_3.add(var3_16);
                                                        ** continue;
                                                    }
                                                    if (!this.matches(var9_6, var17_17)) break block13;
                                                    var3_16 = new SentryStackFrame();
                                                    var4_15 = String.format((String)"%s.%s", (Object[])new Object[]{var9_6.group(1), var9_6.group(2)});
                                                    var3_16.setModule((String)var4_15);
                                                    var3_16.setFunction(var9_6.group(3));
                                                    var3_16.setFilename(var9_6.group(4));
                                                    var3_16.setLineno(this.getUInteger(var9_6, 5, null));
                                                    var3_16.setInApp(this.stackTraceFactory.isInApp((String)var4_15));
                                                    var10_3.add(var3_16);
                                                    break block12;
                                                }
                                                if (!this.matches(var11_7, var17_17)) break block14;
                                                var3_16 = new SentryStackFrame();
                                                var4_15 = String.format((String)"%s.%s", (Object[])new Object[]{var11_7.group(1), var11_7.group(2)});
                                                var3_16.setModule((String)var4_15);
                                                var3_16.setFunction(var11_7.group(3));
                                                var3_16.setInApp(this.stackTraceFactory.isInApp((String)var4_15));
                                                var10_3.add(var3_16);
                                                break block12;
                                            }
                                            if (!this.matches(var15_8, var17_17)) break block15;
                                            var3_16 = var4_15;
                                            if (var4_15 != null) {
                                                var3_16 = new SentryLockReason();
                                                var3_16.setType(1);
                                                var3_16.setAddress(var15_8.group(1));
                                                var3_16.setPackageName(var15_8.group(2));
                                                var3_16.setClassName(var15_8.group(3));
                                                var4_15.setLock((SentryLockReason)var3_16);
                                                this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                                                var3_16 = var4_15;
                                            }
                                            break block12;
                                        }
                                        if (!this.matches(var12_9, var17_17)) break block16;
                                        var3_16 = var4_15;
                                        if (var4_15 != null) {
                                            var3_16 = new SentryLockReason();
                                            var3_16.setType(2);
                                            var3_16.setAddress(var12_9.group(1));
                                            var3_16.setPackageName(var12_9.group(2));
                                            var3_16.setClassName(var12_9.group(3));
                                            var4_15.setLock((SentryLockReason)var3_16);
                                            this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                                            var3_16 = var4_15;
                                        }
                                        break block12;
                                    }
                                    if (!this.matches(var13_10, var17_17)) break block17;
                                    var3_16 = var4_15;
                                    if (var4_15 != null) {
                                        var3_16 = new SentryLockReason();
                                        var3_16.setType(4);
                                        var3_16.setAddress(var13_10.group(1));
                                        var3_16.setPackageName(var13_10.group(2));
                                        var3_16.setClassName(var13_10.group(3));
                                        var4_15.setLock((SentryLockReason)var3_16);
                                        this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                                        var3_16 = var4_15;
                                    }
                                    break block12;
                                }
                                if (!this.matches(var7_11, var17_17)) break block18;
                                var3_16 = var4_15;
                                if (var4_15 == null) break block12;
                                var3_16 = new SentryLockReason();
                                var3_16.setType(8);
                                var3_16.setAddress(var7_11.group(1));
                                var3_16.setPackageName(var7_11.group(2));
                                var3_16.setClassName(var7_11.group(3));
                                var3_16.setThreadId(this.getLong(var7_11, 4, null));
                                var4_15.setLock((SentryLockReason)var3_16);
                                this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                                break block19;
                            }
                            if (!this.matches(var16_12, var17_17)) break block20;
                            if (var4_15 != null) {
                                var3_16 = new SentryLockReason();
                                var3_16.setType(8);
                                var3_16.setAddress(var16_12.group(1));
                                var3_16.setPackageName(var16_12.group(2));
                                var3_16.setClassName(var16_12.group(3));
                                var4_15.setLock((SentryLockReason)var3_16);
                                this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                            }
                        }
lbl121:
                        // 3 sources

                        while (true) {
                            var3_16 = var4_15;
                            break block12;
                            break;
                        }
                    }
                    if (!this.matches(var14_13, var17_17)) break block21;
                    if (var4_15 == null) ** GOTO lbl121
                    var3_16 = new SentryLockReason();
                    var3_16.setType(8);
                    var4_15.setLock((SentryLockReason)var3_16);
                    this.combineThreadLocks(var2_2, (SentryLockReason)var3_16);
                    ** continue;
                }
                if (var17_17.length() == 0) break;
                var3_16 = var4_15;
                if (this.matches(var5_14, var17_17)) break;
            }
            var4_15 = var3_16;
        }
        Collections.reverse((List)var10_3);
        var1_1 = new SentryStackTrace((List<SentryStackFrame>)var10_3);
        var1_1.setSnapshot(true);
        return var1_1;
    }

    private SentryThread parseThread(Lines lines) {
        SentryThread sentryThread = new SentryThread();
        Matcher matcher = BEGIN_MANAGED_THREAD_RE.matcher((CharSequence)"");
        Object object = BEGIN_UNMANAGED_NATIVE_THREAD_RE.matcher((CharSequence)"");
        if (!lines.hasNext()) {
            return null;
        }
        Line line = lines.next();
        boolean bl = false;
        if (line == null) {
            this.options.getLogger().log(SentryLevel.WARNING, "Internal error while parsing thread dump.", new Object[0]);
            return null;
        }
        if (this.matches(matcher, line.text)) {
            object = this.getLong(matcher, 4, null);
            if (object == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "No thread id in the dump, skipping thread.", new Object[0]);
                return null;
            }
            sentryThread.setId((Long)object);
            sentryThread.setName(matcher.group(1));
            object = matcher.group(5);
            if (object != null) {
                if (object.contains((CharSequence)" ")) {
                    sentryThread.setState(object.substring(0, object.indexOf(32)));
                } else {
                    sentryThread.setState((String)object);
                }
            }
        } else if (this.matches((Matcher)object, line.text)) {
            matcher = this.getLong((Matcher)object, 3, null);
            if (matcher == null) {
                this.options.getLogger().log(SentryLevel.DEBUG, "No thread id in the dump, skipping thread.", new Object[0]);
                return null;
            }
            sentryThread.setId((Long)matcher);
            sentryThread.setName(object.group(1));
        }
        if ((object = sentryThread.getName()) != null) {
            boolean bl2 = object.equals((Object)"main");
            sentryThread.setMain(bl2);
            sentryThread.setCrashed(bl2);
            boolean bl3 = bl;
            if (bl2) {
                bl3 = bl;
                if (!this.isBackground) {
                    bl3 = true;
                }
            }
            sentryThread.setCurrent(bl3);
        }
        sentryThread.setStacktrace(this.parseStacktrace(lines, sentryThread));
        return sentryThread;
    }

    public List<SentryThread> parse(Lines lines) {
        ArrayList arrayList = new ArrayList();
        Matcher matcher = BEGIN_MANAGED_THREAD_RE.matcher((CharSequence)"");
        Matcher matcher2 = BEGIN_UNMANAGED_NATIVE_THREAD_RE.matcher((CharSequence)"");
        while (lines.hasNext()) {
            Object object = lines.next();
            if (object == null) {
                this.options.getLogger().log(SentryLevel.WARNING, "Internal error while parsing thread dump.", new Object[0]);
                return arrayList;
            }
            object = ((Line)object).text;
            if (!this.matches(matcher, (String)object) && !this.matches(matcher2, (String)object)) continue;
            lines.rewind();
            object = this.parseThread(lines);
            if (object == null) continue;
            arrayList.add(object);
        }
        return arrayList;
    }
}

