/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package io.sentry.android.core;

import io.sentry.SendCachedEnvelopeFireAndForgetIntegration;
import io.sentry.android.core.AndroidOptionsInitializer;
import io.sentry.android.core.SentryAndroidOptions;

public final class AndroidOptionsInitializer$$ExternalSyntheticLambda1
implements SendCachedEnvelopeFireAndForgetIntegration.SendFireAndForgetDirPath {
    public final SentryAndroidOptions f$0;

    public /* synthetic */ AndroidOptionsInitializer$$ExternalSyntheticLambda1(SentryAndroidOptions sentryAndroidOptions) {
        this.f$0 = sentryAndroidOptions;
    }

    @Override
    public final String getDirPath() {
        return AndroidOptionsInitializer.lambda$installDefaultIntegrations$1(this.f$0);
    }
}

