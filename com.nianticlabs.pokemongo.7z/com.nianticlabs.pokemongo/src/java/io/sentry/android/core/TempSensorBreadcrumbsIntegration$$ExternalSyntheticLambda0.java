/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.SentryOptions;
import io.sentry.android.core.TempSensorBreadcrumbsIntegration;

public final class TempSensorBreadcrumbsIntegration$$ExternalSyntheticLambda0
implements Runnable {
    public final TempSensorBreadcrumbsIntegration f$0;
    public final SentryOptions f$1;

    public /* synthetic */ TempSensorBreadcrumbsIntegration$$ExternalSyntheticLambda0(TempSensorBreadcrumbsIntegration tempSensorBreadcrumbsIntegration, SentryOptions sentryOptions) {
        this.f$0 = tempSensorBreadcrumbsIntegration;
        this.f$1 = sentryOptions;
    }

    public final void run() {
        this.f$0.lambda$register$0$io-sentry-android-core-TempSensorBreadcrumbsIntegration(this.f$1);
    }
}

