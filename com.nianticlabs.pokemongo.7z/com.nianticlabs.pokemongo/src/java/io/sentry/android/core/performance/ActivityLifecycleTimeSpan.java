/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Comparable
 *  java.lang.Long
 *  java.lang.Object
 */
package io.sentry.android.core.performance;

import io.sentry.android.core.performance.TimeSpan;

public class ActivityLifecycleTimeSpan
implements Comparable<ActivityLifecycleTimeSpan> {
    private final TimeSpan onCreate = new TimeSpan();
    private final TimeSpan onStart = new TimeSpan();

    public int compareTo(ActivityLifecycleTimeSpan activityLifecycleTimeSpan) {
        int n2 = Long.compare((long)this.onCreate.getStartUptimeMs(), (long)activityLifecycleTimeSpan.onCreate.getStartUptimeMs());
        if (n2 == 0) {
            return Long.compare((long)this.onStart.getStartUptimeMs(), (long)activityLifecycleTimeSpan.onStart.getStartUptimeMs());
        }
        return n2;
    }

    public final TimeSpan getOnCreate() {
        return this.onCreate;
    }

    public final TimeSpan getOnStart() {
        return this.onStart;
    }
}

