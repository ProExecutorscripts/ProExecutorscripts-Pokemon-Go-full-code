/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.FullyDisplayedReporter;
import io.sentry.ISpan;
import io.sentry.android.core.ActivityLifecycleIntegration;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda8
implements FullyDisplayedReporter.FullyDisplayedReporterListener {
    public final ActivityLifecycleIntegration f$0;
    public final ISpan f$1;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda8(ActivityLifecycleIntegration activityLifecycleIntegration, ISpan iSpan) {
        this.f$0 = activityLifecycleIntegration;
        this.f$1 = iSpan;
    }

    @Override
    public final void onFullyDrawn() {
        this.f$0.lambda$onActivityCreated$7$io-sentry-android-core-ActivityLifecycleIntegration(this.f$1);
    }
}

