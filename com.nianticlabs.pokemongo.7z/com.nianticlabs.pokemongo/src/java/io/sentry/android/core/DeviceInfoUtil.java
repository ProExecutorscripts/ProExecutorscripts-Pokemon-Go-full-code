/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.os.LocaleList
 *  android.os.StatFs
 *  android.os.SystemClock
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Calendar
 *  java.util.Collections
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  java.util.TimeZone
 */
package io.sentry.android.core;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Environment;
import android.os.LocaleList;
import android.os.StatFs;
import android.os.SystemClock;
import io.sentry.DateUtils;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.Installation;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.CpuInfoUtils;
import io.sentry.android.core.internal.util.DeviceOrientations;
import io.sentry.android.core.internal.util.RootChecker;
import io.sentry.protocol.Device;
import io.sentry.protocol.OperatingSystem;
import java.io.File;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public final class DeviceInfoUtil {
    private static volatile DeviceInfoUtil instance;
    private final BuildInfoProvider buildInfoProvider;
    private final Context context;
    private final Boolean isEmulator;
    private final SentryAndroidOptions options;
    private final OperatingSystem os;
    private final ContextUtils.SideLoadedInfo sideLoadedInfo;
    private final Long totalMem;

    public DeviceInfoUtil(Context context, SentryAndroidOptions sentryAndroidOptions) {
        BuildInfoProvider buildInfoProvider;
        this.context = context;
        this.options = sentryAndroidOptions;
        this.buildInfoProvider = buildInfoProvider = new BuildInfoProvider(sentryAndroidOptions.getLogger());
        CpuInfoUtils.getInstance().readMaxFrequencies();
        this.os = this.retrieveOperatingSystemInformation();
        this.isEmulator = buildInfoProvider.isEmulator();
        this.sideLoadedInfo = ContextUtils.retrieveSideLoadedInfo(context, sentryAndroidOptions.getLogger(), buildInfoProvider);
        context = ContextUtils.getMemInfo(context, sentryAndroidOptions.getLogger());
        this.totalMem = context != null ? Long.valueOf((long)context.totalMem) : null;
    }

    private Intent getBatteryIntent() {
        return ContextUtils.registerReceiver(this.context, this.buildInfoProvider, null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
    }

    private Float getBatteryLevel(Intent intent) {
        block2: {
            int n2;
            int n3;
            try {
                n3 = intent.getIntExtra("level", -1);
                n2 = intent.getIntExtra("scale", -1);
                if (n3 == -1 || n2 == -1) break block2;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error getting device battery level.", throwable);
                return null;
            }
            float f2 = (float)n3 / (float)n2;
            return Float.valueOf((float)(f2 * 100.0f));
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Float getBatteryTemperature(Intent intent) {
        int n2;
        try {
            n2 = intent.getIntExtra("temperature", -1);
            if (n2 == -1) return null;
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting battery temperature.", throwable);
            return null;
        }
        float f2 = (float)n2 / 10.0f;
        return Float.valueOf((float)f2);
    }

    private Date getBootTime() {
        try {
            Date date = DateUtils.getDateTime(System.currentTimeMillis() - SystemClock.elapsedRealtime());
            return date;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.options.getLogger().log(SentryLevel.ERROR, illegalArgumentException, "Error getting the device's boot time.", new Object[0]);
            return null;
        }
    }

    private String getDeviceId() {
        try {
            String string2 = Installation.id(this.context);
            return string2;
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting installationId.", throwable);
            return null;
        }
    }

    private File getExternalStorageDep(File object) {
        File[] fileArray = this.context.getExternalFilesDirs(null);
        if (fileArray != null) {
            object = object != null ? object.getAbsolutePath() : null;
            for (File file : fileArray) {
                if (file == null || object != null && !object.isEmpty() && file.getAbsolutePath().contains((CharSequence)object)) {
                    continue;
                }
                return file;
            }
        } else {
            this.options.getLogger().log(SentryLevel.INFO, "Not possible to read getExternalFilesDirs", new Object[0]);
        }
        return null;
    }

    private StatFs getExternalStorageStat(File file) {
        if (!this.isExternalStorageMounted()) {
            if ((file = this.getExternalStorageDep(file)) != null) {
                return new StatFs(file.getPath());
            }
            this.options.getLogger().log(SentryLevel.INFO, "Not possible to read external files directory", new Object[0]);
            return null;
        }
        this.options.getLogger().log(SentryLevel.INFO, "External storage is not mounted or emulated.", new Object[0]);
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static DeviceInfoUtil getInstance(Context context, SentryAndroidOptions sentryAndroidOptions) {
        if (instance != null) return instance;
        Class<DeviceInfoUtil> clazz = DeviceInfoUtil.class;
        synchronized (DeviceInfoUtil.class) {
            DeviceInfoUtil deviceInfoUtil;
            if (instance != null) return instance;
            instance = deviceInfoUtil = new DeviceInfoUtil(context.getApplicationContext(), sentryAndroidOptions);
            // ** MonitorExit[var3_2] (shouldn't be in output)
            return instance;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Device.DeviceOrientation getOrientation() {
        Device.DeviceOrientation deviceOrientation;
        Device.DeviceOrientation deviceOrientation2;
        block4: {
            try {
                deviceOrientation = deviceOrientation2 = DeviceOrientations.getOrientation(this.context.getResources().getConfiguration().orientation);
                if (deviceOrientation2 != null) return deviceOrientation;
            }
            catch (Throwable throwable) {
                deviceOrientation2 = null;
                break block4;
            }
            try {
                this.options.getLogger().log(SentryLevel.INFO, "No device orientation available (ORIENTATION_SQUARE|ORIENTATION_UNDEFINED)", new Object[0]);
                return null;
            }
            catch (Throwable throwable) {}
        }
        this.options.getLogger().log(SentryLevel.ERROR, "Error getting device orientation.", (Throwable)deviceOrientation);
        return deviceOrientation2;
    }

    private TimeZone getTimeZone() {
        LocaleList localeList;
        if (this.buildInfoProvider.getSdkInfoVersion() >= 24 && !(localeList = this.context.getResources().getConfiguration().getLocales()).isEmpty()) {
            return Calendar.getInstance((Locale)localeList.get(0)).getTimeZone();
        }
        return Calendar.getInstance().getTimeZone();
    }

    private Long getTotalExternalStorage(StatFs statFs) {
        long l2;
        long l3;
        try {
            l3 = statFs.getBlockSizeLong();
            l2 = statFs.getBlockCountLong();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting total external storage amount.", throwable);
            return null;
        }
        return l2 * l3;
    }

    private Long getTotalInternalStorage(StatFs statFs) {
        long l2;
        long l3;
        try {
            l3 = statFs.getBlockSizeLong();
            l2 = statFs.getBlockCountLong();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting total internal storage amount.", throwable);
            return null;
        }
        return l2 * l3;
    }

    private Long getUnusedExternalStorage(StatFs statFs) {
        long l2;
        long l3;
        try {
            l3 = statFs.getBlockSizeLong();
            l2 = statFs.getAvailableBlocksLong();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting unused external storage amount.", throwable);
            return null;
        }
        return l2 * l3;
    }

    private Long getUnusedInternalStorage(StatFs statFs) {
        long l2;
        long l3;
        try {
            l3 = statFs.getBlockSizeLong();
            l2 = statFs.getAvailableBlocksLong();
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Error getting unused internal storage amount.", throwable);
            return null;
        }
        return l2 * l3;
    }

    private Boolean isCharging(Intent intent) {
        boolean bl;
        block2: {
            try {
                boolean bl2;
                int n2 = intent.getIntExtra("plugged", -1);
                bl = bl2 = true;
                if (n2 == 1) break block2;
                bl = n2 == 2 ? bl2 : false;
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error getting device charging state.", throwable);
                return null;
            }
        }
        return bl;
    }

    private boolean isExternalStorageMounted() {
        String string2 = Environment.getExternalStorageState();
        boolean bl = ("mounted".equals((Object)string2) || "mounted_ro".equals((Object)string2)) && !Environment.isExternalStorageEmulated();
        return bl;
    }

    public static void resetInstance() {
        instance = null;
    }

    private void setDeviceIO(Device device, boolean bl) {
        int n2;
        Object object = this.getBatteryIntent();
        if (object != null) {
            device.setBatteryLevel(this.getBatteryLevel((Intent)object));
            device.setCharging(this.isCharging((Intent)object));
            device.setBatteryTemperature(this.getBatteryTemperature((Intent)object));
        }
        object = (n2 = 1.$SwitchMap$io$sentry$IConnectionStatusProvider$ConnectionStatus[this.options.getConnectionStatusProvider().getConnectionStatus().ordinal()]) != 1 ? (n2 != 2 ? null : Boolean.valueOf((boolean)true)) : Boolean.valueOf((boolean)false);
        device.setOnline((Boolean)object);
        object = ContextUtils.getMemInfo(this.context, this.options.getLogger());
        if (object != null && bl) {
            device.setFreeMemory(object.availMem);
            device.setLowMemory(object.lowMemory);
        }
        if ((object = this.context.getExternalFilesDir(null)) != null) {
            StatFs statFs = new StatFs(object.getPath());
            device.setStorageSize(this.getTotalInternalStorage(statFs));
            device.setFreeStorage(this.getUnusedInternalStorage(statFs));
        }
        if ((object = this.getExternalStorageStat((File)object)) != null) {
            device.setExternalStorageSize(this.getTotalExternalStorage((StatFs)object));
            device.setExternalFreeStorage(this.getUnusedExternalStorage((StatFs)object));
        }
        if (device.getConnectionType() == null) {
            device.setConnectionType(this.options.getConnectionStatusProvider().getConnectionType());
        }
    }

    public Device collectDeviceInformation(boolean bl, boolean bl2) {
        Device device = new Device();
        if (this.options.isSendDefaultPii()) {
            device.setName(ContextUtils.getDeviceName(this.context));
        }
        device.setManufacturer(Build.MANUFACTURER);
        device.setBrand(Build.BRAND);
        device.setFamily(ContextUtils.getFamily(this.options.getLogger()));
        device.setModel(Build.MODEL);
        device.setModelId(Build.ID);
        device.setArchs(ContextUtils.getArchitectures(this.buildInfoProvider));
        device.setOrientation(this.getOrientation());
        List<Integer> list = this.isEmulator;
        if (list != null) {
            device.setSimulator((Boolean)list);
        }
        if ((list = ContextUtils.getDisplayMetrics(this.context, this.options.getLogger())) != null) {
            device.setScreenWidthPixels(list.widthPixels);
            device.setScreenHeightPixels(list.heightPixels);
            device.setScreenDensity(Float.valueOf((float)list.density));
            device.setScreenDpi(list.densityDpi);
        }
        device.setBootTime(this.getBootTime());
        device.setTimezone(this.getTimeZone());
        if (device.getId() == null) {
            device.setId(this.getDeviceId());
        }
        list = Locale.getDefault();
        if (device.getLanguage() == null) {
            device.setLanguage(list.getLanguage());
        }
        if (device.getLocale() == null) {
            device.setLocale(list.toString());
        }
        if (!(list = CpuInfoUtils.getInstance().readMaxFrequencies()).isEmpty()) {
            device.setProcessorFrequency(((Integer)Collections.max(list)).doubleValue());
            device.setProcessorCount(list.size());
        }
        device.setMemorySize(this.totalMem);
        if (bl && this.options.isCollectAdditionalContext()) {
            this.setDeviceIO(device, bl2);
        }
        return device;
    }

    public OperatingSystem getOperatingSystem() {
        return this.os;
    }

    public ContextUtils.SideLoadedInfo getSideLoadedInfo() {
        return this.sideLoadedInfo;
    }

    protected OperatingSystem retrieveOperatingSystemInformation() {
        OperatingSystem operatingSystem = new OperatingSystem();
        operatingSystem.setName("Android");
        operatingSystem.setVersion(Build.VERSION.RELEASE);
        operatingSystem.setBuild(Build.DISPLAY);
        String string2 = ContextUtils.getKernelVersion(this.options.getLogger());
        if (string2 != null) {
            operatingSystem.setKernelVersion(string2);
        }
        if (this.options.isEnableRootCheck()) {
            operatingSystem.setRooted(new RootChecker(this.context, this.buildInfoProvider, this.options.getLogger()).isDeviceRooted());
        }
        return operatingSystem;
    }
}

