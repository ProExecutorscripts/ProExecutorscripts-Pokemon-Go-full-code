/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 *  java.util.Locale
 */
package io.sentry.android.core;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import io.sentry.ILogger;
import io.sentry.SentryIntegrationPackageStorage;
import io.sentry.SentryLevel;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.protocol.SdkVersion;
import io.sentry.util.Objects;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

final class ManifestMetadataReader {
    static final String ANR_ENABLE = "io.sentry.anr.enable";
    static final String ANR_REPORT_DEBUG = "io.sentry.anr.report-debug";
    static final String ANR_TIMEOUT_INTERVAL_MILLIS = "io.sentry.anr.timeout-interval-millis";
    static final String ATTACH_SCREENSHOT = "io.sentry.attach-screenshot";
    static final String ATTACH_THREADS = "io.sentry.attach-threads";
    static final String ATTACH_VIEW_HIERARCHY = "io.sentry.attach-view-hierarchy";
    static final String AUTO_INIT = "io.sentry.auto-init";
    static final String AUTO_SESSION_TRACKING_ENABLE = "io.sentry.auto-session-tracking.enable";
    static final String BREADCRUMBS_ACTIVITY_LIFECYCLE_ENABLE = "io.sentry.breadcrumbs.activity-lifecycle";
    static final String BREADCRUMBS_APP_COMPONENTS_ENABLE = "io.sentry.breadcrumbs.app-components";
    static final String BREADCRUMBS_APP_LIFECYCLE_ENABLE = "io.sentry.breadcrumbs.app-lifecycle";
    static final String BREADCRUMBS_NETWORK_EVENTS_ENABLE = "io.sentry.breadcrumbs.network-events";
    static final String BREADCRUMBS_SYSTEM_EVENTS_ENABLE = "io.sentry.breadcrumbs.system-events";
    static final String BREADCRUMBS_USER_INTERACTION_ENABLE = "io.sentry.breadcrumbs.user-interaction";
    static final String CLIENT_REPORTS_ENABLE = "io.sentry.send-client-reports";
    static final String COLLECT_ADDITIONAL_CONTEXT = "io.sentry.additional-context";
    static final String DEBUG = "io.sentry.debug";
    static final String DEBUG_LEVEL = "io.sentry.debug.level";
    static final String DSN = "io.sentry.dsn";
    static final String ENABLE_APP_START_PROFILING = "io.sentry.profiling.enable-app-start";
    static final String ENABLE_METRICS = "io.sentry.enable-metrics";
    static final String ENABLE_PERFORMANCE_V2 = "io.sentry.performance-v2.enable";
    static final String ENABLE_ROOT_CHECK = "io.sentry.enable-root-check";
    static final String ENABLE_SCOPE_PERSISTENCE = "io.sentry.enable-scope-persistence";
    static final String ENABLE_SENTRY = "io.sentry.enabled";
    static final String ENVIRONMENT = "io.sentry.environment";
    static final String IDLE_TIMEOUT = "io.sentry.traces.idle-timeout";
    static final String NDK_ENABLE = "io.sentry.ndk.enable";
    static final String NDK_SCOPE_SYNC_ENABLE = "io.sentry.ndk.scope-sync.enable";
    static final String PERFORM_FRAMES_TRACKING = "io.sentry.traces.frames-tracking";
    static final String PROFILES_SAMPLE_RATE = "io.sentry.traces.profiling.sample-rate";
    static final String PROGUARD_UUID = "io.sentry.proguard-uuid";
    static final String RELEASE = "io.sentry.release";
    static final String SAMPLE_RATE = "io.sentry.sample-rate";
    static final String SDK_NAME = "io.sentry.sdk.name";
    static final String SDK_VERSION = "io.sentry.sdk.version";
    static final String SEND_DEFAULT_PII = "io.sentry.send-default-pii";
    static final String SEND_MODULES = "io.sentry.send-modules";
    static final String SENTRY_GRADLE_PLUGIN_INTEGRATIONS = "io.sentry.gradle-plugin-integrations";
    static final String SESSION_TRACKING_ENABLE = "io.sentry.session-tracking.enable";
    static final String SESSION_TRACKING_TIMEOUT_INTERVAL_MILLIS = "io.sentry.session-tracking.timeout-interval-millis";
    static final String TRACES_ACTIVITY_AUTO_FINISH_ENABLE = "io.sentry.traces.activity.auto-finish.enable";
    static final String TRACES_ACTIVITY_ENABLE = "io.sentry.traces.activity.enable";
    static final String TRACES_PROFILING_ENABLE = "io.sentry.traces.profiling.enable";
    static final String TRACES_SAMPLE_RATE = "io.sentry.traces.sample-rate";
    static final String TRACES_UI_ENABLE = "io.sentry.traces.user-interaction.enable";
    static final String TRACE_PROPAGATION_TARGETS = "io.sentry.traces.trace-propagation-targets";
    static final String TRACE_SAMPLING = "io.sentry.traces.trace-sampling";
    static final String TRACING_ENABLE = "io.sentry.traces.enable";
    @Deprecated
    static final String TRACING_ORIGINS = "io.sentry.traces.tracing-origins";
    static final String TTFD_ENABLE = "io.sentry.traces.time-to-full-display.enable";
    static final String UNCAUGHT_EXCEPTION_HANDLER_ENABLE = "io.sentry.uncaught-exception-handler.enable";

    private ManifestMetadataReader() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static void applyMetadata(Context object, SentryAndroidOptions sentryAndroidOptions, BuildInfoProvider object2) {
        Objects.requireNonNull(object, "The application context is required.");
        Objects.requireNonNull(sentryAndroidOptions, "The options object is required.");
        try {
            block22: {
                ILogger iLogger;
                Bundle bundle;
                block23: {
                    block24: {
                        bundle = ManifestMetadataReader.getMetadata((Context)object, sentryAndroidOptions.getLogger(), object2);
                        iLogger = sentryAndroidOptions.getLogger();
                        if (bundle == null) break block22;
                        sentryAndroidOptions.setDebug(ManifestMetadataReader.readBool(bundle, iLogger, DEBUG, sentryAndroidOptions.isDebug()));
                        if (sentryAndroidOptions.isDebug() && (object = ManifestMetadataReader.readString(bundle, iLogger, DEBUG_LEVEL, sentryAndroidOptions.getDiagnosticLevel().name().toLowerCase(Locale.ROOT))) != null) {
                            sentryAndroidOptions.setDiagnosticLevel(SentryLevel.valueOf(object.toUpperCase(Locale.ROOT)));
                        }
                        sentryAndroidOptions.setAnrEnabled(ManifestMetadataReader.readBool(bundle, iLogger, ANR_ENABLE, sentryAndroidOptions.isAnrEnabled()));
                        sentryAndroidOptions.setEnableAutoSessionTracking(ManifestMetadataReader.readBool(bundle, iLogger, AUTO_SESSION_TRACKING_ENABLE, ManifestMetadataReader.readBool(bundle, iLogger, SESSION_TRACKING_ENABLE, sentryAndroidOptions.isEnableAutoSessionTracking())));
                        if (sentryAndroidOptions.getSampleRate() == null && (object = ManifestMetadataReader.readDouble(bundle, iLogger, SAMPLE_RATE)).doubleValue() != -1.0) {
                            sentryAndroidOptions.setSampleRate((Double)object);
                        }
                        sentryAndroidOptions.setAnrReportInDebug(ManifestMetadataReader.readBool(bundle, iLogger, ANR_REPORT_DEBUG, sentryAndroidOptions.isAnrReportInDebug()));
                        sentryAndroidOptions.setAnrTimeoutIntervalMillis(ManifestMetadataReader.readLong(bundle, iLogger, ANR_TIMEOUT_INTERVAL_MILLIS, sentryAndroidOptions.getAnrTimeoutIntervalMillis()));
                        object = ManifestMetadataReader.readString(bundle, iLogger, DSN, sentryAndroidOptions.getDsn());
                        boolean bl = ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_SENTRY, sentryAndroidOptions.isEnabled());
                        if (bl && (object == null || !object.isEmpty())) {
                            if (object == null) {
                                sentryAndroidOptions.getLogger().log(SentryLevel.FATAL, "DSN is required. Use empty string to disable SDK.", new Object[0]);
                            }
                        } else {
                            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "Sentry enabled flag set to false or DSN is empty: disabling sentry-android", new Object[0]);
                        }
                        sentryAndroidOptions.setEnabled(bl);
                        sentryAndroidOptions.setDsn((String)object);
                        sentryAndroidOptions.setEnableNdk(ManifestMetadataReader.readBool(bundle, iLogger, NDK_ENABLE, sentryAndroidOptions.isEnableNdk()));
                        sentryAndroidOptions.setEnableScopeSync(ManifestMetadataReader.readBool(bundle, iLogger, NDK_SCOPE_SYNC_ENABLE, sentryAndroidOptions.isEnableScopeSync()));
                        sentryAndroidOptions.setRelease(ManifestMetadataReader.readString(bundle, iLogger, RELEASE, sentryAndroidOptions.getRelease()));
                        sentryAndroidOptions.setEnvironment(ManifestMetadataReader.readString(bundle, iLogger, ENVIRONMENT, sentryAndroidOptions.getEnvironment()));
                        sentryAndroidOptions.setSessionTrackingIntervalMillis(ManifestMetadataReader.readLong(bundle, iLogger, SESSION_TRACKING_TIMEOUT_INTERVAL_MILLIS, sentryAndroidOptions.getSessionTrackingIntervalMillis()));
                        sentryAndroidOptions.setEnableActivityLifecycleBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_ACTIVITY_LIFECYCLE_ENABLE, sentryAndroidOptions.isEnableActivityLifecycleBreadcrumbs()));
                        sentryAndroidOptions.setEnableAppLifecycleBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_APP_LIFECYCLE_ENABLE, sentryAndroidOptions.isEnableAppLifecycleBreadcrumbs()));
                        sentryAndroidOptions.setEnableSystemEventBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_SYSTEM_EVENTS_ENABLE, sentryAndroidOptions.isEnableSystemEventBreadcrumbs()));
                        sentryAndroidOptions.setEnableAppComponentBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_APP_COMPONENTS_ENABLE, sentryAndroidOptions.isEnableAppComponentBreadcrumbs()));
                        sentryAndroidOptions.setEnableUserInteractionBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_USER_INTERACTION_ENABLE, sentryAndroidOptions.isEnableUserInteractionBreadcrumbs()));
                        sentryAndroidOptions.setEnableNetworkEventBreadcrumbs(ManifestMetadataReader.readBool(bundle, iLogger, BREADCRUMBS_NETWORK_EVENTS_ENABLE, sentryAndroidOptions.isEnableNetworkEventBreadcrumbs()));
                        sentryAndroidOptions.setEnableUncaughtExceptionHandler(ManifestMetadataReader.readBool(bundle, iLogger, UNCAUGHT_EXCEPTION_HANDLER_ENABLE, sentryAndroidOptions.isEnableUncaughtExceptionHandler()));
                        sentryAndroidOptions.setAttachThreads(ManifestMetadataReader.readBool(bundle, iLogger, ATTACH_THREADS, sentryAndroidOptions.isAttachThreads()));
                        sentryAndroidOptions.setAttachScreenshot(ManifestMetadataReader.readBool(bundle, iLogger, ATTACH_SCREENSHOT, sentryAndroidOptions.isAttachScreenshot()));
                        sentryAndroidOptions.setAttachViewHierarchy(ManifestMetadataReader.readBool(bundle, iLogger, ATTACH_VIEW_HIERARCHY, sentryAndroidOptions.isAttachViewHierarchy()));
                        sentryAndroidOptions.setSendClientReports(ManifestMetadataReader.readBool(bundle, iLogger, CLIENT_REPORTS_ENABLE, sentryAndroidOptions.isSendClientReports()));
                        sentryAndroidOptions.setCollectAdditionalContext(ManifestMetadataReader.readBool(bundle, iLogger, COLLECT_ADDITIONAL_CONTEXT, sentryAndroidOptions.isCollectAdditionalContext()));
                        if (sentryAndroidOptions.getEnableTracing() == null) {
                            sentryAndroidOptions.setEnableTracing(ManifestMetadataReader.readBoolNullable(bundle, iLogger, TRACING_ENABLE, null));
                        }
                        if (sentryAndroidOptions.getTracesSampleRate() == null && (object = ManifestMetadataReader.readDouble(bundle, iLogger, TRACES_SAMPLE_RATE)).doubleValue() != -1.0) {
                            sentryAndroidOptions.setTracesSampleRate((Double)object);
                        }
                        sentryAndroidOptions.setTraceSampling(ManifestMetadataReader.readBool(bundle, iLogger, TRACE_SAMPLING, sentryAndroidOptions.isTraceSampling()));
                        sentryAndroidOptions.setEnableAutoActivityLifecycleTracing(ManifestMetadataReader.readBool(bundle, iLogger, TRACES_ACTIVITY_ENABLE, sentryAndroidOptions.isEnableAutoActivityLifecycleTracing()));
                        sentryAndroidOptions.setEnableActivityLifecycleTracingAutoFinish(ManifestMetadataReader.readBool(bundle, iLogger, TRACES_ACTIVITY_AUTO_FINISH_ENABLE, sentryAndroidOptions.isEnableActivityLifecycleTracingAutoFinish()));
                        sentryAndroidOptions.setProfilingEnabled(ManifestMetadataReader.readBool(bundle, iLogger, TRACES_PROFILING_ENABLE, sentryAndroidOptions.isProfilingEnabled()));
                        if (sentryAndroidOptions.getProfilesSampleRate() == null && (object = ManifestMetadataReader.readDouble(bundle, iLogger, PROFILES_SAMPLE_RATE)).doubleValue() != -1.0) {
                            sentryAndroidOptions.setProfilesSampleRate((Double)object);
                        }
                        sentryAndroidOptions.setEnableUserInteractionTracing(ManifestMetadataReader.readBool(bundle, iLogger, TRACES_UI_ENABLE, sentryAndroidOptions.isEnableUserInteractionTracing()));
                        sentryAndroidOptions.setEnableTimeToFullDisplayTracing(ManifestMetadataReader.readBool(bundle, iLogger, TTFD_ENABLE, sentryAndroidOptions.isEnableTimeToFullDisplayTracing()));
                        long l2 = ManifestMetadataReader.readLong(bundle, iLogger, IDLE_TIMEOUT, -1L);
                        if (l2 != -1L) {
                            sentryAndroidOptions.setIdleTimeout(l2);
                        }
                        List<String> list = ManifestMetadataReader.readList(bundle, iLogger, TRACE_PROPAGATION_TARGETS);
                        bl = bundle.containsKey(TRACE_PROPAGATION_TARGETS);
                        object = list;
                        if (bl) break block23;
                        if (list == null) break block24;
                        object = list;
                        if (!list.isEmpty()) break block23;
                    }
                    object = ManifestMetadataReader.readList(bundle, iLogger, TRACING_ORIGINS);
                }
                if ((bundle.containsKey(TRACE_PROPAGATION_TARGETS) || bundle.containsKey(TRACING_ORIGINS)) && object == null) {
                    sentryAndroidOptions.setTracePropagationTargets((List<String>)Collections.emptyList());
                } else if (object != null) {
                    sentryAndroidOptions.setTracePropagationTargets((List<String>)object);
                }
                sentryAndroidOptions.setEnableFramesTracking(ManifestMetadataReader.readBool(bundle, iLogger, PERFORM_FRAMES_TRACKING, true));
                sentryAndroidOptions.setProguardUuid(ManifestMetadataReader.readString(bundle, iLogger, PROGUARD_UUID, sentryAndroidOptions.getProguardUuid()));
                SdkVersion sdkVersion = sentryAndroidOptions.getSdkVersion();
                object = sdkVersion;
                if (sdkVersion == null) {
                    object = new SdkVersion("", "");
                }
                ((SdkVersion)object).setName(ManifestMetadataReader.readStringNotNull(bundle, iLogger, SDK_NAME, ((SdkVersion)object).getName()));
                ((SdkVersion)object).setVersion(ManifestMetadataReader.readStringNotNull(bundle, iLogger, SDK_VERSION, ((SdkVersion)object).getVersion()));
                sentryAndroidOptions.setSdkVersion((SdkVersion)object);
                sentryAndroidOptions.setSendDefaultPii(ManifestMetadataReader.readBool(bundle, iLogger, SEND_DEFAULT_PII, sentryAndroidOptions.isSendDefaultPii()));
                object = ManifestMetadataReader.readList(bundle, iLogger, SENTRY_GRADLE_PLUGIN_INTEGRATIONS);
                if (object != null) {
                    object = object.iterator();
                    while (object.hasNext()) {
                        String string2 = (String)object.next();
                        SentryIntegrationPackageStorage.getInstance().addIntegration(string2);
                    }
                }
                sentryAndroidOptions.setEnableRootCheck(ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_ROOT_CHECK, sentryAndroidOptions.isEnableRootCheck()));
                sentryAndroidOptions.setSendModules(ManifestMetadataReader.readBool(bundle, iLogger, SEND_MODULES, sentryAndroidOptions.isSendModules()));
                sentryAndroidOptions.setEnablePerformanceV2(ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_PERFORMANCE_V2, sentryAndroidOptions.isEnablePerformanceV2()));
                sentryAndroidOptions.setEnableAppStartProfiling(ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_APP_START_PROFILING, sentryAndroidOptions.isEnableAppStartProfiling()));
                sentryAndroidOptions.setEnableScopePersistence(ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_SCOPE_PERSISTENCE, sentryAndroidOptions.isEnableScopePersistence()));
                sentryAndroidOptions.setEnableMetrics(ManifestMetadataReader.readBool(bundle, iLogger, ENABLE_METRICS, sentryAndroidOptions.isEnableMetrics()));
            }
            sentryAndroidOptions.getLogger().log(SentryLevel.INFO, "Retrieving configuration from AndroidManifest.xml", new Object[0]);
            return;
        }
        catch (Throwable throwable) {
            sentryAndroidOptions.getLogger().log(SentryLevel.ERROR, "Failed to read configuration from android manifest metadata.", throwable);
        }
    }

    private static Bundle getMetadata(Context context, ILogger iLogger, BuildInfoProvider buildInfoProvider) throws PackageManager.NameNotFoundException {
        if (buildInfoProvider == null) {
            buildInfoProvider = new BuildInfoProvider(iLogger);
        }
        return ContextUtils.getApplicationInfo((Context)context, (long)128L, (BuildInfoProvider)buildInfoProvider).metaData;
    }

    static boolean isAutoInit(Context context, ILogger iLogger) {
        boolean bl;
        boolean bl2;
        block4: {
            Objects.requireNonNull(context, "The application context is required.");
            boolean bl3 = true;
            bl2 = true;
            bl = bl3;
            context = ManifestMetadataReader.getMetadata(context, iLogger, null);
            if (context == null) break block4;
            bl = bl3;
            bl2 = ManifestMetadataReader.readBool((Bundle)context, iLogger, AUTO_INIT, true);
        }
        bl = bl2;
        try {
            iLogger.log(SentryLevel.INFO, "Retrieving auto-init from AndroidManifest.xml", new Object[0]);
        }
        catch (Throwable throwable) {
            iLogger.log(SentryLevel.ERROR, "Failed to read auto-init from android manifest metadata.", throwable);
            bl2 = bl;
        }
        return bl2;
    }

    private static boolean readBool(Bundle bundle, ILogger iLogger, String string2, boolean bl) {
        bl = bundle.getBoolean(string2, bl);
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, bl);
        return bl;
    }

    private static Boolean readBoolNullable(Bundle bundle, ILogger iLogger, String string2, Boolean bl) {
        if (bundle.getSerializable(string2) != null) {
            boolean bl2 = bl != null;
            bl2 = bundle.getBoolean(string2, bl2);
            iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, bl2);
            return bl2;
        }
        iLogger.log(SentryLevel.DEBUG, "%s used default %s", string2, bl);
        return bl;
    }

    private static Double readDouble(Bundle bundle, ILogger iLogger, String string2) {
        bundle = Double.valueOf((double)Float.valueOf((float)bundle.getFloat(string2, -1.0f)).doubleValue());
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, bundle);
        return bundle;
    }

    private static List<String> readList(Bundle object, ILogger iLogger, String string2) {
        object = object.getString(string2);
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, object);
        if (object != null) {
            return Arrays.asList((Object[])object.split(",", -1));
        }
        return null;
    }

    private static long readLong(Bundle bundle, ILogger iLogger, String string2, long l2) {
        l2 = bundle.getInt(string2, (int)l2);
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, l2);
        return l2;
    }

    private static String readString(Bundle object, ILogger iLogger, String string2, String string3) {
        object = object.getString(string2, string3);
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, object);
        return object;
    }

    private static String readStringNotNull(Bundle object, ILogger iLogger, String string2, String string3) {
        object = object.getString(string2, string3);
        iLogger.log(SentryLevel.DEBUG, "%s read: %s", string2, object);
        return object;
    }
}

