/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 */
package io.sentry.android.core;

public final class AppState {
    private static AppState instance = new AppState();
    private Boolean inBackground = null;

    private AppState() {
    }

    public static AppState getInstance() {
        return instance;
    }

    public Boolean isInBackground() {
        return this.inBackground;
    }

    void resetInstance() {
        instance = new AppState();
    }

    void setInBackground(boolean bl) {
        AppState appState = this;
        synchronized (appState) {
            this.inBackground = bl;
            return;
        }
    }
}

