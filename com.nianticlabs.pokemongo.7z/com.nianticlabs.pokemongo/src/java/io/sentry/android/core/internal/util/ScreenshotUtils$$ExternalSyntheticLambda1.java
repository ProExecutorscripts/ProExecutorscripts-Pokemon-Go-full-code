/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.view.View
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.CountDownLatch
 */
package io.sentry.android.core.internal.util;

import android.graphics.Canvas;
import android.view.View;
import io.sentry.ILogger;
import io.sentry.android.core.internal.util.ScreenshotUtils;
import java.util.concurrent.CountDownLatch;

public final class ScreenshotUtils$$ExternalSyntheticLambda1
implements Runnable {
    public final View f$0;
    public final Canvas f$1;
    public final ILogger f$2;
    public final CountDownLatch f$3;

    public /* synthetic */ ScreenshotUtils$$ExternalSyntheticLambda1(View view2, Canvas canvas, ILogger iLogger, CountDownLatch countDownLatch) {
        this.f$0 = view2;
        this.f$1 = canvas;
        this.f$2 = iLogger;
        this.f$3 = countDownLatch;
    }

    public final void run() {
        ScreenshotUtils.lambda$takeScreenshot$1(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

