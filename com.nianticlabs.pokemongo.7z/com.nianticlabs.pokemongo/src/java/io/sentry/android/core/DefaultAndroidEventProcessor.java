/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collections
 *  java.util.Locale
 *  java.util.concurrent.Executors
 *  java.util.concurrent.Future
 */
package io.sentry.android.core;

import android.content.Context;
import android.content.pm.PackageInfo;
import io.sentry.DateUtils;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.JsonSerializable;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.SentryLevel;
import io.sentry.android.core.AppState;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.DefaultAndroidEventProcessor$$ExternalSyntheticLambda0;
import io.sentry.android.core.DeviceInfoUtil;
import io.sentry.android.core.Installation;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.AndroidMainThreadChecker;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.protocol.App;
import io.sentry.protocol.OperatingSystem;
import io.sentry.protocol.SentryException;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import io.sentry.protocol.SentryTransaction;
import io.sentry.protocol.User;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

final class DefaultAndroidEventProcessor
implements EventProcessor {
    private final BuildInfoProvider buildInfoProvider;
    final Context context;
    private final Future<DeviceInfoUtil> deviceInfoUtil;
    private final SentryAndroidOptions options;

    public DefaultAndroidEventProcessor(Context context, BuildInfoProvider buildInfoProvider, SentryAndroidOptions sentryAndroidOptions) {
        this.context = Objects.requireNonNull(context, "The application context is required.");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "The BuildInfoProvider is required.");
        this.options = Objects.requireNonNull(sentryAndroidOptions, "The options object is required.");
        buildInfoProvider = Executors.newSingleThreadExecutor();
        this.deviceInfoUtil = buildInfoProvider.submit(new DefaultAndroidEventProcessor$$ExternalSyntheticLambda0(context, sentryAndroidOptions));
        buildInfoProvider.shutdown();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void fixExceptionOrder(SentryEvent list) {
        if ((list = list.getExceptions()) == null) return;
        int n2 = list.size();
        boolean bl = true;
        if (n2 <= 1) return;
        JsonSerializable jsonSerializable = (SentryException)list.get(list.size() - 1);
        if (!"java.lang".equals((Object)((SentryException)jsonSerializable).getModule())) return;
        if ((jsonSerializable = ((SentryException)jsonSerializable).getStacktrace()) == null) return;
        if ((jsonSerializable = ((SentryStackTrace)jsonSerializable).getFrames()) == null) return;
        jsonSerializable = jsonSerializable.iterator();
        do {
            if (!jsonSerializable.hasNext()) return;
        } while (!"com.android.internal.os.RuntimeInit$MethodAndArgsCaller".equals((Object)((SentryStackFrame)jsonSerializable.next()).getModule()));
        if (!bl) return;
        Collections.reverse(list);
    }

    static /* synthetic */ DeviceInfoUtil lambda$new$0(Context context, SentryAndroidOptions sentryAndroidOptions) throws Exception {
        return DeviceInfoUtil.getInstance(context, sentryAndroidOptions);
    }

    private void mergeOS(SentryBaseEvent sentryBaseEvent) {
        Object object;
        OperatingSystem operatingSystem = sentryBaseEvent.getContexts().getOperatingSystem();
        try {
            object = ((DeviceInfoUtil)this.deviceInfoUtil.get()).getOperatingSystem();
            sentryBaseEvent.getContexts().setOperatingSystem((OperatingSystem)object);
        }
        catch (Throwable throwable) {
            this.options.getLogger().log(SentryLevel.ERROR, "Failed to retrieve os system", throwable);
        }
        if (operatingSystem != null) {
            object = operatingSystem.getName();
            object = object != null && !object.isEmpty() ? "os_" + object.trim().toLowerCase(Locale.ROOT) : "os_1";
            sentryBaseEvent.getContexts().put(object, operatingSystem);
        }
    }

    private void mergeUser(SentryBaseEvent sentryBaseEvent) {
        User user;
        User user2 = user = sentryBaseEvent.getUser();
        if (user == null) {
            user2 = new User();
            sentryBaseEvent.setUser(user2);
        }
        if (user2.getId() == null) {
            user2.setId(Installation.id(this.context));
        }
        if (user2.getIpAddress() == null) {
            user2.setIpAddress("{{auto}}");
        }
    }

    private void processNonCachedEvent(SentryBaseEvent sentryBaseEvent, Hint hint) {
        App app;
        App app2 = app = sentryBaseEvent.getContexts().getApp();
        if (app == null) {
            app2 = new App();
        }
        this.setAppExtras(app2, hint);
        this.setPackageInfo(sentryBaseEvent, app2);
        sentryBaseEvent.getContexts().setApp(app2);
    }

    private void setAppExtras(App app, Hint hint) {
        app.setAppName(ContextUtils.getApplicationName(this.context, this.options.getLogger()));
        TimeSpan timeSpan = AppStartMetrics.getInstance().getAppStartTimeSpanWithFallback(this.options);
        if (timeSpan.hasStarted()) {
            app.setAppStartTime(DateUtils.toUtilDate(timeSpan.getStartTimestamp()));
        }
        if (!HintUtils.isFromHybridSdk(hint) && app.getInForeground() == null && (hint = AppState.getInstance().isInBackground()) != null) {
            app.setInForeground(hint.booleanValue() ^ true);
        }
    }

    private void setCommons(SentryBaseEvent sentryBaseEvent, boolean bl, boolean bl2) {
        this.mergeUser(sentryBaseEvent);
        this.setDevice(sentryBaseEvent, bl, bl2);
        this.setSideLoadedInfo(sentryBaseEvent);
    }

    private void setDevice(SentryBaseEvent sentryBaseEvent, boolean bl, boolean bl2) {
        if (sentryBaseEvent.getContexts().getDevice() == null) {
            try {
                sentryBaseEvent.getContexts().setDevice(((DeviceInfoUtil)this.deviceInfoUtil.get()).collectDeviceInformation(bl, bl2));
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Failed to retrieve device info", throwable);
            }
            this.mergeOS(sentryBaseEvent);
        }
    }

    private void setDist(SentryBaseEvent sentryBaseEvent, String string2) {
        if (sentryBaseEvent.getDist() == null) {
            sentryBaseEvent.setDist(string2);
        }
    }

    private void setPackageInfo(SentryBaseEvent sentryBaseEvent, App app) {
        PackageInfo packageInfo = ContextUtils.getPackageInfo(this.context, 4096, this.options.getLogger(), this.buildInfoProvider);
        if (packageInfo != null) {
            this.setDist(sentryBaseEvent, ContextUtils.getVersionCode(packageInfo, this.buildInfoProvider));
            ContextUtils.setAppPackageInfo(packageInfo, this.buildInfoProvider, app);
        }
    }

    private void setSideLoadedInfo(SentryBaseEvent sentryBaseEvent) {
        block4: {
            ContextUtils.SideLoadedInfo sideLoadedInfo2 = ((DeviceInfoUtil)this.deviceInfoUtil.get()).getSideLoadedInfo();
            if (sideLoadedInfo2 == null) break block4;
            try {
                for (ContextUtils.SideLoadedInfo sideLoadedInfo2 : sideLoadedInfo2.asTags().entrySet()) {
                    sentryBaseEvent.setTag((String)sideLoadedInfo2.getKey(), (String)sideLoadedInfo2.getValue());
                }
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error getting side loaded info.", throwable);
            }
        }
    }

    private void setThreads(SentryEvent jsonSerializable2, Hint hint) {
        if (((SentryEvent)jsonSerializable2).getThreads() != null) {
            boolean bl = HintUtils.isFromHybridSdk(hint);
            for (JsonSerializable jsonSerializable2 : ((SentryEvent)jsonSerializable2).getThreads()) {
                boolean bl2 = AndroidMainThreadChecker.getInstance().isMainThread((SentryThread)jsonSerializable2);
                if (((SentryThread)jsonSerializable2).isCurrent() == null) {
                    ((SentryThread)jsonSerializable2).setCurrent(bl2);
                }
                if (bl || ((SentryThread)jsonSerializable2).isMain() != null) continue;
                ((SentryThread)jsonSerializable2).setMain(bl2);
            }
        }
    }

    private boolean shouldApplyScopeData(SentryBaseEvent sentryBaseEvent, Hint hint) {
        if (HintUtils.shouldApplyScopeData(hint)) {
            return true;
        }
        this.options.getLogger().log(SentryLevel.DEBUG, "Event was cached so not applying data relevant to the current app execution/version: %s", sentryBaseEvent.getEventId());
        return false;
    }

    public User getDefaultUser(Context context) {
        User user = new User();
        user.setId(Installation.id(context));
        return user;
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        boolean bl = this.shouldApplyScopeData(sentryEvent, hint);
        if (bl) {
            this.processNonCachedEvent(sentryEvent, hint);
            this.setThreads(sentryEvent, hint);
        }
        this.setCommons(sentryEvent, true, bl);
        DefaultAndroidEventProcessor.fixExceptionOrder(sentryEvent);
        return sentryEvent;
    }

    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint hint) {
        boolean bl = this.shouldApplyScopeData(sentryTransaction, hint);
        if (bl) {
            this.processNonCachedEvent(sentryTransaction, hint);
        }
        this.setCommons(sentryTransaction, false, bl);
        return sentryTransaction;
    }
}

