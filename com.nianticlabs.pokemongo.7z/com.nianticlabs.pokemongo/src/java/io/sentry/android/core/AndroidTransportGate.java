/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.IConnectionStatusProvider;
import io.sentry.SentryOptions;
import io.sentry.transport.ITransportGate;

final class AndroidTransportGate
implements ITransportGate {
    private final SentryOptions options;

    AndroidTransportGate(SentryOptions sentryOptions) {
        this.options = sentryOptions;
    }

    @Override
    public boolean isConnected() {
        return this.isConnected(this.options.getConnectionStatusProvider().getConnectionStatus());
    }

    boolean isConnected(IConnectionStatusProvider.ConnectionStatus connectionStatus) {
        int n2 = 1.$SwitchMap$io$sentry$IConnectionStatusProvider$ConnectionStatus[connectionStatus.ordinal()];
        return n2 == 1 || n2 == 2 || n2 == 3;
    }
}

