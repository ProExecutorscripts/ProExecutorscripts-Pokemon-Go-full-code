/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core;

import io.sentry.IScope;
import io.sentry.ScopeCallback;
import io.sentry.android.core.LifecycleWatcher;

public final class LifecycleWatcher$$ExternalSyntheticLambda0
implements ScopeCallback {
    public final LifecycleWatcher f$0;

    public /* synthetic */ LifecycleWatcher$$ExternalSyntheticLambda0(LifecycleWatcher lifecycleWatcher) {
        this.f$0 = lifecycleWatcher;
    }

    @Override
    public final void run(IScope iScope) {
        this.f$0.lambda$startSession$0$io-sentry-android-core-LifecycleWatcher(iScope);
    }
}

