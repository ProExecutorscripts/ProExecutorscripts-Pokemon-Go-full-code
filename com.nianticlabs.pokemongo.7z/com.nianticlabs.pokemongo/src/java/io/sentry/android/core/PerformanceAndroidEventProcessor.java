/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Looper
 *  java.lang.CharSequence
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry.android.core;

import android.os.Looper;
import io.sentry.EventProcessor;
import io.sentry.Hint;
import io.sentry.JsonSerializable;
import io.sentry.MeasurementUnit;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryEvent;
import io.sentry.SpanContext;
import io.sentry.SpanId;
import io.sentry.SpanStatus;
import io.sentry.android.core.ActivityFramesTracker;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.performance.ActivityLifecycleTimeSpan;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.protocol.MeasurementValue;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentrySpan;
import io.sentry.protocol.SentryTransaction;
import io.sentry.util.Objects;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class PerformanceAndroidEventProcessor
implements EventProcessor {
    private static final String APP_METRICS_ACTIVITIES_OP = "activity.load";
    private static final String APP_METRICS_APPLICATION_OP = "application.load";
    private static final String APP_METRICS_CONTENT_PROVIDER_OP = "contentprovider.load";
    private static final String APP_METRICS_ORIGIN = "auto.ui";
    private static final String APP_METRICS_PROCESS_INIT_OP = "process.load";
    private static final long MAX_PROCESS_INIT_APP_START_DIFF_MS = 10000L;
    private final ActivityFramesTracker activityFramesTracker;
    private final SentryAndroidOptions options;
    private boolean sentStartMeasurement = false;

    PerformanceAndroidEventProcessor(SentryAndroidOptions sentryAndroidOptions, ActivityFramesTracker activityFramesTracker) {
        this.options = Objects.requireNonNull(sentryAndroidOptions, "SentryAndroidOptions is required");
        this.activityFramesTracker = Objects.requireNonNull(activityFramesTracker, "ActivityFramesTracker is required");
    }

    private void attachColdAppStartSpans(AppStartMetrics iterator, SentryTransaction sentryTransaction) {
        Object object2;
        SentryId sentryId;
        JsonSerializable jsonSerializable;
        block10: {
            if (iterator.getAppStartType() != AppStartMetrics.AppStartType.COLD) {
                return;
            }
            jsonSerializable = sentryTransaction.getContexts().getTrace();
            if (jsonSerializable == null) {
                return;
            }
            sentryId = jsonSerializable.getTraceId();
            jsonSerializable = sentryTransaction.getSpans().iterator();
            while (jsonSerializable.hasNext()) {
                object2 = (Iterator)jsonSerializable.next();
                if (!((SentrySpan)object2).getOp().contentEquals((CharSequence)"app.start.cold")) continue;
                jsonSerializable = ((SentrySpan)object2).getSpanId();
                break block10;
            }
            jsonSerializable = null;
        }
        long l2 = iterator.getClassLoadedUptimeMs();
        TimeSpan timeSpan = iterator.getAppStartTimeSpan();
        if (timeSpan.hasStarted() && Math.abs((long)(l2 - timeSpan.getStartUptimeMs())) <= 10000L) {
            object2 = new TimeSpan();
            ((TimeSpan)object2).setStartedAt(timeSpan.getStartUptimeMs());
            ((TimeSpan)object2).setStartUnixTimeMs(timeSpan.getStartTimestampMs());
            ((TimeSpan)object2).setStoppedAt(l2);
            ((TimeSpan)object2).setDescription("Process Initialization");
            sentryTransaction.getSpans().add((Object)PerformanceAndroidEventProcessor.timeSpanToSentrySpan((TimeSpan)object2, (SpanId)jsonSerializable, sentryId, APP_METRICS_PROCESS_INIT_OP));
        }
        if (!(object2 = iterator.getContentProviderOnCreateTimeSpans()).isEmpty()) {
            object2 = object2.iterator();
            while (object2.hasNext()) {
                timeSpan = (TimeSpan)object2.next();
                sentryTransaction.getSpans().add((Object)PerformanceAndroidEventProcessor.timeSpanToSentrySpan(timeSpan, (SpanId)jsonSerializable, sentryId, APP_METRICS_CONTENT_PROVIDER_OP));
            }
        }
        if (((TimeSpan)(object2 = iterator.getApplicationOnCreateTimeSpan())).hasStopped()) {
            sentryTransaction.getSpans().add((Object)PerformanceAndroidEventProcessor.timeSpanToSentrySpan((TimeSpan)object2, (SpanId)jsonSerializable, sentryId, APP_METRICS_APPLICATION_OP));
        }
        if (!(iterator = iterator.getActivityLifecycleTimeSpans()).isEmpty()) {
            for (Object object2 : iterator) {
                if (((ActivityLifecycleTimeSpan)object2).getOnCreate().hasStarted() && ((ActivityLifecycleTimeSpan)object2).getOnCreate().hasStopped()) {
                    sentryTransaction.getSpans().add((Object)PerformanceAndroidEventProcessor.timeSpanToSentrySpan(((ActivityLifecycleTimeSpan)object2).getOnCreate(), (SpanId)jsonSerializable, sentryId, APP_METRICS_ACTIVITIES_OP));
                }
                if (!((ActivityLifecycleTimeSpan)object2).getOnStart().hasStarted() || !((ActivityLifecycleTimeSpan)object2).getOnStart().hasStopped()) continue;
                sentryTransaction.getSpans().add((Object)PerformanceAndroidEventProcessor.timeSpanToSentrySpan(((ActivityLifecycleTimeSpan)object2).getOnStart(), (SpanId)jsonSerializable, sentryId, APP_METRICS_ACTIVITIES_OP));
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean hasAppStartSpan(SentryTransaction jsonSerializable) {
        boolean bl;
        boolean bl2;
        block1: {
            SentrySpan sentrySpan;
            Iterator iterator = ((SentryTransaction)jsonSerializable).getSpans().iterator();
            do {
                bl2 = iterator.hasNext();
                bl = true;
                if (!bl2) break block1;
                sentrySpan = (SentrySpan)iterator.next();
                if (sentrySpan.getOp().contentEquals((CharSequence)"app.start.cold")) return true;
            } while (!sentrySpan.getOp().contentEquals((CharSequence)"app.start.warm"));
            return true;
        }
        if ((jsonSerializable = ((SentryBaseEvent)((Object)jsonSerializable)).getContexts().getTrace()) == null) return false;
        bl2 = bl;
        if (((SpanContext)jsonSerializable).getOperation().equals((Object)"app.start.cold")) return bl2;
        if (!((SpanContext)jsonSerializable).getOperation().equals((Object)"app.start.warm")) return false;
        return bl;
    }

    private static SentrySpan timeSpanToSentrySpan(TimeSpan timeSpan, SpanId spanId, SentryId sentryId, String string2) {
        HashMap hashMap = new HashMap(2);
        hashMap.put((Object)"thread.id", (Object)Looper.getMainLooper().getThread().getId());
        hashMap.put((Object)"thread.name", (Object)"main");
        return new SentrySpan(timeSpan.getStartTimestampSecs(), timeSpan.getProjectedStopTimestampSecs(), sentryId, new SpanId(), spanId, string2, timeSpan.getDescription(), SpanStatus.OK, APP_METRICS_ORIGIN, (Map<String, String>)new ConcurrentHashMap(), (Map<String, MeasurementValue>)new ConcurrentHashMap(), null, (Map<String, Object>)hashMap);
    }

    @Override
    public SentryEvent process(SentryEvent sentryEvent, Hint hint) {
        return sentryEvent;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public SentryTransaction process(SentryTransaction sentryTransaction, Hint object) {
        PerformanceAndroidEventProcessor performanceAndroidEventProcessor = this;
        synchronized (performanceAndroidEventProcessor) {
            Map<String, MeasurementValue> map2;
            long l2;
            boolean bl = this.options.isTracingEnabled();
            if (!bl) {
                return sentryTransaction;
            }
            if (!this.sentStartMeasurement && this.hasAppStartSpan(sentryTransaction) && (l2 = AppStartMetrics.getInstance().getAppStartTimeSpanWithFallback(this.options).getDurationMs()) != 0L) {
                void var2_5;
                MeasurementValue measurementValue = new MeasurementValue((Number)Float.valueOf((float)l2), MeasurementUnit.Duration.MILLISECOND.apiName());
                if (AppStartMetrics.getInstance().getAppStartType() == AppStartMetrics.AppStartType.COLD) {
                    object = "app_start_cold";
                } else {
                    String string2 = "app_start_warm";
                }
                sentryTransaction.getMeasurements().put((Object)var2_5, (Object)measurementValue);
                this.attachColdAppStartSpans(AppStartMetrics.getInstance(), sentryTransaction);
                this.sentStartMeasurement = true;
            }
            SentryId sentryId = sentryTransaction.getEventId();
            SpanContext spanContext = sentryTransaction.getContexts().getTrace();
            if (sentryId != null && spanContext != null && spanContext.getOperation().contentEquals((CharSequence)"ui.load") && (map2 = this.activityFramesTracker.takeMetrics(sentryId)) != null) {
                sentryTransaction.getMeasurements().putAll(map2);
            }
            return sentryTransaction;
        }
    }
}

