/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package io.sentry.android.core.internal.util;

import io.sentry.util.FileUtils;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class CpuInfoUtils {
    static final String CPUINFO_MAX_FREQ_PATH = "cpufreq/cpuinfo_max_freq";
    private static final String SYSTEM_CPU_PATH = "/sys/devices/system/cpu";
    private static final CpuInfoUtils instance = new CpuInfoUtils();
    private final List<Integer> cpuMaxFrequenciesMhz = new ArrayList();

    private CpuInfoUtils() {
    }

    public static CpuInfoUtils getInstance() {
        return instance;
    }

    final void clear() {
        this.cpuMaxFrequenciesMhz.clear();
    }

    String getSystemCpuPath() {
        return SYSTEM_CPU_PATH;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public List<Integer> readMaxFrequencies() {
        CpuInfoUtils cpuInfoUtils = this;
        synchronized (cpuInfoUtils) {
            if (!this.cpuMaxFrequenciesMhz.isEmpty()) {
                return this.cpuMaxFrequenciesMhz;
            }
            List<Integer> list = new List<Integer>(this.getSystemCpuPath());
            if ((list = list.listFiles()) == null) {
                return new List<Integer>();
            }
            int n2 = ((File[])list).length;
            int n3 = 0;
            while (true) {
                block11: {
                    boolean bl;
                    Object object;
                    if (n3 >= n2) {
                        return this.cpuMaxFrequenciesMhz;
                    }
                    ArrayList arrayList = list[n3];
                    if (arrayList.getName().matches("cpu[0-9]+") && (object = new File((File)arrayList, CPUINFO_MAX_FREQ_PATH)).exists() && (bl = object.canRead())) {
                        long l2;
                        try {
                            object = FileUtils.readText(object);
                            if (object == null) break block11;
                            l2 = Long.parseLong((String)object.trim());
                        }
                        catch (IOException | NumberFormatException throwable) {}
                        this.cpuMaxFrequenciesMhz.add((Object)((int)(l2 / 1000L)));
                    }
                }
                ++n3;
            }
        }
    }

    public void setCpuMaxFrequencies(List<Integer> list) {
        this.cpuMaxFrequenciesMhz.clear();
        this.cpuMaxFrequenciesMhz.addAll(list);
    }
}

