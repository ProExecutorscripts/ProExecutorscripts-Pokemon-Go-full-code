/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.ref.WeakReference
 */
package io.sentry.android.core;

import io.sentry.ITransaction;
import io.sentry.TransactionFinishedCallback;
import io.sentry.android.core.ActivityLifecycleIntegration;
import java.lang.ref.WeakReference;

public final class ActivityLifecycleIntegration$$ExternalSyntheticLambda4
implements TransactionFinishedCallback {
    public final ActivityLifecycleIntegration f$0;
    public final WeakReference f$1;
    public final String f$2;

    public /* synthetic */ ActivityLifecycleIntegration$$ExternalSyntheticLambda4(ActivityLifecycleIntegration activityLifecycleIntegration, WeakReference weakReference, String string2) {
        this.f$0 = activityLifecycleIntegration;
        this.f$1 = weakReference;
        this.f$2 = string2;
    }

    @Override
    public final void execute(ITransaction iTransaction) {
        this.f$0.lambda$startTracing$0$io-sentry-android-core-ActivityLifecycleIntegration(this.f$1, this.f$2, iTransaction);
    }
}

