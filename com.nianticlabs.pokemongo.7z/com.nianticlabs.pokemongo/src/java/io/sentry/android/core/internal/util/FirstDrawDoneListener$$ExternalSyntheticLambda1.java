/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.Window
 *  android.view.Window$Callback
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core.internal.util;

import android.view.Window;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.internal.util.FirstDrawDoneListener;

public final class FirstDrawDoneListener$$ExternalSyntheticLambda1
implements Runnable {
    public final Window f$0;
    public final Window.Callback f$1;
    public final Runnable f$2;
    public final BuildInfoProvider f$3;

    public /* synthetic */ FirstDrawDoneListener$$ExternalSyntheticLambda1(Window window, Window.Callback callback, Runnable runnable, BuildInfoProvider buildInfoProvider) {
        this.f$0 = window;
        this.f$1 = callback;
        this.f$2 = runnable;
        this.f$3 = buildInfoProvider;
    }

    public final void run() {
        FirstDrawDoneListener.lambda$registerForNextDraw$0(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

