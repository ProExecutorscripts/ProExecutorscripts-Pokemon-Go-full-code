/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.Map$Entry
 *  java.util.WeakHashMap
 *  java.util.concurrent.Future
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import io.sentry.FullyDisplayedReporter;
import io.sentry.IHub;
import io.sentry.IScope;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.Instrumenter;
import io.sentry.Integration;
import io.sentry.MeasurementUnit;
import io.sentry.NoOpTransaction;
import io.sentry.SentryDate;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.SpanStatus;
import io.sentry.TracesSamplingDecision;
import io.sentry.TransactionContext;
import io.sentry.TransactionOptions;
import io.sentry.android.core.ActivityFramesTracker;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda0;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda1;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda2;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda3;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda4;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda5;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda6;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda7;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda8;
import io.sentry.android.core.ActivityLifecycleIntegration$$ExternalSyntheticLambda9;
import io.sentry.android.core.AndroidDateUtils;
import io.sentry.android.core.BuildInfoProvider;
import io.sentry.android.core.ContextUtils;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.internal.util.ClassUtil;
import io.sentry.android.core.internal.util.FirstDrawDoneListener;
import io.sentry.android.core.performance.AppStartMetrics;
import io.sentry.android.core.performance.TimeSpan;
import io.sentry.protocol.TransactionNameSource;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import io.sentry.util.TracingUtils;
import java.io.Closeable;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ActivityLifecycleIntegration
implements Integration,
Closeable,
Application.ActivityLifecycleCallbacks {
    static final String APP_START_COLD = "app.start.cold";
    static final String APP_START_WARM = "app.start.warm";
    private static final String TRACE_ORIGIN = "auto.ui.activity";
    static final String TTFD_OP = "ui.load.full_display";
    static final long TTFD_TIMEOUT_MILLIS = 30000L;
    static final String TTID_OP = "ui.load.initial_display";
    static final String UI_LOAD_OP = "ui.load";
    private final WeakHashMap<Activity, ITransaction> activitiesWithOngoingTransactions;
    private final ActivityFramesTracker activityFramesTracker;
    private ISpan appStartSpan;
    private final Application application;
    private final BuildInfoProvider buildInfoProvider;
    private boolean firstActivityCreated = false;
    private FullyDisplayedReporter fullyDisplayedReporter = null;
    private IHub hub;
    private boolean isAllActivityCallbacksAvailable;
    private SentryDate lastPausedTime;
    private final Handler mainHandler;
    private SentryAndroidOptions options;
    private boolean performanceEnabled = false;
    private boolean timeToFullDisplaySpanEnabled = false;
    private Future<?> ttfdAutoCloseFuture = null;
    private final WeakHashMap<Activity, ISpan> ttfdSpanMap;
    private final WeakHashMap<Activity, ISpan> ttidSpanMap = new WeakHashMap();

    public ActivityLifecycleIntegration(Application application, BuildInfoProvider buildInfoProvider, ActivityFramesTracker activityFramesTracker) {
        this.ttfdSpanMap = new WeakHashMap();
        this.lastPausedTime = AndroidDateUtils.getCurrentSentryDateTime();
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.activitiesWithOngoingTransactions = new WeakHashMap();
        this.application = Objects.requireNonNull(application, "Application is required");
        this.buildInfoProvider = Objects.requireNonNull(buildInfoProvider, "BuildInfoProvider is required");
        this.activityFramesTracker = Objects.requireNonNull(activityFramesTracker, "ActivityFramesTracker is required");
        if (buildInfoProvider.getSdkInfoVersion() >= 29) {
            this.isAllActivityCallbacksAvailable = true;
        }
    }

    private void cancelTtfdAutoClose() {
        Future<?> future = this.ttfdAutoCloseFuture;
        if (future != null) {
            future.cancel(false);
            this.ttfdAutoCloseFuture = null;
        }
    }

    private void finishAppStartSpan() {
        SentryDate sentryDate = AppStartMetrics.getInstance().getAppStartTimeSpanWithFallback(this.options).getProjectedStopTimestamp();
        if (this.performanceEnabled && sentryDate != null) {
            this.finishSpan(this.appStartSpan, sentryDate);
        }
    }

    private void finishExceededTtfdSpan(ISpan iSpan, ISpan object) {
        if (iSpan != null && !iSpan.isFinished()) {
            iSpan.setDescription(this.getExceededTtfdDesc(iSpan));
            object = object != null ? object.getFinishDate() : null;
            if (object == null) {
                object = iSpan.getStartDate();
            }
            this.finishSpan(iSpan, (SentryDate)object, SpanStatus.DEADLINE_EXCEEDED);
        }
    }

    private void finishSpan(ISpan iSpan) {
        if (iSpan != null && !iSpan.isFinished()) {
            iSpan.finish();
        }
    }

    private void finishSpan(ISpan iSpan, SentryDate sentryDate) {
        this.finishSpan(iSpan, sentryDate, null);
    }

    private void finishSpan(ISpan iSpan, SentryDate sentryDate, SpanStatus spanStatus) {
        if (iSpan != null && !iSpan.isFinished()) {
            if (spanStatus == null) {
                spanStatus = iSpan.getStatus() != null ? iSpan.getStatus() : SpanStatus.OK;
            }
            iSpan.finish(spanStatus, sentryDate);
        }
    }

    private void finishSpan(ISpan iSpan, SpanStatus spanStatus) {
        if (iSpan != null && !iSpan.isFinished()) {
            iSpan.finish(spanStatus);
        }
    }

    private void finishTransaction(ITransaction iTransaction, ISpan object, ISpan object2) {
        if (iTransaction != null) {
            if (iTransaction.isFinished()) {
                return;
            }
            this.finishSpan((ISpan)object, SpanStatus.DEADLINE_EXCEEDED);
            this.finishExceededTtfdSpan((ISpan)object2, (ISpan)object);
            this.cancelTtfdAutoClose();
            object = object2 = iTransaction.getStatus();
            if (object2 == null) {
                object = SpanStatus.OK;
            }
            iTransaction.finish((SpanStatus)object);
            object = this.hub;
            if (object != null) {
                object.configureScope(new ActivityLifecycleIntegration$$ExternalSyntheticLambda3(this, iTransaction));
            }
        }
    }

    private String getActivityName(Activity activity2) {
        return activity2.getClass().getSimpleName();
    }

    private String getAppStartDesc(boolean bl) {
        if (bl) {
            return "Cold Start";
        }
        return "Warm Start";
    }

    private String getAppStartOp(boolean bl) {
        if (bl) {
            return APP_START_COLD;
        }
        return APP_START_WARM;
    }

    private String getExceededTtfdDesc(ISpan iSpan) {
        String string2 = iSpan.getDescription();
        if (string2 != null && string2.endsWith(" - Deadline Exceeded")) {
            return string2;
        }
        return iSpan.getDescription() + " - Deadline Exceeded";
    }

    private String getTtfdDesc(String string2) {
        return string2 + " full display";
    }

    private String getTtidDesc(String string2) {
        return string2 + " initial display";
    }

    private boolean isPerformanceEnabled(SentryAndroidOptions sentryAndroidOptions) {
        boolean bl = sentryAndroidOptions.isTracingEnabled() && sentryAndroidOptions.isEnableAutoActivityLifecycleTracing();
        return bl;
    }

    private boolean isRunningTransactionOrTrace(Activity activity2) {
        return this.activitiesWithOngoingTransactions.containsKey((Object)activity2);
    }

    static /* synthetic */ void lambda$clearScope$4(ITransaction iTransaction, IScope iScope, ITransaction iTransaction2) {
        if (iTransaction2 == iTransaction) {
            iScope.clearTransaction();
        }
    }

    static /* synthetic */ void lambda$onActivityCreated$6(String string2, IScope iScope) {
        iScope.setScreen(string2);
    }

    private void onFirstFrameDrawn(ISpan iSpan, ISpan iSpan2) {
        Object object = AppStartMetrics.getInstance();
        Object object2 = ((AppStartMetrics)object).getAppStartTimeSpan();
        object = ((AppStartMetrics)object).getSdkInitTimeSpan();
        if (((TimeSpan)object2).hasStarted() && ((TimeSpan)object2).hasNotStopped()) {
            ((TimeSpan)object2).stop();
        }
        if (((TimeSpan)object).hasStarted() && ((TimeSpan)object).hasNotStopped()) {
            ((TimeSpan)object).stop();
        }
        this.finishAppStartSpan();
        object2 = this.options;
        if (object2 != null && iSpan2 != null) {
            object2 = ((SentryOptions)object2).getDateProvider().now();
            long l2 = ((SentryDate)object2).diff(iSpan2.getStartDate());
            l2 = TimeUnit.NANOSECONDS.toMillis(l2);
            iSpan2.setMeasurement("time_to_initial_display", (Number)Long.valueOf((long)l2), MeasurementUnit.Duration.MILLISECOND);
            if (iSpan != null && iSpan.isFinished()) {
                iSpan.updateEndDate((SentryDate)object2);
                iSpan2.setMeasurement("time_to_full_display", (Number)Long.valueOf((long)l2), MeasurementUnit.Duration.MILLISECOND);
            }
            this.finishSpan(iSpan2, (SentryDate)object2);
        } else {
            this.finishSpan(iSpan2);
        }
    }

    private void onFullFrameDrawn(ISpan iSpan) {
        Object object = this.options;
        if (object != null && iSpan != null) {
            object = ((SentryOptions)object).getDateProvider().now();
            long l2 = ((SentryDate)object).diff(iSpan.getStartDate());
            iSpan.setMeasurement("time_to_full_display", (Number)Long.valueOf((long)TimeUnit.NANOSECONDS.toMillis(l2)), MeasurementUnit.Duration.MILLISECOND);
            this.finishSpan(iSpan, (SentryDate)object);
        } else {
            this.finishSpan(iSpan);
        }
        this.cancelTtfdAutoClose();
    }

    private void setColdStart(Bundle object) {
        Object object2;
        if (!this.firstActivityCreated && (object2 = this.options) != null && !((SentryAndroidOptions)object2).isEnablePerformanceV2()) {
            object2 = AppStartMetrics.getInstance();
            object = object == null ? AppStartMetrics.AppStartType.COLD : AppStartMetrics.AppStartType.WARM;
            ((AppStartMetrics)object2).setAppStartType((AppStartMetrics.AppStartType)((Object)object));
        }
    }

    private void setSpanOrigin(ISpan iSpan) {
        if (iSpan != null) {
            iSpan.getSpanContext().setOrigin(TRACE_ORIGIN);
        }
    }

    private void startTracing(Activity activity2) {
        Object object = new WeakReference((Object)activity2);
        if (this.hub != null && !this.isRunningTransactionOrTrace(activity2)) {
            if (!this.performanceEnabled) {
                this.activitiesWithOngoingTransactions.put((Object)activity2, (Object)NoOpTransaction.getInstance());
                TracingUtils.startNewTrace(this.hub);
            } else {
                Object object2;
                this.stopPreviousTransactions();
                Object object3 = this.getActivityName(activity2);
                Object object4 = AppStartMetrics.getInstance().getAppStartTimeSpanWithFallback(this.options);
                boolean bl = ContextUtils.isForegroundImportance();
                boolean bl2 = false;
                Object object5 = null;
                if (bl && ((TimeSpan)object4).hasStarted()) {
                    object4 = ((TimeSpan)object4).getStartTimestamp();
                    bl = AppStartMetrics.getInstance().getAppStartType() == AppStartMetrics.AppStartType.COLD;
                    object2 = bl;
                } else {
                    object4 = null;
                    object2 = null;
                }
                TransactionOptions transactionOptions = new TransactionOptions();
                transactionOptions.setDeadlineTimeout(30000L);
                if (this.options.isEnableActivityLifecycleTracingAutoFinish()) {
                    transactionOptions.setIdleTimeout(this.options.getIdleTimeout());
                    transactionOptions.setTrimEnd(true);
                }
                transactionOptions.setWaitForChildren(true);
                transactionOptions.setTransactionFinishedCallback(new ActivityLifecycleIntegration$$ExternalSyntheticLambda4(this, (WeakReference)object, (String)object3));
                if (!this.firstActivityCreated && object4 != null && object2 != null) {
                    object5 = AppStartMetrics.getInstance().getAppStartSamplingDecision();
                    AppStartMetrics.getInstance().setAppStartSamplingDecision(null);
                    object = object4;
                } else {
                    object = this.lastPausedTime;
                }
                transactionOptions.setStartTimestamp((SentryDate)object);
                bl = bl2;
                if (object5 != null) {
                    bl = true;
                }
                transactionOptions.setAppStartTransaction(bl);
                object5 = this.hub.startTransaction(new TransactionContext((String)object3, TransactionNameSource.COMPONENT, UI_LOAD_OP, (TracesSamplingDecision)object5), transactionOptions);
                this.setSpanOrigin((ISpan)object5);
                if (!this.firstActivityCreated && object4 != null && object2 != null) {
                    this.appStartSpan = object4 = object5.startChild(this.getAppStartOp((boolean)object2), this.getAppStartDesc((boolean)object2), (SentryDate)object4, Instrumenter.SENTRY);
                    this.setSpanOrigin((ISpan)object4);
                    this.finishAppStartSpan();
                }
                object4 = object5.startChild(TTID_OP, this.getTtidDesc((String)object3), (SentryDate)object, Instrumenter.SENTRY);
                this.ttidSpanMap.put((Object)activity2, object4);
                this.setSpanOrigin((ISpan)object4);
                if (this.timeToFullDisplaySpanEnabled && this.fullyDisplayedReporter != null && this.options != null) {
                    object2 = object5.startChild(TTFD_OP, this.getTtfdDesc((String)object3), (SentryDate)object, Instrumenter.SENTRY);
                    this.setSpanOrigin((ISpan)object2);
                    try {
                        this.ttfdSpanMap.put((Object)activity2, object2);
                        object = this.options.getExecutorService();
                        object3 = new ActivityLifecycleIntegration$$ExternalSyntheticLambda5(this, (ISpan)object2, (ISpan)object4);
                        this.ttfdAutoCloseFuture = object.schedule((Runnable)object3, 30000L);
                    }
                    catch (RejectedExecutionException rejectedExecutionException) {
                        this.options.getLogger().log(SentryLevel.ERROR, "Failed to call the executor. Time to full display span will not be finished automatically. Did you call Sentry.close()?", rejectedExecutionException);
                    }
                }
                this.hub.configureScope(new ActivityLifecycleIntegration$$ExternalSyntheticLambda6(this, (ITransaction)object5));
                this.activitiesWithOngoingTransactions.put((Object)activity2, object5);
            }
        }
    }

    private void stopPreviousTransactions() {
        for (Map.Entry entry : this.activitiesWithOngoingTransactions.entrySet()) {
            this.finishTransaction((ITransaction)entry.getValue(), (ISpan)this.ttidSpanMap.get(entry.getKey()), (ISpan)this.ttfdSpanMap.get(entry.getKey()));
        }
    }

    private void stopTracing(Activity activity2, boolean bl) {
        if (this.performanceEnabled && bl) {
            this.finishTransaction((ITransaction)this.activitiesWithOngoingTransactions.get((Object)activity2), null, null);
        }
    }

    void applyScope(IScope iScope, ITransaction iTransaction) {
        iScope.withTransaction(new ActivityLifecycleIntegration$$ExternalSyntheticLambda9(this, iScope, iTransaction));
    }

    void clearScope(IScope iScope, ITransaction iTransaction) {
        iScope.withTransaction(new ActivityLifecycleIntegration$$ExternalSyntheticLambda0(iTransaction, iScope));
    }

    public void close() throws IOException {
        this.application.unregisterActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
        SentryAndroidOptions sentryAndroidOptions = this.options;
        if (sentryAndroidOptions != null) {
            sentryAndroidOptions.getLogger().log(SentryLevel.DEBUG, "ActivityLifecycleIntegration removed.", new Object[0]);
        }
        this.activityFramesTracker.stop();
    }

    WeakHashMap<Activity, ITransaction> getActivitiesWithOngoingTransactions() {
        return this.activitiesWithOngoingTransactions;
    }

    ActivityFramesTracker getActivityFramesTracker() {
        return this.activityFramesTracker;
    }

    ISpan getAppStartSpan() {
        return this.appStartSpan;
    }

    WeakHashMap<Activity, ISpan> getTtfdSpanMap() {
        return this.ttfdSpanMap;
    }

    WeakHashMap<Activity, ISpan> getTtidSpanMap() {
        return this.ttidSpanMap;
    }

    /* synthetic */ void lambda$applyScope$3$io-sentry-android-core-ActivityLifecycleIntegration(IScope object, ITransaction iTransaction, ITransaction iTransaction2) {
        if (iTransaction2 == null) {
            object.setTransaction(iTransaction);
        } else {
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "Transaction '%s' won't be bound to the Scope since there's one already in there.", iTransaction.getName());
            }
        }
    }

    /* synthetic */ void lambda$finishTransaction$5$io-sentry-android-core-ActivityLifecycleIntegration(ITransaction iTransaction, IScope iScope) {
        this.clearScope(iScope, iTransaction);
    }

    /* synthetic */ void lambda$onActivityCreated$7$io-sentry-android-core-ActivityLifecycleIntegration(ISpan iSpan) {
        this.onFullFrameDrawn(iSpan);
    }

    /* synthetic */ void lambda$onActivityResumed$8$io-sentry-android-core-ActivityLifecycleIntegration(ISpan iSpan, ISpan iSpan2) {
        this.onFirstFrameDrawn(iSpan, iSpan2);
    }

    /* synthetic */ void lambda$onActivityResumed$9$io-sentry-android-core-ActivityLifecycleIntegration(ISpan iSpan, ISpan iSpan2) {
        this.onFirstFrameDrawn(iSpan, iSpan2);
    }

    /* synthetic */ void lambda$startTracing$0$io-sentry-android-core-ActivityLifecycleIntegration(WeakReference object, String string2, ITransaction iTransaction) {
        if ((object = (Activity)object.get()) != null) {
            this.activityFramesTracker.setMetrics((Activity)object, iTransaction.getEventId());
        } else {
            object = this.options;
            if (object != null) {
                ((SentryOptions)object).getLogger().log(SentryLevel.WARNING, "Unable to track activity frames as the Activity %s has been destroyed.", string2);
            }
        }
    }

    /* synthetic */ void lambda$startTracing$1$io-sentry-android-core-ActivityLifecycleIntegration(ISpan iSpan, ISpan iSpan2) {
        this.finishExceededTtfdSpan(iSpan, iSpan2);
    }

    /* synthetic */ void lambda$startTracing$2$io-sentry-android-core-ActivityLifecycleIntegration(ITransaction iTransaction, IScope iScope) {
        this.applyScope(iScope, iTransaction);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onActivityCreated(Activity object, Bundle object2) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        synchronized (activityLifecycleIntegration) {
            Object object3;
            Object object4;
            this.setColdStart((Bundle)object4);
            if (this.hub != null) {
                object3 = ClassUtil.getClassName(object);
                object4 = this.hub;
                ActivityLifecycleIntegration$$ExternalSyntheticLambda7 activityLifecycleIntegration$$ExternalSyntheticLambda7 = new ActivityLifecycleIntegration$$ExternalSyntheticLambda7((String)object3);
                object4.configureScope(activityLifecycleIntegration$$ExternalSyntheticLambda7);
            }
            this.startTracing((Activity)object);
            object4 = (ISpan)this.ttfdSpanMap.get(object);
            this.firstActivityCreated = true;
            object = this.fullyDisplayedReporter;
            if (object != null) {
                object3 = new ActivityLifecycleIntegration$$ExternalSyntheticLambda8(this, (ISpan)object4);
                ((FullyDisplayedReporter)object).registerFullyDrawnListener((FullyDisplayedReporter.FullyDisplayedReporterListener)object3);
            }
            return;
        }
    }

    public void onActivityDestroyed(Activity activity2) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        synchronized (activityLifecycleIntegration) {
            if (this.performanceEnabled) {
                this.finishSpan(this.appStartSpan, SpanStatus.CANCELLED);
                ISpan iSpan = (ISpan)this.ttidSpanMap.get((Object)activity2);
                ISpan iSpan2 = (ISpan)this.ttfdSpanMap.get((Object)activity2);
                this.finishSpan(iSpan, SpanStatus.DEADLINE_EXCEEDED);
                this.finishExceededTtfdSpan(iSpan2, iSpan);
                this.cancelTtfdAutoClose();
                this.stopTracing(activity2, true);
                this.appStartSpan = null;
                this.ttidSpanMap.remove((Object)activity2);
                this.ttfdSpanMap.remove((Object)activity2);
            }
            this.activitiesWithOngoingTransactions.remove((Object)activity2);
            return;
        }
    }

    public void onActivityPaused(Activity object) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        synchronized (activityLifecycleIntegration) {
            if (!this.isAllActivityCallbacksAvailable) {
                this.firstActivityCreated = true;
                object = this.hub;
                this.lastPausedTime = object == null ? AndroidDateUtils.getCurrentSentryDateTime() : object.getOptions().getDateProvider().now();
            }
            return;
        }
    }

    public void onActivityPostResumed(Activity activity2) {
    }

    public void onActivityPrePaused(Activity object) {
        if (this.isAllActivityCallbacksAvailable) {
            this.firstActivityCreated = true;
            object = this.hub;
            this.lastPausedTime = object == null ? AndroidDateUtils.getCurrentSentryDateTime() : object.getOptions().getDateProvider().now();
        }
    }

    public void onActivityResumed(Activity object) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        synchronized (activityLifecycleIntegration) {
            if (this.performanceEnabled) {
                ISpan iSpan = (ISpan)this.ttidSpanMap.get(object);
                ISpan iSpan2 = (ISpan)this.ttfdSpanMap.get(object);
                Object object2 = object.findViewById(0x1020002);
                if (object2 != null) {
                    object = new ActivityLifecycleIntegration$$ExternalSyntheticLambda1(this, iSpan2, iSpan);
                    FirstDrawDoneListener.registerForNextDraw(object2, (Runnable)object, this.buildInfoProvider);
                } else {
                    object = this.mainHandler;
                    object2 = new ActivityLifecycleIntegration$$ExternalSyntheticLambda2(this, iSpan2, iSpan);
                    object.post((Runnable)object2);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void onActivitySaveInstanceState(Activity activity2, Bundle bundle) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        // MONITORENTER : activityLifecycleIntegration
        // MONITOREXIT : activityLifecycleIntegration
    }

    public void onActivityStarted(Activity activity2) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        synchronized (activityLifecycleIntegration) {
            if (this.performanceEnabled) {
                this.activityFramesTracker.addActivity(activity2);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void onActivityStopped(Activity activity2) {
        ActivityLifecycleIntegration activityLifecycleIntegration = this;
        // MONITORENTER : activityLifecycleIntegration
        // MONITOREXIT : activityLifecycleIntegration
    }

    @Override
    public void register(IHub iHub, SentryOptions sentryOptions) {
        sentryOptions = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = (SentryAndroidOptions)Objects.requireNonNull(sentryOptions, "SentryAndroidOptions is required");
        this.hub = Objects.requireNonNull(iHub, "Hub is required");
        this.performanceEnabled = this.isPerformanceEnabled(this.options);
        this.fullyDisplayedReporter = this.options.getFullyDisplayedReporter();
        this.timeToFullDisplaySpanEnabled = this.options.isEnableTimeToFullDisplayTracing();
        this.application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)this);
        this.options.getLogger().log(SentryLevel.DEBUG, "ActivityLifecycleIntegration installed.", new Object[0]);
        IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
    }
}

