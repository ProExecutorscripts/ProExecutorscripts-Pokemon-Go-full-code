/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.IHub;
import io.sentry.android.core.AnrIntegration;
import io.sentry.android.core.SentryAndroidOptions;

public final class AnrIntegration$$ExternalSyntheticLambda1
implements Runnable {
    public final AnrIntegration f$0;
    public final IHub f$1;
    public final SentryAndroidOptions f$2;

    public /* synthetic */ AnrIntegration$$ExternalSyntheticLambda1(AnrIntegration anrIntegration, IHub iHub, SentryAndroidOptions sentryAndroidOptions) {
        this.f$0 = anrIntegration;
        this.f$1 = iHub;
        this.f$2 = sentryAndroidOptions;
    }

    public final void run() {
        this.f$0.lambda$register$0$io-sentry-android-core-AnrIntegration(this.f$1, this.f$2);
    }
}

