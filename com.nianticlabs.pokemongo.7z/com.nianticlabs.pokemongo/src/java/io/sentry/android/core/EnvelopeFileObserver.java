/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.FileObserver
 *  java.io.File
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import android.os.FileObserver;
import io.sentry.Hint;
import io.sentry.IEnvelopeSender;
import io.sentry.ILogger;
import io.sentry.SentryLevel;
import io.sentry.hints.ApplyScopeData;
import io.sentry.hints.Cached;
import io.sentry.hints.Flushable;
import io.sentry.hints.Resettable;
import io.sentry.hints.Retryable;
import io.sentry.hints.SubmissionResult;
import io.sentry.util.HintUtils;
import io.sentry.util.Objects;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

final class EnvelopeFileObserver
extends FileObserver {
    private final IEnvelopeSender envelopeSender;
    private final long flushTimeoutMillis;
    private final ILogger logger;
    private final String rootPath;

    EnvelopeFileObserver(String string2, IEnvelopeSender iEnvelopeSender, ILogger iLogger, long l2) {
        super(string2);
        this.rootPath = string2;
        this.envelopeSender = Objects.requireNonNull(iEnvelopeSender, "Envelope sender is required.");
        this.logger = Objects.requireNonNull(iLogger, "Logger is required.");
        this.flushTimeoutMillis = l2;
    }

    public void onEvent(int n2, String string2) {
        if (string2 != null && n2 == 8) {
            this.logger.log(SentryLevel.DEBUG, "onEvent fired for EnvelopeFileObserver with event type %d on path: %s for file %s.", n2, this.rootPath, string2);
            Hint hint = HintUtils.createWithTypeCheckHint(new CachedEnvelopeHint(this.flushTimeoutMillis, this.logger));
            this.envelopeSender.processEnvelopeFile(this.rootPath + File.separator + string2, hint);
        }
    }

    private static final class CachedEnvelopeHint
    implements Cached,
    Retryable,
    SubmissionResult,
    Flushable,
    ApplyScopeData,
    Resettable {
        private final long flushTimeoutMillis;
        private CountDownLatch latch;
        private final ILogger logger;
        boolean retry;
        boolean succeeded;

        public CachedEnvelopeHint(long l2, ILogger iLogger) {
            this.reset();
            this.flushTimeoutMillis = l2;
            this.logger = Objects.requireNonNull(iLogger, "ILogger is required.");
        }

        @Override
        public boolean isRetry() {
            return this.retry;
        }

        @Override
        public boolean isSuccess() {
            return this.succeeded;
        }

        @Override
        public void reset() {
            this.latch = new CountDownLatch(1);
            this.retry = false;
            this.succeeded = false;
        }

        @Override
        public void setResult(boolean bl) {
            this.succeeded = bl;
            this.latch.countDown();
        }

        @Override
        public void setRetry(boolean bl) {
            this.retry = bl;
        }

        @Override
        public boolean waitFlush() {
            try {
                boolean bl = this.latch.await(this.flushTimeoutMillis, TimeUnit.MILLISECONDS);
                return bl;
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
                this.logger.log(SentryLevel.ERROR, "Exception while awaiting on lock.", interruptedException);
                return false;
            }
        }
    }
}

