/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ProviderInfo
 *  android.net.Uri
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core;

import android.content.Context;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import io.sentry.Sentry;
import io.sentry.SentryIntegrationPackageStorage;
import io.sentry.SentryLevel;
import io.sentry.android.core.AndroidLogger;
import io.sentry.android.core.EmptySecureContentProvider;
import io.sentry.android.core.ManifestMetadataReader;
import io.sentry.android.core.SentryAndroid;

public final class SentryInitProvider
extends EmptySecureContentProvider {
    public void attachInfo(Context context, ProviderInfo providerInfo) {
        if (!SentryInitProvider.class.getName().equals((Object)providerInfo.authority)) {
            super.attachInfo(context, providerInfo);
            return;
        }
        throw new IllegalStateException("An applicationId is required to fulfill the manifest placeholder.");
    }

    public String getType(Uri uri) {
        return null;
    }

    public boolean onCreate() {
        AndroidLogger androidLogger = new AndroidLogger();
        Context context = this.getContext();
        if (context == null) {
            androidLogger.log(SentryLevel.FATAL, "App. Context from ContentProvider is null", new Object[0]);
            return false;
        }
        if (ManifestMetadataReader.isAutoInit(context, androidLogger)) {
            SentryAndroid.init(context, androidLogger);
            SentryIntegrationPackageStorage.getInstance().addIntegration("AutoInit");
        }
        return true;
    }

    public void shutdown() {
        Sentry.close();
    }
}

