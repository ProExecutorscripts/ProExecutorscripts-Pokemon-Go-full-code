/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  java.lang.Object
 */
package io.sentry.android.core.internal.util;

import android.view.View;
import android.view.ViewTreeObserver;
import io.sentry.android.core.internal.util.FirstDrawDoneListener;

public final class FirstDrawDoneListener$$ExternalSyntheticLambda0
implements ViewTreeObserver.OnGlobalLayoutListener {
    public final FirstDrawDoneListener f$0;
    public final View f$1;

    public /* synthetic */ FirstDrawDoneListener$$ExternalSyntheticLambda0(FirstDrawDoneListener firstDrawDoneListener, View view2) {
        this.f$0 = firstDrawDoneListener;
        this.f$1 = view2;
    }

    public final void onGlobalLayout() {
        this.f$0.lambda$onDraw$1$io-sentry-android-core-internal-util-FirstDrawDoneListener(this.f$1);
    }
}

