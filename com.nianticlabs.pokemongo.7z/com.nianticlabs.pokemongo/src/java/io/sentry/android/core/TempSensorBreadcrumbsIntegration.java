/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.Throwable
 */
package io.sentry.android.core;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import io.sentry.Breadcrumb;
import io.sentry.Hint;
import io.sentry.IHub;
import io.sentry.ISentryExecutorService;
import io.sentry.Integration;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.TempSensorBreadcrumbsIntegration$$ExternalSyntheticLambda0;
import io.sentry.util.IntegrationUtils;
import io.sentry.util.Objects;
import java.io.Closeable;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class TempSensorBreadcrumbsIntegration
implements Integration,
Closeable,
SensorEventListener {
    private final Context context;
    private IHub hub;
    private boolean isClosed = false;
    private SentryAndroidOptions options;
    SensorManager sensorManager;
    private final Object startLock = new Object();

    public TempSensorBreadcrumbsIntegration(Context context) {
        this.context = Objects.requireNonNull(context, "Context is required");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void startSensorListener(SentryOptions sentryOptions) {
        try {
            SensorManager sensorManager;
            this.sensorManager = sensorManager = (SensorManager)this.context.getSystemService("sensor");
            if (sensorManager == null) {
                sentryOptions.getLogger().log(SentryLevel.INFO, "SENSOR_SERVICE is not available.", new Object[0]);
                return;
            }
            if ((sensorManager = sensorManager.getDefaultSensor(13)) != null) {
                this.sensorManager.registerListener((SensorEventListener)this, (Sensor)sensorManager, 3);
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "TempSensorBreadcrumbsIntegration installed.", new Object[0]);
                IntegrationUtils.addIntegrationToSdkVersion(this.getClass());
                return;
            }
            sentryOptions.getLogger().log(SentryLevel.INFO, "TYPE_AMBIENT_TEMPERATURE is not available.", new Object[0]);
            return;
        }
        catch (Throwable throwable) {
            sentryOptions.getLogger().log(SentryLevel.ERROR, throwable, "Failed to init. the SENSOR_SERVICE.", new Object[0]);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void close() throws IOException {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            this.isClosed = true;
        }
        Object object3 = this.sensorManager;
        if (object3 != null) {
            object3.unregisterListener((SensorEventListener)this);
            this.sensorManager = null;
            object3 = this.options;
            if (object3 != null) {
                ((SentryOptions)object3).getLogger().log(SentryLevel.DEBUG, "TempSensorBreadcrumbsIntegration removed.", new Object[0]);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    /* synthetic */ void lambda$register$0$io-sentry-android-core-TempSensorBreadcrumbsIntegration(SentryOptions sentryOptions) {
        Object object;
        Object object2 = object = this.startLock;
        synchronized (object2) {
            if (!this.isClosed) {
                this.startSensorListener(sentryOptions);
            }
            return;
        }
    }

    public void onAccuracyChanged(Sensor sensor, int n2) {
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        Object object = sensorEvent.values;
        if (object != null && ((float[])object).length != 0 && object[0] != 0.0f && this.hub != null) {
            object = new Breadcrumb();
            object.setType("system");
            object.setCategory("device.event");
            object.setData("action", "TYPE_AMBIENT_TEMPERATURE");
            object.setData("accuracy", sensorEvent.accuracy);
            object.setData("timestamp", sensorEvent.timestamp);
            object.setLevel(SentryLevel.INFO);
            object.setData("degree", Float.valueOf((float)sensorEvent.values[0]));
            Hint hint = new Hint();
            hint.set("android:sensorEvent", sensorEvent);
            this.hub.addBreadcrumb((Breadcrumb)object, hint);
        }
    }

    @Override
    public void register(IHub object, SentryOptions sentryOptions) {
        this.hub = Objects.requireNonNull(object, "Hub is required");
        object = sentryOptions instanceof SentryAndroidOptions ? (SentryAndroidOptions)sentryOptions : null;
        this.options = object = (SentryAndroidOptions)Objects.requireNonNull(object, "SentryAndroidOptions is required");
        ((SentryOptions)object).getLogger().log(SentryLevel.DEBUG, "enableSystemEventsBreadcrumbs enabled: %s", this.options.isEnableSystemEventBreadcrumbs());
        if (this.options.isEnableSystemEventBreadcrumbs()) {
            try {
                ISentryExecutorService iSentryExecutorService = sentryOptions.getExecutorService();
                object = new TempSensorBreadcrumbsIntegration$$ExternalSyntheticLambda0(this, sentryOptions);
                iSentryExecutorService.submit((Runnable)object);
            }
            catch (Throwable throwable) {
                sentryOptions.getLogger().log(SentryLevel.DEBUG, "Failed to start TempSensorBreadcrumbsIntegration on executor thread.", throwable);
            }
        }
    }
}

