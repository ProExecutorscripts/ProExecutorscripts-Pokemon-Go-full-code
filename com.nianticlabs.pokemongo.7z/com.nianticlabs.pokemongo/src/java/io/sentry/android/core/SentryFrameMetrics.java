/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.core;

final class SentryFrameMetrics {
    private int frozenFrameCount;
    private long frozenFrameDelayNanos;
    private int normalFrameCount;
    private int slowFrameCount;
    private long slowFrameDelayNanos;
    private long totalDurationNanos;

    public SentryFrameMetrics() {
    }

    public SentryFrameMetrics(int n2, int n3, long l2, int n4, long l3, long l4) {
        this.normalFrameCount = n2;
        this.slowFrameCount = n3;
        this.slowFrameDelayNanos = l2;
        this.frozenFrameCount = n4;
        this.frozenFrameDelayNanos = l3;
        this.totalDurationNanos = l4;
    }

    public void addFrame(long l2, long l3, boolean bl, boolean bl2) {
        this.totalDurationNanos += l2;
        if (bl2) {
            this.frozenFrameDelayNanos += l3;
            ++this.frozenFrameCount;
        } else if (bl) {
            this.slowFrameDelayNanos += l3;
            ++this.slowFrameCount;
        } else {
            ++this.normalFrameCount;
        }
    }

    public void clear() {
        this.normalFrameCount = 0;
        this.slowFrameCount = 0;
        this.slowFrameDelayNanos = 0L;
        this.frozenFrameCount = 0;
        this.frozenFrameDelayNanos = 0L;
        this.totalDurationNanos = 0L;
    }

    public boolean containsValidData() {
        boolean bl = this.normalFrameCount >= 0 && this.slowFrameCount >= 0 && this.slowFrameDelayNanos >= 0L && this.frozenFrameCount >= 0 && this.frozenFrameDelayNanos >= 0L && this.totalDurationNanos >= 0L;
        return bl;
    }

    public SentryFrameMetrics diffTo(SentryFrameMetrics sentryFrameMetrics) {
        return new SentryFrameMetrics(this.normalFrameCount - sentryFrameMetrics.normalFrameCount, this.slowFrameCount - sentryFrameMetrics.slowFrameCount, this.slowFrameDelayNanos - sentryFrameMetrics.slowFrameDelayNanos, this.frozenFrameCount - sentryFrameMetrics.frozenFrameCount, this.frozenFrameDelayNanos - sentryFrameMetrics.frozenFrameDelayNanos, this.totalDurationNanos - sentryFrameMetrics.totalDurationNanos);
    }

    public SentryFrameMetrics duplicate() {
        return new SentryFrameMetrics(this.normalFrameCount, this.slowFrameCount, this.slowFrameDelayNanos, this.frozenFrameCount, this.frozenFrameDelayNanos, this.totalDurationNanos);
    }

    public int getFrozenFrameCount() {
        return this.frozenFrameCount;
    }

    public long getFrozenFrameDelayNanos() {
        return this.frozenFrameDelayNanos;
    }

    public int getNormalFrameCount() {
        return this.normalFrameCount;
    }

    public int getSlowFrameCount() {
        return this.slowFrameCount;
    }

    public long getSlowFrameDelayNanos() {
        return this.slowFrameDelayNanos;
    }

    public long getTotalDurationNanos() {
        return this.totalDurationNanos;
    }

    public int getTotalFrameCount() {
        return this.normalFrameCount + this.slowFrameCount + this.frozenFrameCount;
    }
}

