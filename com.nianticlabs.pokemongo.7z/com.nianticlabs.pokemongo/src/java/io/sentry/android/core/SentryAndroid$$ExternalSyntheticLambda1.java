/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.sentry.android.core;

import io.sentry.Sentry;
import io.sentry.SentryOptions;
import io.sentry.android.core.SentryAndroid;
import io.sentry.android.core.SentryAndroidOptions;

public final class SentryAndroid$$ExternalSyntheticLambda1
implements Sentry.OptionsConfiguration {
    public final void configure(SentryOptions sentryOptions) {
        SentryAndroid.lambda$init$0((SentryAndroidOptions)sentryOptions);
    }
}

