/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Comparator
 */
package io.sentry.android.core;

import io.sentry.ISpan;
import io.sentry.android.core.SpanFrameMetricsCollector;
import java.util.Comparator;

public final class SpanFrameMetricsCollector$$ExternalSyntheticLambda0
implements Comparator {
    public final int compare(Object object, Object object2) {
        return SpanFrameMetricsCollector.lambda$new$0((ISpan)object, (ISpan)object2);
    }
}

