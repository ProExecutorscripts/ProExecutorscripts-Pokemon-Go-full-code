/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.concurrent.atomic.AtomicLong
 */
package io.sentry.android.core.internal.util;

import io.sentry.transport.ICurrentDateProvider;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class Debouncer {
    private final AtomicInteger executions = new AtomicInteger(0);
    private final AtomicLong lastExecutionTime = new AtomicLong(0L);
    private final int maxExecutions;
    private final ICurrentDateProvider timeProvider;
    private final long waitTimeMs;

    public Debouncer(ICurrentDateProvider iCurrentDateProvider, long l2, int n2) {
        this.timeProvider = iCurrentDateProvider;
        this.waitTimeMs = l2;
        int n3 = n2;
        if (n2 <= 0) {
            n3 = 1;
        }
        this.maxExecutions = n3;
    }

    public boolean checkForDebounce() {
        long l2 = this.timeProvider.getCurrentTimeMillis();
        if (this.lastExecutionTime.get() != 0L && this.lastExecutionTime.get() + this.waitTimeMs > l2) {
            if (this.executions.incrementAndGet() < this.maxExecutions) {
                return false;
            }
            this.executions.set(0);
            return true;
        }
        this.executions.set(0);
        this.lastExecutionTime.set(l2);
        return false;
    }
}

