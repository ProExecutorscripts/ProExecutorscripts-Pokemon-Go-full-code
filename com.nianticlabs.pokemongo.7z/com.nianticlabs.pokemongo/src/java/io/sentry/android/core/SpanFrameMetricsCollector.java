/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Comparable
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Comparator
 *  java.util.Date
 *  java.util.SortedSet
 *  java.util.TreeSet
 *  java.util.concurrent.ConcurrentSkipListSet
 *  java.util.concurrent.TimeUnit
 */
package io.sentry.android.core;

import io.sentry.IPerformanceContinuousCollector;
import io.sentry.ISpan;
import io.sentry.ITransaction;
import io.sentry.NoOpSpan;
import io.sentry.NoOpTransaction;
import io.sentry.SentryDate;
import io.sentry.SentryNanotimeDate;
import io.sentry.android.core.SentryAndroidOptions;
import io.sentry.android.core.SentryFrameMetrics;
import io.sentry.android.core.SpanFrameMetricsCollector$$ExternalSyntheticLambda0;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import java.util.Comparator;
import java.util.Date;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.TimeUnit;

public class SpanFrameMetricsCollector
implements IPerformanceContinuousCollector,
SentryFrameMetricsCollector.FrameMetricsCollectorListener {
    private static final int MAX_FRAMES_COUNT = 3600;
    private static final long ONE_SECOND_NANOS = TimeUnit.SECONDS.toNanos(1L);
    private static final SentryNanotimeDate UNIX_START_DATE = new SentryNanotimeDate(new Date(0L), 0L);
    private final boolean enabled;
    private final SentryFrameMetricsCollector frameMetricsCollector;
    private final ConcurrentSkipListSet<Frame> frames;
    private long lastKnownFrameDurationNanos = 16666666L;
    private volatile String listenerId;
    private final Object lock = new Object();
    private final SortedSet<ISpan> runningSpans = new TreeSet((Comparator)new SpanFrameMetricsCollector$$ExternalSyntheticLambda0());

    public SpanFrameMetricsCollector(SentryAndroidOptions sentryAndroidOptions, SentryFrameMetricsCollector sentryFrameMetricsCollector) {
        this.frames = new ConcurrentSkipListSet();
        this.frameMetricsCollector = sentryFrameMetricsCollector;
        boolean bl = sentryAndroidOptions.isEnablePerformanceV2() && sentryAndroidOptions.isEnableFramesTracking();
        this.enabled = bl;
    }

    private static int addPendingFrameDelay(SentryFrameMetrics sentryFrameMetrics, long l2, long l3, long l4) {
        if (SentryFrameMetricsCollector.isSlow(l3 = Math.max((long)0L, (long)(l3 - l4)), l2)) {
            boolean bl = SentryFrameMetricsCollector.isFrozen(l3);
            sentryFrameMetrics.addFrame(l3, Math.max((long)0L, (long)(l3 - l2)), true, bl);
            return 1;
        }
        return 0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void captureFrameMetrics(ISpan var1_1) {
        var22_4 = var18_3 = this.lock;
        synchronized (var22_4) {
            if (!this.runningSpans.remove((Object)var1_1)) {
                return;
            }
            var19_5 = var1_1.getFinishDate();
            if (var19_5 == null) {
                return;
            }
            var13_6 = SpanFrameMetricsCollector.realNanos((SentryDate)var19_5);
            var19_5 = new SentryFrameMetrics();
            var15_7 = SpanFrameMetricsCollector.realNanos(var1_1.getStartDate());
            if (var15_7 >= var13_6) {
                return;
            }
            var5_8 = var13_6 - var15_7;
            var7_9 = this.lastKnownFrameDurationNanos;
            var17_10 = this.frames.isEmpty();
            var11_11 = var7_9;
            var9_12 = var5_8;
            if (var17_10) ** GOTO lbl43
            var21_13 /* !! */  = this.frames;
            var20_14 = new Frame(var15_7);
            var20_14 = var21_13 /* !! */ .tailSet((Object)var20_14).iterator();
            while (true) {
                var11_11 = var7_9;
                var9_12 = var5_8;
                if (!var20_14.hasNext()) break;
                var21_13 /* !! */  = (Frame)var20_14.next();
                if (Frame.access$000(var21_13 /* !! */ ) > var13_6) {
                    var11_11 = var7_9;
                    var9_12 = var5_8;
                    break;
                }
                if (Frame.access$000(var21_13 /* !! */ ) >= var15_7 && Frame.access$100(var21_13 /* !! */ ) <= var13_6) {
                    var19_5.addFrame(Frame.access$200(var21_13 /* !! */ ), Frame.access$300(var21_13 /* !! */ ), Frame.access$400(var21_13 /* !! */ ), Frame.access$500(var21_13 /* !! */ ));
                } else if (var15_7 > Frame.access$000(var21_13 /* !! */ ) && var15_7 < Frame.access$100(var21_13 /* !! */ ) || var13_6 > Frame.access$000(var21_13 /* !! */ ) && var13_6 < Frame.access$100(var21_13 /* !! */ )) {
                    var7_9 = Math.max((long)0L, (long)(Math.max((long)0L, (long)(var15_7 - Frame.access$000(var21_13 /* !! */ ))) - Frame.access$600(var21_13 /* !! */ )));
                    var7_9 = Math.min((long)(Frame.access$300(var21_13 /* !! */ ) - var7_9), (long)var5_8);
                    var9_12 = Math.max((long)var15_7, (long)Frame.access$000(var21_13 /* !! */ ));
                    var9_12 = Math.min((long)var13_6, (long)Frame.access$100(var21_13 /* !! */ )) - var9_12;
                    var19_5.addFrame(var9_12, var7_9, SentryFrameMetricsCollector.isSlow(var9_12, Frame.access$600(var21_13 /* !! */ )), SentryFrameMetricsCollector.isFrozen(var9_12));
                }
                var7_9 = Frame.access$600(var21_13 /* !! */ );
            }
lbl43:
            // 3 sources

            var4_15 = var19_5.getTotalFrameCount();
            var4_15 = var4_15 + SpanFrameMetricsCollector.addPendingFrameDelay((SentryFrameMetrics)var19_5, var11_11, var13_6, this.frameMetricsCollector.getLastKnownFrameStartTimeNanos()) + SpanFrameMetricsCollector.interpolateFrameCount((SentryFrameMetrics)var19_5, var11_11, var9_12);
            var2_16 = (double)(var19_5.getSlowFrameDelayNanos() + var19_5.getFrozenFrameDelayNanos()) / 1.0E9;
            var1_1.setData("frames.total", var4_15);
            var1_1.setData("frames.slow", var19_5.getSlowFrameCount());
            var1_1.setData("frames.frozen", var19_5.getFrozenFrameCount());
            var1_1.setData("frames.delay", var2_16);
            if (var1_1 instanceof ITransaction) {
                var1_1.setMeasurement("frames_total", (Number)Integer.valueOf((int)var4_15));
                var1_1.setMeasurement("frames_slow", (Number)Integer.valueOf((int)var19_5.getSlowFrameCount()));
                var1_1.setMeasurement("frames_frozen", (Number)Integer.valueOf((int)var19_5.getFrozenFrameCount()));
                var1_1.setMeasurement("frames_delay", (Number)Double.valueOf((double)var2_16));
            }
            return;
        }
    }

    private static int interpolateFrameCount(SentryFrameMetrics sentryFrameMetrics, long l2, long l3) {
        if ((l3 -= sentryFrameMetrics.getTotalDurationNanos()) > 0L) {
            return (int)(l3 / l2);
        }
        return 0;
    }

    static /* synthetic */ int lambda$new$0(ISpan iSpan, ISpan iSpan2) {
        int n2 = iSpan.getStartDate().compareTo(iSpan2.getStartDate());
        if (n2 != 0) {
            return n2;
        }
        return iSpan.getSpanContext().getSpanId().toString().compareTo(iSpan2.getSpanContext().getSpanId().toString());
    }

    private static long realNanos(SentryDate sentryDate) {
        return sentryDate.diff(UNIX_START_DATE);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void clear() {
        Object object;
        Object object2 = object = this.lock;
        synchronized (object2) {
            if (this.listenerId != null) {
                this.frameMetricsCollector.stopCollection(this.listenerId);
                this.listenerId = null;
            }
            this.frames.clear();
            this.runningSpans.clear();
            return;
        }
    }

    @Override
    public void onFrameMetricCollected(long l2, long l3, long l4, long l5, boolean bl, boolean bl2, float f2) {
        long l6;
        if (this.frames.size() > 3600) {
            return;
        }
        this.lastKnownFrameDurationNanos = l6 = (long)((double)ONE_SECOND_NANOS / (double)f2);
        this.frames.add((Object)new Frame(l2, l3, l4, l5, bl, bl2, l6));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onSpanFinished(ISpan object) {
        Object object2;
        if (!this.enabled) {
            return;
        }
        if (object instanceof NoOpSpan) {
            return;
        }
        if (object instanceof NoOpTransaction) {
            return;
        }
        Object object3 = object2 = this.lock;
        synchronized (object3) {
            if (!this.runningSpans.contains(object)) {
                return;
            }
        }
        this.captureFrameMetrics((ISpan)object);
        Object object4 = object = this.lock;
        synchronized (object4) {
            if (this.runningSpans.isEmpty()) {
                this.clear();
            } else {
                object2 = (ISpan)this.runningSpans.first();
                ConcurrentSkipListSet<Frame> concurrentSkipListSet = this.frames;
                Frame frame = new Frame(SpanFrameMetricsCollector.realNanos(object2.getStartDate()));
                concurrentSkipListSet.headSet((Object)frame).clear();
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void onSpanStarted(ISpan iSpan) {
        Object object;
        if (!this.enabled) {
            return;
        }
        if (iSpan instanceof NoOpSpan) {
            return;
        }
        if (iSpan instanceof NoOpTransaction) {
            return;
        }
        Object object2 = object = this.lock;
        synchronized (object2) {
            this.runningSpans.add((Object)iSpan);
            if (this.listenerId == null) {
                this.listenerId = this.frameMetricsCollector.startCollection(this);
            }
            return;
        }
    }

    private static class Frame
    implements Comparable<Frame> {
        private final long delayNanos;
        private final long durationNanos;
        private final long endNanos;
        private final long expectedDurationNanos;
        private final boolean isFrozen;
        private final boolean isSlow;
        private final long startNanos;

        Frame(long l2) {
            this(l2, l2, 0L, 0L, false, false, 0L);
        }

        Frame(long l2, long l3, long l4, long l5, boolean bl, boolean bl2, long l6) {
            this.startNanos = l2;
            this.endNanos = l3;
            this.durationNanos = l4;
            this.delayNanos = l5;
            this.isSlow = bl;
            this.isFrozen = bl2;
            this.expectedDurationNanos = l6;
        }

        static /* synthetic */ long access$000(Frame frame) {
            return frame.startNanos;
        }

        static /* synthetic */ long access$100(Frame frame) {
            return frame.endNanos;
        }

        static /* synthetic */ long access$200(Frame frame) {
            return frame.durationNanos;
        }

        static /* synthetic */ long access$300(Frame frame) {
            return frame.delayNanos;
        }

        static /* synthetic */ boolean access$400(Frame frame) {
            return frame.isSlow;
        }

        static /* synthetic */ boolean access$500(Frame frame) {
            return frame.isFrozen;
        }

        static /* synthetic */ long access$600(Frame frame) {
            return frame.expectedDurationNanos;
        }

        public int compareTo(Frame frame) {
            return Long.compare((long)this.endNanos, (long)frame.endNanos);
        }
    }
}

