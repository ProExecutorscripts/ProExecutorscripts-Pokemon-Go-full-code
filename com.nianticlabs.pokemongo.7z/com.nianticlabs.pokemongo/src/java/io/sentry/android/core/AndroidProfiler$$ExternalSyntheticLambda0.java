/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package io.sentry.android.core;

import io.sentry.android.core.AndroidProfiler;

public final class AndroidProfiler$$ExternalSyntheticLambda0
implements Runnable {
    public final AndroidProfiler f$0;

    public /* synthetic */ AndroidProfiler$$ExternalSyntheticLambda0(AndroidProfiler androidProfiler) {
        this.f$0 = androidProfiler;
    }

    public final void run() {
        this.f$0.lambda$start$0$io-sentry-android-core-AndroidProfiler();
    }
}

