/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core;

public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "io.sentry.android.core";
    public static final String SENTRY_ANDROID_SDK_NAME = "sentry.java.android";
    public static final String VERSION_NAME = "7.8.0";
}

