/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.List
 *  java.util.concurrent.CountDownLatch
 *  java.util.concurrent.atomic.AtomicReference
 */
package io.sentry.android.core;

import android.view.View;
import io.sentry.ILogger;
import io.sentry.android.core.ViewHierarchyEventProcessor;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public final class ViewHierarchyEventProcessor$$ExternalSyntheticLambda0
implements Runnable {
    public final AtomicReference f$0;
    public final View f$1;
    public final List f$2;
    public final CountDownLatch f$3;
    public final ILogger f$4;

    public /* synthetic */ ViewHierarchyEventProcessor$$ExternalSyntheticLambda0(AtomicReference atomicReference, View view2, List list, CountDownLatch countDownLatch, ILogger iLogger) {
        this.f$0 = atomicReference;
        this.f$1 = view2;
        this.f$2 = list;
        this.f$3 = countDownLatch;
        this.f$4 = iLogger;
    }

    public final void run() {
        ViewHierarchyEventProcessor.lambda$snapshotViewHierarchy$0(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4);
    }
}

