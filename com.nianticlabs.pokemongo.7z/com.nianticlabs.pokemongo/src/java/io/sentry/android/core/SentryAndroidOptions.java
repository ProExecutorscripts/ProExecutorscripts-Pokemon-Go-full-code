/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry.android.core;

import io.sentry.Hint;
import io.sentry.SentryEvent;
import io.sentry.SentryOptions;
import io.sentry.android.core.IDebugImagesLoader;
import io.sentry.android.core.NoOpDebugImagesLoader;
import io.sentry.android.core.internal.util.SentryFrameMetricsCollector;
import io.sentry.protocol.SdkVersion;

public final class SentryAndroidOptions
extends SentryOptions {
    private boolean anrEnabled = true;
    private boolean anrReportInDebug = false;
    private long anrTimeoutIntervalMillis = 5000L;
    private boolean attachAnrThreadDump = false;
    private boolean attachScreenshot;
    private boolean attachViewHierarchy;
    private BeforeCaptureCallback beforeScreenshotCaptureCallback;
    private BeforeCaptureCallback beforeViewHierarchyCaptureCallback;
    private boolean collectAdditionalContext = true;
    private IDebugImagesLoader debugImagesLoader = NoOpDebugImagesLoader.getInstance();
    private boolean enableActivityLifecycleBreadcrumbs = true;
    private boolean enableActivityLifecycleTracingAutoFinish = true;
    private boolean enableAppComponentBreadcrumbs = true;
    private boolean enableAppLifecycleBreadcrumbs = true;
    private boolean enableAutoActivityLifecycleTracing = true;
    private boolean enableFramesTracking = true;
    private boolean enableNdk = true;
    private boolean enableNetworkEventBreadcrumbs = true;
    private boolean enablePerformanceV2 = false;
    private boolean enableRootCheck = true;
    private boolean enableScopeSync = true;
    private boolean enableSystemEventBreadcrumbs = true;
    private SentryFrameMetricsCollector frameMetricsCollector;
    private String nativeSdkName = null;
    private boolean reportHistoricalAnrs = false;
    private final long startupCrashDurationThresholdMillis;
    private long startupCrashFlushTimeoutMillis = 5000L;

    public SentryAndroidOptions() {
        this.startupCrashDurationThresholdMillis = 2000L;
        this.setSentryClientName("sentry.java.android/7.8.0");
        this.setSdkVersion(this.createSdkVersion());
        this.setAttachServerName(false);
    }

    private SdkVersion createSdkVersion() {
        SdkVersion sdkVersion = SdkVersion.updateSdkVersion(this.getSdkVersion(), "sentry.java.android", "7.8.0");
        sdkVersion.addPackage("maven:io.sentry:sentry-android-core", "7.8.0");
        return sdkVersion;
    }

    public void enableAllAutoBreadcrumbs(boolean bl) {
        this.enableActivityLifecycleBreadcrumbs = bl;
        this.enableAppComponentBreadcrumbs = bl;
        this.enableSystemEventBreadcrumbs = bl;
        this.enableAppLifecycleBreadcrumbs = bl;
        this.enableNetworkEventBreadcrumbs = bl;
        this.setEnableUserInteractionBreadcrumbs(bl);
    }

    public long getAnrTimeoutIntervalMillis() {
        return this.anrTimeoutIntervalMillis;
    }

    public BeforeCaptureCallback getBeforeScreenshotCaptureCallback() {
        return this.beforeScreenshotCaptureCallback;
    }

    public BeforeCaptureCallback getBeforeViewHierarchyCaptureCallback() {
        return this.beforeViewHierarchyCaptureCallback;
    }

    public IDebugImagesLoader getDebugImagesLoader() {
        return this.debugImagesLoader;
    }

    public SentryFrameMetricsCollector getFrameMetricsCollector() {
        return this.frameMetricsCollector;
    }

    public String getNativeSdkName() {
        return this.nativeSdkName;
    }

    @Deprecated
    public int getProfilingTracesIntervalMillis() {
        return 0;
    }

    public long getStartupCrashDurationThresholdMillis() {
        return 2000L;
    }

    long getStartupCrashFlushTimeoutMillis() {
        return this.startupCrashFlushTimeoutMillis;
    }

    public boolean isAnrEnabled() {
        return this.anrEnabled;
    }

    public boolean isAnrReportInDebug() {
        return this.anrReportInDebug;
    }

    public boolean isAttachAnrThreadDump() {
        return this.attachAnrThreadDump;
    }

    public boolean isAttachScreenshot() {
        return this.attachScreenshot;
    }

    public boolean isAttachViewHierarchy() {
        return this.attachViewHierarchy;
    }

    public boolean isCollectAdditionalContext() {
        return this.collectAdditionalContext;
    }

    public boolean isEnableActivityLifecycleBreadcrumbs() {
        return this.enableActivityLifecycleBreadcrumbs;
    }

    public boolean isEnableActivityLifecycleTracingAutoFinish() {
        return this.enableActivityLifecycleTracingAutoFinish;
    }

    public boolean isEnableAppComponentBreadcrumbs() {
        return this.enableAppComponentBreadcrumbs;
    }

    public boolean isEnableAppLifecycleBreadcrumbs() {
        return this.enableAppLifecycleBreadcrumbs;
    }

    public boolean isEnableAutoActivityLifecycleTracing() {
        return this.enableAutoActivityLifecycleTracing;
    }

    public boolean isEnableFramesTracking() {
        return this.enableFramesTracking;
    }

    public boolean isEnableNdk() {
        return this.enableNdk;
    }

    public boolean isEnableNetworkEventBreadcrumbs() {
        return this.enableNetworkEventBreadcrumbs;
    }

    public boolean isEnablePerformanceV2() {
        return this.enablePerformanceV2;
    }

    public boolean isEnableRootCheck() {
        return this.enableRootCheck;
    }

    public boolean isEnableScopeSync() {
        return this.enableScopeSync;
    }

    public boolean isEnableSystemEventBreadcrumbs() {
        return this.enableSystemEventBreadcrumbs;
    }

    public boolean isReportHistoricalAnrs() {
        return this.reportHistoricalAnrs;
    }

    public void setAnrEnabled(boolean bl) {
        this.anrEnabled = bl;
    }

    public void setAnrReportInDebug(boolean bl) {
        this.anrReportInDebug = bl;
    }

    public void setAnrTimeoutIntervalMillis(long l2) {
        this.anrTimeoutIntervalMillis = l2;
    }

    public void setAttachAnrThreadDump(boolean bl) {
        this.attachAnrThreadDump = bl;
    }

    public void setAttachScreenshot(boolean bl) {
        this.attachScreenshot = bl;
    }

    public void setAttachViewHierarchy(boolean bl) {
        this.attachViewHierarchy = bl;
    }

    public void setBeforeScreenshotCaptureCallback(BeforeCaptureCallback beforeCaptureCallback) {
        this.beforeScreenshotCaptureCallback = beforeCaptureCallback;
    }

    public void setBeforeViewHierarchyCaptureCallback(BeforeCaptureCallback beforeCaptureCallback) {
        this.beforeViewHierarchyCaptureCallback = beforeCaptureCallback;
    }

    public void setCollectAdditionalContext(boolean bl) {
        this.collectAdditionalContext = bl;
    }

    public void setDebugImagesLoader(IDebugImagesLoader iDebugImagesLoader) {
        if (iDebugImagesLoader == null) {
            iDebugImagesLoader = NoOpDebugImagesLoader.getInstance();
        }
        this.debugImagesLoader = iDebugImagesLoader;
    }

    public void setEnableActivityLifecycleBreadcrumbs(boolean bl) {
        this.enableActivityLifecycleBreadcrumbs = bl;
    }

    public void setEnableActivityLifecycleTracingAutoFinish(boolean bl) {
        this.enableActivityLifecycleTracingAutoFinish = bl;
    }

    public void setEnableAppComponentBreadcrumbs(boolean bl) {
        this.enableAppComponentBreadcrumbs = bl;
    }

    public void setEnableAppLifecycleBreadcrumbs(boolean bl) {
        this.enableAppLifecycleBreadcrumbs = bl;
    }

    public void setEnableAutoActivityLifecycleTracing(boolean bl) {
        this.enableAutoActivityLifecycleTracing = bl;
    }

    public void setEnableFramesTracking(boolean bl) {
        this.enableFramesTracking = bl;
    }

    public void setEnableNdk(boolean bl) {
        this.enableNdk = bl;
    }

    public void setEnableNetworkEventBreadcrumbs(boolean bl) {
        this.enableNetworkEventBreadcrumbs = bl;
    }

    public void setEnablePerformanceV2(boolean bl) {
        this.enablePerformanceV2 = bl;
    }

    public void setEnableRootCheck(boolean bl) {
        this.enableRootCheck = bl;
    }

    public void setEnableScopeSync(boolean bl) {
        this.enableScopeSync = bl;
    }

    public void setEnableSystemEventBreadcrumbs(boolean bl) {
        this.enableSystemEventBreadcrumbs = bl;
    }

    public void setFrameMetricsCollector(SentryFrameMetricsCollector sentryFrameMetricsCollector) {
        this.frameMetricsCollector = sentryFrameMetricsCollector;
    }

    public void setNativeSdkName(String string2) {
        this.nativeSdkName = string2;
    }

    @Deprecated
    public void setProfilingTracesIntervalMillis(int n2) {
    }

    public void setReportHistoricalAnrs(boolean bl) {
        this.reportHistoricalAnrs = bl;
    }

    void setStartupCrashFlushTimeoutMillis(long l2) {
        this.startupCrashFlushTimeoutMillis = l2;
    }

    public static interface BeforeCaptureCallback {
        public boolean execute(SentryEvent var1, Hint var2, boolean var3);
    }
}

