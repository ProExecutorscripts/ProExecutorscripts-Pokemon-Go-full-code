/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package io.sentry.android.core.internal.gestures;

import io.sentry.IScope;
import io.sentry.ITransaction;
import io.sentry.ScopeCallback;
import io.sentry.android.core.internal.gestures.SentryGestureListener;

public final class SentryGestureListener$$ExternalSyntheticLambda2
implements ScopeCallback {
    public final SentryGestureListener f$0;
    public final ITransaction f$1;

    public /* synthetic */ SentryGestureListener$$ExternalSyntheticLambda2(SentryGestureListener sentryGestureListener, ITransaction iTransaction) {
        this.f$0 = sentryGestureListener;
        this.f$1 = iTransaction;
    }

    @Override
    public final void run(IScope iScope) {
        this.f$0.lambda$startTracing$0$io-sentry-android-core-internal-gestures-SentryGestureListener(this.f$1, iScope);
    }
}

