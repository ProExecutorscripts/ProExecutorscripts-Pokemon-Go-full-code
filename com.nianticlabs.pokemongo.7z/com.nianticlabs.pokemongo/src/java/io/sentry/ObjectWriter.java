/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 */
package io.sentry;

import io.sentry.ILogger;
import java.io.IOException;

public interface ObjectWriter {
    public ObjectWriter beginArray() throws IOException;

    public ObjectWriter beginObject() throws IOException;

    public ObjectWriter endArray() throws IOException;

    public ObjectWriter endObject() throws IOException;

    public ObjectWriter name(String var1) throws IOException;

    public ObjectWriter nullValue() throws IOException;

    public ObjectWriter value(double var1) throws IOException;

    public ObjectWriter value(long var1) throws IOException;

    public ObjectWriter value(ILogger var1, Object var2) throws IOException;

    public ObjectWriter value(Boolean var1) throws IOException;

    public ObjectWriter value(Number var1) throws IOException;

    public ObjectWriter value(String var1) throws IOException;

    public ObjectWriter value(boolean var1) throws IOException;
}

