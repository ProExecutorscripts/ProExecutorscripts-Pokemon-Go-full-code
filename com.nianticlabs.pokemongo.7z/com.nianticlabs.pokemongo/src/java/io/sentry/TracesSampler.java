/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.security.SecureRandom
 */
package io.sentry;

import io.sentry.SamplingContext;
import io.sentry.SentryLevel;
import io.sentry.SentryOptions;
import io.sentry.TracesSamplingDecision;
import io.sentry.util.Objects;
import java.security.SecureRandom;

final class TracesSampler {
    private static final Double DEFAULT_TRACES_SAMPLE_RATE = 1.0;
    private final SentryOptions options;
    private final SecureRandom random;

    public TracesSampler(SentryOptions sentryOptions) {
        this(Objects.requireNonNull(sentryOptions, "options are required"), new SecureRandom());
    }

    TracesSampler(SentryOptions sentryOptions, SecureRandom secureRandom) {
        this.options = sentryOptions;
        this.random = secureRandom;
    }

    private boolean sample(Double d2) {
        boolean bl = !(d2 < this.random.nextDouble());
        return bl;
    }

    TracesSamplingDecision sample(SamplingContext object) {
        Object object2;
        block12: {
            object2 = ((SamplingContext)object).getTransactionContext().getSamplingDecision();
            if (object2 != null) {
                return object2;
            }
            if (this.options.getProfilesSampler() != null) {
                try {
                    object2 = this.options.getProfilesSampler().sample((SamplingContext)object);
                    break block12;
                }
                catch (Throwable throwable) {
                    this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'ProfilesSamplerCallback' callback.", throwable);
                }
            }
            object2 = null;
        }
        TracesSamplingDecision tracesSamplingDecision = object2;
        if (object2 == null) {
            tracesSamplingDecision = this.options.getProfilesSampleRate();
        }
        boolean bl = tracesSamplingDecision != null && this.sample((Double)tracesSamplingDecision);
        Boolean bl2 = bl;
        if (this.options.getTracesSampler() != null) {
            try {
                object2 = this.options.getTracesSampler().sample((SamplingContext)object);
            }
            catch (Throwable throwable) {
                this.options.getLogger().log(SentryLevel.ERROR, "Error in the 'TracesSamplerCallback' callback.", throwable);
                object2 = null;
            }
            if (object2 != null) {
                return new TracesSamplingDecision(this.sample((Double)object2), (Double)object2, bl2, (Double)tracesSamplingDecision);
            }
        }
        if ((object = ((SamplingContext)object).getTransactionContext().getParentSamplingDecision()) != null) {
            return object;
        }
        Double d2 = this.options.getTracesSampleRate();
        object = this.options.getEnableTracing();
        object = Boolean.TRUE.equals(object) ? DEFAULT_TRACES_SAMPLE_RATE : null;
        object2 = d2;
        if (d2 == null) {
            object2 = object;
        }
        double d3 = Math.pow((double)2.0, (double)this.options.getBackpressureMonitor().getDownsampleFactor());
        object = object2 == null ? null : Double.valueOf((double)(object2.doubleValue() / Double.valueOf((double)d3)));
        if (object != null) {
            return new TracesSamplingDecision(this.sample((Double)object), (Double)object, bl2, (Double)tracesSamplingDecision);
        }
        return new TracesSamplingDecision(false, null, false, null);
    }
}

