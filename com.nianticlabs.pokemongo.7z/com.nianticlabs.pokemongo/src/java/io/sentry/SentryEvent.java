/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentHashMap
 */
package io.sentry;

import io.sentry.DateUtils;
import io.sentry.ILogger;
import io.sentry.JsonDeserializer;
import io.sentry.JsonObjectReader;
import io.sentry.JsonSerializable;
import io.sentry.JsonUnknown;
import io.sentry.ObjectWriter;
import io.sentry.SentryBaseEvent;
import io.sentry.SentryLevel;
import io.sentry.SentryValues;
import io.sentry.protocol.Message;
import io.sentry.protocol.SentryException;
import io.sentry.protocol.SentryId;
import io.sentry.protocol.SentryThread;
import io.sentry.util.CollectionUtils;
import io.sentry.vendor.gson.stream.JsonToken;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SentryEvent
extends SentryBaseEvent
implements JsonUnknown,
JsonSerializable {
    private SentryValues<SentryException> exception;
    private List<String> fingerprint;
    private SentryLevel level;
    private String logger;
    private Message message;
    private Map<String, String> modules;
    private SentryValues<SentryThread> threads;
    private Date timestamp;
    private String transaction;
    private Map<String, Object> unknown;

    public SentryEvent() {
        this(new SentryId(), DateUtils.getCurrentDateTime());
    }

    SentryEvent(SentryId sentryId, Date date) {
        super(sentryId);
        this.timestamp = date;
    }

    public SentryEvent(Throwable throwable) {
        this();
        this.throwable = throwable;
    }

    public SentryEvent(Date date) {
        this(new SentryId(), date);
    }

    static /* synthetic */ Date access$002(SentryEvent sentryEvent, Date date) {
        sentryEvent.timestamp = date;
        return date;
    }

    static /* synthetic */ Message access$102(SentryEvent sentryEvent, Message message) {
        sentryEvent.message = message;
        return message;
    }

    static /* synthetic */ String access$202(SentryEvent sentryEvent, String string2) {
        sentryEvent.logger = string2;
        return string2;
    }

    static /* synthetic */ SentryValues access$302(SentryEvent sentryEvent, SentryValues sentryValues) {
        sentryEvent.threads = sentryValues;
        return sentryValues;
    }

    static /* synthetic */ SentryValues access$402(SentryEvent sentryEvent, SentryValues sentryValues) {
        sentryEvent.exception = sentryValues;
        return sentryValues;
    }

    static /* synthetic */ SentryLevel access$502(SentryEvent sentryEvent, SentryLevel sentryLevel) {
        sentryEvent.level = sentryLevel;
        return sentryLevel;
    }

    static /* synthetic */ String access$602(SentryEvent sentryEvent, String string2) {
        sentryEvent.transaction = string2;
        return string2;
    }

    static /* synthetic */ List access$702(SentryEvent sentryEvent, List list) {
        sentryEvent.fingerprint = list;
        return list;
    }

    static /* synthetic */ Map access$802(SentryEvent sentryEvent, Map map2) {
        sentryEvent.modules = map2;
        return map2;
    }

    public List<SentryException> getExceptions() {
        SentryValues<SentryException> sentryValues = this.exception;
        sentryValues = sentryValues == null ? null : sentryValues.getValues();
        return sentryValues;
    }

    public List<String> getFingerprints() {
        return this.fingerprint;
    }

    public SentryLevel getLevel() {
        return this.level;
    }

    public String getLogger() {
        return this.logger;
    }

    public Message getMessage() {
        return this.message;
    }

    public String getModule(String string2) {
        Map<String, String> map2 = this.modules;
        if (map2 != null) {
            return (String)map2.get((Object)string2);
        }
        return null;
    }

    Map<String, String> getModules() {
        return this.modules;
    }

    public List<SentryThread> getThreads() {
        SentryValues<SentryThread> sentryValues = this.threads;
        if (sentryValues != null) {
            return sentryValues.getValues();
        }
        return null;
    }

    public Date getTimestamp() {
        return (Date)this.timestamp.clone();
    }

    public String getTransaction() {
        return this.transaction;
    }

    public SentryException getUnhandledException() {
        Iterator iterator = this.exception;
        if (iterator != null) {
            for (SentryException sentryException : iterator.getValues()) {
                if (sentryException.getMechanism() == null || sentryException.getMechanism().isHandled() == null || sentryException.getMechanism().isHandled().booleanValue()) continue;
                return sentryException;
            }
        }
        return null;
    }

    @Override
    public Map<String, Object> getUnknown() {
        return this.unknown;
    }

    public boolean isCrashed() {
        boolean bl = this.getUnhandledException() != null;
        return bl;
    }

    public boolean isErrored() {
        SentryValues<SentryException> sentryValues = this.exception;
        boolean bl = sentryValues != null && !sentryValues.getValues().isEmpty();
        return bl;
    }

    public void removeModule(String string2) {
        Map<String, String> map2 = this.modules;
        if (map2 != null) {
            map2.remove((Object)string2);
        }
    }

    @Override
    public void serialize(ObjectWriter objectWriter, ILogger iLogger) throws IOException {
        Object object;
        objectWriter.beginObject();
        objectWriter.name("timestamp").value(iLogger, this.timestamp);
        if (this.message != null) {
            objectWriter.name("message").value(iLogger, this.message);
        }
        if (this.logger != null) {
            objectWriter.name("logger").value(this.logger);
        }
        if ((object = this.threads) != null && !((SentryValues)object).getValues().isEmpty()) {
            objectWriter.name("threads");
            objectWriter.beginObject();
            objectWriter.name("values").value(iLogger, this.threads.getValues());
            objectWriter.endObject();
        }
        if ((object = this.exception) != null && !((SentryValues)object).getValues().isEmpty()) {
            objectWriter.name("exception");
            objectWriter.beginObject();
            objectWriter.name("values").value(iLogger, this.exception.getValues());
            objectWriter.endObject();
        }
        if (this.level != null) {
            objectWriter.name("level").value(iLogger, this.level);
        }
        if (this.transaction != null) {
            objectWriter.name("transaction").value(this.transaction);
        }
        if (this.fingerprint != null) {
            objectWriter.name("fingerprint").value(iLogger, this.fingerprint);
        }
        if (this.modules != null) {
            objectWriter.name("modules").value(iLogger, this.modules);
        }
        new SentryBaseEvent.Serializer().serialize(this, objectWriter, iLogger);
        object = this.unknown;
        if (object != null) {
            for (String string2 : object.keySet()) {
                object = this.unknown.get((Object)string2);
                objectWriter.name(string2);
                objectWriter.value(iLogger, object);
            }
        }
        objectWriter.endObject();
    }

    public void setExceptions(List<SentryException> list) {
        this.exception = new SentryValues<SentryException>(list);
    }

    public void setFingerprints(List<String> object) {
        object = object != null ? new ArrayList(object) : null;
        this.fingerprint = object;
    }

    public void setLevel(SentryLevel sentryLevel) {
        this.level = sentryLevel;
    }

    public void setLogger(String string2) {
        this.logger = string2;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public void setModule(String string2, String string3) {
        if (this.modules == null) {
            this.modules = new HashMap();
        }
        this.modules.put((Object)string2, (Object)string3);
    }

    public void setModules(Map<String, String> map2) {
        this.modules = CollectionUtils.newHashMap(map2);
    }

    public void setThreads(List<SentryThread> list) {
        this.threads = new SentryValues<SentryThread>(list);
    }

    public void setTimestamp(Date date) {
        this.timestamp = date;
    }

    public void setTransaction(String string2) {
        this.transaction = string2;
    }

    @Override
    public void setUnknown(Map<String, Object> map2) {
        this.unknown = map2;
    }

    public static final class Deserializer
    implements JsonDeserializer<SentryEvent> {
        @Override
        public SentryEvent deserialize(JsonObjectReader jsonObjectReader, ILogger iLogger) throws Exception {
            jsonObjectReader.beginObject();
            SentryEvent sentryEvent = new SentryEvent();
            SentryBaseEvent.Deserializer deserializer = new SentryBaseEvent.Deserializer();
            Date date = null;
            block22: while (jsonObjectReader.peek() == JsonToken.NAME) {
                Date date2;
                String string2 = jsonObjectReader.nextName();
                string2.hashCode();
                int n2 = string2.hashCode();
                int n3 = -1;
                switch (n2) {
                    default: {
                        break;
                    }
                    case 2141246174: {
                        if (!string2.equals((Object)"transaction")) break;
                        n3 = 8;
                        break;
                    }
                    case 1481625679: {
                        if (!string2.equals((Object)"exception")) break;
                        n3 = 7;
                        break;
                    }
                    case 1227433863: {
                        if (!string2.equals((Object)"modules")) break;
                        n3 = 6;
                        break;
                    }
                    case 954925063: {
                        if (!string2.equals((Object)"message")) break;
                        n3 = 5;
                        break;
                    }
                    case 102865796: {
                        if (!string2.equals((Object)"level")) break;
                        n3 = 4;
                        break;
                    }
                    case 55126294: {
                        if (!string2.equals((Object)"timestamp")) break;
                        n3 = 3;
                        break;
                    }
                    case -1097337456: {
                        if (!string2.equals((Object)"logger")) break;
                        n3 = 2;
                        break;
                    }
                    case -1337936983: {
                        if (!string2.equals((Object)"threads")) break;
                        n3 = 1;
                        break;
                    }
                    case -1375934236: {
                        if (!string2.equals((Object)"fingerprint")) break;
                        n3 = 0;
                    }
                }
                switch (n3) {
                    default: {
                        if (deserializer.deserializeValue(sentryEvent, string2, jsonObjectReader, iLogger)) continue block22;
                        date2 = date;
                        if (date == null) {
                            date2 = new ConcurrentHashMap();
                        }
                        jsonObjectReader.nextUnknown(iLogger, (Map<String, Object>)date2, string2);
                        date = date2;
                        continue block22;
                    }
                    case 8: {
                        SentryEvent.access$602(sentryEvent, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 7: {
                        jsonObjectReader.beginObject();
                        jsonObjectReader.nextName();
                        SentryEvent.access$402(sentryEvent, new SentryValues<SentryException>(jsonObjectReader.nextListOrNull(iLogger, new SentryException.Deserializer())));
                        jsonObjectReader.endObject();
                        continue block22;
                    }
                    case 6: {
                        SentryEvent.access$802(sentryEvent, CollectionUtils.newConcurrentHashMap((Map)jsonObjectReader.nextObjectOrNull()));
                        continue block22;
                    }
                    case 5: {
                        SentryEvent.access$102(sentryEvent, jsonObjectReader.nextOrNull(iLogger, new Message.Deserializer()));
                        continue block22;
                    }
                    case 4: {
                        SentryEvent.access$502(sentryEvent, jsonObjectReader.nextOrNull(iLogger, new SentryLevel.Deserializer()));
                        continue block22;
                    }
                    case 3: {
                        date2 = jsonObjectReader.nextDateOrNull(iLogger);
                        if (date2 == null) continue block22;
                        SentryEvent.access$002(sentryEvent, date2);
                        continue block22;
                    }
                    case 2: {
                        SentryEvent.access$202(sentryEvent, jsonObjectReader.nextStringOrNull());
                        continue block22;
                    }
                    case 1: {
                        jsonObjectReader.beginObject();
                        jsonObjectReader.nextName();
                        SentryEvent.access$302(sentryEvent, new SentryValues<SentryThread>(jsonObjectReader.nextListOrNull(iLogger, new SentryThread.Deserializer())));
                        jsonObjectReader.endObject();
                        continue block22;
                    }
                    case 0: 
                }
                date2 = (List)jsonObjectReader.nextObjectOrNull();
                if (date2 == null) continue;
                SentryEvent.access$702(sentryEvent, (List)date2);
            }
            sentryEvent.setUnknown((Map<String, Object>)date);
            jsonObjectReader.endObject();
            return sentryEvent;
        }
    }

    public static final class JsonKeys {
        public static final String EXCEPTION = "exception";
        public static final String FINGERPRINT = "fingerprint";
        public static final String LEVEL = "level";
        public static final String LOGGER = "logger";
        public static final String MESSAGE = "message";
        public static final String MODULES = "modules";
        public static final String THREADS = "threads";
        public static final String TIMESTAMP = "timestamp";
        public static final String TRANSACTION = "transaction";
    }
}

