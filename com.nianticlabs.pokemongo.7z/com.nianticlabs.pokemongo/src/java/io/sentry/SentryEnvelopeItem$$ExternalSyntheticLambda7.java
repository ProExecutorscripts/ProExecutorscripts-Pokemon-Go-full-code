/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package io.sentry;

import io.sentry.SentryEnvelopeItem;
import java.util.concurrent.Callable;

public final class SentryEnvelopeItem$$ExternalSyntheticLambda7
implements Callable {
    public final SentryEnvelopeItem.CachedItem f$0;

    public /* synthetic */ SentryEnvelopeItem$$ExternalSyntheticLambda7(SentryEnvelopeItem.CachedItem cachedItem) {
        this.f$0 = cachedItem;
    }

    public final Object call() {
        return SentryEnvelopeItem.lambda$fromAttachment$16(this.f$0);
    }
}

