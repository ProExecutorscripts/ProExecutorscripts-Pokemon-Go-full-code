/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Locale
 */
package io.sentry;

import java.util.Locale;

public interface MeasurementUnit {
    public static final String NONE = "none";

    public String apiName();

    public String name();

    public static final class Custom
    implements MeasurementUnit {
        private final String name;

        public Custom(String string2) {
            this.name = string2;
        }

        @Override
        public String apiName() {
            return this.name().toLowerCase(Locale.ROOT);
        }

        @Override
        public String name() {
            return this.name;
        }
    }

    public static enum Duration implements MeasurementUnit
    {
        NANOSECOND,
        MICROSECOND,
        MILLISECOND,
        SECOND,
        MINUTE,
        HOUR,
        DAY,
        WEEK;


        @Override
        public String apiName() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }

    public static enum Fraction implements MeasurementUnit
    {
        RATIO,
        PERCENT;


        @Override
        public String apiName() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }

    public static enum Information implements MeasurementUnit
    {
        BIT,
        BYTE,
        KILOBYTE,
        KIBIBYTE,
        MEGABYTE,
        MEBIBYTE,
        GIGABYTE,
        GIBIBYTE,
        TERABYTE,
        TEBIBYTE,
        PETABYTE,
        PEBIBYTE,
        EXABYTE,
        EXBIBYTE;


        @Override
        public String apiName() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }
}

