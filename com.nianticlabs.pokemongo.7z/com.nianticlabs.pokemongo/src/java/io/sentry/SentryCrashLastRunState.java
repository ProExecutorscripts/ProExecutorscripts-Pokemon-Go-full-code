/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.sentry;

import java.io.File;

public final class SentryCrashLastRunState {
    private static final SentryCrashLastRunState INSTANCE = new SentryCrashLastRunState();
    private Boolean crashedLastRun;
    private final Object crashedLastRunLock = new Object();
    private boolean readCrashedLastRun;

    private SentryCrashLastRunState() {
    }

    public static SentryCrashLastRunState getInstance() {
        return INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Boolean isCrashedLastRun(String string2, boolean bl) {
        Object object;
        Object object2 = object = this.crashedLastRunLock;
        synchronized (object2) {
            boolean bl2;
            block14: {
                boolean bl3;
                block13: {
                    File file;
                    block12: {
                        if (this.readCrashedLastRun) {
                            return this.crashedLastRun;
                        }
                        if (string2 == null) {
                            return null;
                        }
                        bl3 = true;
                        this.readCrashedLastRun = true;
                        File file2 = new File(string2, "last_crash");
                        file = new File(string2, ".sentry-native/last_crash");
                        try {
                            bl2 = file2.exists();
                            if (!bl2) break block12;
                        }
                        catch (Throwable throwable) {}
                        file2.delete();
                    }
                    bl2 = file.exists();
                    if (!bl2) break block13;
                    bl2 = bl3;
                    if (!bl) break block14;
                    try {
                        file.delete();
                        bl2 = bl3;
                        break block14;
                    }
                    catch (Throwable throwable) {}
                }
                bl2 = false;
                break block14;
                finally {
                    bl2 = bl3;
                }
            }
            string2 = Boolean.valueOf((boolean)bl2);
            this.crashedLastRun = string2;
            return string2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void reset() {
        Object object;
        Object object2 = object = this.crashedLastRunLock;
        synchronized (object2) {
            this.readCrashedLastRun = false;
            this.crashedLastRun = null;
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setCrashedLastRun(boolean bl) {
        Object object;
        Object object2 = object = this.crashedLastRunLock;
        synchronized (object2) {
            if (!this.readCrashedLastRun) {
                this.crashedLastRun = bl;
                this.readCrashedLastRun = true;
            }
            return;
        }
    }
}

