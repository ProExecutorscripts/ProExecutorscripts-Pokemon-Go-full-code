/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Package
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Deque
 *  java.util.HashSet
 *  java.util.List
 */
package io.sentry;

import io.sentry.SentryStackTraceFactory;
import io.sentry.exception.ExceptionMechanismException;
import io.sentry.protocol.Mechanism;
import io.sentry.protocol.SentryException;
import io.sentry.protocol.SentryStackFrame;
import io.sentry.protocol.SentryStackTrace;
import io.sentry.protocol.SentryThread;
import io.sentry.util.Objects;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;

public final class SentryExceptionFactory {
    private final SentryStackTraceFactory sentryStackTraceFactory;

    public SentryExceptionFactory(SentryStackTraceFactory sentryStackTraceFactory) {
        this.sentryStackTraceFactory = Objects.requireNonNull(sentryStackTraceFactory, "The SentryStackTraceFactory is required.");
    }

    private SentryException getSentryException(Throwable object, Mechanism mechanism, Long l2, List<SentryStackFrame> object2, boolean bl) {
        Package package_ = object.getClass().getPackage();
        String string2 = object.getClass().getName();
        SentryException sentryException = new SentryException();
        String string3 = object.getMessage();
        object = string2;
        if (package_ != null) {
            object = string2.replace((CharSequence)(package_.getName() + "."), (CharSequence)"");
        }
        string2 = package_ != null ? package_.getName() : null;
        if (object2 != null && !object2.isEmpty()) {
            object2 = new SentryStackTrace((List<SentryStackFrame>)object2);
            if (bl) {
                ((SentryStackTrace)object2).setSnapshot(true);
            }
            sentryException.setStacktrace((SentryStackTrace)object2);
        }
        sentryException.setThreadId(l2);
        sentryException.setType((String)object);
        sentryException.setMechanism(mechanism);
        sentryException.setModule(string2);
        sentryException.setValue(string3);
        return sentryException;
    }

    private List<SentryException> getSentryExceptions(Deque<SentryException> deque) {
        return new ArrayList(deque);
    }

    Deque<SentryException> extractExceptionQueue(Throwable object) {
        ArrayDeque arrayDeque = new ArrayDeque();
        HashSet hashSet = new HashSet();
        while (object != null && hashSet.add(object)) {
            Throwable throwable;
            Mechanism mechanism;
            Object object2;
            boolean bl = object instanceof ExceptionMechanismException;
            boolean bl2 = false;
            if (bl) {
                object2 = (ExceptionMechanismException)((Object)object);
                mechanism = ((ExceptionMechanismException)((Object)object2)).getExceptionMechanism();
                throwable = ((ExceptionMechanismException)((Object)object2)).getThrowable();
                object = ((ExceptionMechanismException)((Object)object2)).getThread();
                bl = ((ExceptionMechanismException)((Object)object2)).isSnapshot();
            } else {
                object2 = Thread.currentThread();
                mechanism = null;
                bl = false;
                throwable = object;
                object = object2;
            }
            boolean bl3 = bl2;
            if (mechanism != null) {
                bl3 = bl2;
                if (Boolean.FALSE.equals((Object)mechanism.isHandled())) {
                    bl3 = true;
                }
            }
            object2 = this.sentryStackTraceFactory.getStackFrames(throwable.getStackTrace(), bl3);
            arrayDeque.addFirst((Object)this.getSentryException(throwable, mechanism, object.getId(), (List<SentryStackFrame>)object2, bl));
            object = throwable.getCause();
        }
        return arrayDeque;
    }

    public List<SentryException> getSentryExceptions(Throwable throwable) {
        return this.getSentryExceptions(this.extractExceptionQueue(throwable));
    }

    public List<SentryException> getSentryExceptionsFromThread(SentryThread sentryThread, Mechanism mechanism, Throwable throwable) {
        SentryStackTrace sentryStackTrace = sentryThread.getStacktrace();
        if (sentryStackTrace == null) {
            return new ArrayList(0);
        }
        ArrayList arrayList = new ArrayList(1);
        arrayList.add((Object)this.getSentryException(throwable, mechanism, sentryThread.getId(), sentryStackTrace.getFrames(), true));
        return arrayList;
    }
}

